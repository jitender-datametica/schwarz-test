ALTER MATERIALIZED VIEW dbp_msi_view_ek_kun.mv_crm_kunde_fact SET OPTIONS (enable_refresh = FALSE);
