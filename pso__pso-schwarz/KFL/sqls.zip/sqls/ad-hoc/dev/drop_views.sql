DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_bonuskauf_promotiontyp_agg ;
DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_gp_counts ;
DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_pmr_counts ;
DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_ts_scm_art_cluster_zu ;
DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_uebernahmequote_vz2 ;
DROP VIEW IF EXISTS dbp_msi_view_scm.mv_dt_werbeaenderung_zum_vortag ;