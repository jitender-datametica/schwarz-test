SELECT CURRENT_DATE() AS current_date;
CREATE TABLE `default.daip_test_cicd`(environment string, date_dt date, current_ts timestamp);