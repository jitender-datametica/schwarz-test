ALTER TABLE `dbp_ods.ods_bon_kopf`
ALTER COLUMN kundenkarte_fehler_txt
SET OPTIONS (
  description ='''Errorcode der Kundenkarte, den die Kasse vom CRM in der Schnittstelle erhält. Quelle ../loyaltyCardPositions/errorcode
            ERROR_ARVADO_INTERNAL (arvato state: true)   -> no CRM BBYs, only common BBYs
            ERROR_ARVADO_UNSUPPORTED(arvato state: true) -> no CRM BBYs, only common BBYs
            ERROR_CARD_NOT_ACTIVATED(arvato state: true) -> no CRM BBYs, only common BBYs
            ERROR_CARD_UNKNOWN(arvato state: true)       -> no CRM BBYs, only common BBYs
            ERROR_INTERNAL(arvato state: false)          -> common BBYs + CRM customer BBYs granted
            ERROR_INVALID_RESPONSE(arvato state: false)  -> common BBYs + CRM customer BBYs granted
            ERROR_IO(arvato state: false)                -> common BBYs + CRM customer BBYs granted
            NULL                                         -> all promotions are granted'''
);
ALTER TABLE `dbp_data.lagerbew_det`
ALTER COLUMN lagerbew_beleg_pos_mutter_id
SET OPTIONS (
  description ='''Verweis auf die umsortierte Lagerbewegungsbelegposition des übergeordneten Artikels (falls existent). Aus parent_id. 
Displays (a.k.a. Aussteller) und Komponenten/Artikel in einem Display werden im Lagerbewegungsbeleg als eigene Positionen/Artikel aufgeführt. Zur Zuordnung wurden in SAP neue Spalten hinzugefügt, welche die Belegzeilen (lagerbew_beleg_pos_id) neu sortieren und die neue Displaybelegzeile (line_id) bei den Komponenten angeben (aktuelle Spalte). In der veränderten Sortierung (line_id) stehen Komponenten am Ende des Belegs: erst kommen alle Artikel ohne Kopfartikel (lagerbew_beleg_pos_mutter_id = 0) und danach die Komponenten. In lagerbew_beleg_pos_mutter_id (aktuelle Spalte) steht dann der Wert der umsortierten Displaybelegzeile aus line_id. 
(Spaltenname wurde zur Konsistenz an bestehende Spalten anderer lagerbew Tabellen angepasst. Besser wäre: lagerbew_beleg_parent_pos_sort_id oder lagerbew_beleg_pos_sort_mutter_id)'''),
ALTER COLUMN line_id
SET OPTIONS (
  description ='''Umsortierte Lagerbewegungsbelegpositionen zur Verbindung von Displays und Displaykomponenten (entspricht der Form von Belegen vor der Display/Komponenten-Beziehung). Aus line_id. 
Displays (a.k.a. Aussteller) und Komponenten/Artikel in einem Display werden im Lagerbewegungsbeleg als eigene Positionen/Artikel aufgeführt. Um Komponenten und Displays einander zuzuordnen, wurden in SAP neue Spalten hinzugefügt, welche die Belegzeilen (lagerbew_beleg_pos_id) neu sortieren und die neue Displaybelegzeile (line_id) bei den Komponenten angeben (lagerbew_beleg_pos_mutter_id). In der neuen Sortierung (aktuelle Spalte) stehen Komponenten am Ende des Belegs: erst kommen Artikel ohne Kopfartikel (lagerbew_beleg_pos_mutter_id = 0), danach die Komponenten. In lagerbew_beleg_pos_mutter_id steht der Wert der umsortierten Displaybelegzeile aus line_id (aktuelle Spalte). 
(Spaltenname wurde zur Konsistenz an bestehende Spalten in anderen lagerbew Tabellen angepasst. Besserer Name wäre: lagerbew_beleg_pos_sort_id)''');

ALTER TABLE `dbp_data.lagerbew_det_delta`
ALTER COLUMN lagerbew_beleg_pos_mutter_id
SET OPTIONS (
  description ='''Verweis auf die umsortierte Lagerbewegungsbelegposition des übergeordneten Artikels (falls existent). Aus parent_id. 
Displays (a.k.a. Aussteller) und Komponenten/Artikel in einem Display werden im Lagerbewegungsbeleg als eigene Positionen/Artikel aufgeführt. Zur Zuordnung wurden in SAP neue Spalten hinzugefügt, welche die Belegzeilen (lagerbew_beleg_pos_id) neu sortieren und die neue Displaybelegzeile (line_id) bei den Komponenten angeben (aktuelle Spalte). In der veränderten Sortierung (line_id) stehen Komponenten am Ende des Belegs: erst kommen alle Artikel ohne Kopfartikel (lagerbew_beleg_pos_mutter_id = 0) und danach die Komponenten. In lagerbew_beleg_pos_mutter_id (aktuelle Spalte) steht dann der Wert der umsortierten Displaybelegzeile aus line_id. 
(Spaltenname wurde zur Konsistenz an bestehende Spalten anderer lagerbew Tabellen angepasst. Besser wäre: lagerbew_beleg_parent_pos_sort_id oder lagerbew_beleg_pos_sort_mutter_id)''');