DROP TABLE IF EXISTS dbp_data.l_gewerk;
DROP TABLE IF EXISTS dbp_data.ts_wbs_artikel_vz;
DROP TABLE IF EXISTS dbp_data.ts_wbs_ausliefergruppe;
DROP TABLE IF EXISTS dbp_msi_data.ts_wbs_refmarkt;
