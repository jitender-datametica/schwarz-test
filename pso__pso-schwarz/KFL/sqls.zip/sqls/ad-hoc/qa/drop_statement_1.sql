DROP TABLE IF EXISTS dbp_data.art_gp_nm_zu_per;
DROP TABLE IF EXISTS dbp_data.lagerplatz_ewm_per;
DROP TABLE IF EXISTS dbp_data.lagerplatz_ewm_tag;
DROP TABLE IF EXISTS dbp_data.tour_we;
DROP TABLE IF EXISTS dbp_data.art_wup_frplauf_per;
DROP TABLE IF EXISTS dbp_data.flw_rauchverlust;
