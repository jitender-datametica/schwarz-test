-- dbp_data
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_data.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_ods_archiv
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_ods_archiv.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_ods
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_ods.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_etl_process
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_etl_process.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_vis
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_vis.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_data
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_data.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_process
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_process.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view2
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view2.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_nfmd
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_nfmd.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_dialog
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_dialog.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_log
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_log.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view3
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view3.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_security
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_security.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_reb
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_reb.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_data_center
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_data_center.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_lin
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_lin.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_scm
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_scm.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_msi_view_ios
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_msi_view_ios.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_rfi
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_rfi.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;

-- dbp_etl_rfi
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_etl_rfi.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;