DROP TABLE IF EXISTS dbp_data.art_wup_status_per;
DROP TABLE IF EXISTS dbp_data.aktion_art_wup_zu;
DROP TABLE IF EXISTS dbp_data.art_gp_wup_zu_per;
DROP TABLE IF EXISTS dbp_data.art_wg_zu_per;

