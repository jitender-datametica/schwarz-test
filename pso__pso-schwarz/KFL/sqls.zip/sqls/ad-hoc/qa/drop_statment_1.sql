-- dbp_etl_rfi
BEGIN
  FOR record IN (
    SELECT CONCAT('DROP TABLE IF EXISTS `', table_catalog, '.', table_schema, '.', table_name, '`;') AS drop_statement
    FROM `uapc-q-edwh-prj-7pnqa.dbp_etl_rfi.INFORMATION_SCHEMA.TABLES`
    WHERE table_type='BASE TABLE'
  ) DO
    EXECUTE IMMEDIATE record.drop_statement;
  END FOR;
END;