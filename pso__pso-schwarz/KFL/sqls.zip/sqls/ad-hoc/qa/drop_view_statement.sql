DROP VIEW IF EXISTS dbp_msi_view_ais_kmo.tbl_mv_artbew_wo_sum ;
DROP VIEW IF EXISTS dbp_msi_view_ais_kmo.tbl_mv_artbew_wg_tag_sum;
DROP VIEW IF EXISTS dbp_msi_view_ais_int.tbl_mv_artbew_wg_tag_sum ;
