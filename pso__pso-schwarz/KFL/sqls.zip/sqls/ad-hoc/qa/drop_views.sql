DROP TABLE IF EXISTS dbp_data.ts_wbs_artikel_vz;
DROP MATERIALIZED VIEW IF EXISTS dbp_msi_view_ais_kmo.mv_best_ausg_menge_einh ;
DROP TABLE IF EXISTS dbp_data.l_gewerk;
DROP TABLE IF EXISTS dbp_data.ts_wbs_ausliefergruppe;
DROP TABLE IF EXISTS dbp_msi_data.ts_wbs_refmarkt;
