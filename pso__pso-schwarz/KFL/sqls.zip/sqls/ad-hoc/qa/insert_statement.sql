-- Table: DBP_MSI_DATA.KL_LISTUNG_KMO
insert into `dbp_msi_data.kl_listung_kmo` (kl_listung_kmo_id, mandant_id, listung_art, art_id, wup_id, sm_id_selected, ksm_id_selected, sm_id, ksm_id, umsatz_hr, absatz_hr, rohertrag_hr, erweiterung_fg, reduktion_fg, kjwo_update, list_kz, td_update, td_insert)
SELECT CAST(kl_listung_kmo_id AS NUMERIC) AS kl_listung_kmo_id, CAST(mandant_id AS INT64) AS mandant_id, listung_art, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(sm_id_selected AS INT64) AS sm_id_selected, ksm_id_selected, CAST(sm_id AS INT64) AS sm_id, ksm_id, CAST(umsatz_hr AS NUMERIC) AS umsatz_hr, CAST(absatz_hr AS NUMERIC) AS absatz_hr, CAST(rohertrag_hr AS NUMERIC) AS rohertrag_hr, CAST(erweiterung_fg AS INT64) AS erweiterung_fg, CAST(reduktion_fg AS INT64) AS reduktion_fg, CAST(kjwo_update AS INT64) AS kjwo_update, list_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_kl_listung_kmo`;

-- Table: DBP_MSI_DATA.NL_LISTUNG
insert into `dbp_msi_data.nl_listung` (nl_listung_id, mandant_id, listung_art, sm_id_selected, sm_id, gtin, ost_basis, ost_gross, sued_ost, sued_west, west, nord, kl_owg_id, wg_id, art_nielsen_bez, umsatz_artikel, durchschnitt_anz_maerkte, durchschnitt_preis, anz_wochen, anz_maerkte, umsatz_hr, absatz_hr, kjwo_update, td_update, td_insert)
SELECT CAST(nl_listung_id AS NUMERIC) AS nl_listung_id, CAST(mandant_id AS INT64) AS mandant_id, listung_art, CAST(sm_id_selected AS INT64) AS sm_id_selected, CAST(sm_id AS INT64) AS sm_id, gtin, ost_basis, ost_gross, sued_ost, sued_west, west, nord, CAST(kl_owg_id AS INT64) AS kl_owg_id, CAST(wg_id AS INT64) AS wg_id, art_nielsen_bez, CAST(umsatz_artikel AS NUMERIC) AS umsatz_artikel, CAST(durchschnitt_anz_maerkte AS INT64) AS durchschnitt_anz_maerkte, CAST(durchschnitt_preis AS NUMERIC) AS durchschnitt_preis, CAST(anz_wochen AS INT64) AS anz_wochen, CAST(anz_maerkte AS INT64) AS anz_maerkte, CAST(umsatz_hr AS NUMERIC) AS umsatz_hr, CAST(absatz_hr AS NUMERIC) AS absatz_hr, CAST(kjwo_update AS INT64) AS kjwo_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_nl_listung`;

-- Table: DBP_ODS.ODS_LETZTER_ABVERKAUF
insert into `dbp_ods.ods_letzter_abverkauf` (kl_art_id, mandant_id, wup_id, datzeit, dat, td_insert, td_update)
SELECT CAST(kl_art_id AS INT64) AS kl_art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, datzeit, dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_letzter_abverkauf`;

-- Table: DBP_DATA.KAMPAGNE_NACHRICHT
insert into `dbp_data.kampagne_nachricht` (mandant_id, nachricht_workflow_id, nachricht_vorlage_id, kommunikationskanal_id, kampagne_id, kampagne_kunde_id, nachricht_subvorlage_id_liste_txt, nachricht_subvorlage_name_liste_txt, email_domain_name, betriebssystem_name, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, nachricht_workflow_id, nachricht_vorlage_id, CAST(kommunikationskanal_id AS INT64) AS kommunikationskanal_id, kampagne_id, kampagne_kunde_id, nachricht_subvorlage_id_liste_txt, nachricht_subvorlage_name_liste_txt, email_domain_name, betriebssystem_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_kampagne_nachricht`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_KOPF
insert into `dbp_ods_archiv.ods_bon_kopf` (bon_id, bon_dat, kasse_typ_id, kundenkarte_typ_id, wup_id, mandant_id, bon_nr, kasse_nr, kassierer_nr, kunde_fg, bon_beginn, bon_ende, umsatz_mwst, umsatz_brutto, bon_booking, dat_booking, turnover_fg, wrg_id, reactivated_fg, personal_id, betrag_personal_rabatt, kpos_kasse_typ, wagen_nr, kundenkarte_id, td_insert, td_update, druecken_summentaste, schliessen_kassenschublade, fiskalisierung_fg)
SELECT bon_id, bon_dat, CAST(kasse_typ_id AS INT64) AS kasse_typ_id, CAST(kundenkarte_typ_id AS INT64) AS kundenkarte_typ_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(bon_nr AS INT64) AS bon_nr, CAST(kasse_nr AS INT64) AS kasse_nr, kassierer_nr, CAST(kunde_fg AS INT64) AS kunde_fg, CAST(bon_beginn AS DATETIME) AS bon_beginn, CAST(bon_ende AS DATETIME) AS bon_ende, CAST(umsatz_mwst AS NUMERIC) AS umsatz_mwst, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(bon_booking AS DATETIME) AS bon_booking, dat_booking, CAST(turnover_fg AS INT64) AS turnover_fg, wrg_id, CAST(reactivated_fg AS INT64) AS reactivated_fg, personal_id, CAST(betrag_personal_rabatt AS NUMERIC) AS betrag_personal_rabatt, kpos_kasse_typ, CAST(wagen_nr AS INT64) AS wagen_nr, kundenkarte_id, td_insert, td_update, CAST(druecken_summentaste AS DATETIME) AS druecken_summentaste, CAST(schliessen_kassenschublade AS DATETIME) AS schliessen_kassenschublade, CAST(fiskalisierung_fg AS INT64) AS fiskalisierung_fg
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_kopf`;

-- Table: DBP_DATA.TRANSPORTAUFTRAG_DET
insert into `dbp_data.transportauftrag_det` (mandant_id, transport_beleg_id, transport_beleg_pos_id, lagernummer_id, wup_id, nb_id, lagerort_id, art_id, dat_quittierung, dat_erstellung, von_lagerplatz_id, von_lagertyp_id, nach_lagerplatz_id, nach_lagertyp_id, system_id, menge_transportauftrag_kolli, dat_entnahme_quittierung, zeit_entnahme_quittierung, lager_einheit_id_von, lager_einheit_id_nach, zeit_quittierung, menge_ist_nach, menge_soll_von, quittierung_fg, lager_einheiten_typ, transport_vorgang_id, dat_verfall, bruttogew_kg, nachschubzeit_sekunden, platz_leer_fg, menge_soll_nach_altnv, min_nachschub_kdr, distanz, einl_ebene, sap_user, handling_unit_id_ext, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transport_beleg_id AS INT64) AS transport_beleg_id, CAST(transport_beleg_pos_id AS INT64) AS transport_beleg_pos_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagerort_id, CAST(art_id AS INT64) AS art_id, dat_quittierung, dat_erstellung, von_lagerplatz_id, von_lagertyp_id, nach_lagerplatz_id, nach_lagertyp_id, CAST(system_id AS INT64) AS system_id, CAST(menge_transportauftrag_kolli AS NUMERIC) AS menge_transportauftrag_kolli, dat_entnahme_quittierung, CAST(zeit_entnahme_quittierung AS INT64) AS zeit_entnahme_quittierung, lager_einheit_id_von, lager_einheit_id_nach, CAST(zeit_quittierung AS INT64) AS zeit_quittierung, CAST(menge_ist_nach AS NUMERIC) AS menge_ist_nach, CAST(menge_soll_von AS NUMERIC) AS menge_soll_von, CAST(quittierung_fg AS INT64) AS quittierung_fg, lager_einheiten_typ, transport_vorgang_id, dat_verfall, CAST(bruttogew_kg AS NUMERIC) AS bruttogew_kg, CAST(nachschubzeit_sekunden AS INT64) AS nachschubzeit_sekunden, CAST(platz_leer_fg AS INT64) AS platz_leer_fg, CAST(menge_soll_nach_altnv AS NUMERIC) AS menge_soll_nach_altnv, CAST(min_nachschub_kdr AS INT64) AS min_nachschub_kdr, CAST(distanz AS NUMERIC) AS distanz, CAST(einl_ebene AS INT64) AS einl_ebene, sap_user, handling_unit_id_ext, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportauftrag_det`;

-- Table: DBP_DATA.WBS_WERBEAENDERUNGEN
insert into `dbp_data.wbs_werbeaenderungen` (mandant_id, aktion_id, offer_id, wup_id, art_id, dat_beladung, mandant_id_vz, wup_id_vz, nb_id, nb_id_vz, dat_ab, dat_bis, kjwo, ausliefergruppe_id, wbs_phase_id, gp_id, gk_fg, fachboden_fg, titel_fg, rueckseite_fg, erste_seite_fg, kasse_fg, tv_fg, neuer_artikel_fg, preis_normal, preis_aktion, anz_tage_werbung, tage_bis_bestellung_lieferant, tage_bis_deadline_print, tage_bis_initiale_belieferung, anz_werbeaenderungen_aufg, anz_werbeaenderungen_nach_print, werbeaenderung_angebotspreisreduktion_fg, werbeaenderung_angebotspreiserhoehung_fg, werbeaenderung_normalpreisreduktion_fg, werbeaenderung_normalpreiserhoehung_fg, werbeaenderung_artikelneuanlage_fg, werbeaenderung_artikelentfernung_fg, werbeaenderung_marktanzahlerhoehung_fg, werbeaenderung_marktanzahlreduktion_fg, werbeaenderung_abbildungsaenderung_fg, werbeaenderung_radio_tv_billboard_fg, werbeaenderung_kolliinhaltsaenderung_fg, werbeaenderung_werbethema_fg, werbeaenderung_sonstiges_fg, werbeaenderung_bonuskauf_promotionstyp_fg, mindestplatzierung_fg, best_generiert_fg, hohe_mengenaenderung_fg, geringe_mengenaenderung_fg, gesteuerte_prognose_fg, menge_mindestplatzierung_bme, fixmenge_fg, fixmenge_bme, mindestmenge_fg, mindestmenge_bme, maximalmenge_fg, maximalmenge_bme, bestand_wup_bme, offene_bestellungen_bme, order_forecast_bme, projizierter_bestand_vor_werbung_bme, durchschnittlicher_abverkauf_bme, prognose_werbezeitraum_bme, anteil_wup_artikel_perc, bedarf_bme, bedarf_ame, bedarf_pal, zielbestand_bme, bestellmenge_ohne_bestand_ame, bestellmenge_ohne_bestand_pal, bestellmenge_mit_bestand_ame, bestellmenge_mit_bestand_pal, aktion_reihenfolge_zukunft_nr, preis_nachlass_perc, kollifaktor, multi_offer_id_fg, werbeaenderung_menge_vorlauf, fixmenge_wfl_fg, fixmenge_wfl_bme, fixmenge_wfl_aenderung_fg, fixmenge_wfl_vortag_bme, preis_normal_vorlauf, preis_aktion_vorlauf, top_gk_fg, bestand_vz, blockierter_bestand_vz, final_verfuegbarer_bestand_vz, bestellung_lieferant_menge, bestellung_lieferant_fg, bestellung_lieferant_mit_bestand_fg, stille_aktion_fg, prognose_ungesteuert, menge_zuletzt_dc_promo, pmr_werbethema_id, referenzmarkt_fallback_fg, rabattaenderung_fg, abbildung_vortag_id, werbethema_vortag_bez, art_id_mutter, wrg_id, werbelistung_fg, werbelistung_aenderung_fg, aktion_reihenfolge_aenderung_fg, vortag_aktion_reihenfolge_zukunft_nr, zeitpunkt_bestellung_lieferant_prognose_bedarf_bme, wup_id_ref, nb_id_ref, art_id_ref, faktor_ref, wfl_menge_geprueft_fg, wfl_menge_geprueft_reset_fg, wfl_nutzer_kommentar_txt, fixmenge_ek_aenderung_fg, fixmenge_ek_vortag_bme, anz_angebote_zeitraum, anz_angebote_zeitraum_aenderung_fg, nur_online_fg, kundenkarte_personalisiert_fg, werbeaenderung_kundenkarte_personalisiert_fg, stille_aktion_mit_menge_fg, min_platzierung_markt_cluster_id, estimation_id, estimation_id_aenderung_fg, utp_relevant_fg, utp_relevant_aenderung_fg, utp_lieferant_bestaetigt_fg, dat_gueltig_von_konditionsart_zar5, dat_gueltig_bis_konditionsart_zar5, menge_kolliinhalt_vortag_bme, init_lief_modus_kz, gp_id_aenderung_fg, konditionsart_zar5_gueltigkeit_aenderung_fg, posten_kz_sap, posten_kz_sap_aenderung_fg, bonuskauf_promotionstyp_liste_txt, saison_id, saison_id_aenderung_fg, best_menge_einh_id, best_menge_einh_vortag_id, best_menge_einh_id_aenderung_fg, bedarf_estimation_id_2_bme, bestellmenge_estimation_id_2_ohne_bestand_ame, bestellmenge_estimation_id_2_mit_bestand_ame, adjustment_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(offer_id AS INT64) AS offer_id, CAST(wup_id AS INT64) AS wup_id, CAST(art_id AS INT64) AS art_id, dat_beladung, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(nb_id AS INT64) AS nb_id, CAST(nb_id_vz AS INT64) AS nb_id_vz, dat_ab, dat_bis, CAST(kjwo AS INT64) AS kjwo, ausliefergruppe_id, CAST(wbs_phase_id AS INT64) AS wbs_phase_id, CAST(gp_id AS INT64) AS gp_id, CAST(gk_fg AS INT64) AS gk_fg, CAST(fachboden_fg AS INT64) AS fachboden_fg, CAST(titel_fg AS INT64) AS titel_fg, CAST(rueckseite_fg AS INT64) AS rueckseite_fg, CAST(erste_seite_fg AS INT64) AS erste_seite_fg, CAST(kasse_fg AS INT64) AS kasse_fg, CAST(tv_fg AS INT64) AS tv_fg, CAST(neuer_artikel_fg AS INT64) AS neuer_artikel_fg, CAST(preis_normal AS NUMERIC) AS preis_normal, CAST(preis_aktion AS NUMERIC) AS preis_aktion, CAST(anz_tage_werbung AS INT64) AS anz_tage_werbung, CAST(tage_bis_bestellung_lieferant AS INT64) AS tage_bis_bestellung_lieferant, CAST(tage_bis_deadline_print AS INT64) AS tage_bis_deadline_print, CAST(tage_bis_initiale_belieferung AS INT64) AS tage_bis_initiale_belieferung, CAST(anz_werbeaenderungen_aufg AS INT64) AS anz_werbeaenderungen_aufg, CAST(anz_werbeaenderungen_nach_print AS INT64) AS anz_werbeaenderungen_nach_print, CAST(werbeaenderung_angebotspreisreduktion_fg AS INT64) AS werbeaenderung_angebotspreisreduktion_fg, CAST(werbeaenderung_angebotspreiserhoehung_fg AS INT64) AS werbeaenderung_angebotspreiserhoehung_fg, CAST(werbeaenderung_normalpreisreduktion_fg AS INT64) AS werbeaenderung_normalpreisreduktion_fg, CAST(werbeaenderung_normalpreiserhoehung_fg AS INT64) AS werbeaenderung_normalpreiserhoehung_fg, CAST(werbeaenderung_artikelneuanlage_fg AS INT64) AS werbeaenderung_artikelneuanlage_fg, CAST(werbeaenderung_artikelentfernung_fg AS INT64) AS werbeaenderung_artikelentfernung_fg, CAST(werbeaenderung_marktanzahlerhoehung_fg AS INT64) AS werbeaenderung_marktanzahlerhoehung_fg, CAST(werbeaenderung_marktanzahlreduktion_fg AS INT64) AS werbeaenderung_marktanzahlreduktion_fg, CAST(werbeaenderung_abbildungsaenderung_fg AS INT64) AS werbeaenderung_abbildungsaenderung_fg, CAST(werbeaenderung_radio_tv_billboard_fg AS INT64) AS werbeaenderung_radio_tv_billboard_fg, CAST(werbeaenderung_kolliinhaltsaenderung_fg AS INT64) AS werbeaenderung_kolliinhaltsaenderung_fg, CAST(werbeaenderung_werbethema_fg AS INT64) AS werbeaenderung_werbethema_fg, CAST(werbeaenderung_sonstiges_fg AS INT64) AS werbeaenderung_sonstiges_fg, CAST(werbeaenderung_bonuskauf_promotionstyp_fg AS INT64) AS werbeaenderung_bonuskauf_promotionstyp_fg, CAST(mindestplatzierung_fg AS INT64) AS mindestplatzierung_fg, CAST(best_generiert_fg AS INT64) AS best_generiert_fg, CAST(hohe_mengenaenderung_fg AS INT64) AS hohe_mengenaenderung_fg, CAST(geringe_mengenaenderung_fg AS INT64) AS geringe_mengenaenderung_fg, CAST(gesteuerte_prognose_fg AS INT64) AS gesteuerte_prognose_fg, CAST(menge_mindestplatzierung_bme AS NUMERIC) AS menge_mindestplatzierung_bme, CAST(fixmenge_fg AS INT64) AS fixmenge_fg, CAST(fixmenge_bme AS NUMERIC) AS fixmenge_bme, CAST(mindestmenge_fg AS INT64) AS mindestmenge_fg, CAST(mindestmenge_bme AS NUMERIC) AS mindestmenge_bme, CAST(maximalmenge_fg AS INT64) AS maximalmenge_fg, CAST(maximalmenge_bme AS NUMERIC) AS maximalmenge_bme, CAST(bestand_wup_bme AS NUMERIC) AS bestand_wup_bme, CAST(offene_bestellungen_bme AS NUMERIC) AS offene_bestellungen_bme, CAST(order_forecast_bme AS NUMERIC) AS order_forecast_bme, CAST(projizierter_bestand_vor_werbung_bme AS NUMERIC) AS projizierter_bestand_vor_werbung_bme, CAST(durchschnittlicher_abverkauf_bme AS NUMERIC) AS durchschnittlicher_abverkauf_bme, CAST(prognose_werbezeitraum_bme AS NUMERIC) AS prognose_werbezeitraum_bme, CAST(anteil_wup_artikel_perc AS NUMERIC) AS anteil_wup_artikel_perc, CAST(bedarf_bme AS NUMERIC) AS bedarf_bme, CAST(bedarf_ame AS NUMERIC) AS bedarf_ame, CAST(bedarf_pal AS NUMERIC) AS bedarf_pal, CAST(zielbestand_bme AS NUMERIC) AS zielbestand_bme, CAST(bestellmenge_ohne_bestand_ame AS NUMERIC) AS bestellmenge_ohne_bestand_ame, CAST(bestellmenge_ohne_bestand_pal AS NUMERIC) AS bestellmenge_ohne_bestand_pal, CAST(bestellmenge_mit_bestand_ame AS NUMERIC) AS bestellmenge_mit_bestand_ame, CAST(bestellmenge_mit_bestand_pal AS NUMERIC) AS bestellmenge_mit_bestand_pal, CAST(aktion_reihenfolge_zukunft_nr AS INT64) AS aktion_reihenfolge_zukunft_nr, CAST(preis_nachlass_perc AS NUMERIC) AS preis_nachlass_perc, CAST(kollifaktor AS NUMERIC) AS kollifaktor, CAST(multi_offer_id_fg AS INT64) AS multi_offer_id_fg, CAST(werbeaenderung_menge_vorlauf AS NUMERIC) AS werbeaenderung_menge_vorlauf, CAST(fixmenge_wfl_fg AS INT64) AS fixmenge_wfl_fg, CAST(fixmenge_wfl_bme AS NUMERIC) AS fixmenge_wfl_bme, CAST(fixmenge_wfl_aenderung_fg AS INT64) AS fixmenge_wfl_aenderung_fg, CAST(fixmenge_wfl_vortag_bme AS NUMERIC) AS fixmenge_wfl_vortag_bme, CAST(preis_normal_vorlauf AS NUMERIC) AS preis_normal_vorlauf, CAST(preis_aktion_vorlauf AS NUMERIC) AS preis_aktion_vorlauf, CAST(top_gk_fg AS INT64) AS top_gk_fg, CAST(bestand_vz AS NUMERIC) AS bestand_vz, CAST(blockierter_bestand_vz AS NUMERIC) AS blockierter_bestand_vz, CAST(final_verfuegbarer_bestand_vz AS NUMERIC) AS final_verfuegbarer_bestand_vz, CAST(bestellung_lieferant_menge AS NUMERIC) AS bestellung_lieferant_menge, CAST(bestellung_lieferant_fg AS INT64) AS bestellung_lieferant_fg, CAST(bestellung_lieferant_mit_bestand_fg AS INT64) AS bestellung_lieferant_mit_bestand_fg, CAST(stille_aktion_fg AS INT64) AS stille_aktion_fg, CAST(prognose_ungesteuert AS NUMERIC) AS prognose_ungesteuert, CAST(menge_zuletzt_dc_promo AS NUMERIC) AS menge_zuletzt_dc_promo, pmr_werbethema_id, CAST(referenzmarkt_fallback_fg AS INT64) AS referenzmarkt_fallback_fg, CAST(rabattaenderung_fg AS INT64) AS rabattaenderung_fg, abbildung_vortag_id, werbethema_vortag_bez, CAST(art_id_mutter AS INT64) AS art_id_mutter, wrg_id, CAST(werbelistung_fg AS INT64) AS werbelistung_fg, CAST(werbelistung_aenderung_fg AS INT64) AS werbelistung_aenderung_fg, CAST(aktion_reihenfolge_aenderung_fg AS INT64) AS aktion_reihenfolge_aenderung_fg, CAST(vortag_aktion_reihenfolge_zukunft_nr AS INT64) AS vortag_aktion_reihenfolge_zukunft_nr, CAST(zeitpunkt_bestellung_lieferant_prognose_bedarf_bme AS NUMERIC) AS zeitpunkt_bestellung_lieferant_prognose_bedarf_bme, CAST(wup_id_ref AS INT64) AS wup_id_ref, CAST(nb_id_ref AS INT64) AS nb_id_ref, CAST(art_id_ref AS INT64) AS art_id_ref, CAST(faktor_ref AS NUMERIC) AS faktor_ref, CAST(wfl_menge_geprueft_fg AS INT64) AS wfl_menge_geprueft_fg, CAST(wfl_menge_geprueft_reset_fg AS INT64) AS wfl_menge_geprueft_reset_fg, wfl_nutzer_kommentar_txt, CAST(fixmenge_ek_aenderung_fg AS INT64) AS fixmenge_ek_aenderung_fg, CAST(fixmenge_ek_vortag_bme AS NUMERIC) AS fixmenge_ek_vortag_bme, CAST(anz_angebote_zeitraum AS INT64) AS anz_angebote_zeitraum, CAST(anz_angebote_zeitraum_aenderung_fg AS INT64) AS anz_angebote_zeitraum_aenderung_fg, CAST(nur_online_fg AS INT64) AS nur_online_fg, CAST(kundenkarte_personalisiert_fg AS INT64) AS kundenkarte_personalisiert_fg, CAST(werbeaenderung_kundenkarte_personalisiert_fg AS INT64) AS werbeaenderung_kundenkarte_personalisiert_fg, CAST(stille_aktion_mit_menge_fg AS INT64) AS stille_aktion_mit_menge_fg, CAST(min_platzierung_markt_cluster_id AS INT64) AS min_platzierung_markt_cluster_id, CAST(estimation_id AS INT64) AS estimation_id, CAST(estimation_id_aenderung_fg AS INT64) AS estimation_id_aenderung_fg, CAST(utp_relevant_fg AS INT64) AS utp_relevant_fg, CAST(utp_relevant_aenderung_fg AS INT64) AS utp_relevant_aenderung_fg, CAST(utp_lieferant_bestaetigt_fg AS INT64) AS utp_lieferant_bestaetigt_fg, dat_gueltig_von_konditionsart_zar5, dat_gueltig_bis_konditionsart_zar5, CAST(menge_kolliinhalt_vortag_bme AS NUMERIC) AS menge_kolliinhalt_vortag_bme, init_lief_modus_kz, CAST(gp_id_aenderung_fg AS INT64) AS gp_id_aenderung_fg, CAST(konditionsart_zar5_gueltigkeit_aenderung_fg AS INT64) AS konditionsart_zar5_gueltigkeit_aenderung_fg, posten_kz_sap, CAST(posten_kz_sap_aenderung_fg AS INT64) AS posten_kz_sap_aenderung_fg, bonuskauf_promotionstyp_liste_txt, saison_id, CAST(saison_id_aenderung_fg AS INT64) AS saison_id_aenderung_fg, best_menge_einh_id, best_menge_einh_vortag_id, CAST(best_menge_einh_id_aenderung_fg AS INT64) AS best_menge_einh_id_aenderung_fg, CAST(bedarf_estimation_id_2_bme AS NUMERIC) AS bedarf_estimation_id_2_bme, CAST(bestellmenge_estimation_id_2_ohne_bestand_ame AS NUMERIC) AS bestellmenge_estimation_id_2_ohne_bestand_ame, CAST(bestellmenge_estimation_id_2_mit_bestand_ame AS NUMERIC) AS bestellmenge_estimation_id_2_mit_bestand_ame, CAST(adjustment_id AS INT64) AS adjustment_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_werbeaenderungen`;

-- Table: DBP_DATA.AUSNAHME
insert into `dbp_data.ausnahme` (ausnahme_id, mandant_id, art_id, wup_id, nb_id, dat_plan, pruef_id, z_arbeitsgebiet_id, gp_id, ausnahme_mutter_id, ausnahme_menge_bme, ausnahme_menge_kolli, td_update, td_insert)
SELECT ausnahme_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_plan, CAST(pruef_id AS INT64) AS pruef_id, CAST(z_arbeitsgebiet_id AS INT64) AS z_arbeitsgebiet_id, CAST(gp_id AS INT64) AS gp_id, ausnahme_mutter_id, CAST(ausnahme_menge_bme AS NUMERIC) AS ausnahme_menge_bme, CAST(ausnahme_menge_kolli AS NUMERIC) AS ausnahme_menge_kolli, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ausnahme`;

-- Table: DBP_DATA.LAGERBEW_DET_WWC_WOCHE
insert into `dbp_data.lagerbew_det_wwc_woche` (art_id, mandant_id, wup_id, nb_id, lager_bewart_id, gp_id, kjwo_kl, exvkw_gleich_vkwrt_fg, betrag_lagerbew, betrag_verkauf, menge_lagerbew_bme, betrag_vk_netto, betrag_verkauf_ist, betrag_exbwr, betrag_verkauf_ist_netto, wrg_id, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lager_bewart_id, CAST(gp_id AS INT64) AS gp_id, CAST(kjwo_kl AS INT64) AS kjwo_kl, CAST(exvkw_gleich_vkwrt_fg AS INT64) AS exvkw_gleich_vkwrt_fg, CAST(betrag_lagerbew AS NUMERIC) AS betrag_lagerbew, CAST(betrag_verkauf AS NUMERIC) AS betrag_verkauf, CAST(menge_lagerbew_bme AS NUMERIC) AS menge_lagerbew_bme, CAST(betrag_vk_netto AS NUMERIC) AS betrag_vk_netto, CAST(betrag_verkauf_ist AS NUMERIC) AS betrag_verkauf_ist, CAST(betrag_exbwr AS NUMERIC) AS betrag_exbwr, CAST(betrag_verkauf_ist_netto AS NUMERIC) AS betrag_verkauf_ist_netto, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_lagerbew_det_wwc_woche`;

-- Table: DBP_DATA.BESCH_FAKTURA_KONDIT
insert into `dbp_data.besch_faktura_kondit` (mandant_id, faktura_beleg_id, faktura_beleg_pos_id, beleg_kondition_id, kondition_schl_id, wrg_id, kondition_wert, kappl, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(faktura_beleg_id AS INT64) AS faktura_beleg_id, CAST(faktura_beleg_pos_id AS INT64) AS faktura_beleg_pos_id, CAST(beleg_kondition_id AS INT64) AS beleg_kondition_id, kondition_schl_id, wrg_id, CAST(kondition_wert AS NUMERIC) AS kondition_wert, kappl, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_faktura_kondit`;

-- Table: DBP_MSI_DATA.NL_LISTUNG_KMO
insert into `dbp_msi_data.nl_listung_kmo` (nl_listung_kmo_id, mandant_id, listung_art, sm_id_selected, ksm_id_selected, sm_id, ksm_id, gtin, ost_basis, ost_gross, sued_ost, sued_west, west, nord, kl_owg_id, wg_id, art_nielsen_bez, umsatz_artikel, durchschnitt_anz_maerkte, durchschnitt_preis, anz_wochen, anz_maerkte, umsatz_hr, absatz_hr, kjwo_update, td_update, td_insert)
SELECT CAST(nl_listung_kmo_id AS NUMERIC) AS nl_listung_kmo_id, CAST(mandant_id AS INT64) AS mandant_id, listung_art, CAST(sm_id_selected AS INT64) AS sm_id_selected, ksm_id_selected, CAST(sm_id AS INT64) AS sm_id, ksm_id, gtin, ost_basis, ost_gross, sued_ost, sued_west, west, nord, CAST(kl_owg_id AS INT64) AS kl_owg_id, CAST(wg_id AS INT64) AS wg_id, art_nielsen_bez, CAST(umsatz_artikel AS NUMERIC) AS umsatz_artikel, CAST(durchschnitt_anz_maerkte AS INT64) AS durchschnitt_anz_maerkte, CAST(durchschnitt_preis AS NUMERIC) AS durchschnitt_preis, CAST(anz_wochen AS INT64) AS anz_wochen, CAST(anz_maerkte AS INT64) AS anz_maerkte, CAST(umsatz_hr AS NUMERIC) AS umsatz_hr, CAST(absatz_hr AS NUMERIC) AS absatz_hr, CAST(kjwo_update AS INT64) AS kjwo_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_nl_listung_kmo`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_ZAHLUNG
insert into `dbp_ods_archiv.ods_bon_zahlung` (bon_id, bon_zeile, mandant_id, wup_id, bon_dat, zahlung_typ_id, start_bon_zeile, betrag_zahlung, wrg_id, kpos_zahlung_typ_id, bon_zeile_cashback_referenz, kartennummer_maskiert, barcode_leergut, td_update, td_insert)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, bon_dat, CAST(zahlung_typ_id AS INT64) AS zahlung_typ_id, start_bon_zeile, CAST(betrag_zahlung AS NUMERIC) AS betrag_zahlung, wrg_id, kpos_zahlung_typ_id, CAST(bon_zeile_cashback_referenz AS INT64) AS bon_zeile_cashback_referenz, kartennummer_maskiert, barcode_leergut, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_zahlung`;

-- Table: DBP_DATA.LAGERBESTAND_LVS
insert into `dbp_data.lagerbestand_lvs` (lagerquant_id, dat, mandant_id, lagerplatz_id, lagernummer_id, lagertyp_id, wup_id, nb_id, art_id, best_qualifikation_id, lagerort_id, menge_lgbest_lvs_frei_bme, sond_best_id, menge_lgbest_lvs_ges_bme, menge_lgbest_lvs_off_trans_bme, menge_lgbest_lvs_kolli, menge_lgbest_lvs_palette, dat_haltbarkeit, lief_beleg_id, lief_beleg_pos_id, betrag_lgbest_lvs, menge_lgbest_lvs_auslager, system_id, wrg_id, vk_netto_lgbest_lvs, lager_einheiten_typ, gewicht_gesamt, dat_letzte_bewegung, volumen_kolli, volumen_palette, kj_lief_beleg, td_insert, td_update)
SELECT lagerquant_id, dat, CAST(mandant_id AS INT64) AS mandant_id, lagerplatz_id, lagernummer_id, lagertyp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, best_qualifikation_id, lagerort_id, CAST(menge_lgbest_lvs_frei_bme AS NUMERIC) AS menge_lgbest_lvs_frei_bme, sond_best_id, CAST(menge_lgbest_lvs_ges_bme AS NUMERIC) AS menge_lgbest_lvs_ges_bme, CAST(menge_lgbest_lvs_off_trans_bme AS NUMERIC) AS menge_lgbest_lvs_off_trans_bme, CAST(menge_lgbest_lvs_kolli AS NUMERIC) AS menge_lgbest_lvs_kolli, CAST(menge_lgbest_lvs_palette AS NUMERIC) AS menge_lgbest_lvs_palette, dat_haltbarkeit, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, CAST(betrag_lgbest_lvs AS NUMERIC) AS betrag_lgbest_lvs, CAST(menge_lgbest_lvs_auslager AS NUMERIC) AS menge_lgbest_lvs_auslager, CAST(system_id AS INT64) AS system_id, wrg_id, CAST(vk_netto_lgbest_lvs AS NUMERIC) AS vk_netto_lgbest_lvs, lager_einheiten_typ, CAST(gewicht_gesamt AS NUMERIC) AS gewicht_gesamt, dat_letzte_bewegung, CAST(volumen_kolli AS NUMERIC) AS volumen_kolli, CAST(volumen_palette AS NUMERIC) AS volumen_palette, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_lagerbestand_lvs`;

-- Table: DBP_DATA.ART_BESTAND_VW_SUM
insert into `dbp_data.art_bestand_vw_sum` (mandant_id, vw_id, bezugsweg_id, lagerbestand_fg, nb_id, art_id, wup_id, dat, gp_id, relevant_fg, wrg_id, menge_lgbest_erp_frei_bme, menge_lgbest_erp_qual_bme, menge_lgbest_erp_gesamt_bme, betrag_vk_netto_frei_bme, betrag_vk_netto_qual_bme, betrag_vk_netto_gesamt_bme, menge_abgang_bme, betrag_vk_netto_abgang, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vw_id AS INT64) AS vw_id, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, CAST(lagerbestand_fg AS INT64) AS lagerbestand_fg, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, dat, CAST(gp_id AS INT64) AS gp_id, CAST(relevant_fg AS INT64) AS relevant_fg, wrg_id, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, CAST(menge_lgbest_erp_gesamt_bme AS NUMERIC) AS menge_lgbest_erp_gesamt_bme, CAST(betrag_vk_netto_frei_bme AS NUMERIC) AS betrag_vk_netto_frei_bme, CAST(betrag_vk_netto_qual_bme AS NUMERIC) AS betrag_vk_netto_qual_bme, CAST(betrag_vk_netto_gesamt_bme AS NUMERIC) AS betrag_vk_netto_gesamt_bme, CAST(menge_abgang_bme AS NUMERIC) AS menge_abgang_bme, CAST(betrag_vk_netto_abgang AS NUMERIC) AS betrag_vk_netto_abgang, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_art_bestand_vw_sum`;

-- Table: DBP_DATA.FUR_PROGNOSE_WO_SUM
insert into `dbp_data.fur_prognose_wo_sum` (mandant_id, wup_id, nb_id, art_id, kjwo_kl, menge_prognose, menge_prognose_bef, menge_prognose_max, menge_af, menge_sa, diff_menge_af_prognose, sum_progn_groesser, sum_menge_af_groesser, menge_af_mittel_3wo, progn_groesser_wo_fg, menge_af_groesser_wo_fg, progn_grosser_wo0_fg, progn_groesser_wo1_fg, progn_groesser_wo2_fg, menge_af_groesser_wo0_fg, menge_af_groesser_wo1_fg, menge_af_groesser_wo2_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(kjwo_kl AS INT64) AS kjwo_kl, CAST(menge_prognose AS NUMERIC) AS menge_prognose, CAST(menge_prognose_bef AS NUMERIC) AS menge_prognose_bef, CAST(menge_prognose_max AS NUMERIC) AS menge_prognose_max, CAST(menge_af AS NUMERIC) AS menge_af, CAST(menge_sa AS NUMERIC) AS menge_sa, CAST(diff_menge_af_prognose AS NUMERIC) AS diff_menge_af_prognose, CAST(sum_progn_groesser AS INT64) AS sum_progn_groesser, CAST(sum_menge_af_groesser AS INT64) AS sum_menge_af_groesser, CAST(menge_af_mittel_3wo AS NUMERIC) AS menge_af_mittel_3wo, CAST(progn_groesser_wo_fg AS INT64) AS progn_groesser_wo_fg, CAST(menge_af_groesser_wo_fg AS INT64) AS menge_af_groesser_wo_fg, CAST(progn_grosser_wo0_fg AS INT64) AS progn_grosser_wo0_fg, CAST(progn_groesser_wo1_fg AS INT64) AS progn_groesser_wo1_fg, CAST(progn_groesser_wo2_fg AS INT64) AS progn_groesser_wo2_fg, CAST(menge_af_groesser_wo0_fg AS INT64) AS menge_af_groesser_wo0_fg, CAST(menge_af_groesser_wo1_fg AS INT64) AS menge_af_groesser_wo1_fg, CAST(menge_af_groesser_wo2_fg AS INT64) AS menge_af_groesser_wo2_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fur_prognose_wo_sum`;

-- Table: DBP_DATA.ART_WUP_AUTODISPO_FLW_TAG
insert into `dbp_data.art_wup_autodispo_flw_tag` (mandant_id, kunde_id, wup_id, nb_id_kunde, nb_id_lieferant, art_id, dat, menge_einh_id, we_bearbeitungszeit, planlieferzeit, kdis, verkaufslistung_fg, sa_af_fg, udf_prognose_menge_gesteuert, udf_prognose_menge_ungesteuert, fur_prognose_menge_ungesteuert, fur_prognose_menge_gesteuert, fur_prognose_menge_max, menge_abverkauf, ret_bestand, fur_bestand, menge_we_offen, menge_bv, menge_ofc, nullbestand_fg, menge_preisabschriften, menge_totalabschriften, kollifaktor, egalisierungsfaktor, servicelevel, optik, menge_we, nullbestand_exc_fg, menge_we_geplant, display_art_id, komponentenmenge, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id_kunde AS INT64) AS nb_id_kunde, CAST(nb_id_lieferant AS INT64) AS nb_id_lieferant, CAST(art_id AS INT64) AS art_id, dat, menge_einh_id, CAST(we_bearbeitungszeit AS INT64) AS we_bearbeitungszeit, CAST(planlieferzeit AS INT64) AS planlieferzeit, CAST(kdis AS INT64) AS kdis, CAST(verkaufslistung_fg AS INT64) AS verkaufslistung_fg, CAST(sa_af_fg AS INT64) AS sa_af_fg, CAST(udf_prognose_menge_gesteuert AS NUMERIC) AS udf_prognose_menge_gesteuert, CAST(udf_prognose_menge_ungesteuert AS NUMERIC) AS udf_prognose_menge_ungesteuert, CAST(fur_prognose_menge_ungesteuert AS NUMERIC) AS fur_prognose_menge_ungesteuert, CAST(fur_prognose_menge_gesteuert AS NUMERIC) AS fur_prognose_menge_gesteuert, CAST(fur_prognose_menge_max AS NUMERIC) AS fur_prognose_menge_max, CAST(menge_abverkauf AS NUMERIC) AS menge_abverkauf, CAST(ret_bestand AS NUMERIC) AS ret_bestand, CAST(fur_bestand AS NUMERIC) AS fur_bestand, CAST(menge_we_offen AS NUMERIC) AS menge_we_offen, CAST(menge_bv AS NUMERIC) AS menge_bv, CAST(menge_ofc AS NUMERIC) AS menge_ofc, CAST(nullbestand_fg AS INT64) AS nullbestand_fg, CAST(menge_preisabschriften AS NUMERIC) AS menge_preisabschriften, CAST(menge_totalabschriften AS NUMERIC) AS menge_totalabschriften, CAST(kollifaktor AS NUMERIC) AS kollifaktor, CAST(egalisierungsfaktor AS NUMERIC) AS egalisierungsfaktor, CAST(servicelevel AS NUMERIC) AS servicelevel, CAST(optik AS NUMERIC) AS optik, CAST(menge_we AS NUMERIC) AS menge_we, CAST(nullbestand_exc_fg AS INT64) AS nullbestand_exc_fg, CAST(menge_we_geplant AS NUMERIC) AS menge_we_geplant, CAST(display_art_id AS INT64) AS display_art_id, CAST(komponentenmenge AS NUMERIC) AS komponentenmenge, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_art_wup_autodispo_flw_tag`;

-- Table: DBP_DATA.KAMPAGNE_KAMPAGNE_KUNDE_ZU
insert into `dbp_data.kampagne_kampagne_kunde_zu` (mandant_id, kampagne_id, kampagne_kunde_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kampagne_id, kampagne_kunde_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_kampagne_kampagne_kunde_zu`;

-- Table: DBP_DATA.BESCH_FAKTURA_DET
insert into `dbp_data.besch_faktura_det` (mandant_id, faktura_beleg_id, faktura_beleg_pos_id, art_id, wup_id, nb_id, lagerort_id, verrechnung_betrag, zwsum_1_betrag, zwsum_2_betrag, zwsum_3_betrag, zwsum_4_betrag, zwsum_5_betrag, zwsum_6_betrag, menge_faktura_bme, aktion_id, verk_menge_einh_id, menge_faktura_kolli, menge_faktura_palette, dat_leist_erstellung, vorlage_beleg_id, vorlage_beleg_pos_id, best_beleg_id, best_beleg_pos_id, dat_faktura_sap, auftrag_grund_id, dat_faktura, zwsum_8_betrag, zwsum_9_betrag, bestellart_id, menge_faktura_kg, dat_preisfindung, mwst, ek_netto_bnk, ek_mep, wrg_id, betrag_ek_mep_vor_fwu, betrag_logkostenzuschlag, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(faktura_beleg_id AS INT64) AS faktura_beleg_id, CAST(faktura_beleg_pos_id AS INT64) AS faktura_beleg_pos_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagerort_id, CAST(verrechnung_betrag AS NUMERIC) AS verrechnung_betrag, CAST(zwsum_1_betrag AS NUMERIC) AS zwsum_1_betrag, CAST(zwsum_2_betrag AS NUMERIC) AS zwsum_2_betrag, CAST(zwsum_3_betrag AS NUMERIC) AS zwsum_3_betrag, CAST(zwsum_4_betrag AS NUMERIC) AS zwsum_4_betrag, CAST(zwsum_5_betrag AS NUMERIC) AS zwsum_5_betrag, CAST(zwsum_6_betrag AS NUMERIC) AS zwsum_6_betrag, CAST(menge_faktura_bme AS NUMERIC) AS menge_faktura_bme, aktion_id, verk_menge_einh_id, CAST(menge_faktura_kolli AS NUMERIC) AS menge_faktura_kolli, CAST(menge_faktura_palette AS NUMERIC) AS menge_faktura_palette, dat_leist_erstellung, CAST(vorlage_beleg_id AS INT64) AS vorlage_beleg_id, CAST(vorlage_beleg_pos_id AS INT64) AS vorlage_beleg_pos_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, dat_faktura_sap, auftrag_grund_id, dat_faktura, CAST(zwsum_8_betrag AS NUMERIC) AS zwsum_8_betrag, CAST(zwsum_9_betrag AS NUMERIC) AS zwsum_9_betrag, bestellart_id, CAST(menge_faktura_kg AS NUMERIC) AS menge_faktura_kg, dat_preisfindung, CAST(mwst AS NUMERIC) AS mwst, CAST(ek_netto_bnk AS NUMERIC) AS ek_netto_bnk, CAST(ek_mep AS NUMERIC) AS ek_mep, wrg_id, CAST(betrag_ek_mep_vor_fwu AS NUMERIC) AS betrag_ek_mep_vor_fwu, CAST(betrag_logkostenzuschlag AS NUMERIC) AS betrag_logkostenzuschlag, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_faktura_det`;

-- Table: DBP_DATA.LAGERBEW_DET_WWC_MONAT
insert into `dbp_data.lagerbew_det_wwc_monat` (art_id, mandant_id, wup_id, nb_id, lager_bewart_id, gp_id, kjmo, exvkw_gleich_vkwrt_fg, betrag_lagerbew, betrag_verkauf, menge_lagerbew_bme, betrag_vk_netto, betrag_verkauf_ist, betrag_exbwr, betrag_verkauf_ist_netto, wrg_id, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lager_bewart_id, CAST(gp_id AS INT64) AS gp_id, CAST(kjmo AS INT64) AS kjmo, CAST(exvkw_gleich_vkwrt_fg AS INT64) AS exvkw_gleich_vkwrt_fg, CAST(betrag_lagerbew AS NUMERIC) AS betrag_lagerbew, CAST(betrag_verkauf AS NUMERIC) AS betrag_verkauf, CAST(menge_lagerbew_bme AS NUMERIC) AS menge_lagerbew_bme, CAST(betrag_vk_netto AS NUMERIC) AS betrag_vk_netto, CAST(betrag_verkauf_ist AS NUMERIC) AS betrag_verkauf_ist, CAST(betrag_exbwr AS NUMERIC) AS betrag_exbwr, CAST(betrag_verkauf_ist_netto AS NUMERIC) AS betrag_verkauf_ist_netto, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_lagerbew_det_wwc_monat`;

-- Table: DBP_DATA.BESTAND_ERP_MONAT
insert into `dbp_data.bestand_erp_monat` (art_id, mandant_id, wup_id, nb_id, gjmo, lagerort_id, menge_lgbest_erp_frei_bme, menge_lgbest_erp_umlag_bme, menge_lgbest_erp_qual_bme, menge_lgbest_erp_nf_charge_bme, menge_lgbest_erp_gesp_bme, menge_lgbest_erp_ret_gesp_bme, gjmo_bis, mard_fg, datzeit_daten_abzug, vk_brutto, wrg_id, td_update, td_insert)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gjmo AS INT64) AS gjmo, lagerort_id, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_umlag_bme AS NUMERIC) AS menge_lgbest_erp_umlag_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, CAST(menge_lgbest_erp_nf_charge_bme AS NUMERIC) AS menge_lgbest_erp_nf_charge_bme, CAST(menge_lgbest_erp_gesp_bme AS NUMERIC) AS menge_lgbest_erp_gesp_bme, CAST(menge_lgbest_erp_ret_gesp_bme AS NUMERIC) AS menge_lgbest_erp_ret_gesp_bme, CAST(gjmo_bis AS INT64) AS gjmo_bis, CAST(mard_fg AS INT64) AS mard_fg, datzeit_daten_abzug, CAST(vk_brutto AS NUMERIC) AS vk_brutto, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_bestand_erp_monat`;

-- Table: DBP_DATA.T_FACT_IOT_COLD_LOCATION_PER_HOUR
insert into `dbp_data.t_fact_iot_cold_location_per_hour` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, supply_airtemp_actual_meas, supply_airtemp_setpoint_meas, return_airtemp_actual_meas, return_airtemp_setpoint_meas, temp_actual_meas, temp_setpoint_meas, vaporizationtemp_effective_meas, superheat_meas, defrosting_activ_pct, door_open_pct, overtemp_diff, alarm_delay_hightemp_meas, alarm_priority_qty, defrosttime_max_qty, driptime_qty, evaporator_active_qty, cooling_active_pct, overtemp_meas, evaporationtemp_max_meas, evaporation_limittemp_setpoint_meas, lowtemp_setpoint_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(supply_airtemp_actual_meas AS NUMERIC) AS supply_airtemp_actual_meas, CAST(supply_airtemp_setpoint_meas AS NUMERIC) AS supply_airtemp_setpoint_meas, CAST(return_airtemp_actual_meas AS NUMERIC) AS return_airtemp_actual_meas, CAST(return_airtemp_setpoint_meas AS NUMERIC) AS return_airtemp_setpoint_meas, CAST(temp_actual_meas AS NUMERIC) AS temp_actual_meas, CAST(temp_setpoint_meas AS NUMERIC) AS temp_setpoint_meas, CAST(vaporizationtemp_effective_meas AS NUMERIC) AS vaporizationtemp_effective_meas, CAST(superheat_meas AS NUMERIC) AS superheat_meas, CAST(defrosting_activ_pct AS NUMERIC) AS defrosting_activ_pct, CAST(door_open_pct AS NUMERIC) AS door_open_pct, CAST(overtemp_diff AS NUMERIC) AS overtemp_diff, CAST(alarm_delay_hightemp_meas AS NUMERIC) AS alarm_delay_hightemp_meas, CAST(alarm_priority_qty AS NUMERIC) AS alarm_priority_qty, CAST(defrosttime_max_qty AS NUMERIC) AS defrosttime_max_qty, CAST(driptime_qty AS NUMERIC) AS driptime_qty, CAST(evaporator_active_qty AS NUMERIC) AS evaporator_active_qty, CAST(cooling_active_pct AS NUMERIC) AS cooling_active_pct, CAST(overtemp_meas AS NUMERIC) AS overtemp_meas, CAST(evaporationtemp_max_meas AS NUMERIC) AS evaporationtemp_max_meas, CAST(evaporation_limittemp_setpoint_meas AS NUMERIC) AS evaporation_limittemp_setpoint_meas, CAST(lowtemp_setpoint_meas AS NUMERIC) AS lowtemp_setpoint_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_cold_location_per_hour`;

-- Table: DBP_DATA.COS_BONUSPUNKTE_TRANSAKTION
insert into `dbp_data.cos_bonuspunkte_transaktion` (crm_konto_id, datzeit_bonuspunkte_transaktion, bonuspunkte_transaktion_richtung, mandant_id, dat_bonuspunkte_blockiert_bis, bonuspunkte_transaktion_id, bonuspunkte_kanal_id, bonuspunkte_grund_cd, bonuspunkte_herkunft_id, anz_bonuspunkte_transaktion, datzeit_update, td_update, td_insert)
SELECT crm_konto_id, CAST(datzeit_bonuspunkte_transaktion AS DATETIME) AS datzeit_bonuspunkte_transaktion, CAST(bonuspunkte_transaktion_richtung AS INT64) AS bonuspunkte_transaktion_richtung, CAST(mandant_id AS INT64) AS mandant_id, dat_bonuspunkte_blockiert_bis, bonuspunkte_transaktion_id, CAST(bonuspunkte_kanal_id AS INT64) AS bonuspunkte_kanal_id, bonuspunkte_grund_cd, CAST(bonuspunkte_herkunft_id AS INT64) AS bonuspunkte_herkunft_id, CAST(anz_bonuspunkte_transaktion AS INT64) AS anz_bonuspunkte_transaktion, CAST(datzeit_update AS DATETIME) AS datzeit_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_cos_bonuspunkte_transaktion`;

-- Table: DBP_DATA.BESCH_LIEF_WA_DET
insert into `dbp_data.besch_lief_wa_det` (mandant_id, lief_beleg_id, lief_beleg_pos_id, handling_unit_id, handling_unit_pos_id, hu_typ_id, best_beleg_id, transportation_unit_id, belos_vorgang_id, wup_id, nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, art_id, kunde_id, wg_verkett_lief, menge_lief_soll_kolli, menge_lief_ist_kolli, menge_lief_soll_bme, menge_lief_ist_bme, menge_lief_soll_pal, menge_lief_ist_pal, lief_pal_typ_id, lief_pal_typ_dwh_id, mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, handling_unit_id_ext_parent, handling_unit_id_ext, handling_unit_id_parent, originalposition_lief_fg, position_charg_split_fg, disponent_id, dat_haltbarkeit, charge_id, anzahl_packstueck, vk_netto_lief_ist, vk_netto_lief_soll, transportsortiment_id, split_lief_kennz, lief_beleg_id_orig, wg_verkett_fg, wrg_id, uebg_chargensplit_pos, auslieferungsgruppe_id, dat_erstellung, tms_tour_id, dat_tour, tms_system_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, CAST(handling_unit_id AS INT64) AS handling_unit_id, CAST(handling_unit_pos_id AS INT64) AS handling_unit_pos_id, CAST(hu_typ_id AS INT64) AS hu_typ_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(belos_vorgang_id AS INT64) AS belos_vorgang_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, CAST(art_id AS INT64) AS art_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(menge_lief_soll_bme AS NUMERIC) AS menge_lief_soll_bme, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, CAST(menge_lief_soll_pal AS NUMERIC) AS menge_lief_soll_pal, CAST(menge_lief_ist_pal AS NUMERIC) AS menge_lief_ist_pal, lief_pal_typ_id, lief_pal_typ_dwh_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, handling_unit_id_ext_parent, handling_unit_id_ext, CAST(handling_unit_id_parent AS INT64) AS handling_unit_id_parent, CAST(originalposition_lief_fg AS INT64) AS originalposition_lief_fg, CAST(position_charg_split_fg AS INT64) AS position_charg_split_fg, disponent_id, dat_haltbarkeit, charge_id, CAST(anzahl_packstueck AS INT64) AS anzahl_packstueck, CAST(vk_netto_lief_ist AS NUMERIC) AS vk_netto_lief_ist, CAST(vk_netto_lief_soll AS NUMERIC) AS vk_netto_lief_soll, transportsortiment_id, split_lief_kennz, CAST(lief_beleg_id_orig AS INT64) AS lief_beleg_id_orig, CAST(wg_verkett_fg AS INT64) AS wg_verkett_fg, wrg_id, CAST(uebg_chargensplit_pos AS INT64) AS uebg_chargensplit_pos, auslieferungsgruppe_id, dat_erstellung, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(tms_system_id AS INT64) AS tms_system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_wa_det`;

-- Table: DBP_DATA.IST_KOSTEN_DET
insert into `dbp_data.ist_kosten_det` (mandant_id, psp_id, gj, buchungsperiode_id, krk_id, soll_haben_kz, kostenart_id, dat_beleg, beleg_id, beleg_pos_id, betrag, wrg_id, geschaeftsbereich_id, beleg_bez, in_lief_id, nebenkontierung_id, nebenkontierungsart_id, berichts_position_it_id, berichts_position_invest_id, sparte_id, auftrag_id, in_art_id, buchungskreis_id, anlage_id, anlage_sub_id, dat_buch, menge, menge_einh_id, kostenstelle_id, gegenkonto_id, gegenkontoart_id, ref_beleg_id, ref_fi_beleg_id, in_fi_belegkopftext, best_beleg_id, best_beleg_pos_id, partner_objektart_id, partner_objekt_id, bestell_text, ref_buchungskreis_id, belegart_id, belastungs_kz, ref_vorgang_id, hb2_fg, co_leistungsart_id, bedarf_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(psp_id AS INT64) AS psp_id, CAST(gj AS INT64) AS gj, CAST(buchungsperiode_id AS INT64) AS buchungsperiode_id, krk_id, soll_haben_kz, kostenart_id, dat_beleg, beleg_id, CAST(beleg_pos_id AS INT64) AS beleg_pos_id, CAST(betrag AS NUMERIC) AS betrag, wrg_id, geschaeftsbereich_id, beleg_bez, CAST(in_lief_id AS INT64) AS in_lief_id, nebenkontierung_id, nebenkontierungsart_id, CAST(berichts_position_it_id AS INT64) AS berichts_position_it_id, CAST(berichts_position_invest_id AS INT64) AS berichts_position_invest_id, CAST(sparte_id AS INT64) AS sparte_id, auftrag_id, CAST(in_art_id AS INT64) AS in_art_id, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, anlage_id, CAST(anlage_sub_id AS INT64) AS anlage_sub_id, dat_buch, CAST(menge AS NUMERIC) AS menge, menge_einh_id, kostenstelle_id, gegenkonto_id, gegenkontoart_id, CAST(ref_beleg_id AS INT64) AS ref_beleg_id, ref_fi_beleg_id, in_fi_belegkopftext, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, partner_objektart_id, partner_objekt_id, bestell_text, CAST(ref_buchungskreis_id AS INT64) AS ref_buchungskreis_id, belegart_id, belastungs_kz, ref_vorgang_id, CAST(hb2_fg AS INT64) AS hb2_fg, co_leistungsart_id, bedarf_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ist_kosten_det`;

-- Table: DBP_DATA.IN_ART_BEWERTUNGSKREIS_TAG
insert into `dbp_data.in_art_bewertungskreis_tag` (mandant_id, in_art_id, bewertungskreis_id, dat, wrg_id, menge_bestand_bme, betrag_preis_bestand, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(in_art_id AS INT64) AS in_art_id, bewertungskreis_id, dat, wrg_id, CAST(menge_bestand_bme AS NUMERIC) AS menge_bestand_bme, CAST(betrag_preis_bestand AS NUMERIC) AS betrag_preis_bestand, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_in_art_bewertungskreis_tag`;

-- Table: DBP_DATA.BELEGREFERENZ
insert into `dbp_data.belegreferenz` (mandant_id, beleg_guid, beleg_pos_guid, referenz_belegtyp_id, referenzbeleg_guid, referenzbeleg_pos_guid, referenzbeleg_id, belegtyp_id, referenz_bs_id, partner_guid, referenzbeleg_pos_id, zeitzone, datzeit_termin_beginn, datzeit_termin_ende, datzeit_erstellung, datzeit_aenderung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, beleg_guid, beleg_pos_guid, referenz_belegtyp_id, referenzbeleg_guid, referenzbeleg_pos_guid, referenzbeleg_id, belegtyp_id, referenz_bs_id, partner_guid, CAST(referenzbeleg_pos_id AS INT64) AS referenzbeleg_pos_id, zeitzone, datzeit_termin_beginn, datzeit_termin_ende, datzeit_erstellung, datzeit_aenderung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_belegreferenz`;

-- Table: DBP_DATA.EPS_DRUCK_STATISTIK_PER
insert into `dbp_data.eps_druck_statistik_per` (eps_druck_statistik_id, mandant_id, wup_id, nb_id, kl_art_id, druck_anlass_id, datzeit_anforderung, datzeit_druck, containertyp_id, layout_groesse_id, papierart_id, td_update, td_insert)
SELECT CAST(eps_druck_statistik_id AS INT64) AS eps_druck_statistik_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kl_art_id AS INT64) AS kl_art_id, druck_anlass_id, datzeit_anforderung, datzeit_druck, CAST(containertyp_id AS INT64) AS containertyp_id, CAST(layout_groesse_id AS INT64) AS layout_groesse_id, CAST(papierart_id AS INT64) AS papierart_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_eps_druck_statistik_per`;

-- Table: DBP_DATA.ORDER_FORECAST
insert into `dbp_data.order_forecast` (mandant_id, wup_id, nb_id, art_id, gp_id, dat_plan, dat_best, dispoteilsortiment_id, best_menge_einh_id, basis_menge_einh_id, menge_ofc_ame, menge_ofc_bme, dat_lief, banf_beleg_id, best_beleg_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, dat_plan, dat_best, dispoteilsortiment_id, best_menge_einh_id, basis_menge_einh_id, CAST(menge_ofc_ame AS NUMERIC) AS menge_ofc_ame, CAST(menge_ofc_bme AS NUMERIC) AS menge_ofc_bme, dat_lief, CAST(banf_beleg_id AS INT64) AS banf_beleg_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_order_forecast`;

-- Table: DBP_DATA.SSM_WUP_TAG_STUNDE
insert into `dbp_data.ssm_wup_tag_stunde` (mandant_id, wup_id, nb_id, wup_bereich_id, wup_abt_id, ssm_cluster_id, ssm_prozess_id, dat, zeit_stunde, zeit_15min, ssm_aufwand_typ_id, wert, wert_gerundet, wert_minimal_berechnung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_bereich_id AS INT64) AS wup_bereich_id, CAST(wup_abt_id AS INT64) AS wup_abt_id, CAST(ssm_cluster_id AS INT64) AS ssm_cluster_id, CAST(ssm_prozess_id AS INT64) AS ssm_prozess_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(zeit_15min AS INT64) AS zeit_15min, CAST(ssm_aufwand_typ_id AS INT64) AS ssm_aufwand_typ_id, CAST(wert AS NUMERIC) AS wert, CAST(wert_gerundet AS NUMERIC) AS wert_gerundet, CAST(wert_minimal_berechnung AS NUMERIC) AS wert_minimal_berechnung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_tag_stunde`;

-- Table: DBP_DATA.WEWA_WWC
insert into `dbp_data.wewa_wwc` (ekbe_mandant_id, ekbe_best_beleg_id, ekbe_best_beleg_pos_id, mseg_kj, rseg_beleg_id, rseg_beleg_pos_id, rseg_gj, ekpo_art_id, rbkp_belegart_id, mseg_beleg_id, mseg_beleg_pos_id, ekbe_best_entw_typ_id_we, ekbe_best_entw_typ_id_rech, ekbe_betrag, ekbe_betrag_rech, ekbe_betrag_wrbtr, ekbe_betrag_wrbtr_rech, mkpf_dat_beleg, rbkp_dat_beleg, ekbe_dat_buch_rech, mkpf_dat_buch, mkpf_dat_erfasst, rbkp_dat_erfasst, ekko_dat_best_beleg, mseg_gp_id, mseg_lager_bewart_id, rseg_menge_bestand_bme, rseg_menge_bestand_bme_rbp, ekbe_menge_basis, ekbe_menge_best, ekbe_menge_best_rech, mseg_menge_bestand_bme, ekbe_nb_id, rseg_rueck_buchung_fg, ekbe_soll_haben_kz, rseg_soll_haben_kz, rseg_wert_bestand, rseg_wert_bestand_vp, rseg_wert_bestand_buchung, rseg_wert_bestand_buchung_vp, mseg_wert_bestand, mseg_wrg_id, rseg_wrg_id, ekbe_wup_id, mkpf_zeit_erfasst, rbkp_zeit_erfasst, ref_beleg_id, ref_beleg_pos_id, ref_gj, td_insert, td_update)
SELECT CAST(ekbe_mandant_id AS INT64) AS ekbe_mandant_id, CAST(ekbe_best_beleg_id AS INT64) AS ekbe_best_beleg_id, CAST(ekbe_best_beleg_pos_id AS INT64) AS ekbe_best_beleg_pos_id, CAST(mseg_kj AS INT64) AS mseg_kj, CAST(rseg_beleg_id AS INT64) AS rseg_beleg_id, CAST(rseg_beleg_pos_id AS INT64) AS rseg_beleg_pos_id, CAST(rseg_gj AS INT64) AS rseg_gj, CAST(ekpo_art_id AS INT64) AS ekpo_art_id, rbkp_belegart_id, CAST(mseg_beleg_id AS INT64) AS mseg_beleg_id, CAST(mseg_beleg_pos_id AS INT64) AS mseg_beleg_pos_id, ekbe_best_entw_typ_id_we, ekbe_best_entw_typ_id_rech, CAST(ekbe_betrag AS NUMERIC) AS ekbe_betrag, CAST(ekbe_betrag_rech AS NUMERIC) AS ekbe_betrag_rech, CAST(ekbe_betrag_wrbtr AS NUMERIC) AS ekbe_betrag_wrbtr, CAST(ekbe_betrag_wrbtr_rech AS NUMERIC) AS ekbe_betrag_wrbtr_rech, mkpf_dat_beleg, rbkp_dat_beleg, ekbe_dat_buch_rech, mkpf_dat_buch, mkpf_dat_erfasst, rbkp_dat_erfasst, ekko_dat_best_beleg, CAST(mseg_gp_id AS INT64) AS mseg_gp_id, mseg_lager_bewart_id, CAST(rseg_menge_bestand_bme AS NUMERIC) AS rseg_menge_bestand_bme, CAST(rseg_menge_bestand_bme_rbp AS NUMERIC) AS rseg_menge_bestand_bme_rbp, CAST(ekbe_menge_basis AS NUMERIC) AS ekbe_menge_basis, CAST(ekbe_menge_best AS NUMERIC) AS ekbe_menge_best, CAST(ekbe_menge_best_rech AS NUMERIC) AS ekbe_menge_best_rech, CAST(mseg_menge_bestand_bme AS NUMERIC) AS mseg_menge_bestand_bme, CAST(ekbe_nb_id AS INT64) AS ekbe_nb_id, CAST(rseg_rueck_buchung_fg AS INT64) AS rseg_rueck_buchung_fg, ekbe_soll_haben_kz, rseg_soll_haben_kz, CAST(rseg_wert_bestand AS NUMERIC) AS rseg_wert_bestand, CAST(rseg_wert_bestand_vp AS NUMERIC) AS rseg_wert_bestand_vp, CAST(rseg_wert_bestand_buchung AS NUMERIC) AS rseg_wert_bestand_buchung, CAST(rseg_wert_bestand_buchung_vp AS NUMERIC) AS rseg_wert_bestand_buchung_vp, CAST(mseg_wert_bestand AS NUMERIC) AS mseg_wert_bestand, mseg_wrg_id, rseg_wrg_id, CAST(ekbe_wup_id AS INT64) AS ekbe_wup_id, CAST(mkpf_zeit_erfasst AS INT64) AS mkpf_zeit_erfasst, CAST(rbkp_zeit_erfasst AS INT64) AS rbkp_zeit_erfasst, CAST(ref_beleg_id AS INT64) AS ref_beleg_id, CAST(ref_beleg_pos_id AS INT64) AS ref_beleg_pos_id, CAST(ref_gj AS INT64) AS ref_gj, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wewa_wwc`;

-- Table: DBP_MSI_DATA.VIS_TAG_UMSATZ_WG
insert into `dbp_msi_data.vis_tag_umsatz_wg` (mandant_id, dat, nb_id, wup_id, wg_id, arthiertyp_id, wrg_id, abt_id, gj, kjmo, kjwo, wtag_id, ums_netto, ums_netto_af, ums_netto_sa, ums_netto_wvj, ums_netto_af_wvj, ums_netto_sa_wvj, ums_netto_wvvj, ums_netto_af_wvvj, ums_netto_sa_wvvj, ums_netto_kvj, ums_netto_af_kvj, ums_netto_sa_kvj, ums_netto_kvvj, ums_netto_af_kvvj, ums_netto_sa_kvvj, ums_brutto, ums_brutto_kvj, ums_brutto_wvj, menge_absatz, menge_absatz_af, menge_absatz_sa, menge_absatz_kvj, menge_absatz_af_kvj, menge_absatz_sa_kvj, menge_absatz_wvj, menge_absatz_af_wvj, menge_absatz_sa_wvj, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, wrg_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(wtag_id AS INT64) AS wtag_id, CAST(ums_netto AS NUMERIC) AS ums_netto, CAST(ums_netto_af AS NUMERIC) AS ums_netto_af, CAST(ums_netto_sa AS NUMERIC) AS ums_netto_sa, CAST(ums_netto_wvj AS NUMERIC) AS ums_netto_wvj, CAST(ums_netto_af_wvj AS NUMERIC) AS ums_netto_af_wvj, CAST(ums_netto_sa_wvj AS NUMERIC) AS ums_netto_sa_wvj, CAST(ums_netto_wvvj AS NUMERIC) AS ums_netto_wvvj, CAST(ums_netto_af_wvvj AS NUMERIC) AS ums_netto_af_wvvj, CAST(ums_netto_sa_wvvj AS NUMERIC) AS ums_netto_sa_wvvj, CAST(ums_netto_kvj AS NUMERIC) AS ums_netto_kvj, CAST(ums_netto_af_kvj AS NUMERIC) AS ums_netto_af_kvj, CAST(ums_netto_sa_kvj AS NUMERIC) AS ums_netto_sa_kvj, CAST(ums_netto_kvvj AS NUMERIC) AS ums_netto_kvvj, CAST(ums_netto_af_kvvj AS NUMERIC) AS ums_netto_af_kvvj, CAST(ums_netto_sa_kvvj AS NUMERIC) AS ums_netto_sa_kvvj, CAST(ums_brutto AS NUMERIC) AS ums_brutto, CAST(ums_brutto_kvj AS NUMERIC) AS ums_brutto_kvj, CAST(ums_brutto_wvj AS NUMERIC) AS ums_brutto_wvj, CAST(menge_absatz AS NUMERIC) AS menge_absatz, CAST(menge_absatz_af AS NUMERIC) AS menge_absatz_af, CAST(menge_absatz_sa AS NUMERIC) AS menge_absatz_sa, CAST(menge_absatz_kvj AS NUMERIC) AS menge_absatz_kvj, CAST(menge_absatz_af_kvj AS NUMERIC) AS menge_absatz_af_kvj, CAST(menge_absatz_sa_kvj AS NUMERIC) AS menge_absatz_sa_kvj, CAST(menge_absatz_wvj AS NUMERIC) AS menge_absatz_wvj, CAST(menge_absatz_af_wvj AS NUMERIC) AS menge_absatz_af_wvj, CAST(menge_absatz_sa_wvj AS NUMERIC) AS menge_absatz_sa_wvj, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_umsatz_wg`;

-- Table: DBP_DATA.COS_TRANSAKTION
insert into `dbp_data.cos_transaktion` (bonuspunkte_transaktion_id, wrg_id, mandant_id, wup_id, umsatz_brutto, bon_dat, bon_barcode, bon_nr, umsatz_brutto_loyalty, td_update, td_insert)
SELECT bonuspunkte_transaktion_id, wrg_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, bon_dat, bon_barcode, CAST(bon_nr AS INT64) AS bon_nr, CAST(umsatz_brutto_loyalty AS NUMERIC) AS umsatz_brutto_loyalty, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_cos_transaktion`;

-- Table: DBP_DATA.LAGERPLATZ_EWM_TAG
insert into `dbp_data.lagerplatz_ewm_tag` (mandant_id, lagernummer_id, lagerplatz_id, dat, lagertyp_id, lagerbereich_id, lagerplatztyp_id, lagerplatz_zugriffstyp_id, lagerplatz_aufteilung_id, lagerplatz_position, auslagerung_sperr_fg, einlagerung_sperr_fg, inventur_block_fg, aufgeteilt_fg, anz_hu, anz_hu_max, gewicht_max, gew_einh_id, gewicht, volumen_netto, volumen_max, vol_einh_id, kapa_max, kapa_frei, leer_fg, voll_fg, dat_erste_einlagerung, datzeit_letzte_bewegung, lageraufgabe_id_letzte_bew, brandabschnitt_id, datzeit_aenderung, haupt_lagerplatz_id, loc_guid, handling_unit_guid, gang_id, saeule_id, ebene_id, x_koordinate, y_koordinate, z_koordinate, lagernereich_lgst_id, feldtyp_id, regaltyp_id, wa_lane_kapa, we_lane_kapa, kapa_erh_fg, tiefe_frei, tiefe_max, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, lagerplatz_id, dat, lagertyp_id, lagerbereich_id, lagerplatztyp_id, lagerplatz_zugriffstyp_id, lagerplatz_aufteilung_id, lagerplatz_position, CAST(auslagerung_sperr_fg AS INT64) AS auslagerung_sperr_fg, CAST(einlagerung_sperr_fg AS INT64) AS einlagerung_sperr_fg, CAST(inventur_block_fg AS INT64) AS inventur_block_fg, CAST(aufgeteilt_fg AS INT64) AS aufgeteilt_fg, CAST(anz_hu AS INT64) AS anz_hu, CAST(anz_hu_max AS INT64) AS anz_hu_max, CAST(gewicht_max AS NUMERIC) AS gewicht_max, gew_einh_id, CAST(gewicht AS NUMERIC) AS gewicht, CAST(volumen_netto AS NUMERIC) AS volumen_netto, CAST(volumen_max AS NUMERIC) AS volumen_max, vol_einh_id, CAST(kapa_max AS NUMERIC) AS kapa_max, CAST(kapa_frei AS NUMERIC) AS kapa_frei, CAST(leer_fg AS INT64) AS leer_fg, CAST(voll_fg AS INT64) AS voll_fg, dat_erste_einlagerung, datzeit_letzte_bewegung, CAST(lageraufgabe_id_letzte_bew AS INT64) AS lageraufgabe_id_letzte_bew, brandabschnitt_id, datzeit_aenderung, haupt_lagerplatz_id, loc_guid, handling_unit_guid, CAST(gang_id AS INT64) AS gang_id, CAST(saeule_id AS INT64) AS saeule_id, ebene_id, CAST(x_koordinate AS NUMERIC) AS x_koordinate, CAST(y_koordinate AS NUMERIC) AS y_koordinate, CAST(z_koordinate AS NUMERIC) AS z_koordinate, lagernereich_lgst_id, feldtyp_id, regaltyp_id, CAST(wa_lane_kapa AS NUMERIC) AS wa_lane_kapa, CAST(we_lane_kapa AS NUMERIC) AS we_lane_kapa, CAST(kapa_erh_fg AS INT64) AS kapa_erh_fg, CAST(tiefe_frei AS INT64) AS tiefe_frei, CAST(tiefe_max AS INT64) AS tiefe_max, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerplatz_ewm_tag`;

-- Table: DBP_DATA.TRANSPORTAUFTRAG_LEISTUNG
insert into `dbp_data.transportauftrag_leistung` (mandant_id, transport_beleg_id, transport_beleg_pos_id, lagernummer_id, wup_id, nb_id, transport_beleg_pos_sub_id, leist_empfaenger_sap_id, leist_empfaenger_gruppe_id, ext_ma_fg, ausschluss_fg, art_id, menge_ist_nach, dat_leistung, zeit_leistung, transport_gv_id, versandblock_id, von_lagertyp_id, nach_lagertyp_id, gp_id, ressource_typ_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transport_beleg_id AS INT64) AS transport_beleg_id, CAST(transport_beleg_pos_id AS INT64) AS transport_beleg_pos_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(transport_beleg_pos_sub_id AS INT64) AS transport_beleg_pos_sub_id, leist_empfaenger_sap_id, leist_empfaenger_gruppe_id, CAST(ext_ma_fg AS INT64) AS ext_ma_fg, CAST(ausschluss_fg AS INT64) AS ausschluss_fg, CAST(art_id AS INT64) AS art_id, CAST(menge_ist_nach AS NUMERIC) AS menge_ist_nach, dat_leistung, CAST(zeit_leistung AS INT64) AS zeit_leistung, CAST(transport_gv_id AS INT64) AS transport_gv_id, versandblock_id, von_lagertyp_id, nach_lagertyp_id, CAST(gp_id AS INT64) AS gp_id, CAST(ressource_typ_id AS INT64) AS ressource_typ_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_transportauftrag_leistung`;

-- Table: DBP_DATA.ANGEBOT_ART_WUP_ZU
insert into `dbp_data.angebot_art_wup_zu` (mandant_id, angebot_nr, art_id, wup_id, nb_id, verkaufsorganisation_id, art_basismenge_einh_id, art_typ_cd, art_gtin_id, mutter_wb_id, art_posten_fg, art_prio_nr, art_theken_verkauf_fg, art_nis_fg, art_national_fg, art_export_werbemittel_fg, art_preisangabe_cd, art_werbe_prod_gruppe_name, gp_id, opv_markt_fg, opv_prospekt_fg, anz_bonuskauf_bezahlt, anz_bonuskauf_kauf, anz_bonuskauf_gratis, proz_bonuskauf_rabatt, betrag_bonuskauf_rabatt, betrag_bonuskauf_min, menge_bonuskauf_min, bonuskauf_bedingung_id, bonuskauf_dimension_id, bonuskauf_produktvariante_id, bonuskauf_rabattzuordnung_id, wrg_id, rabatt_typ_id, preis_vk_brutto, preis_vk_brutto_aktion, preis_vk_brutto_normalisiert, preis_vk_brutto_stk, preis_vk_brutto_aktion_stk, proz_preisnachlass, menge_prog_scm, menge_prog_am, betrag_prog_rohertrag_scm, betrag_prog_pv, betrag_prog_umsatz_am, betrag_prog_umsatz_scm, preis_ek_nettonetto, proz_art_rabatt, preis_ek_mep_vor_fwu, preis_ek_nettonetto_rabatt, preis_ek_mep_vor_fwu_rabatt, proz_prog_spanne_ek_nettonetto, proz_prog_spanne_ek_mep_vor_fwu, proz_prog_spanne_ek_einstandspreis, ek_preis_ermittlung_rabatt_typ_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, angebot_nr, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, verkaufsorganisation_id, art_basismenge_einh_id, art_typ_cd, CAST(art_gtin_id AS INT64) AS art_gtin_id, CAST(mutter_wb_id AS INT64) AS mutter_wb_id, CAST(art_posten_fg AS INT64) AS art_posten_fg, CAST(art_prio_nr AS INT64) AS art_prio_nr, CAST(art_theken_verkauf_fg AS INT64) AS art_theken_verkauf_fg, CAST(art_nis_fg AS INT64) AS art_nis_fg, CAST(art_national_fg AS INT64) AS art_national_fg, CAST(art_export_werbemittel_fg AS INT64) AS art_export_werbemittel_fg, art_preisangabe_cd, art_werbe_prod_gruppe_name, CAST(gp_id AS INT64) AS gp_id, CAST(opv_markt_fg AS INT64) AS opv_markt_fg, CAST(opv_prospekt_fg AS INT64) AS opv_prospekt_fg, CAST(anz_bonuskauf_bezahlt AS INT64) AS anz_bonuskauf_bezahlt, CAST(anz_bonuskauf_kauf AS INT64) AS anz_bonuskauf_kauf, CAST(anz_bonuskauf_gratis AS INT64) AS anz_bonuskauf_gratis, CAST(proz_bonuskauf_rabatt AS NUMERIC) AS proz_bonuskauf_rabatt, CAST(betrag_bonuskauf_rabatt AS NUMERIC) AS betrag_bonuskauf_rabatt, CAST(betrag_bonuskauf_min AS NUMERIC) AS betrag_bonuskauf_min, CAST(menge_bonuskauf_min AS NUMERIC) AS menge_bonuskauf_min, CAST(bonuskauf_bedingung_id AS INT64) AS bonuskauf_bedingung_id, bonuskauf_dimension_id, bonuskauf_produktvariante_id, CAST(bonuskauf_rabattzuordnung_id AS INT64) AS bonuskauf_rabattzuordnung_id, wrg_id, CAST(rabatt_typ_id AS INT64) AS rabatt_typ_id, CAST(preis_vk_brutto AS NUMERIC) AS preis_vk_brutto, CAST(preis_vk_brutto_aktion AS NUMERIC) AS preis_vk_brutto_aktion, CAST(preis_vk_brutto_normalisiert AS NUMERIC) AS preis_vk_brutto_normalisiert, CAST(preis_vk_brutto_stk AS NUMERIC) AS preis_vk_brutto_stk, CAST(preis_vk_brutto_aktion_stk AS NUMERIC) AS preis_vk_brutto_aktion_stk, CAST(proz_preisnachlass AS NUMERIC) AS proz_preisnachlass, CAST(menge_prog_scm AS NUMERIC) AS menge_prog_scm, CAST(menge_prog_am AS NUMERIC) AS menge_prog_am, CAST(betrag_prog_rohertrag_scm AS NUMERIC) AS betrag_prog_rohertrag_scm, CAST(betrag_prog_pv AS NUMERIC) AS betrag_prog_pv, CAST(betrag_prog_umsatz_am AS NUMERIC) AS betrag_prog_umsatz_am, CAST(betrag_prog_umsatz_scm AS NUMERIC) AS betrag_prog_umsatz_scm, CAST(preis_ek_nettonetto AS NUMERIC) AS preis_ek_nettonetto, CAST(proz_art_rabatt AS NUMERIC) AS proz_art_rabatt, CAST(preis_ek_mep_vor_fwu AS NUMERIC) AS preis_ek_mep_vor_fwu, CAST(preis_ek_nettonetto_rabatt AS NUMERIC) AS preis_ek_nettonetto_rabatt, CAST(preis_ek_mep_vor_fwu_rabatt AS NUMERIC) AS preis_ek_mep_vor_fwu_rabatt, CAST(proz_prog_spanne_ek_nettonetto AS NUMERIC) AS proz_prog_spanne_ek_nettonetto, CAST(proz_prog_spanne_ek_mep_vor_fwu AS NUMERIC) AS proz_prog_spanne_ek_mep_vor_fwu, CAST(proz_prog_spanne_ek_einstandspreis AS NUMERIC) AS proz_prog_spanne_ek_einstandspreis, CAST(ek_preis_ermittlung_rabatt_typ_id AS INT64) AS ek_preis_ermittlung_rabatt_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_angebot_art_wup_zu`;

-- Table: DBP_DATA.LAGERBEW_LGORT_GRUND_WUP
insert into `dbp_data.lagerbew_lgort_grund_wup` (mandant_id, lagerort_id, grund_id, wup_id, nb_id, auto_fg, vorgangsart_id, lager_bewart_id, wg_id, arthiertyp_id, lief_pal_typ_id, dat_buch, empfaenger_id, betrag_lagerbew, betrag_verkauf, menge_lagerbew_bme, menge_lief, menge_lieferschein, menge_lagerbew_kolli, menge_lagerbew_palette, menge_erf, wrg_id, mandant_id_empfaenger, betrag_vk_netto_vz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagerort_id, grund_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, auto_fg, vorgangsart_id, lager_bewart_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, lief_pal_typ_id, dat_buch, CAST(empfaenger_id AS INT64) AS empfaenger_id, CAST(betrag_lagerbew AS NUMERIC) AS betrag_lagerbew, CAST(betrag_verkauf AS NUMERIC) AS betrag_verkauf, CAST(menge_lagerbew_bme AS NUMERIC) AS menge_lagerbew_bme, CAST(menge_lief AS NUMERIC) AS menge_lief, CAST(menge_lieferschein AS NUMERIC) AS menge_lieferschein, CAST(menge_lagerbew_kolli AS NUMERIC) AS menge_lagerbew_kolli, CAST(menge_lagerbew_palette AS NUMERIC) AS menge_lagerbew_palette, CAST(menge_erf AS NUMERIC) AS menge_erf, wrg_id, CAST(mandant_id_empfaenger AS INT64) AS mandant_id_empfaenger, CAST(betrag_vk_netto_vz AS NUMERIC) AS betrag_vk_netto_vz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerbew_lgort_grund_wup`;

-- Table: DBP_ETL_PROCESS.ART_WUP_VK_KONDITION_PER
insert into `dbp_etl_process.art_wup_vk_kondition_per` (mandant_id, verkaufsorganisation_id, vw_id, wup_id, nb_id, art_id, kl_art_id, wg_id, preisliste_typ_id, quelltabelle_name, konditionsart_id, datzeit_erstellung_kondition, datzeit_kondition_gueltig_von, datzeit_kondition_gueltig_bis, vk_brutto, wrg_id, menge_kondition_gueltig_ab, konditionssatz_id, aktion_id, datzeit_erstellung_quelle, datzeit_extrakt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verkaufsorganisation_id, CAST(vw_id AS INT64) AS vw_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(kl_art_id AS INT64) AS kl_art_id, CAST(wg_id AS INT64) AS wg_id, preisliste_typ_id, quelltabelle_name, konditionsart_id, CAST(datzeit_erstellung_kondition AS DATETIME) AS datzeit_erstellung_kondition, CAST(datzeit_kondition_gueltig_von AS DATETIME) AS datzeit_kondition_gueltig_von, CAST(datzeit_kondition_gueltig_bis AS DATETIME) AS datzeit_kondition_gueltig_bis, CAST(vk_brutto AS NUMERIC) AS vk_brutto, wrg_id, CAST(menge_kondition_gueltig_ab AS INT64) AS menge_kondition_gueltig_ab, CAST(konditionssatz_id AS INT64) AS konditionssatz_id, aktion_id, CAST(datzeit_erstellung_quelle AS DATETIME) AS datzeit_erstellung_quelle, CAST(datzeit_extrakt AS DATETIME) AS datzeit_extrakt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_art_wup_vk_kondition_per`;

-- Table: DBP_DATA.INVENTUR_DET
insert into `dbp_data.inventur_det` (inv_beleg_id, gj, inv_beleg_pos_id, mandant_id, dat_letzt_zaehl, lagerort_id, dat_buch, wup_id, nb_id, art_id, lagerbew_beleg_id, lagerbew_beleg_pos_id, kj, erfsngs_menge_einh_id, menge_erf, menge_buch, menge_zaehl, wert_diff_inv, wert_vk_brutto, wert_vk_extern, wert_vk_netto, vk_inventur_diff_brutto, vk_inventur_diff_netto, wert_zaehl, wert_menge_buch, nullzaehl_fg, beleg_erfasser_id, wrg_id, td_update, td_insert)
SELECT CAST(inv_beleg_id AS INT64) AS inv_beleg_id, CAST(gj AS INT64) AS gj, CAST(inv_beleg_pos_id AS INT64) AS inv_beleg_pos_id, CAST(mandant_id AS INT64) AS mandant_id, dat_letzt_zaehl, lagerort_id, dat_buch, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(lagerbew_beleg_pos_id AS INT64) AS lagerbew_beleg_pos_id, CAST(kj AS INT64) AS kj, erfsngs_menge_einh_id, CAST(menge_erf AS NUMERIC) AS menge_erf, CAST(menge_buch AS NUMERIC) AS menge_buch, CAST(menge_zaehl AS NUMERIC) AS menge_zaehl, CAST(wert_diff_inv AS NUMERIC) AS wert_diff_inv, CAST(wert_vk_brutto AS NUMERIC) AS wert_vk_brutto, CAST(wert_vk_extern AS NUMERIC) AS wert_vk_extern, CAST(wert_vk_netto AS NUMERIC) AS wert_vk_netto, CAST(vk_inventur_diff_brutto AS NUMERIC) AS vk_inventur_diff_brutto, CAST(vk_inventur_diff_netto AS NUMERIC) AS vk_inventur_diff_netto, CAST(wert_zaehl AS NUMERIC) AS wert_zaehl, CAST(wert_menge_buch AS NUMERIC) AS wert_menge_buch, CAST(nullzaehl_fg AS INT64) AS nullzaehl_fg, beleg_erfasser_id, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_inventur_det`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_SEGMENT
insert into `dbp_ods_archiv.ods_bon_segment` (bon_id, wup_id, mandant_id, segment_id, td_update, td_insert)
SELECT bon_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(segment_id AS INT64) AS segment_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_segment`;

-- Table: DBP_DATA.FLW_BEW
insert into `dbp_data.flw_bew` (bde_vorgang_id, werk_id, mandant_id, best_beleg_id, best_beleg_pos_id, lagerbew_beleg_id, kj, dat_erfasst, zeit_erfasst, loesch_fg, nettogew, menge_dme, dme_einh_id, flw_beleg_typ_id, beleg_gruppe_id, dat_haltbarkeit, flw_art_id, status_mb, storno_fg, menge_bme, retourenpos_fg, auftrag_id, betrag_bew, charge_id, lagerort_id, wrg_id, datzeit_erstellung, min_dat_erfasst, min_zeit_erfasst, system_id, bestandsart, terminal_id, dat_herstellung, ext_tiernummer, menge_erfasst, erfmenge_einh_id, bruttogew, taragew, schnitt_id, um_lagerort_id, um_flw_art_id, um_charge_id, prueflos_id, flw_lief_id, verwendung_ziel_id, bde_vorgang_id_nachf, bde_vorgang_id_vorg, behaelter_id, erzeuger_1_id, erzeuger_2_id, wechsel_id, schlachtbetrieb_id, transport_einheit_id, dat_schlachtung, dat_zerlegung, prueflos_id_2, tier_kategorie_id, tier_gattung_id, vpap_id, flw_arbeitsplatz_id, altnv_menge_einh_id, pdao_job_id, lagernummer_id, lager_beleg_id, lager_beleg_pos_id, transport_beleg_id, transport_beleg_pos_id, mfr_transport_einheit_id, pdao_bediener_id, flw_arbeitsplatz1_id, nve_id, lief_charge_id, herkunft_id, flw_bew_grund_id, land_gemaestet_id, land_geschlachtet_id, land_geboren_id, land_zerlegt_id, rauchwagen_id, menge_rauchwagen, rauchwagenmenge_einh_id, rauchstock, anz_rauchstoecke, menge_rauchstoecke, rauchstoeckemenge_einh_id, anz_rohre, menge_diff_rauchkammer, komm_auftrag_pos_id, flw_ziel_id, flw_arbeitsplatz_mischer_id, basismenge_einh_id, td_insert, td_update)
SELECT CAST(bde_vorgang_id AS INT64) AS bde_vorgang_id, CAST(werk_id AS INT64) AS werk_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(kj AS INT64) AS kj, dat_erfasst, CAST(zeit_erfasst AS INT64) AS zeit_erfasst, CAST(loesch_fg AS INT64) AS loesch_fg, CAST(nettogew AS NUMERIC) AS nettogew, CAST(menge_dme AS NUMERIC) AS menge_dme, dme_einh_id, flw_beleg_typ_id, beleg_gruppe_id, dat_haltbarkeit, CAST(flw_art_id AS INT64) AS flw_art_id, status_mb, CAST(storno_fg AS INT64) AS storno_fg, CAST(menge_bme AS NUMERIC) AS menge_bme, CAST(retourenpos_fg AS INT64) AS retourenpos_fg, auftrag_id, CAST(betrag_bew AS NUMERIC) AS betrag_bew, charge_id, lagerort_id, wrg_id, datzeit_erstellung, min_dat_erfasst, CAST(min_zeit_erfasst AS INT64) AS min_zeit_erfasst, CAST(system_id AS INT64) AS system_id, bestandsart, terminal_id, dat_herstellung, CAST(ext_tiernummer AS INT64) AS ext_tiernummer, CAST(menge_erfasst AS NUMERIC) AS menge_erfasst, erfmenge_einh_id, CAST(bruttogew AS NUMERIC) AS bruttogew, CAST(taragew AS NUMERIC) AS taragew, CAST(schnitt_id AS INT64) AS schnitt_id, um_lagerort_id, CAST(um_flw_art_id AS INT64) AS um_flw_art_id, um_charge_id, CAST(prueflos_id AS INT64) AS prueflos_id, CAST(flw_lief_id AS INT64) AS flw_lief_id, verwendung_ziel_id, CAST(bde_vorgang_id_nachf AS INT64) AS bde_vorgang_id_nachf, CAST(bde_vorgang_id_vorg AS INT64) AS bde_vorgang_id_vorg, CAST(behaelter_id AS INT64) AS behaelter_id, erzeuger_1_id, erzeuger_2_id, CAST(wechsel_id AS INT64) AS wechsel_id, schlachtbetrieb_id, CAST(transport_einheit_id AS INT64) AS transport_einheit_id, dat_schlachtung, dat_zerlegung, CAST(prueflos_id_2 AS INT64) AS prueflos_id_2, CAST(tier_kategorie_id AS INT64) AS tier_kategorie_id, CAST(tier_gattung_id AS INT64) AS tier_gattung_id, CAST(vpap_id AS INT64) AS vpap_id, flw_arbeitsplatz_id, altnv_menge_einh_id, pdao_job_id, lagernummer_id, CAST(lager_beleg_id AS INT64) AS lager_beleg_id, CAST(lager_beleg_pos_id AS INT64) AS lager_beleg_pos_id, CAST(transport_beleg_id AS INT64) AS transport_beleg_id, CAST(transport_beleg_pos_id AS INT64) AS transport_beleg_pos_id, CAST(mfr_transport_einheit_id AS INT64) AS mfr_transport_einheit_id, pdao_bediener_id, flw_arbeitsplatz1_id, nve_id, lief_charge_id, herkunft_id, CAST(flw_bew_grund_id AS INT64) AS flw_bew_grund_id, land_gemaestet_id, land_geschlachtet_id, land_geboren_id, land_zerlegt_id, rauchwagen_id, CAST(menge_rauchwagen AS NUMERIC) AS menge_rauchwagen, rauchwagenmenge_einh_id, rauchstock, CAST(anz_rauchstoecke AS INT64) AS anz_rauchstoecke, CAST(menge_rauchstoecke AS NUMERIC) AS menge_rauchstoecke, rauchstoeckemenge_einh_id, CAST(anz_rohre AS INT64) AS anz_rohre, menge_diff_rauchkammer, komm_auftrag_pos_id, CAST(flw_ziel_id AS INT64) AS flw_ziel_id, flw_arbeitsplatz_mischer_id, basismenge_einh_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_bew`;

-- Table: DBP_DATA.ART_LAGERPLATZ_TAG
insert into `dbp_data.art_lagerplatz_tag` (art_id, mandant_id, dat, lagerplatz_id, lagernummer_id, lagertyp_id, wup_id, nb_id, mlgt_fg, bestand_kz, lagerplatz_loesch_kz, system_id, anzahl_quant, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, dat, lagerplatz_id, lagernummer_id, lagertyp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mlgt_fg AS INT64) AS mlgt_fg, CAST(bestand_kz AS INT64) AS bestand_kz, CAST(lagerplatz_loesch_kz AS INT64) AS lagerplatz_loesch_kz, CAST(system_id AS INT64) AS system_id, CAST(anzahl_quant AS INT64) AS anzahl_quant, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_art_lagerplatz_tag`;

-- Table: DBP_MSI_DATA.VIS_TAG_ABSCHRIFTEN_WG
insert into `dbp_msi_data.vis_tag_abschriften_wg` (mandant_id, wup_id, nb_id, wrg_id, arthiertyp_id, wg_id, dat, abschriftart_id, abt_id, gj, kjmo, kjwo, wtag_id, abschrift_brutto, abschrift_brutto_kvj, abschrift_brutto_wvj, abschrift_netto, abschrift_netto_kvj, abschrift_netto_wvj, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, wrg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, dat, CAST(abschriftart_id AS INT64) AS abschriftart_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(wtag_id AS INT64) AS wtag_id, CAST(abschrift_brutto AS NUMERIC) AS abschrift_brutto, CAST(abschrift_brutto_kvj AS NUMERIC) AS abschrift_brutto_kvj, CAST(abschrift_brutto_wvj AS NUMERIC) AS abschrift_brutto_wvj, CAST(abschrift_netto AS NUMERIC) AS abschrift_netto, CAST(abschrift_netto_kvj AS NUMERIC) AS abschrift_netto_kvj, CAST(abschrift_netto_wvj AS NUMERIC) AS abschrift_netto_wvj, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_abschriften_wg`;

-- Table: DBP_DATA.ART_BEWERTUNGSKREIS_PERIODE
insert into `dbp_data.art_bewertungskreis_periode` (gjmo, art_id, mandant_id, bewertungskreis_id, wrg_id, dat_aenderung, menge_bestand_bme, wert_bestand, vk_wert, mbew_fg, gjmo_bis, bewertung_klasse_id, preis_steuer_kz, gld, standard_preis, dat_letzte_preisaenderung, vk_wert_netto, td_update, td_insert)
SELECT CAST(gjmo AS INT64) AS gjmo, CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, bewertungskreis_id, wrg_id, dat_aenderung, CAST(menge_bestand_bme AS NUMERIC) AS menge_bestand_bme, CAST(wert_bestand AS NUMERIC) AS wert_bestand, CAST(vk_wert AS NUMERIC) AS vk_wert, CAST(mbew_fg AS INT64) AS mbew_fg, CAST(gjmo_bis AS INT64) AS gjmo_bis, bewertung_klasse_id, preis_steuer_kz, CAST(gld AS NUMERIC) AS gld, CAST(standard_preis AS NUMERIC) AS standard_preis, dat_letzte_preisaenderung, CAST(vk_wert_netto AS NUMERIC) AS vk_wert_netto, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_art_bewertungskreis_periode`;

-- Table: DBP_ODS.ODS_BON_SEGMENT
insert into `dbp_ods.ods_bon_segment` (bon_id, wup_id, mandant_id, segment_id, td_insert, td_update)
SELECT bon_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(segment_id AS INT64) AS segment_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_segment`;

-- Table: DBP_DATA.BEST_VORSCHLAG_WBS
insert into `dbp_data.best_vorschlag_wbs` (mandant_id, wup_id, nb_id, art_id, dat_ausfuehrung, ausliefergruppe_id, gondelkopf_fg, zweitplatzierung_fg, aktion_id, gewicht_tag1, gewicht_tag2, gewicht_tag3, gewicht_tag4, gewicht_tag5, gewicht_tag6, gewicht_tag7, gewicht_stunde1, gewicht_stunde2, menge_min_tag1, menge_max_tag1, vz_wup_id, dat_bedarf_von, dat_bedarf_bis, nachversorgung_mgl_fg, dat_letze_nachversorgung, absatz_woche_aktion, abverkauf_projeziert_woche_aktion, abverkauf_projeziert_bestandsperiode, abverkauf_projeziert_bedarfsperiode, menge_lgbest_bme, menge_best_offen_bme, menge_lgbest_projeziert_bme, menge_lgbest_final_bme_min, menge_bedarf_bme, menge_bedarf_ame, menge_auffuell_ame, menge_best_vorl_bme, menge_best_vorl_ame, menge_standardbestand_vz_ame, menge_blockbestand_vz_ame, menge_verfuegbarerbestand_vz_ame, menge_bedarf_sum_ame, fair_share_fg, rang_fair_share, mopro_mhd_fg, clear_stock_fg, rang_clear_stock, abverkauf_durchschnitt_bme, reichweite_zielbestand, reichweite_zielbestand_clear_stock, menge_wbs, ausnahme_pallette_fg, ausnahme_mhd_fg, ausnahme_webeabsatz_fg, menge_lgbest_initial, ausnahme_kolli_fg, zielbestand_akt_bme, zielbestand_akt_bme_updated, dat_lief_wunsch, vz_order_forecast_woche_ame, dispoteilsortiment_id, menge_wbs_pal, best_menge_einh_id_final, order_generated_fg, vz_mandant_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_ausfuehrung, ausliefergruppe_id, CAST(gondelkopf_fg AS INT64) AS gondelkopf_fg, CAST(zweitplatzierung_fg AS INT64) AS zweitplatzierung_fg, aktion_id, CAST(gewicht_tag1 AS NUMERIC) AS gewicht_tag1, CAST(gewicht_tag2 AS NUMERIC) AS gewicht_tag2, CAST(gewicht_tag3 AS NUMERIC) AS gewicht_tag3, CAST(gewicht_tag4 AS NUMERIC) AS gewicht_tag4, CAST(gewicht_tag5 AS NUMERIC) AS gewicht_tag5, CAST(gewicht_tag6 AS NUMERIC) AS gewicht_tag6, CAST(gewicht_tag7 AS NUMERIC) AS gewicht_tag7, CAST(gewicht_stunde1 AS NUMERIC) AS gewicht_stunde1, CAST(gewicht_stunde2 AS NUMERIC) AS gewicht_stunde2, CAST(menge_min_tag1 AS INT64) AS menge_min_tag1, CAST(menge_max_tag1 AS INT64) AS menge_max_tag1, CAST(vz_wup_id AS INT64) AS vz_wup_id, dat_bedarf_von, dat_bedarf_bis, CAST(nachversorgung_mgl_fg AS INT64) AS nachversorgung_mgl_fg, dat_letze_nachversorgung, CAST(absatz_woche_aktion AS NUMERIC) AS absatz_woche_aktion, CAST(abverkauf_projeziert_woche_aktion AS NUMERIC) AS abverkauf_projeziert_woche_aktion, CAST(abverkauf_projeziert_bestandsperiode AS NUMERIC) AS abverkauf_projeziert_bestandsperiode, CAST(abverkauf_projeziert_bedarfsperiode AS NUMERIC) AS abverkauf_projeziert_bedarfsperiode, CAST(menge_lgbest_bme AS NUMERIC) AS menge_lgbest_bme, CAST(menge_best_offen_bme AS NUMERIC) AS menge_best_offen_bme, CAST(menge_lgbest_projeziert_bme AS NUMERIC) AS menge_lgbest_projeziert_bme, CAST(menge_lgbest_final_bme_min AS NUMERIC) AS menge_lgbest_final_bme_min, CAST(menge_bedarf_bme AS NUMERIC) AS menge_bedarf_bme, CAST(menge_bedarf_ame AS NUMERIC) AS menge_bedarf_ame, CAST(menge_auffuell_ame AS NUMERIC) AS menge_auffuell_ame, CAST(menge_best_vorl_bme AS NUMERIC) AS menge_best_vorl_bme, CAST(menge_best_vorl_ame AS NUMERIC) AS menge_best_vorl_ame, CAST(menge_standardbestand_vz_ame AS NUMERIC) AS menge_standardbestand_vz_ame, CAST(menge_blockbestand_vz_ame AS NUMERIC) AS menge_blockbestand_vz_ame, CAST(menge_verfuegbarerbestand_vz_ame AS NUMERIC) AS menge_verfuegbarerbestand_vz_ame, CAST(menge_bedarf_sum_ame AS NUMERIC) AS menge_bedarf_sum_ame, CAST(fair_share_fg AS INT64) AS fair_share_fg, CAST(rang_fair_share AS INT64) AS rang_fair_share, CAST(mopro_mhd_fg AS INT64) AS mopro_mhd_fg, CAST(clear_stock_fg AS INT64) AS clear_stock_fg, CAST(rang_clear_stock AS INT64) AS rang_clear_stock, CAST(abverkauf_durchschnitt_bme AS NUMERIC) AS abverkauf_durchschnitt_bme, CAST(reichweite_zielbestand AS NUMERIC) AS reichweite_zielbestand, CAST(reichweite_zielbestand_clear_stock AS NUMERIC) AS reichweite_zielbestand_clear_stock, CAST(menge_wbs AS NUMERIC) AS menge_wbs, CAST(ausnahme_pallette_fg AS INT64) AS ausnahme_pallette_fg, CAST(ausnahme_mhd_fg AS INT64) AS ausnahme_mhd_fg, CAST(ausnahme_webeabsatz_fg AS INT64) AS ausnahme_webeabsatz_fg, CAST(menge_lgbest_initial AS NUMERIC) AS menge_lgbest_initial, CAST(ausnahme_kolli_fg AS INT64) AS ausnahme_kolli_fg, CAST(zielbestand_akt_bme AS NUMERIC) AS zielbestand_akt_bme, CAST(zielbestand_akt_bme_updated AS NUMERIC) AS zielbestand_akt_bme_updated, dat_lief_wunsch, CAST(vz_order_forecast_woche_ame AS NUMERIC) AS vz_order_forecast_woche_ame, dispoteilsortiment_id, CAST(menge_wbs_pal AS NUMERIC) AS menge_wbs_pal, best_menge_einh_id_final, CAST(order_generated_fg AS INT64) AS order_generated_fg, CAST(vz_mandant_id AS INT64) AS vz_mandant_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_best_vorschlag_wbs`;

-- Table: DBP_DATA.LAGERAUFTRAG
insert into `dbp_data.lagerauftrag` (mandant_id, lagernummer_id, lagerauftrag_id, wcr_id, wcr_typ_id, lagerprozessart_id_belegkopf, welle_id, lagerauftrag_status_id, aktivitaetsbereich_id, lagertyp_id, lagerplatz_id, queue_id, startzeit_fixiert_fg, ressource_id, manuelle_zuordnung_fg, inventur_fg, lagerauftrag_id_split, split_fg, lagerplatz_id_start, lagerauftrag_bez, handling_unit_id_joining, nachschub_option_id, dauer_geplant, menge_einh_id, lagerauftrag_guid, datzeit_start, datzeit_start_max, datzeit_erstellung, datzeit_bestaetigung, datzeit_aenderung, datzeit_lsd_berechnung, lsd_berechnungsart_id, dat_bereitstellung, zeit_bereitstellung, datzeit_bereitstellung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(lagerauftrag_id AS INT64) AS lagerauftrag_id, wcr_id, wcr_typ_id, lagerprozessart_id_belegkopf, CAST(welle_id AS INT64) AS welle_id, lagerauftrag_status_id, aktivitaetsbereich_id, lagertyp_id, lagerplatz_id, queue_id, CAST(startzeit_fixiert_fg AS INT64) AS startzeit_fixiert_fg, ressource_id, CAST(manuelle_zuordnung_fg AS INT64) AS manuelle_zuordnung_fg, CAST(inventur_fg AS INT64) AS inventur_fg, CAST(lagerauftrag_id_split AS INT64) AS lagerauftrag_id_split, CAST(split_fg AS INT64) AS split_fg, lagerplatz_id_start, lagerauftrag_bez, handling_unit_id_joining, CAST(nachschub_option_id AS INT64) AS nachschub_option_id, CAST(dauer_geplant AS INT64) AS dauer_geplant, menge_einh_id, lagerauftrag_guid, datzeit_start, datzeit_start_max, datzeit_erstellung, datzeit_bestaetigung, datzeit_aenderung, datzeit_lsd_berechnung, lsd_berechnungsart_id, dat_bereitstellung, zeit_bereitstellung, datzeit_bereitstellung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerauftrag`;

-- Table: DBP_DATA.SHOPPER
insert into `dbp_data.shopper` (wup_id, nb_id, mandant_id, art_id_werbung, baseline, kjwo_werbe_ende, dat_baseline_von, dat_baseline_bis, anz_markt_baseline_af, ums_netto_baseline_af, ums_netto_sa, menge_baseline_af, menge_sa, ertrag_baseline_af, ertrag_sa, anz_kaeufer_af, anz_kaeufer_sa, anz_bon_af, anz_bon_sa, anz_bon_aktion, anz_tage_baseline_af, anz_tage_sa, kaeufer_prozent_baseline_af, kaeufer_prozent_sa, anz_cp_kaeufer, anz_cp_kaeufer_70_prozent, ums_rest_bon_af, ums_rest_bon_gesamt, ums_aktivierter_normalpreis, wrg_id, aktion_thema_gruppe_id, medien_kz, menge_wo1, menge_wo2, menge_wo3, anz_tage_wo1, anz_tage_wo2, anz_tage_wo3, vk_brutto_af_mittel, vk_brutto_sa_mittel, ums_gesamt_ausser_artikel, ums_gesamt_af_mit_wv, anz_markt_sa, vk_brutto_sa_max, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id_werbung AS INT64) AS art_id_werbung, CAST(baseline AS INT64) AS baseline, CAST(kjwo_werbe_ende AS INT64) AS kjwo_werbe_ende, dat_baseline_von, dat_baseline_bis, CAST(anz_markt_baseline_af AS INT64) AS anz_markt_baseline_af, CAST(ums_netto_baseline_af AS NUMERIC) AS ums_netto_baseline_af, CAST(ums_netto_sa AS NUMERIC) AS ums_netto_sa, CAST(menge_baseline_af AS NUMERIC) AS menge_baseline_af, CAST(menge_sa AS NUMERIC) AS menge_sa, CAST(ertrag_baseline_af AS NUMERIC) AS ertrag_baseline_af, CAST(ertrag_sa AS NUMERIC) AS ertrag_sa, CAST(anz_kaeufer_af AS INT64) AS anz_kaeufer_af, CAST(anz_kaeufer_sa AS INT64) AS anz_kaeufer_sa, CAST(anz_bon_af AS INT64) AS anz_bon_af, CAST(anz_bon_sa AS INT64) AS anz_bon_sa, CAST(anz_bon_aktion AS INT64) AS anz_bon_aktion, CAST(anz_tage_baseline_af AS INT64) AS anz_tage_baseline_af, CAST(anz_tage_sa AS INT64) AS anz_tage_sa, CAST(kaeufer_prozent_baseline_af AS NUMERIC) AS kaeufer_prozent_baseline_af, CAST(kaeufer_prozent_sa AS NUMERIC) AS kaeufer_prozent_sa, CAST(anz_cp_kaeufer AS INT64) AS anz_cp_kaeufer, CAST(anz_cp_kaeufer_70_prozent AS INT64) AS anz_cp_kaeufer_70_prozent, CAST(ums_rest_bon_af AS NUMERIC) AS ums_rest_bon_af, CAST(ums_rest_bon_gesamt AS NUMERIC) AS ums_rest_bon_gesamt, CAST(ums_aktivierter_normalpreis AS NUMERIC) AS ums_aktivierter_normalpreis, wrg_id, CAST(aktion_thema_gruppe_id AS INT64) AS aktion_thema_gruppe_id, medien_kz, CAST(menge_wo1 AS NUMERIC) AS menge_wo1, CAST(menge_wo2 AS NUMERIC) AS menge_wo2, CAST(menge_wo3 AS NUMERIC) AS menge_wo3, CAST(anz_tage_wo1 AS INT64) AS anz_tage_wo1, CAST(anz_tage_wo2 AS INT64) AS anz_tage_wo2, CAST(anz_tage_wo3 AS INT64) AS anz_tage_wo3, CAST(vk_brutto_af_mittel AS NUMERIC) AS vk_brutto_af_mittel, CAST(vk_brutto_sa_mittel AS NUMERIC) AS vk_brutto_sa_mittel, CAST(ums_gesamt_ausser_artikel AS NUMERIC) AS ums_gesamt_ausser_artikel, CAST(ums_gesamt_af_mit_wv AS NUMERIC) AS ums_gesamt_af_mit_wv, CAST(anz_markt_sa AS INT64) AS anz_markt_sa, CAST(vk_brutto_sa_max AS NUMERIC) AS vk_brutto_sa_max, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_shopper`;

-- Table: DBP_DATA.BEST_OFFEN
insert into `dbp_data.best_offen` (mandant_id, best_beleg_id, best_beleg_pos_id, wup_id, nb_id, gp_id, art_id, dat_best_beleg, dat_lief_wunsch, kunde_id, nb_id_kunde, einkaufsorganisation_id, einkaeufer_grp_id, menge_best, menge_einh_id, menge_lief_ist, endlief_fg, menge_offen, bestellart_id, dat_generierung, block_stock_fg, cpo_fg, best_aend_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, CAST(art_id AS INT64) AS art_id, dat_best_beleg, dat_lief_wunsch, CAST(kunde_id AS INT64) AS kunde_id, CAST(nb_id_kunde AS INT64) AS nb_id_kunde, CAST(einkaufsorganisation_id AS INT64) AS einkaufsorganisation_id, einkaeufer_grp_id, CAST(menge_best AS NUMERIC) AS menge_best, menge_einh_id, CAST(menge_lief_ist AS NUMERIC) AS menge_lief_ist, CAST(endlief_fg AS INT64) AS endlief_fg, CAST(menge_offen AS NUMERIC) AS menge_offen, bestellart_id, dat_generierung, CAST(block_stock_fg AS INT64) AS block_stock_fg, CAST(cpo_fg AS INT64) AS cpo_fg, best_aend_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_best_offen`;

-- Table: DBP_DATA.BESCH_LIEF_WG_WUP
insert into `dbp_data.besch_lief_wg_wup` (mandant_id, wup_id, nb_id, lagerort_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, wg_id, arthiertyp_id, kunde_id, wg_verkett_lief, menge_lief_soll_bme, menge_lief_soll_kolli, betrag_lief_soll, menge_lief_ist_bme, menge_lief_ist_kolli, betrag_lief_ist, lief_pal_typ_id, anzahl_position, wrg_id, mandant_id_kunde, vk_netto_lief_soll, vk_netto_lief_ist, werbeware_id, bestellart_id, hu_status_id, anzahl_packstueck, brtvol_ladung_liter, brtvol_ladung_liter_gedeckelt, auslieferungsgruppe_id, ntvol_ladung_liter, ntvol_ladung_liter_gedeckelt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagerort_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, kunde_id, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, CAST(menge_lief_soll_bme AS NUMERIC) AS menge_lief_soll_bme, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, CAST(betrag_lief_soll AS NUMERIC) AS betrag_lief_soll, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(betrag_lief_ist AS NUMERIC) AS betrag_lief_ist, lief_pal_typ_id, CAST(anzahl_position AS INT64) AS anzahl_position, wrg_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, CAST(vk_netto_lief_soll AS NUMERIC) AS vk_netto_lief_soll, CAST(vk_netto_lief_ist AS NUMERIC) AS vk_netto_lief_ist, werbeware_id, bestellart_id, hu_status_id, CAST(anzahl_packstueck AS INT64) AS anzahl_packstueck, CAST(brtvol_ladung_liter AS NUMERIC) AS brtvol_ladung_liter, CAST(brtvol_ladung_liter_gedeckelt AS NUMERIC) AS brtvol_ladung_liter_gedeckelt, auslieferungsgruppe_id, CAST(ntvol_ladung_liter AS NUMERIC) AS ntvol_ladung_liter, CAST(ntvol_ladung_liter_gedeckelt AS NUMERIC) AS ntvol_ladung_liter_gedeckelt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_wg_wup`;

-- Table: DBP_DATA.AOF_PROGNOSE
insert into `dbp_data.aof_prognose` (mandant_id, wup_id, nb_id, art_id, zeitreihenart, dat_prognoselauf, dat, menge, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, zeitreihenart, dat_prognoselauf, dat, CAST(menge AS NUMERIC) AS menge, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_aof_prognose`;

-- Table: DBP_DATA.BSCH_BESTVOR_DET
insert into `dbp_data.bsch_bestvor_det` (mandant_id, best_vor_nr, best_vor_pos, dat_plan, art_id, gp_id, menge_best_vor, menge_best, status, best_vor_einh, best_einh, wup_id, nb_id, bestellart_id, dat_lief_soll, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(best_vor_nr AS INT64) AS best_vor_nr, CAST(best_vor_pos AS INT64) AS best_vor_pos, dat_plan, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, CAST(menge_best_vor AS NUMERIC) AS menge_best_vor, CAST(menge_best AS NUMERIC) AS menge_best, status, CAST(best_vor_einh AS INT64) AS best_vor_einh, CAST(best_einh AS INT64) AS best_einh, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, bestellart_id, dat_lief_soll, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_bsch_bestvor_det`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_HU_LIEF_ZU
insert into `dbp_data.transportation_unit_hu_lief_zu` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, transportation_unit_seq_id, compartment_hu_guid, ladeposition, lagernummer_id, beleg_guid, beleg_pos_guid, belegtyp_id, beleg_id, beleg_pos_id, zuordnungsart_id, top_hu_guid, top_hu_id, cross_hu_fg, change_fg, status_fg, datzeit_erstellung, datzeit_aenderung, auslieferung_exist_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, CAST(transportation_unit_seq_id AS INT64) AS transportation_unit_seq_id, compartment_hu_guid, CAST(ladeposition AS INT64) AS ladeposition, lagernummer_id, beleg_guid, beleg_pos_guid, belegtyp_id, CAST(beleg_id AS INT64) AS beleg_id, CAST(beleg_pos_id AS INT64) AS beleg_pos_id, zuordnungsart_id, top_hu_guid, top_hu_id, cross_hu_fg, change_fg, status_fg, datzeit_erstellung, datzeit_aenderung, auslieferung_exist_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_hu_lief_zu`;

-- Table: DBP_DATA.TRANSPORTAUFTRAG
insert into `dbp_data.transportauftrag` (mandant_id, transport_beleg_id, lagernummer_id, wup_id, nb_id, dat_erstellung, zeit_erstellung, dat_quittierung, transportart_id, system_id, lvs_bewart_id, lief_beleg_id, ta_prio, dat_prio_upd, zeit_prio_upd, kj_lief_beleg, anz_pos_ta, datzeit_start_ta, datzeit_end_ta, referenznummer, dat_bereitstellung, datzeit_bereitstellung, wg_verkett_id, werbeware_id, lief_pal_typ_id, dat_lief_soll, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transport_beleg_id AS INT64) AS transport_beleg_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_erstellung, CAST(zeit_erstellung AS INT64) AS zeit_erstellung, dat_quittierung, transportart_id, CAST(system_id AS INT64) AS system_id, CAST(lvs_bewart_id AS INT64) AS lvs_bewart_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(ta_prio AS INT64) AS ta_prio, dat_prio_upd, CAST(zeit_prio_upd AS INT64) AS zeit_prio_upd, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, anz_pos_ta, CAST(datzeit_start_ta AS DATETIME) AS datzeit_start_ta, CAST(datzeit_end_ta AS DATETIME) AS datzeit_end_ta, CAST(referenznummer AS INT64) AS referenznummer, dat_bereitstellung, CAST(datzeit_bereitstellung AS DATETIME) AS datzeit_bereitstellung, CAST(wg_verkett_id AS INT64) AS wg_verkett_id, werbeware_id, lief_pal_typ_id, dat_lief_soll, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportauftrag`;

-- Table: DBP_ETL_PROCESS.QUERY_HISTORY_CREDITS
insert into `dbp_etl_process.query_history_credits` (session_id, query_id, role_name, warehouse_id, warehouse_name, warehouse_size, warehouse_type, query_text, query_tag, query_type, execution_status, error_code, error_message, start_time, end_time, total_elapsed_time, bytes_scanned, percentage_scanned_from_cache, bytes_written, bytes_written_to_result, bytes_read_from_result, rows_produced, rows_inserted, rows_updated, rows_deleted, rows_unloaded, bytes_deleted, bytes_spilled_to_local_storage, bytes_spilled_to_remote_storage, bytes_sent_over_the_network, compilation_time, execution_time, queued_provisioning_time, queued_repair_time, queued_overload_time, transaction_blocked_time, outbound_data_transfer_cloud, outbound_data_transfer_region, outbound_data_transfer_bytes, inbound_data_transfer_cloud, inbound_data_transfer_region, inbound_data_transfer_bytes, list_external_files_time, credits_used_cloud_services, release_version, external_function_total_invocations, external_function_total_sent_rows, external_function_total_received_rows, external_function_total_received_bytes, query_load_percent, is_client_generated_statement, database_name, query_hash, query_hash_version, query_parameterized_hash, query_parameterized_hash_version, sparte, job, date_credits, cpusecs, credits_query)
SELECT CAST(session_id AS INT64) AS session_id, query_id, role_name, CAST(warehouse_id AS INT64) AS warehouse_id, warehouse_name, warehouse_size, warehouse_type, query_text, query_tag, query_type, execution_status, error_code, error_message, CAST(start_time AS DATETIME) AS start_time, CAST(end_time AS DATETIME) AS end_time, CAST(total_elapsed_time AS INT64) AS total_elapsed_time, CAST(bytes_scanned AS INT64) AS bytes_scanned, percentage_scanned_from_cache, CAST(bytes_written AS INT64) AS bytes_written, CAST(bytes_written_to_result AS INT64) AS bytes_written_to_result, CAST(bytes_read_from_result AS INT64) AS bytes_read_from_result, CAST(rows_produced AS INT64) AS rows_produced, CAST(rows_inserted AS INT64) AS rows_inserted, CAST(rows_updated AS INT64) AS rows_updated, CAST(rows_deleted AS INT64) AS rows_deleted, CAST(rows_unloaded AS INT64) AS rows_unloaded, CAST(bytes_deleted AS INT64) AS bytes_deleted, CAST(bytes_spilled_to_local_storage AS INT64) AS bytes_spilled_to_local_storage, CAST(bytes_spilled_to_remote_storage AS INT64) AS bytes_spilled_to_remote_storage, CAST(bytes_sent_over_the_network AS INT64) AS bytes_sent_over_the_network, CAST(compilation_time AS INT64) AS compilation_time, CAST(execution_time AS INT64) AS execution_time, CAST(queued_provisioning_time AS INT64) AS queued_provisioning_time, CAST(queued_repair_time AS INT64) AS queued_repair_time, CAST(queued_overload_time AS INT64) AS queued_overload_time, CAST(transaction_blocked_time AS INT64) AS transaction_blocked_time, outbound_data_transfer_cloud, outbound_data_transfer_region, CAST(outbound_data_transfer_bytes AS INT64) AS outbound_data_transfer_bytes, inbound_data_transfer_cloud, inbound_data_transfer_region, CAST(inbound_data_transfer_bytes AS INT64) AS inbound_data_transfer_bytes, CAST(list_external_files_time AS INT64) AS list_external_files_time, credits_used_cloud_services, release_version, CAST(external_function_total_invocations AS INT64) AS external_function_total_invocations, CAST(external_function_total_sent_rows AS INT64) AS external_function_total_sent_rows, CAST(external_function_total_received_rows AS INT64) AS external_function_total_received_rows, CAST(external_function_total_received_bytes AS INT64) AS external_function_total_received_bytes, CAST(query_load_percent AS INT64) AS query_load_percent, is_client_generated_statement, database_name, query_hash, CAST(query_hash_version AS INT64) AS query_hash_version, query_parameterized_hash, CAST(query_parameterized_hash_version AS INT64) AS query_parameterized_hash_version, sparte, job, date_credits, CAST(cpusecs AS INT64) AS cpusecs, credits_query
FROM `snowflake_snapshots.kfl_dbp_etl_process_query_history_credits`;

-- Table: DBP_DATA.LAGERPLATZ_EWM_PER
insert into `dbp_data.lagerplatz_ewm_per` (mandant_id, lagernummer_id, lagerplatz_id, datzeit_von, datzeit_bis, lagertyp_id, lagerbereich_id, lagerplatztyp_id, lagerplatz_zugriffstyp_id, lagerplatz_aufteilung_id, lagerplatz_position, auslagerung_sperr_fg, einlagerung_sperr_fg, inventur_block_fg, aufgeteilt_fg, anz_hu, anz_hu_max, gewicht_max, gew_einh_id, gewicht, volumen_netto, volumen_max, vol_einh_id, kapa_max, kapa_frei, leer_fg, voll_fg, dat_erste_einlagerung, datzeit_letzte_bewegung, lageraufgabe_id_letzte_bew, brandabschnitt_id, datzeit_aenderung, haupt_lagerplatz_id, loc_guid, handling_unit_guid, gang_id, saeule_id, ebene_id, x_koordinate, y_koordinate, z_koordinate, lagernereich_lgst_id, feldtyp_id, regaltyp_id, wa_lane_kapa, we_lane_kapa, kapa_erh_fg, tiefe_frei, tiefe_max, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, lagerplatz_id, datzeit_von, datzeit_bis, lagertyp_id, lagerbereich_id, lagerplatztyp_id, lagerplatz_zugriffstyp_id, lagerplatz_aufteilung_id, lagerplatz_position, CAST(auslagerung_sperr_fg AS INT64) AS auslagerung_sperr_fg, CAST(einlagerung_sperr_fg AS INT64) AS einlagerung_sperr_fg, CAST(inventur_block_fg AS INT64) AS inventur_block_fg, CAST(aufgeteilt_fg AS INT64) AS aufgeteilt_fg, CAST(anz_hu AS INT64) AS anz_hu, CAST(anz_hu_max AS INT64) AS anz_hu_max, CAST(gewicht_max AS NUMERIC) AS gewicht_max, gew_einh_id, CAST(gewicht AS NUMERIC) AS gewicht, CAST(volumen_netto AS NUMERIC) AS volumen_netto, CAST(volumen_max AS NUMERIC) AS volumen_max, vol_einh_id, CAST(kapa_max AS NUMERIC) AS kapa_max, CAST(kapa_frei AS NUMERIC) AS kapa_frei, CAST(leer_fg AS INT64) AS leer_fg, CAST(voll_fg AS INT64) AS voll_fg, dat_erste_einlagerung, datzeit_letzte_bewegung, CAST(lageraufgabe_id_letzte_bew AS INT64) AS lageraufgabe_id_letzte_bew, brandabschnitt_id, datzeit_aenderung, haupt_lagerplatz_id, loc_guid, handling_unit_guid, CAST(gang_id AS INT64) AS gang_id, CAST(saeule_id AS INT64) AS saeule_id, ebene_id, CAST(x_koordinate AS NUMERIC) AS x_koordinate, CAST(y_koordinate AS NUMERIC) AS y_koordinate, CAST(z_koordinate AS NUMERIC) AS z_koordinate, lagernereich_lgst_id, feldtyp_id, regaltyp_id, CAST(wa_lane_kapa AS NUMERIC) AS wa_lane_kapa, CAST(we_lane_kapa AS NUMERIC) AS we_lane_kapa, CAST(kapa_erh_fg AS INT64) AS kapa_erh_fg, CAST(tiefe_frei AS INT64) AS tiefe_frei, CAST(tiefe_max AS INT64) AS tiefe_max, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerplatz_ewm_per`;

-- Table: DBP_DATA.T_FACT_IOT_COMPOUND
insert into `dbp_data.t_fact_iot_compound` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, liquefactiontemp_actual_meas, liquefactiontemp_setpoint_meas, roomtemp_meas, evaporationtemp_actual_meas, evaporation_pressure_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(liquefactiontemp_actual_meas AS NUMERIC) AS liquefactiontemp_actual_meas, CAST(liquefactiontemp_setpoint_meas AS NUMERIC) AS liquefactiontemp_setpoint_meas, CAST(roomtemp_meas AS NUMERIC) AS roomtemp_meas, CAST(evaporationtemp_actual_meas AS NUMERIC) AS evaporationtemp_actual_meas, CAST(evaporation_pressure_meas AS NUMERIC) AS evaporation_pressure_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_compound`;

-- Table: DBP_DATA.STATUSMELDUNG
insert into `dbp_data.statusmeldung` (system_id, mandant_id, statusmeldung_id, statuscode_id, beleg_gj, beleg_id, ecm_vorgang, ursprung_beleg_id, ursprung_beleg_gj, ersteller_id, gp_id, einkaufsorganisation_id, auto_fg, betrag_brutto, betrag_mwst, wrg_id, quellsystem_id, belegklasse_id, fi_beleg_id, beleg_id_orig, beleg_gj_orig, edi_nr_orig, loesch_fg, edi_nr, dat_erfasst, dat_beleg, dat_buch, manuelle_buchung_fg, last_gp_id, imprint_nr, imprint_nr_orig, zeitstempel, statusmeldung_ecm_lfd_nr, last_fg, dat, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, statusmeldung_id, CAST(statuscode_id AS INT64) AS statuscode_id, CAST(beleg_gj AS INT64) AS beleg_gj, CAST(beleg_id AS INT64) AS beleg_id, CAST(ecm_vorgang AS INT64) AS ecm_vorgang, CAST(ursprung_beleg_id AS INT64) AS ursprung_beleg_id, CAST(ursprung_beleg_gj AS INT64) AS ursprung_beleg_gj, CAST(ersteller_id AS INT64) AS ersteller_id, CAST(gp_id AS INT64) AS gp_id, CAST(einkaufsorganisation_id AS INT64) AS einkaufsorganisation_id, CAST(auto_fg AS INT64) AS auto_fg, CAST(betrag_brutto AS NUMERIC) AS betrag_brutto, CAST(betrag_mwst AS NUMERIC) AS betrag_mwst, wrg_id, quellsystem_id, belegklasse_id, CAST(fi_beleg_id AS INT64) AS fi_beleg_id, CAST(beleg_id_orig AS INT64) AS beleg_id_orig, CAST(beleg_gj_orig AS INT64) AS beleg_gj_orig, CAST(edi_nr_orig AS INT64) AS edi_nr_orig, CAST(loesch_fg AS INT64) AS loesch_fg, CAST(edi_nr AS INT64) AS edi_nr, dat_erfasst, dat_beleg, dat_buch, CAST(manuelle_buchung_fg AS INT64) AS manuelle_buchung_fg, CAST(last_gp_id AS INT64) AS last_gp_id, imprint_nr, imprint_nr_orig, zeitstempel, CAST(statusmeldung_ecm_lfd_nr AS INT64) AS statusmeldung_ecm_lfd_nr, CAST(last_fg AS INT64) AS last_fg, dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_statusmeldung`;

-- Table: DBP_DATA.PROBLEMMELDUNG
insert into `dbp_data.problemmeldung` (system_id, mandant_id, problemmeldung_id, beleg_pos_id, ecm_vorgang, problemcode_id, zeitstempel, belegklasse_id, ursprung_beleg_id, ursprung_beleg_pos_id, ursprung_beleg_gj, gp_rech_id, gp_rech_pos_id, auto_fg, loesch_fg, gp_id, einkaufsorganisation_id, art_id, wup_id, nb_id, betrag_brutto, betrag_netto, betrag_mwst, wrg_id, ersteller_id, verursacher_id, zek_id, imprint_nr_orig, beleg_id_orig, beleg_gj_orig, edi_nr_orig, imprint_nr, edi_nr, beleg_id, beleg_gj, dat_erfasst, dat_beleg, dat_buch, manuelle_buchung_fg, last_gp_id, prozessbereich_id, problemmeldung_ecm_lfd_nr, last_fg, dat, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, problemmeldung_id, CAST(beleg_pos_id AS INT64) AS beleg_pos_id, CAST(ecm_vorgang AS INT64) AS ecm_vorgang, problemcode_id, zeitstempel, belegklasse_id, CAST(ursprung_beleg_id AS INT64) AS ursprung_beleg_id, CAST(ursprung_beleg_pos_id AS INT64) AS ursprung_beleg_pos_id, CAST(ursprung_beleg_gj AS INT64) AS ursprung_beleg_gj, gp_rech_id, CAST(gp_rech_pos_id AS INT64) AS gp_rech_pos_id, CAST(auto_fg AS INT64) AS auto_fg, CAST(loesch_fg AS INT64) AS loesch_fg, CAST(gp_id AS INT64) AS gp_id, CAST(einkaufsorganisation_id AS INT64) AS einkaufsorganisation_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(betrag_brutto AS NUMERIC) AS betrag_brutto, CAST(betrag_netto AS NUMERIC) AS betrag_netto, CAST(betrag_mwst AS NUMERIC) AS betrag_mwst, wrg_id, CAST(ersteller_id AS INT64) AS ersteller_id, CAST(verursacher_id AS INT64) AS verursacher_id, zek_id, imprint_nr_orig, CAST(beleg_id_orig AS INT64) AS beleg_id_orig, CAST(beleg_gj_orig AS INT64) AS beleg_gj_orig, CAST(edi_nr_orig AS INT64) AS edi_nr_orig, imprint_nr, CAST(edi_nr AS INT64) AS edi_nr, CAST(beleg_id AS INT64) AS beleg_id, CAST(beleg_gj AS INT64) AS beleg_gj, dat_erfasst, dat_beleg, dat_buch, CAST(manuelle_buchung_fg AS INT64) AS manuelle_buchung_fg, CAST(last_gp_id AS INT64) AS last_gp_id, prozessbereich_id, CAST(problemmeldung_ecm_lfd_nr AS INT64) AS problemmeldung_ecm_lfd_nr, CAST(last_fg AS INT64) AS last_fg, dat, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_problemmeldung`;

-- Table: DBP_DATA.WBS_ART_AKTION_PER
insert into `dbp_data.wbs_art_aktion_per` (mandant_id, wup_id, nb_id, art_id, aktion_id, kjwo_von, dat_von, dat_bis, aktion_dauer, wtag_id_von, mutter_wb_id, mandant_id_vz, wup_id_vz, menge_sa_bme, menge_gesamt_bme, zeitraum_korrigierte_menge, zeitraum_menge_af_4wo, sales_fg, in_gruppe_fg, anz_art_in_gruppe, tv_fg, titelseite_fg, rueckseite_fg, gk_fg, vk_aktion_brutto, vk_vor_aktion_brutto, wrg_id, multi_offer_id_fg, bonuskauf_fg, lokale_geschaeftsvorfall_bez, berechnete_menge_gesamt_bme, lief_menge_initial_bme, lief_menge_hochrechnung_bme, lief_menge_anteil_prozent, nur_online_fg, kundenkarte_personalisiert_fg, stille_aktion_fg, stille_aktion_mit_menge_fg, werbeflaeche_abschnitt_name, werbeflaeche_thema_bez, fixmenge_fg, fixmenge_wfl_fg, mindestplatzierung_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, aktion_id, CAST(kjwo_von AS INT64) AS kjwo_von, dat_von, dat_bis, CAST(aktion_dauer AS INT64) AS aktion_dauer, CAST(wtag_id_von AS INT64) AS wtag_id_von, CAST(mutter_wb_id AS INT64) AS mutter_wb_id, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(menge_sa_bme AS NUMERIC) AS menge_sa_bme, CAST(menge_gesamt_bme AS NUMERIC) AS menge_gesamt_bme, CAST(zeitraum_korrigierte_menge AS NUMERIC) AS zeitraum_korrigierte_menge, CAST(zeitraum_menge_af_4wo AS NUMERIC) AS zeitraum_menge_af_4wo, CAST(sales_fg AS INT64) AS sales_fg, CAST(in_gruppe_fg AS INT64) AS in_gruppe_fg, CAST(anz_art_in_gruppe AS INT64) AS anz_art_in_gruppe, CAST(tv_fg AS INT64) AS tv_fg, CAST(titelseite_fg AS INT64) AS titelseite_fg, CAST(rueckseite_fg AS INT64) AS rueckseite_fg, CAST(gk_fg AS INT64) AS gk_fg, CAST(vk_aktion_brutto AS NUMERIC) AS vk_aktion_brutto, CAST(vk_vor_aktion_brutto AS NUMERIC) AS vk_vor_aktion_brutto, wrg_id, CAST(multi_offer_id_fg AS INT64) AS multi_offer_id_fg, CAST(bonuskauf_fg AS INT64) AS bonuskauf_fg, lokale_geschaeftsvorfall_bez, CAST(berechnete_menge_gesamt_bme AS NUMERIC) AS berechnete_menge_gesamt_bme, CAST(lief_menge_initial_bme AS NUMERIC) AS lief_menge_initial_bme, CAST(lief_menge_hochrechnung_bme AS NUMERIC) AS lief_menge_hochrechnung_bme, CAST(lief_menge_anteil_prozent AS NUMERIC) AS lief_menge_anteil_prozent, CAST(nur_online_fg AS INT64) AS nur_online_fg, CAST(kundenkarte_personalisiert_fg AS INT64) AS kundenkarte_personalisiert_fg, CAST(stille_aktion_fg AS INT64) AS stille_aktion_fg, CAST(stille_aktion_mit_menge_fg AS INT64) AS stille_aktion_mit_menge_fg, werbeflaeche_abschnitt_name, werbeflaeche_thema_bez, CAST(fixmenge_fg AS INT64) AS fixmenge_fg, CAST(fixmenge_wfl_fg AS INT64) AS fixmenge_wfl_fg, CAST(mindestplatzierung_fg AS INT64) AS mindestplatzierung_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_art_aktion_per`;

-- Table: DBP_DATA.COI_UMP_UMSATZPLAN_MASSNAHMEN_ZU
insert into `dbp_data.coi_ump_umsatzplan_massnahmen_zu` (mandant_id, gj_plan, version_id, wup_id, nb_id, dat_plan, arthiertyp_id, hwg_id, massnahme_art_id, massnahme_typ_bez, massnahme_id, wrg_id, massnahme_art_bez, massnahme_auswirkung_bez, faktor, wert, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(gj_plan AS INT64) AS gj_plan, CAST(version_id AS INT64) AS version_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_plan, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(massnahme_art_id AS INT64) AS massnahme_art_id, massnahme_typ_bez, CAST(massnahme_id AS INT64) AS massnahme_id, wrg_id, massnahme_art_bez, massnahme_auswirkung_bez, CAST(faktor AS NUMERIC) AS faktor, CAST(wert AS NUMERIC) AS wert, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_coi_ump_umsatzplan_massnahmen_zu`;

-- Table: DBP_DATA.BESCH_LIEF_ARBEITSBEREICHE
insert into `dbp_data.besch_lief_arbeitsbereiche` (mandant_id, lagerort_id, wup_id, nb_id, kunde_id, wtag_id, dat_lief_soll, wg_id, arthiertyp_id, disponent_id, wg_verkett_id, disposition_rhythmus_ltf_id, terminierungsgruppe_1_id, terminierungsgruppe_2_id, terminierungsgruppe_3_id, auslieferungsgruppe_id, kunde_bez, disposition_rhythmus_id, disponent_name, wup_standort, bestellart_id, lief_pal_typ_id, diff_id, menge_lief_ist_kolli, menge_lief_soll_kolli, betrag_lief_ist, betrag_lief_soll, menge_lief_palette, mandant_id_kunde, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagerort_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wtag_id AS INT64) AS wtag_id, dat_lief_soll, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, disponent_id, CAST(wg_verkett_id AS INT64) AS wg_verkett_id, disposition_rhythmus_ltf_id, terminierungsgruppe_1_id, terminierungsgruppe_2_id, terminierungsgruppe_3_id, auslieferungsgruppe_id, kunde_bez, disposition_rhythmus_id, disponent_name, wup_standort, bestellart_id, lief_pal_typ_id, diff_id, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, CAST(betrag_lief_ist AS NUMERIC) AS betrag_lief_ist, CAST(betrag_lief_soll AS NUMERIC) AS betrag_lief_soll, CAST(menge_lief_palette AS NUMERIC) AS menge_lief_palette, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_arbeitsbereiche`;

-- Table: DBP_DATA.CRM_KUNDE_OPTIN_ZU
insert into `dbp_data.crm_kunde_optin_zu` (crm_kunde_id, crm_optin_id, zeit_erstellung, zeit_aenderung, bonuspunkte_fg, optin_versions_url, crm_optin_statusgrund_cd, aktiv_fg, td_update, td_insert)
SELECT crm_kunde_id, crm_optin_id, CAST(zeit_erstellung AS DATETIME) AS zeit_erstellung, CAST(zeit_aenderung AS DATETIME) AS zeit_aenderung, CAST(bonuspunkte_fg AS INT64) AS bonuspunkte_fg, optin_versions_url, crm_optin_statusgrund_cd, CAST(aktiv_fg AS INT64) AS aktiv_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_crm_kunde_optin_zu`;

-- Table: DBP_DATA.LAGERBEW_ART_BEWART_ZU
insert into `dbp_data.lagerbew_art_bewart_zu` (art_id, mandant_id, lager_bewart_id, wup_id, nb_id, dat_buch_first, dat_buch_last, dat_erfasst_first, dat_erfasst_last, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, lager_bewart_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_buch_first, dat_buch_last, dat_erfasst_first, dat_erfasst_last, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_lagerbew_art_bewart_zu`;

-- Table: DBP_DATA.BESCH_RECH_DET
insert into `dbp_data.besch_rech_det` (system_id, mandant_id, rech_beleg_id, rech_beleg_pos_id, gj, best_beleg_id, best_beleg_pos_id, wbnk_fg, ean_id, gp_art_id, edi_pos_nr, betrag_mwst, gp_id, wup_id, nb_id, art_id, menge_rech, best_menge_einh_id, best_preis_menge, best_preis_menge_einh_id, buch_grund_int_id, buch_grund_ext_id, lagerbew_beleg_id, lagerbew_beleg_pos_id, kj, mengenabw_rpw_fg, preisabw_rpw_fg, menge_rechsteller, rechsteller_menge_einh_id, betrag_kondition, kondition_einh_id, kondition_menge_einh_id, kondition_preis_einh_id, preis_vk_brutto, betrag_vk_brutto, betrag_beleg, soll_haben_kz, vk_wrg_id, pos_manuell_erstellt_fg, konditionsart_id, wg_id, arthiertyp_id, einkaufsorganisation_id, betrag_korrektur_netto, sap_mwst_id, mwst, menge_bestand_bme, menge_bestand_bme_rbp, wert_bestand, wert_bestand_vp, wert_bestand_buchung, wert_bestand_buchung_vp, wrg_id, rueck_buchung_fg, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(rech_beleg_id AS INT64) AS rech_beleg_id, CAST(rech_beleg_pos_id AS INT64) AS rech_beleg_pos_id, CAST(gj AS INT64) AS gj, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(wbnk_fg AS INT64) AS wbnk_fg, CAST(ean_id AS NUMERIC) AS ean_id, gp_art_id, CAST(edi_pos_nr AS INT64) AS edi_pos_nr, CAST(betrag_mwst AS NUMERIC) AS betrag_mwst, CAST(gp_id AS INT64) AS gp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(menge_rech AS NUMERIC) AS menge_rech, best_menge_einh_id, CAST(best_preis_menge AS NUMERIC) AS best_preis_menge, best_preis_menge_einh_id, buch_grund_int_id, buch_grund_ext_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(lagerbew_beleg_pos_id AS INT64) AS lagerbew_beleg_pos_id, CAST(kj AS INT64) AS kj, CAST(mengenabw_rpw_fg AS INT64) AS mengenabw_rpw_fg, CAST(preisabw_rpw_fg AS INT64) AS preisabw_rpw_fg, CAST(menge_rechsteller AS NUMERIC) AS menge_rechsteller, rechsteller_menge_einh_id, CAST(betrag_kondition AS NUMERIC) AS betrag_kondition, kondition_einh_id, kondition_menge_einh_id, CAST(kondition_preis_einh_id AS INT64) AS kondition_preis_einh_id, CAST(preis_vk_brutto AS NUMERIC) AS preis_vk_brutto, CAST(betrag_vk_brutto AS NUMERIC) AS betrag_vk_brutto, CAST(betrag_beleg AS NUMERIC) AS betrag_beleg, soll_haben_kz, vk_wrg_id, CAST(pos_manuell_erstellt_fg AS INT64) AS pos_manuell_erstellt_fg, konditionsart_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(einkaufsorganisation_id AS INT64) AS einkaufsorganisation_id, CAST(betrag_korrektur_netto AS NUMERIC) AS betrag_korrektur_netto, sap_mwst_id, CAST(mwst AS NUMERIC) AS mwst, CAST(menge_bestand_bme AS NUMERIC) AS menge_bestand_bme, CAST(menge_bestand_bme_rbp AS NUMERIC) AS menge_bestand_bme_rbp, CAST(wert_bestand AS NUMERIC) AS wert_bestand, CAST(wert_bestand_vp AS NUMERIC) AS wert_bestand_vp, CAST(wert_bestand_buchung AS NUMERIC) AS wert_bestand_buchung, CAST(wert_bestand_buchung_vp AS NUMERIC) AS wert_bestand_buchung_vp, wrg_id, CAST(rueck_buchung_fg AS INT64) AS rueck_buchung_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_besch_rech_det`;

-- Table: DBP_DATA.VZ_BEST_VOR
insert into `dbp_data.vz_best_vor` (mandant_id, dat_plan, wup_id, nb_id, gp_id, gp_teilsortiment_id, lagerort_id, disponent_id, art_id, dat_best, dat_lief, bv_quelle_id, menge_best_gesamt, menge_best_normal, menge_best_bevorratung, menge_best_iwt, menge_best_werbung, menge_einh_id, umrech_faktor_best_bme, dat_verfuegbarkeit, dat_bestandsperiode_ende, bestand, bestand_werbung, bestand_iwt, reichweite, dat_besdarfsperiode_ende, bedarf_netto, bedarf_erweitert, bedarf_nach_mbm_art, bedarf_nach_rundung, bedarf_nach_dyn_rundung, bedarf_nach_mbm_lieferant, vz_dispo_status_id, art_dispo_id, gp_dispo_id, best_vor_dispo_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat_plan, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, gp_teilsortiment_id, lagerort_id, disponent_id, art_id, dat_best, dat_lief, CAST(bv_quelle_id AS INT64) AS bv_quelle_id, CAST(menge_best_gesamt AS INT64) AS menge_best_gesamt, CAST(menge_best_normal AS INT64) AS menge_best_normal, CAST(menge_best_bevorratung AS INT64) AS menge_best_bevorratung, CAST(menge_best_iwt AS INT64) AS menge_best_iwt, CAST(menge_best_werbung AS INT64) AS menge_best_werbung, menge_einh_id, CAST(umrech_faktor_best_bme AS NUMERIC) AS umrech_faktor_best_bme, dat_verfuegbarkeit, dat_bestandsperiode_ende, CAST(bestand AS INT64) AS bestand, CAST(bestand_werbung AS INT64) AS bestand_werbung, CAST(bestand_iwt AS INT64) AS bestand_iwt, CAST(reichweite AS NUMERIC) AS reichweite, dat_besdarfsperiode_ende, CAST(bedarf_netto AS INT64) AS bedarf_netto, CAST(bedarf_erweitert AS INT64) AS bedarf_erweitert, CAST(bedarf_nach_mbm_art AS INT64) AS bedarf_nach_mbm_art, CAST(bedarf_nach_rundung AS INT64) AS bedarf_nach_rundung, CAST(bedarf_nach_dyn_rundung AS INT64) AS bedarf_nach_dyn_rundung, CAST(bedarf_nach_mbm_lieferant AS INT64) AS bedarf_nach_mbm_lieferant, CAST(vz_dispo_status_id AS INT64) AS vz_dispo_status_id, CAST(art_dispo_id AS INT64) AS art_dispo_id, CAST(gp_dispo_id AS INT64) AS gp_dispo_id, CAST(best_vor_dispo_id AS INT64) AS best_vor_dispo_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_vz_best_vor`;

-- Table: DBP_DATA.BESCH_LIEF_WA_HU_SUM
insert into `dbp_data.besch_lief_wa_hu_sum` (mandant_id, handling_unit_id, lief_beleg_id, transportation_unit_id, belos_vorgang_id, wup_id, nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, arthiertyp_id, kunde_id, wg_id, wg_verkett_lief, menge_lief_soll_kolli, menge_lief_ist_kolli, menge_lief_soll_bme, menge_lief_ist_bme, menge_lief_soll_pal, menge_lief_ist_pal, lief_pal_typ_id, lief_pal_typ_dwh_id, anzahl_position, anzahl_position_charg_split, anzahl_packstueck_hu, anzahl_packstueck_anzpk, mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, brtvol_ladung, brtvol_ladung_gedeckelt, hu_relevant_fg, handling_unit_id_ext_parent, hu_in_beziehung_fg, vol_relevant_fg, anzahl_stellplatz_ewm_ext_parent, anzahl_stellplatz_ewm, handling_unit_id_ext, handling_unit_id_parent, disponent_id, vk_netto_lief_ist, vk_netto_lief_soll, transportsortiment_id, wg_verkett_fg, ntvol_ladung, ntvol_ladung_gedeckelt, menge_gefahrgut, wrg_id, brtvol_hu_oa, ntvol_hu_oa, brtvol_hu_gedeckelt_oa, ntvol_hu_gedeckelt_oa, brtgew_hu, ntgew_hu, brtgew_hu_oa, ntgew_hu_oa, menge_lief_ist_kolli_hu, auslieferungsgruppe_id, dat_erstellung, tms_tour_id, dat_tour, tms_system_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(handling_unit_id AS INT64) AS handling_unit_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(belos_vorgang_id AS INT64) AS belos_vorgang_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wg_id AS INT64) AS wg_id, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(menge_lief_soll_bme AS NUMERIC) AS menge_lief_soll_bme, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, CAST(menge_lief_soll_pal AS NUMERIC) AS menge_lief_soll_pal, CAST(menge_lief_ist_pal AS NUMERIC) AS menge_lief_ist_pal, lief_pal_typ_id, lief_pal_typ_dwh_id, CAST(anzahl_position AS INT64) AS anzahl_position, CAST(anzahl_position_charg_split AS INT64) AS anzahl_position_charg_split, CAST(anzahl_packstueck_hu AS INT64) AS anzahl_packstueck_hu, CAST(anzahl_packstueck_anzpk AS INT64) AS anzahl_packstueck_anzpk, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, CAST(brtvol_ladung AS NUMERIC) AS brtvol_ladung, CAST(brtvol_ladung_gedeckelt AS NUMERIC) AS brtvol_ladung_gedeckelt, CAST(hu_relevant_fg AS INT64) AS hu_relevant_fg, handling_unit_id_ext_parent, CAST(hu_in_beziehung_fg AS INT64) AS hu_in_beziehung_fg, CAST(vol_relevant_fg AS INT64) AS vol_relevant_fg, CAST(anzahl_stellplatz_ewm_ext_parent AS NUMERIC) AS anzahl_stellplatz_ewm_ext_parent, CAST(anzahl_stellplatz_ewm AS NUMERIC) AS anzahl_stellplatz_ewm, handling_unit_id_ext, CAST(handling_unit_id_parent AS INT64) AS handling_unit_id_parent, disponent_id, CAST(vk_netto_lief_ist AS NUMERIC) AS vk_netto_lief_ist, CAST(vk_netto_lief_soll AS NUMERIC) AS vk_netto_lief_soll, transportsortiment_id, CAST(wg_verkett_fg AS INT64) AS wg_verkett_fg, CAST(ntvol_ladung AS NUMERIC) AS ntvol_ladung, CAST(ntvol_ladung_gedeckelt AS NUMERIC) AS ntvol_ladung_gedeckelt, CAST(menge_gefahrgut AS NUMERIC) AS menge_gefahrgut, wrg_id, CAST(brtvol_hu_oa AS NUMERIC) AS brtvol_hu_oa, CAST(ntvol_hu_oa AS NUMERIC) AS ntvol_hu_oa, CAST(brtvol_hu_gedeckelt_oa AS NUMERIC) AS brtvol_hu_gedeckelt_oa, CAST(ntvol_hu_gedeckelt_oa AS NUMERIC) AS ntvol_hu_gedeckelt_oa, CAST(brtgew_hu AS NUMERIC) AS brtgew_hu, CAST(ntgew_hu AS NUMERIC) AS ntgew_hu, CAST(brtgew_hu_oa AS NUMERIC) AS brtgew_hu_oa, CAST(ntgew_hu_oa AS NUMERIC) AS ntgew_hu_oa, CAST(menge_lief_ist_kolli_hu AS NUMERIC) AS menge_lief_ist_kolli_hu, auslieferungsgruppe_id, dat_erstellung, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(tms_system_id AS INT64) AS tms_system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_wa_hu_sum`;

-- Table: DBP_DATA.AUSLIEFERPOSITION
insert into `dbp_data.auslieferposition` (mandant_id, beleg_guid, beleg_pos_guid, belegtyp_id, beleg_id, manuell_erzeugt_fg, beleg_pos_id, tor_id, datzeit_erstellung, datzeit_aenderung, dat_lief_soll, zeit_lief_soll, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, beleg_guid, beleg_pos_guid, belegtyp_id, CAST(beleg_id AS NUMERIC) AS beleg_id, CAST(manuell_erzeugt_fg AS INT64) AS manuell_erzeugt_fg, CAST(beleg_pos_id AS INT64) AS beleg_pos_id, tor_id, datzeit_erstellung, datzeit_aenderung, dat_lief_soll, zeit_lief_soll, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_auslieferposition`;

-- Table: DBP_DATA.SKIPPED_POSITIONS_EWM
insert into `dbp_data.skipped_positions_ewm` (mandant_id, lagernummer_id, lagerauftrag_id, lageraufgabe_id, lageraufgabe_pos_id, lagersortiment_id, lagerauftrag_status_id, lageraufgabe_status_id, lagerprozessart_id, artikelsortiment_id, lief_beleg_id, lief_beleg_pos_id, lief_pal_typ_id, ewm_gv_grp_id, ewm_exc_kategorie_id, lagerauftrag_has_exc_1_fg, lagerauftrag_has_exc_2_fg, lagerauftrag_has_exc_3_fg, dat_lief_soll, wg_verkett_lief, werbeware_id, art_id, ausnahme_code, bus_kontext, ausfuehr_schritt_id, menge_ist_bme, manuell_erzeugt_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(lagerauftrag_id AS INT64) AS lagerauftrag_id, CAST(lageraufgabe_id AS INT64) AS lageraufgabe_id, CAST(lageraufgabe_pos_id AS INT64) AS lageraufgabe_pos_id, lagersortiment_id, lagerauftrag_status_id, lageraufgabe_status_id, lagerprozessart_id, artikelsortiment_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, lief_pal_typ_id, ewm_gv_grp_id, ewm_exc_kategorie_id, CAST(lagerauftrag_has_exc_1_fg AS INT64) AS lagerauftrag_has_exc_1_fg, CAST(lagerauftrag_has_exc_2_fg AS INT64) AS lagerauftrag_has_exc_2_fg, CAST(lagerauftrag_has_exc_3_fg AS INT64) AS lagerauftrag_has_exc_3_fg, dat_lief_soll, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, werbeware_id, CAST(art_id AS INT64) AS art_id, ausnahme_code, bus_kontext, ausfuehr_schritt_id, CAST(menge_ist_bme AS BIGNUMERIC) AS menge_ist_bme, CAST(manuell_erzeugt_fg AS INT64) AS manuell_erzeugt_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_skipped_positions_ewm`;

-- Table: DBP_DATA.ART_KL_PREISLAGE_ZU_PER_NEU
insert into `dbp_data.art_kl_preislage_zu_per_neu` (mandant_id, art_matching_id, kjmo, kjwo_update, wrg_id, sm_id, ksm_id, owg_id, wg_id, wug_id, vk_brutto_pk_1, durchschnitt_preis_kasse, umsatz_brutto, umsatz_brutto_af, umsatz_brutto_sa, menge, menge_af, menge_sa, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_matching_id AS INT64) AS art_matching_id, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo_update AS INT64) AS kjwo_update, wrg_id, sm_id, ksm_id, CAST(owg_id AS INT64) AS owg_id, CAST(wg_id AS INT64) AS wg_id, CAST(wug_id AS INT64) AS wug_id, CAST(vk_brutto_pk_1 AS NUMERIC) AS vk_brutto_pk_1, CAST(durchschnitt_preis_kasse AS NUMERIC) AS durchschnitt_preis_kasse, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(umsatz_brutto_af AS NUMERIC) AS umsatz_brutto_af, CAST(umsatz_brutto_sa AS NUMERIC) AS umsatz_brutto_sa, CAST(menge AS NUMERIC) AS menge, CAST(menge_af AS NUMERIC) AS menge_af, CAST(menge_sa AS NUMERIC) AS menge_sa, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_art_kl_preislage_zu_per_neu`;

-- Table: DBP_DATA.FUR_PROGNOSE_WG_SUM
insert into `dbp_data.fur_prognose_wg_sum` (mandant_id, wup_id, nb_id, wg_id, arthiertyp_id, dat, menge_prognose, menge_prognose_bef, menge_prognose_max, menge_af, menge_sa, diff_menge_af_prognose, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, dat, CAST(menge_prognose AS NUMERIC) AS menge_prognose, CAST(menge_prognose_bef AS NUMERIC) AS menge_prognose_bef, CAST(menge_prognose_max AS NUMERIC) AS menge_prognose_max, CAST(menge_af AS NUMERIC) AS menge_af, CAST(menge_sa AS NUMERIC) AS menge_sa, CAST(diff_menge_af_prognose AS NUMERIC) AS diff_menge_af_prognose, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fur_prognose_wg_sum`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_LEERGUT
insert into `dbp_ods_archiv.ods_bon_leergut` (bon_id, bon_zeile, ean_kasse, umsatz_brutto, mandant_id, wup_id, start_bon_zeile, bon_nr_extern, bon_dat, td_insert, td_update)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(ean_kasse AS NUMERIC) AS ean_kasse, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(start_bon_zeile AS DATETIME) AS start_bon_zeile, CAST(bon_nr_extern AS INT64) AS bon_nr_extern, bon_dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_leergut`;

-- Table: DBP_MSI_DATA.TUPEL_52_WOCHEN
insert into `dbp_msi_data.tupel_52_wochen` (mandant_id, kjwo_52, matching_id, anzahl_markt_wochen_kombis_abverkauf_af, anzahl_markt_wochen_kombis_abverkauf_sa, anzahl_markt_wochen_kombis_abverkauf_af_vj, anzahl_markt_wochen_kombis_abverkauf_sa_vj, kassenumsatz_kl_absolut_brutto, kassenumsatz_af_kl_absolut_brutto, kassenumsatz_sa_kl_absolut_brutto, kassenumsatz_kl_absolut_brutto_vj, kassenumsatz_af_kl_absolut_brutto_vj, kassenumsatz_sa_kl_absolut_brutto_vj, kassenumsatz_kl_absolut_netto, kassenumsatz_af_kl_absolut_netto, kassenumsatz_sa_kl_absolut_netto, kassenumsatz_kl_absolut_netto_vj, kassenumsatz_af_kl_absolut_netto_vj, kassenumsatz_sa_kl_absolut_netto_vj, absatz_kl, absatz_af_kl, absatz_sa_kl, absatz_kl_vj, absatz_af_kl_vj, absatz_sa_kl_vj, absatz_sst1, absatz_sst2, absatz_sst3, absatz_sst4, absatz_sst5, absatz_sst6, absatz_sst7, absatz_ksst1, absatz_ksst2, absatz_ksst3, absatz_ksst4, absatz_ksst5, absatz_ksst6, absatz_ksst7, absatz_ost_basis, absatz_ost_gross, absatz_sued_ost, absatz_sued_west, absatz_west, absatz_nord, markt_wochen_sst1, markt_wochen_sst2, markt_wochen_sst3, markt_wochen_sst4, markt_wochen_sst5, markt_wochen_sst6, markt_wochen_sst7, markt_wochen_ksst1, markt_wochen_ksst2, markt_wochen_ksst3, markt_wochen_ksst4, markt_wochen_ksst5, markt_wochen_ksst6, markt_wochen_ksst7, markt_wochen_ost_basis, markt_wochen_ost_gross, markt_wochen_sued_ost, markt_wochen_sued_west, markt_wochen_west, markt_wochen_nord, anzahl_markt_wochen_kombis_abverkauf_mit_listung, anzahl_markt_wochen_kombis_listung, rohertrag_ekmep_olk_4n, rohertrag_ekmep_olk_4n_vj, rohertrag_ekmep_olk_4n_af, rohertrag_ekmep_olk_4n_sa, rohertrag_ekmep_olk_4n_af_vj, rohertrag_ekmep_olk_4n_sa_vj, totalabschriften_wert_netto_absolut, preisabschriften_preisanderungen_wert_netto_absolut, totalabschriften_wert_netto_absolut_vj, preisabschriften_preisanderungen_wert_netto_absolut_vj, totalabschriften_wert_netto_absolut_wg, preisabschriften_preisanderungen_wert_netto_absolut_wg, kassenumsatz_kl_absolut_netto_wg, absatz_af_kl_listungswochen, absatz_af_kl_vj_listungswochen, absatz_sa_kl_listungswochen, absatz_sa_kl_vj_listungswochen, kassenumsatz_af_kl_absolut_netto_listungswochen, kassenumsatz_af_kl_absolut_netto_vj_listungswochen, kassenumsatz_sa_kl_absolut_netto_listungswochen, kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, rohertrag_ekmep_olk_4n_af_listungswochen, rohertrag_ekmep_olk_4n_af_vj_listungswochen, rohertrag_ekmep_olk_4n_sa_listungswochen, rohertrag_ekmep_olk_4n_sa_vj_listungswochen, kjwo_update, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo_52 AS INT64) AS kjwo_52, CAST(matching_id AS INT64) AS matching_id, CAST(anzahl_markt_wochen_kombis_abverkauf_af AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af, CAST(anzahl_markt_wochen_kombis_abverkauf_sa AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa, CAST(anzahl_markt_wochen_kombis_abverkauf_af_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af_vj, CAST(anzahl_markt_wochen_kombis_abverkauf_sa_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa_vj, CAST(kassenumsatz_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_kl_absolut_brutto, CAST(kassenumsatz_af_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto, CAST(kassenumsatz_sa_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto, CAST(kassenumsatz_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_brutto_vj, CAST(kassenumsatz_af_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto_vj, CAST(kassenumsatz_sa_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto_vj, CAST(kassenumsatz_kl_absolut_netto AS NUMERIC) AS kassenumsatz_kl_absolut_netto, CAST(kassenumsatz_af_kl_absolut_netto AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto, CAST(kassenumsatz_sa_kl_absolut_netto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto, CAST(kassenumsatz_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_netto_vj, CAST(kassenumsatz_af_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj, CAST(kassenumsatz_sa_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj, CAST(absatz_kl AS NUMERIC) AS absatz_kl, CAST(absatz_af_kl AS NUMERIC) AS absatz_af_kl, CAST(absatz_sa_kl AS NUMERIC) AS absatz_sa_kl, CAST(absatz_kl_vj AS NUMERIC) AS absatz_kl_vj, CAST(absatz_af_kl_vj AS NUMERIC) AS absatz_af_kl_vj, CAST(absatz_sa_kl_vj AS NUMERIC) AS absatz_sa_kl_vj, CAST(absatz_sst1 AS NUMERIC) AS absatz_sst1, CAST(absatz_sst2 AS NUMERIC) AS absatz_sst2, CAST(absatz_sst3 AS NUMERIC) AS absatz_sst3, CAST(absatz_sst4 AS NUMERIC) AS absatz_sst4, CAST(absatz_sst5 AS NUMERIC) AS absatz_sst5, CAST(absatz_sst6 AS NUMERIC) AS absatz_sst6, CAST(absatz_sst7 AS NUMERIC) AS absatz_sst7, CAST(absatz_ksst1 AS NUMERIC) AS absatz_ksst1, CAST(absatz_ksst2 AS NUMERIC) AS absatz_ksst2, CAST(absatz_ksst3 AS NUMERIC) AS absatz_ksst3, CAST(absatz_ksst4 AS NUMERIC) AS absatz_ksst4, CAST(absatz_ksst5 AS NUMERIC) AS absatz_ksst5, CAST(absatz_ksst6 AS NUMERIC) AS absatz_ksst6, CAST(absatz_ksst7 AS NUMERIC) AS absatz_ksst7, CAST(absatz_ost_basis AS NUMERIC) AS absatz_ost_basis, CAST(absatz_ost_gross AS NUMERIC) AS absatz_ost_gross, CAST(absatz_sued_ost AS NUMERIC) AS absatz_sued_ost, CAST(absatz_sued_west AS NUMERIC) AS absatz_sued_west, CAST(absatz_west AS NUMERIC) AS absatz_west, CAST(absatz_nord AS NUMERIC) AS absatz_nord, CAST(markt_wochen_sst1 AS INT64) AS markt_wochen_sst1, CAST(markt_wochen_sst2 AS INT64) AS markt_wochen_sst2, CAST(markt_wochen_sst3 AS INT64) AS markt_wochen_sst3, CAST(markt_wochen_sst4 AS INT64) AS markt_wochen_sst4, CAST(markt_wochen_sst5 AS INT64) AS markt_wochen_sst5, CAST(markt_wochen_sst6 AS INT64) AS markt_wochen_sst6, CAST(markt_wochen_sst7 AS INT64) AS markt_wochen_sst7, CAST(markt_wochen_ksst1 AS INT64) AS markt_wochen_ksst1, CAST(markt_wochen_ksst2 AS INT64) AS markt_wochen_ksst2, CAST(markt_wochen_ksst3 AS INT64) AS markt_wochen_ksst3, CAST(markt_wochen_ksst4 AS INT64) AS markt_wochen_ksst4, CAST(markt_wochen_ksst5 AS INT64) AS markt_wochen_ksst5, CAST(markt_wochen_ksst6 AS INT64) AS markt_wochen_ksst6, CAST(markt_wochen_ksst7 AS INT64) AS markt_wochen_ksst7, CAST(markt_wochen_ost_basis AS INT64) AS markt_wochen_ost_basis, CAST(markt_wochen_ost_gross AS INT64) AS markt_wochen_ost_gross, CAST(markt_wochen_sued_ost AS INT64) AS markt_wochen_sued_ost, CAST(markt_wochen_sued_west AS INT64) AS markt_wochen_sued_west, CAST(markt_wochen_west AS INT64) AS markt_wochen_west, CAST(markt_wochen_nord AS INT64) AS markt_wochen_nord, CAST(anzahl_markt_wochen_kombis_abverkauf_mit_listung AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_mit_listung, CAST(anzahl_markt_wochen_kombis_listung AS INT64) AS anzahl_markt_wochen_kombis_listung, CAST(rohertrag_ekmep_olk_4n AS NUMERIC) AS rohertrag_ekmep_olk_4n, CAST(rohertrag_ekmep_olk_4n_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_vj, CAST(rohertrag_ekmep_olk_4n_af AS NUMERIC) AS rohertrag_ekmep_olk_4n_af, CAST(rohertrag_ekmep_olk_4n_sa AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa, CAST(rohertrag_ekmep_olk_4n_af_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj, CAST(rohertrag_ekmep_olk_4n_sa_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj, CAST(totalabschriften_wert_netto_absolut AS NUMERIC) AS totalabschriften_wert_netto_absolut, CAST(preisabschriften_preisanderungen_wert_netto_absolut AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut, CAST(totalabschriften_wert_netto_absolut_vj AS NUMERIC) AS totalabschriften_wert_netto_absolut_vj, CAST(preisabschriften_preisanderungen_wert_netto_absolut_vj AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_vj, CAST(totalabschriften_wert_netto_absolut_wg AS NUMERIC) AS totalabschriften_wert_netto_absolut_wg, CAST(preisabschriften_preisanderungen_wert_netto_absolut_wg AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_wg, CAST(kassenumsatz_kl_absolut_netto_wg AS NUMERIC) AS kassenumsatz_kl_absolut_netto_wg, CAST(absatz_af_kl_listungswochen AS NUMERIC) AS absatz_af_kl_listungswochen, CAST(absatz_af_kl_vj_listungswochen AS NUMERIC) AS absatz_af_kl_vj_listungswochen, CAST(absatz_sa_kl_listungswochen AS NUMERIC) AS absatz_sa_kl_listungswochen, CAST(absatz_sa_kl_vj_listungswochen AS NUMERIC) AS absatz_sa_kl_vj_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj_listungswochen, CAST(kjwo_update AS INT64) AS kjwo_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_tupel_52_wochen`;

-- Table: DBP_DATA.FLW_SCHNITTLISTE_MAT_KOSTEN
insert into `dbp_data.flw_schnittliste_mat_kosten` (schnittliste_id, flw_art_id, input_material_typ_id, kosten_block_id, sek_schl_typ_id, sek_schl_id, mandant_id, intern_var_kosten, betrag_intern_var_kosten, wrg_id, system_id, td_insert, td_update)
SELECT CAST(schnittliste_id AS INT64) AS schnittliste_id, CAST(flw_art_id AS INT64) AS flw_art_id, input_material_typ_id, kosten_block_id, sek_schl_typ_id, CAST(sek_schl_id AS INT64) AS sek_schl_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(intern_var_kosten AS NUMERIC) AS intern_var_kosten, CAST(betrag_intern_var_kosten AS NUMERIC) AS betrag_intern_var_kosten, wrg_id, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_schnittliste_mat_kosten`;

-- Table: DBP_DATA.VIS_ZAEHL_AUFTRAG
insert into `dbp_data.vis_zaehl_auftrag` (art_id, mandant_id, wup_id, nb_id, dat_auftrag, zaehl_grund_id, bezugsweg_id, zaehl_sort_id, dat_zaehl, zeit_zaehl, gesendet_fg, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_auftrag, zaehl_grund_id, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, zaehl_sort_id, dat_zaehl, zeit_zaehl, CAST(gesendet_fg AS INT64) AS gesendet_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_zaehl_auftrag`;

-- Table: DBP_DATA.AVQ_WERBUNG_TAG
insert into `dbp_data.avq_werbung_tag` (mandant_id, wup_id, nb_id, art_id, dat_aktion_von, dat_aktion_bis, tag_index, dat, menge_bestand, menge_abverkauf, menge_abverkauf_af, menge_abverkauf_sa, menge_we, wrg_id, betrag_umsatz_netto, exc209_fg, nullbestand_fg, exc214_fg, minusbestand_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_aktion_von, dat_aktion_bis, CAST(tag_index AS INT64) AS tag_index, dat, CAST(menge_bestand AS NUMERIC) AS menge_bestand, CAST(menge_abverkauf AS NUMERIC) AS menge_abverkauf, CAST(menge_abverkauf_af AS NUMERIC) AS menge_abverkauf_af, CAST(menge_abverkauf_sa AS NUMERIC) AS menge_abverkauf_sa, CAST(menge_we AS NUMERIC) AS menge_we, wrg_id, CAST(betrag_umsatz_netto AS NUMERIC) AS betrag_umsatz_netto, CAST(exc209_fg AS INT64) AS exc209_fg, CAST(nullbestand_fg AS NUMERIC) AS nullbestand_fg, CAST(exc214_fg AS INT64) AS exc214_fg, CAST(minusbestand_fg AS NUMERIC) AS minusbestand_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_avq_werbung_tag`;

-- Table: DBP_DATA.CPR_BAU_GV_SPR_ZU_PER
insert into `dbp_data.cpr_bau_gv_spr_zu_per` (projekt_id, dat_von, bau_gv_dok_id, spr_id, dat_bis, dokument_bez, dokument_bez_lang, td_update, td_insert)
SELECT projekt_id, dat_von, bau_gv_dok_id, CAST(spr_id AS INT64) AS spr_id, dat_bis, dokument_bez, dokument_bez_lang, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_cpr_bau_gv_spr_zu_per`;

-- Table: DBP_MSI_DATA.TUPEL_26_WOCHEN
insert into `dbp_msi_data.tupel_26_wochen` (mandant_id, kjwo_26, matching_id, anzahl_markt_wochen_kombis_abverkauf_af, anzahl_markt_wochen_kombis_abverkauf_sa, anzahl_markt_wochen_kombis_abverkauf_af_vj, anzahl_markt_wochen_kombis_abverkauf_sa_vj, kassenumsatz_kl_absolut_brutto, kassenumsatz_af_kl_absolut_brutto, kassenumsatz_sa_kl_absolut_brutto, kassenumsatz_kl_absolut_brutto_vj, kassenumsatz_af_kl_absolut_brutto_vj, kassenumsatz_sa_kl_absolut_brutto_vj, kassenumsatz_kl_absolut_netto, kassenumsatz_af_kl_absolut_netto, kassenumsatz_sa_kl_absolut_netto, kassenumsatz_kl_absolut_netto_vj, kassenumsatz_af_kl_absolut_netto_vj, kassenumsatz_sa_kl_absolut_netto_vj, absatz_kl, absatz_af_kl, absatz_sa_kl, absatz_kl_vj, absatz_af_kl_vj, absatz_sa_kl_vj, absatz_sst1, absatz_sst2, absatz_sst3, absatz_sst4, absatz_sst5, absatz_sst6, absatz_sst7, absatz_ksst1, absatz_ksst2, absatz_ksst3, absatz_ksst4, absatz_ksst5, absatz_ksst6, absatz_ksst7, absatz_ost_basis, absatz_ost_gross, absatz_sued_ost, absatz_sued_west, absatz_west, absatz_nord, markt_wochen_sst1, markt_wochen_sst2, markt_wochen_sst3, markt_wochen_sst4, markt_wochen_sst5, markt_wochen_sst6, markt_wochen_sst7, markt_wochen_ksst1, markt_wochen_ksst2, markt_wochen_ksst3, markt_wochen_ksst4, markt_wochen_ksst5, markt_wochen_ksst6, markt_wochen_ksst7, markt_wochen_ost_basis, markt_wochen_ost_gross, markt_wochen_sued_ost, markt_wochen_sued_west, markt_wochen_west, markt_wochen_nord, anzahl_markt_wochen_kombis_abverkauf_mit_listung, anzahl_markt_wochen_kombis_listung, rohertrag_ekmep_olk_4n, rohertrag_ekmep_olk_4n_vj, rohertrag_ekmep_olk_4n_af, rohertrag_ekmep_olk_4n_sa, rohertrag_ekmep_olk_4n_af_vj, rohertrag_ekmep_olk_4n_sa_vj, totalabschriften_wert_netto_absolut, preisabschriften_preisanderungen_wert_netto_absolut, totalabschriften_wert_netto_absolut_vj, preisabschriften_preisanderungen_wert_netto_absolut_vj, totalabschriften_wert_netto_absolut_wg, preisabschriften_preisanderungen_wert_netto_absolut_wg, kassenumsatz_kl_absolut_netto_wg, absatz_af_kl_listungswochen, absatz_af_kl_vj_listungswochen, absatz_sa_kl_listungswochen, absatz_sa_kl_vj_listungswochen, kassenumsatz_af_kl_absolut_netto_listungswochen, kassenumsatz_af_kl_absolut_netto_vj_listungswochen, kassenumsatz_sa_kl_absolut_netto_listungswochen, kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, rohertrag_ekmep_olk_4n_af_listungswochen, rohertrag_ekmep_olk_4n_af_vj_listungswochen, rohertrag_ekmep_olk_4n_sa_listungswochen, rohertrag_ekmep_olk_4n_sa_vj_listungswochen, kjwo_update, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo_26 AS INT64) AS kjwo_26, CAST(matching_id AS INT64) AS matching_id, CAST(anzahl_markt_wochen_kombis_abverkauf_af AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af, CAST(anzahl_markt_wochen_kombis_abverkauf_sa AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa, CAST(anzahl_markt_wochen_kombis_abverkauf_af_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af_vj, CAST(anzahl_markt_wochen_kombis_abverkauf_sa_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa_vj, CAST(kassenumsatz_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_kl_absolut_brutto, CAST(kassenumsatz_af_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto, CAST(kassenumsatz_sa_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto, CAST(kassenumsatz_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_brutto_vj, CAST(kassenumsatz_af_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto_vj, CAST(kassenumsatz_sa_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto_vj, CAST(kassenumsatz_kl_absolut_netto AS NUMERIC) AS kassenumsatz_kl_absolut_netto, CAST(kassenumsatz_af_kl_absolut_netto AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto, CAST(kassenumsatz_sa_kl_absolut_netto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto, CAST(kassenumsatz_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_netto_vj, CAST(kassenumsatz_af_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj, CAST(kassenumsatz_sa_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj, CAST(absatz_kl AS NUMERIC) AS absatz_kl, CAST(absatz_af_kl AS NUMERIC) AS absatz_af_kl, CAST(absatz_sa_kl AS NUMERIC) AS absatz_sa_kl, CAST(absatz_kl_vj AS NUMERIC) AS absatz_kl_vj, CAST(absatz_af_kl_vj AS NUMERIC) AS absatz_af_kl_vj, CAST(absatz_sa_kl_vj AS NUMERIC) AS absatz_sa_kl_vj, CAST(absatz_sst1 AS NUMERIC) AS absatz_sst1, CAST(absatz_sst2 AS NUMERIC) AS absatz_sst2, CAST(absatz_sst3 AS NUMERIC) AS absatz_sst3, CAST(absatz_sst4 AS NUMERIC) AS absatz_sst4, CAST(absatz_sst5 AS NUMERIC) AS absatz_sst5, CAST(absatz_sst6 AS NUMERIC) AS absatz_sst6, CAST(absatz_sst7 AS NUMERIC) AS absatz_sst7, CAST(absatz_ksst1 AS NUMERIC) AS absatz_ksst1, CAST(absatz_ksst2 AS NUMERIC) AS absatz_ksst2, CAST(absatz_ksst3 AS NUMERIC) AS absatz_ksst3, CAST(absatz_ksst4 AS NUMERIC) AS absatz_ksst4, CAST(absatz_ksst5 AS NUMERIC) AS absatz_ksst5, CAST(absatz_ksst6 AS NUMERIC) AS absatz_ksst6, CAST(absatz_ksst7 AS NUMERIC) AS absatz_ksst7, CAST(absatz_ost_basis AS NUMERIC) AS absatz_ost_basis, CAST(absatz_ost_gross AS NUMERIC) AS absatz_ost_gross, CAST(absatz_sued_ost AS NUMERIC) AS absatz_sued_ost, CAST(absatz_sued_west AS NUMERIC) AS absatz_sued_west, CAST(absatz_west AS NUMERIC) AS absatz_west, CAST(absatz_nord AS NUMERIC) AS absatz_nord, CAST(markt_wochen_sst1 AS INT64) AS markt_wochen_sst1, CAST(markt_wochen_sst2 AS INT64) AS markt_wochen_sst2, CAST(markt_wochen_sst3 AS INT64) AS markt_wochen_sst3, CAST(markt_wochen_sst4 AS INT64) AS markt_wochen_sst4, CAST(markt_wochen_sst5 AS INT64) AS markt_wochen_sst5, CAST(markt_wochen_sst6 AS INT64) AS markt_wochen_sst6, CAST(markt_wochen_sst7 AS INT64) AS markt_wochen_sst7, CAST(markt_wochen_ksst1 AS INT64) AS markt_wochen_ksst1, CAST(markt_wochen_ksst2 AS INT64) AS markt_wochen_ksst2, CAST(markt_wochen_ksst3 AS INT64) AS markt_wochen_ksst3, CAST(markt_wochen_ksst4 AS INT64) AS markt_wochen_ksst4, CAST(markt_wochen_ksst5 AS INT64) AS markt_wochen_ksst5, CAST(markt_wochen_ksst6 AS INT64) AS markt_wochen_ksst6, CAST(markt_wochen_ksst7 AS INT64) AS markt_wochen_ksst7, CAST(markt_wochen_ost_basis AS INT64) AS markt_wochen_ost_basis, CAST(markt_wochen_ost_gross AS INT64) AS markt_wochen_ost_gross, CAST(markt_wochen_sued_ost AS INT64) AS markt_wochen_sued_ost, CAST(markt_wochen_sued_west AS INT64) AS markt_wochen_sued_west, CAST(markt_wochen_west AS INT64) AS markt_wochen_west, CAST(markt_wochen_nord AS INT64) AS markt_wochen_nord, CAST(anzahl_markt_wochen_kombis_abverkauf_mit_listung AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_mit_listung, CAST(anzahl_markt_wochen_kombis_listung AS INT64) AS anzahl_markt_wochen_kombis_listung, CAST(rohertrag_ekmep_olk_4n AS NUMERIC) AS rohertrag_ekmep_olk_4n, CAST(rohertrag_ekmep_olk_4n_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_vj, CAST(rohertrag_ekmep_olk_4n_af AS NUMERIC) AS rohertrag_ekmep_olk_4n_af, CAST(rohertrag_ekmep_olk_4n_sa AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa, CAST(rohertrag_ekmep_olk_4n_af_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj, CAST(rohertrag_ekmep_olk_4n_sa_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj, CAST(totalabschriften_wert_netto_absolut AS NUMERIC) AS totalabschriften_wert_netto_absolut, CAST(preisabschriften_preisanderungen_wert_netto_absolut AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut, CAST(totalabschriften_wert_netto_absolut_vj AS NUMERIC) AS totalabschriften_wert_netto_absolut_vj, CAST(preisabschriften_preisanderungen_wert_netto_absolut_vj AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_vj, CAST(totalabschriften_wert_netto_absolut_wg AS NUMERIC) AS totalabschriften_wert_netto_absolut_wg, CAST(preisabschriften_preisanderungen_wert_netto_absolut_wg AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_wg, CAST(kassenumsatz_kl_absolut_netto_wg AS NUMERIC) AS kassenumsatz_kl_absolut_netto_wg, CAST(absatz_af_kl_listungswochen AS NUMERIC) AS absatz_af_kl_listungswochen, CAST(absatz_af_kl_vj_listungswochen AS NUMERIC) AS absatz_af_kl_vj_listungswochen, CAST(absatz_sa_kl_listungswochen AS NUMERIC) AS absatz_sa_kl_listungswochen, CAST(absatz_sa_kl_vj_listungswochen AS NUMERIC) AS absatz_sa_kl_vj_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj_listungswochen, CAST(kjwo_update AS INT64) AS kjwo_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_tupel_26_wochen`;

-- Table: DBP_DATA.WBS_ART_WUP_AKTION_INITIAL
insert into `dbp_data.wbs_art_wup_aktion_initial` (mandant_id, art_id, wup_id, nb_id, mandant_id_vz, wup_id_vz, nb_id_vz, aktion_id, ausliefergruppe_id, dat_von, dat_bis, dat_bestandsperiode_rel, dat_lief_split, dat_lief_wunsch, dat_bestandsperiode_bis, dat_letzte_nachversorgung, we_bearbeitungszeit, menge_gesamt_bme, menge_min_bme, menge_initial_bme, menge_initial_ame, menge_initial_pal, split_fg, fair_share_fg, order_type, init_lief_modus_kz, dat_beladung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(nb_id_vz AS INT64) AS nb_id_vz, aktion_id, ausliefergruppe_id, dat_von, dat_bis, dat_bestandsperiode_rel, dat_lief_split, dat_lief_wunsch, dat_bestandsperiode_bis, dat_letzte_nachversorgung, CAST(we_bearbeitungszeit AS INT64) AS we_bearbeitungszeit, CAST(menge_gesamt_bme AS NUMERIC) AS menge_gesamt_bme, CAST(menge_min_bme AS NUMERIC) AS menge_min_bme, CAST(menge_initial_bme AS NUMERIC) AS menge_initial_bme, CAST(menge_initial_ame AS NUMERIC) AS menge_initial_ame, CAST(menge_initial_pal AS NUMERIC) AS menge_initial_pal, CAST(split_fg AS INT64) AS split_fg, CAST(fair_share_fg AS INT64) AS fair_share_fg, order_type, init_lief_modus_kz, dat_beladung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_art_wup_aktion_initial`;

-- Table: DBP_DATA.BESCH_LIEF_WA_WG_SUM
insert into `dbp_data.besch_lief_wa_wg_sum` (mandant_id, wup_id, nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, wg_id, arthiertyp_id, kunde_id, wg_verkett_lief, lief_pal_typ_id, lief_pal_typ_dwh_id, mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, disponent_id, anzahl_position, anzahl_position_charg_split, anzahl_packstueck_anzpk, anzahl_packstueck_hu, brtvol_ladung, brtvol_ladung_gedeckelt, menge_lief_soll_kolli, menge_lief_ist_kolli, menge_lief_soll_bme, menge_lief_ist_bme, menge_lief_soll_pal, menge_lief_ist_pal, anzahl_stellplatz_ewm_ext_parent, anzahl_stellplatz_ewm, vk_netto_lief_ist, vk_netto_lief_soll, transportsortiment_id, wg_verkett_fg, ntvol_ladung, ntvol_ladung_gedeckelt, menge_gefahrgut, wrg_id, brtvol_hu_oa, ntvol_hu_oa, brtvol_hu_gedeckelt_oa, ntvol_hu_gedeckelt_oa, brtgew_hu, ntgew_hu, brtgew_hu_oa, ntgew_hu_oa, menge_lief_ist_kolli_hu, auslieferungsgruppe_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, versandstelle_id, lagerort_id, lagersortiment_id, diff_id, dat_lief_soll, lief_typ_id, vertr_beleg_typ_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, lief_pal_typ_id, lief_pal_typ_dwh_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, werbeware_id, bestellart_id, hu_status_id, disponent_id, CAST(anzahl_position AS INT64) AS anzahl_position, CAST(anzahl_position_charg_split AS INT64) AS anzahl_position_charg_split, CAST(anzahl_packstueck_anzpk AS INT64) AS anzahl_packstueck_anzpk, CAST(anzahl_packstueck_hu AS INT64) AS anzahl_packstueck_hu, CAST(brtvol_ladung AS NUMERIC) AS brtvol_ladung, CAST(brtvol_ladung_gedeckelt AS NUMERIC) AS brtvol_ladung_gedeckelt, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(menge_lief_soll_bme AS NUMERIC) AS menge_lief_soll_bme, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, CAST(menge_lief_soll_pal AS NUMERIC) AS menge_lief_soll_pal, CAST(menge_lief_ist_pal AS NUMERIC) AS menge_lief_ist_pal, CAST(anzahl_stellplatz_ewm_ext_parent AS NUMERIC) AS anzahl_stellplatz_ewm_ext_parent, CAST(anzahl_stellplatz_ewm AS NUMERIC) AS anzahl_stellplatz_ewm, CAST(vk_netto_lief_ist AS NUMERIC) AS vk_netto_lief_ist, CAST(vk_netto_lief_soll AS NUMERIC) AS vk_netto_lief_soll, transportsortiment_id, CAST(wg_verkett_fg AS INT64) AS wg_verkett_fg, CAST(ntvol_ladung AS NUMERIC) AS ntvol_ladung, CAST(ntvol_ladung_gedeckelt AS NUMERIC) AS ntvol_ladung_gedeckelt, CAST(menge_gefahrgut AS NUMERIC) AS menge_gefahrgut, wrg_id, CAST(brtvol_hu_oa AS NUMERIC) AS brtvol_hu_oa, CAST(ntvol_hu_oa AS NUMERIC) AS ntvol_hu_oa, CAST(brtvol_hu_gedeckelt_oa AS NUMERIC) AS brtvol_hu_gedeckelt_oa, CAST(ntvol_hu_gedeckelt_oa AS NUMERIC) AS ntvol_hu_gedeckelt_oa, CAST(brtgew_hu AS NUMERIC) AS brtgew_hu, CAST(ntgew_hu AS NUMERIC) AS ntgew_hu, CAST(brtgew_hu_oa AS NUMERIC) AS brtgew_hu_oa, CAST(ntgew_hu_oa AS NUMERIC) AS ntgew_hu_oa, CAST(menge_lief_ist_kolli_hu AS NUMERIC) AS menge_lief_ist_kolli_hu, auslieferungsgruppe_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_wa_wg_sum`;

-- Table: DBP_DATA.BESCH_FAKTURA_LGORT_WG_WUP
insert into `dbp_data.besch_faktura_lgort_wg_wup` (mandant_id, wup_id, nb_id, lagerort_id, wg_id, fakturaart_id, dat_faktura, dat_erstellung, dat_leist_erstellung, arthiertyp_id, auftraggeber_id, bestellart_id, dat_preisfindung, auftrag_grund_id, verrechnung_betrag, zwsum_1_betrag, zwsum_2_betrag, zwsum_3_betrag, zwsum_4_betrag, zwsum_5_betrag, zwsum_6_betrag, zwsum_8_betrag, zwsum_9_betrag, vk_netto_betrag, vk_netto_rekl_tkl_betrag, menge_faktura_kolli, menge_faktura_palette, menge_faktura_bme, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagerort_id, CAST(wg_id AS INT64) AS wg_id, fakturaart_id, dat_faktura, dat_erstellung, dat_leist_erstellung, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, auftraggeber_id, bestellart_id, dat_preisfindung, auftrag_grund_id, CAST(verrechnung_betrag AS NUMERIC) AS verrechnung_betrag, CAST(zwsum_1_betrag AS NUMERIC) AS zwsum_1_betrag, CAST(zwsum_2_betrag AS NUMERIC) AS zwsum_2_betrag, CAST(zwsum_3_betrag AS NUMERIC) AS zwsum_3_betrag, CAST(zwsum_4_betrag AS NUMERIC) AS zwsum_4_betrag, CAST(zwsum_5_betrag AS NUMERIC) AS zwsum_5_betrag, CAST(zwsum_6_betrag AS NUMERIC) AS zwsum_6_betrag, CAST(zwsum_8_betrag AS NUMERIC) AS zwsum_8_betrag, CAST(zwsum_9_betrag AS NUMERIC) AS zwsum_9_betrag, CAST(vk_netto_betrag AS NUMERIC) AS vk_netto_betrag, CAST(vk_netto_rekl_tkl_betrag AS NUMERIC) AS vk_netto_rekl_tkl_betrag, CAST(menge_faktura_kolli AS NUMERIC) AS menge_faktura_kolli, CAST(menge_faktura_palette AS NUMERIC) AS menge_faktura_palette, CAST(menge_faktura_bme AS NUMERIC) AS menge_faktura_bme, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_faktura_lgort_wg_wup`;

-- Table: DBP_DATA.WBS_AKTION_ABSATZ_BEREINIGT
insert into `dbp_data.wbs_aktion_absatz_bereinigt` (mandant_id, wup_id, nb_id, art_id, dat, aktion_id, bewart_id, menge_bereinigt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat, aktion_id, CAST(bewart_id AS INT64) AS bewart_id, CAST(menge_bereinigt AS NUMERIC) AS menge_bereinigt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_aktion_absatz_bereinigt`;

-- Table: DBP_MSI_DATA.REICHWEITE_VZ
insert into `dbp_msi_data.reichweite_vz` (mandant_id, wup_id, nb_id, gp_dispo_id, art_dispo_id, dat_plan, gp_id, gp_teilsortiment_id, art_id, disponent_id, menge_best_min, menge_best_min_einh_id, planlieferzeit, menge_einh_lam_id, dat_listung_vz_von, dat_listung_vz_bis, anz_wup_kdis, anz_wup_dis, dat_raeumen_ab, dat_aktion_1, dat_aktion_2, dat_aktion_3, reichweite, reichweite_neu, dat_listung_markt_von, dat_listung_markt_bis, artikelstatus_betrieb, rlz_vz, umrech_faktor_best_bme, lagefaktor, palettenfaktor, gp_dispo_multi_id, ratio, posten_fg, posten_kz_sap, saison_fg, saison_id, auspackware_fg, rundungsprofil, einkaeufer_grp_id, neuer_artikel_fg, werbung_fg, menge_lgbest_erp_frei_kolli, menge_blockbestand_akt_kolli, menge_blockbestand_iwt_kolli, menge_best_iwt_bme, menge_best_gesamt_bme, menge_best_akt_bme, menge_best_bevorratung_bme, menge_wa, menge_wa_akt, dat_lief_next, dat_lief_max, diff_tage_next_max_lief, menge_best_offen_gesamt_bme, menge_best_offen_gesamt_kolli, anz_best_pos, menge_best_offen_next_bme, menge_best_offen_next_kolli, prognose_reichweite_tage_vz_bestand, prognose_reichweite_tage_vz_bestand_we, anz_tage_we_next, prognose_reichweite_tage_vz_minusbestand, menge_best_nwbs_bme, menge_blockbestand_nwbs_kolli, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_dispo_id AS INT64) AS gp_dispo_id, CAST(art_dispo_id AS INT64) AS art_dispo_id, dat_plan, CAST(gp_id AS INT64) AS gp_id, gp_teilsortiment_id, CAST(art_id AS INT64) AS art_id, disponent_id, CAST(menge_best_min AS INT64) AS menge_best_min, menge_best_min_einh_id, CAST(planlieferzeit AS INT64) AS planlieferzeit, menge_einh_lam_id, dat_listung_vz_von, dat_listung_vz_bis, CAST(anz_wup_kdis AS INT64) AS anz_wup_kdis, CAST(anz_wup_dis AS INT64) AS anz_wup_dis, dat_raeumen_ab, dat_aktion_1, dat_aktion_2, dat_aktion_3, CAST(reichweite AS BIGNUMERIC) AS reichweite, CAST(reichweite_neu AS BIGNUMERIC) AS reichweite_neu, dat_listung_markt_von, dat_listung_markt_bis, artikelstatus_betrieb, CAST(rlz_vz AS BIGNUMERIC) AS rlz_vz, CAST(umrech_faktor_best_bme AS BIGNUMERIC) AS umrech_faktor_best_bme, CAST(lagefaktor AS INT64) AS lagefaktor, CAST(palettenfaktor AS INT64) AS palettenfaktor, CAST(gp_dispo_multi_id AS INT64) AS gp_dispo_multi_id, CAST(ratio AS INT64) AS ratio, CAST(posten_fg AS INT64) AS posten_fg, posten_kz_sap, CAST(saison_fg AS INT64) AS saison_fg, saison_id, CAST(auspackware_fg AS INT64) AS auspackware_fg, rundungsprofil, CAST(einkaeufer_grp_id AS INT64) AS einkaeufer_grp_id, CAST(neuer_artikel_fg AS INT64) AS neuer_artikel_fg, CAST(werbung_fg AS INT64) AS werbung_fg, CAST(menge_lgbest_erp_frei_kolli AS BIGNUMERIC) AS menge_lgbest_erp_frei_kolli, CAST(menge_blockbestand_akt_kolli AS BIGNUMERIC) AS menge_blockbestand_akt_kolli, CAST(menge_blockbestand_iwt_kolli AS BIGNUMERIC) AS menge_blockbestand_iwt_kolli, CAST(menge_best_iwt_bme AS BIGNUMERIC) AS menge_best_iwt_bme, CAST(menge_best_gesamt_bme AS BIGNUMERIC) AS menge_best_gesamt_bme, CAST(menge_best_akt_bme AS BIGNUMERIC) AS menge_best_akt_bme, CAST(menge_best_bevorratung_bme AS BIGNUMERIC) AS menge_best_bevorratung_bme, CAST(menge_wa AS BIGNUMERIC) AS menge_wa, CAST(menge_wa_akt AS BIGNUMERIC) AS menge_wa_akt, dat_lief_next, dat_lief_max, CAST(diff_tage_next_max_lief AS INT64) AS diff_tage_next_max_lief, CAST(menge_best_offen_gesamt_bme AS BIGNUMERIC) AS menge_best_offen_gesamt_bme, CAST(menge_best_offen_gesamt_kolli AS BIGNUMERIC) AS menge_best_offen_gesamt_kolli, CAST(anz_best_pos AS INT64) AS anz_best_pos, CAST(menge_best_offen_next_bme AS BIGNUMERIC) AS menge_best_offen_next_bme, CAST(menge_best_offen_next_kolli AS BIGNUMERIC) AS menge_best_offen_next_kolli, CAST(prognose_reichweite_tage_vz_bestand AS INT64) AS prognose_reichweite_tage_vz_bestand, CAST(prognose_reichweite_tage_vz_bestand_we AS INT64) AS prognose_reichweite_tage_vz_bestand_we, CAST(anz_tage_we_next AS INT64) AS anz_tage_we_next, CAST(prognose_reichweite_tage_vz_minusbestand AS INT64) AS prognose_reichweite_tage_vz_minusbestand, CAST(menge_best_nwbs_bme AS BIGNUMERIC) AS menge_best_nwbs_bme, CAST(menge_blockbestand_nwbs_kolli AS BIGNUMERIC) AS menge_blockbestand_nwbs_kolli, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_reichweite_vz`;

-- Table: DBP_ODS.ELS_LEERGUT_POSITION
insert into `dbp_ods.els_leergut_position` (barcode_leergut, mandant_id, bon_zeile, mwst_id, wrg_id, kl_art_id, menge, bon_zeilen_wert, plu_gruppe, td_update, td_insert)
SELECT barcode_leergut, CAST(mandant_id AS INT64) AS mandant_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(mwst_id AS INT64) AS mwst_id, wrg_id, CAST(kl_art_id AS INT64) AS kl_art_id, CAST(menge AS INT64) AS menge, CAST(bon_zeilen_wert AS NUMERIC) AS bon_zeilen_wert, plu_gruppe, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_els_leergut_position`;

-- Table: DBP_ODS.ODS_BON_KOPF_OLD
insert into `dbp_ods.ods_bon_kopf_old` (bon_id, bon_dat, kasse_typ_id, kundenkarte_typ_id, wup_id, mandant_id, bon_nr, kasse_nr, kassierer_nr, kunde_fg, bon_beginn, bon_ende, umsatz_mwst, umsatz_brutto, bon_booking, dat_booking, turnover_fg, wrg_id, reactivated_fg, personal_id, betrag_personal_rabatt, kpos_kasse_typ, wagen_nr, kundenkarte_id, druecken_summentaste, schliessen_kassenschublade, td_insert, td_update)
SELECT bon_id, bon_dat, CAST(kasse_typ_id AS INT64) AS kasse_typ_id, CAST(kundenkarte_typ_id AS INT64) AS kundenkarte_typ_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(bon_nr AS INT64) AS bon_nr, CAST(kasse_nr AS INT64) AS kasse_nr, kassierer_nr, CAST(kunde_fg AS INT64) AS kunde_fg, CAST(bon_beginn AS DATETIME) AS bon_beginn, CAST(bon_ende AS DATETIME) AS bon_ende, CAST(umsatz_mwst AS NUMERIC) AS umsatz_mwst, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(bon_booking AS DATETIME) AS bon_booking, dat_booking, CAST(turnover_fg AS INT64) AS turnover_fg, wrg_id, CAST(reactivated_fg AS INT64) AS reactivated_fg, personal_id, CAST(betrag_personal_rabatt AS NUMERIC) AS betrag_personal_rabatt, kpos_kasse_typ, CAST(wagen_nr AS INT64) AS wagen_nr, kundenkarte_id, CAST(druecken_summentaste AS DATETIME) AS druecken_summentaste, CAST(schliessen_kassenschublade AS DATETIME) AS schliessen_kassenschublade, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_kopf_old`;

-- Table: DBP_MSI_DATA.TUPEL_13_WOCHEN
insert into `dbp_msi_data.tupel_13_wochen` (mandant_id, kjwo_13, matching_id, anzahl_markt_wochen_kombis_abverkauf_af, anzahl_markt_wochen_kombis_abverkauf_sa, anzahl_markt_wochen_kombis_abverkauf_af_vj, anzahl_markt_wochen_kombis_abverkauf_sa_vj, kassenumsatz_kl_absolut_brutto, kassenumsatz_af_kl_absolut_brutto, kassenumsatz_sa_kl_absolut_brutto, kassenumsatz_kl_absolut_brutto_vj, kassenumsatz_af_kl_absolut_brutto_vj, kassenumsatz_sa_kl_absolut_brutto_vj, kassenumsatz_kl_absolut_netto, kassenumsatz_af_kl_absolut_netto, kassenumsatz_sa_kl_absolut_netto, kassenumsatz_kl_absolut_netto_vj, kassenumsatz_af_kl_absolut_netto_vj, kassenumsatz_sa_kl_absolut_netto_vj, absatz_kl, absatz_af_kl, absatz_sa_kl, absatz_kl_vj, absatz_af_kl_vj, absatz_sa_kl_vj, absatz_sst1, absatz_sst2, absatz_sst3, absatz_sst4, absatz_sst5, absatz_sst6, absatz_sst7, absatz_ksst1, absatz_ksst2, absatz_ksst3, absatz_ksst4, absatz_ksst5, absatz_ksst6, absatz_ksst7, absatz_ost_basis, absatz_ost_gross, absatz_sued_ost, absatz_sued_west, absatz_west, absatz_nord, markt_wochen_sst1, markt_wochen_sst2, markt_wochen_sst3, markt_wochen_sst4, markt_wochen_sst5, markt_wochen_sst6, markt_wochen_sst7, markt_wochen_ksst1, markt_wochen_ksst2, markt_wochen_ksst3, markt_wochen_ksst4, markt_wochen_ksst5, markt_wochen_ksst6, markt_wochen_ksst7, markt_wochen_ost_basis, markt_wochen_ost_gross, markt_wochen_sued_ost, markt_wochen_sued_west, markt_wochen_west, markt_wochen_nord, anzahl_markt_wochen_kombis_abverkauf_mit_listung, anzahl_markt_wochen_kombis_listung, rohertrag_ekmep_olk_4n, rohertrag_ekmep_olk_4n_vj, rohertrag_ekmep_olk_4n_af, rohertrag_ekmep_olk_4n_sa, rohertrag_ekmep_olk_4n_af_vj, rohertrag_ekmep_olk_4n_sa_vj, totalabschriften_wert_netto_absolut, preisabschriften_preisanderungen_wert_netto_absolut, totalabschriften_wert_netto_absolut_vj, preisabschriften_preisanderungen_wert_netto_absolut_vj, totalabschriften_wert_netto_absolut_wg, preisabschriften_preisanderungen_wert_netto_absolut_wg, kassenumsatz_kl_absolut_netto_wg, absatz_af_kl_listungswochen, absatz_af_kl_vj_listungswochen, absatz_sa_kl_listungswochen, absatz_sa_kl_vj_listungswochen, kassenumsatz_af_kl_absolut_netto_listungswochen, kassenumsatz_af_kl_absolut_netto_vj_listungswochen, kassenumsatz_sa_kl_absolut_netto_listungswochen, kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, rohertrag_ekmep_olk_4n_af_listungswochen, rohertrag_ekmep_olk_4n_af_vj_listungswochen, rohertrag_ekmep_olk_4n_sa_listungswochen, rohertrag_ekmep_olk_4n_sa_vj_listungswochen, kjwo_update, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo_13 AS INT64) AS kjwo_13, CAST(matching_id AS INT64) AS matching_id, CAST(anzahl_markt_wochen_kombis_abverkauf_af AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af, CAST(anzahl_markt_wochen_kombis_abverkauf_sa AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa, CAST(anzahl_markt_wochen_kombis_abverkauf_af_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_af_vj, CAST(anzahl_markt_wochen_kombis_abverkauf_sa_vj AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_sa_vj, CAST(kassenumsatz_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_kl_absolut_brutto, CAST(kassenumsatz_af_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto, CAST(kassenumsatz_sa_kl_absolut_brutto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto, CAST(kassenumsatz_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_brutto_vj, CAST(kassenumsatz_af_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_brutto_vj, CAST(kassenumsatz_sa_kl_absolut_brutto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_brutto_vj, CAST(kassenumsatz_kl_absolut_netto AS NUMERIC) AS kassenumsatz_kl_absolut_netto, CAST(kassenumsatz_af_kl_absolut_netto AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto, CAST(kassenumsatz_sa_kl_absolut_netto AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto, CAST(kassenumsatz_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_kl_absolut_netto_vj, CAST(kassenumsatz_af_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj, CAST(kassenumsatz_sa_kl_absolut_netto_vj AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj, CAST(absatz_kl AS NUMERIC) AS absatz_kl, CAST(absatz_af_kl AS NUMERIC) AS absatz_af_kl, CAST(absatz_sa_kl AS NUMERIC) AS absatz_sa_kl, CAST(absatz_kl_vj AS NUMERIC) AS absatz_kl_vj, CAST(absatz_af_kl_vj AS NUMERIC) AS absatz_af_kl_vj, CAST(absatz_sa_kl_vj AS NUMERIC) AS absatz_sa_kl_vj, CAST(absatz_sst1 AS NUMERIC) AS absatz_sst1, CAST(absatz_sst2 AS NUMERIC) AS absatz_sst2, CAST(absatz_sst3 AS NUMERIC) AS absatz_sst3, CAST(absatz_sst4 AS NUMERIC) AS absatz_sst4, CAST(absatz_sst5 AS NUMERIC) AS absatz_sst5, CAST(absatz_sst6 AS NUMERIC) AS absatz_sst6, CAST(absatz_sst7 AS NUMERIC) AS absatz_sst7, CAST(absatz_ksst1 AS NUMERIC) AS absatz_ksst1, CAST(absatz_ksst2 AS NUMERIC) AS absatz_ksst2, CAST(absatz_ksst3 AS NUMERIC) AS absatz_ksst3, CAST(absatz_ksst4 AS NUMERIC) AS absatz_ksst4, CAST(absatz_ksst5 AS NUMERIC) AS absatz_ksst5, CAST(absatz_ksst6 AS NUMERIC) AS absatz_ksst6, CAST(absatz_ksst7 AS NUMERIC) AS absatz_ksst7, CAST(absatz_ost_basis AS NUMERIC) AS absatz_ost_basis, CAST(absatz_ost_gross AS NUMERIC) AS absatz_ost_gross, CAST(absatz_sued_ost AS NUMERIC) AS absatz_sued_ost, CAST(absatz_sued_west AS NUMERIC) AS absatz_sued_west, CAST(absatz_west AS NUMERIC) AS absatz_west, CAST(absatz_nord AS NUMERIC) AS absatz_nord, CAST(markt_wochen_sst1 AS INT64) AS markt_wochen_sst1, CAST(markt_wochen_sst2 AS INT64) AS markt_wochen_sst2, CAST(markt_wochen_sst3 AS INT64) AS markt_wochen_sst3, CAST(markt_wochen_sst4 AS INT64) AS markt_wochen_sst4, CAST(markt_wochen_sst5 AS INT64) AS markt_wochen_sst5, CAST(markt_wochen_sst6 AS INT64) AS markt_wochen_sst6, CAST(markt_wochen_sst7 AS INT64) AS markt_wochen_sst7, CAST(markt_wochen_ksst1 AS INT64) AS markt_wochen_ksst1, CAST(markt_wochen_ksst2 AS INT64) AS markt_wochen_ksst2, CAST(markt_wochen_ksst3 AS INT64) AS markt_wochen_ksst3, CAST(markt_wochen_ksst4 AS INT64) AS markt_wochen_ksst4, CAST(markt_wochen_ksst5 AS INT64) AS markt_wochen_ksst5, CAST(markt_wochen_ksst6 AS INT64) AS markt_wochen_ksst6, CAST(markt_wochen_ksst7 AS INT64) AS markt_wochen_ksst7, CAST(markt_wochen_ost_basis AS INT64) AS markt_wochen_ost_basis, CAST(markt_wochen_ost_gross AS INT64) AS markt_wochen_ost_gross, CAST(markt_wochen_sued_ost AS INT64) AS markt_wochen_sued_ost, CAST(markt_wochen_sued_west AS INT64) AS markt_wochen_sued_west, CAST(markt_wochen_west AS INT64) AS markt_wochen_west, CAST(markt_wochen_nord AS INT64) AS markt_wochen_nord, CAST(anzahl_markt_wochen_kombis_abverkauf_mit_listung AS INT64) AS anzahl_markt_wochen_kombis_abverkauf_mit_listung, CAST(anzahl_markt_wochen_kombis_listung AS INT64) AS anzahl_markt_wochen_kombis_listung, CAST(rohertrag_ekmep_olk_4n AS NUMERIC) AS rohertrag_ekmep_olk_4n, CAST(rohertrag_ekmep_olk_4n_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_vj, CAST(rohertrag_ekmep_olk_4n_af AS NUMERIC) AS rohertrag_ekmep_olk_4n_af, CAST(rohertrag_ekmep_olk_4n_sa AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa, CAST(rohertrag_ekmep_olk_4n_af_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj, CAST(rohertrag_ekmep_olk_4n_sa_vj AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj, CAST(totalabschriften_wert_netto_absolut AS NUMERIC) AS totalabschriften_wert_netto_absolut, CAST(preisabschriften_preisanderungen_wert_netto_absolut AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut, CAST(totalabschriften_wert_netto_absolut_vj AS NUMERIC) AS totalabschriften_wert_netto_absolut_vj, CAST(preisabschriften_preisanderungen_wert_netto_absolut_vj AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_vj, CAST(totalabschriften_wert_netto_absolut_wg AS NUMERIC) AS totalabschriften_wert_netto_absolut_wg, CAST(preisabschriften_preisanderungen_wert_netto_absolut_wg AS NUMERIC) AS preisabschriften_preisanderungen_wert_netto_absolut_wg, CAST(kassenumsatz_kl_absolut_netto_wg AS NUMERIC) AS kassenumsatz_kl_absolut_netto_wg, CAST(absatz_af_kl_listungswochen AS NUMERIC) AS absatz_af_kl_listungswochen, CAST(absatz_af_kl_vj_listungswochen AS NUMERIC) AS absatz_af_kl_vj_listungswochen, CAST(absatz_sa_kl_listungswochen AS NUMERIC) AS absatz_sa_kl_listungswochen, CAST(absatz_sa_kl_vj_listungswochen AS NUMERIC) AS absatz_sa_kl_vj_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_listungswochen, CAST(kassenumsatz_af_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_af_kl_absolut_netto_vj_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_listungswochen, CAST(kassenumsatz_sa_kl_absolut_netto_vj_listungswochen AS NUMERIC) AS kassenumsatz_sa_kl_absolut_netto_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_listungswochen, CAST(rohertrag_ekmep_olk_4n_af_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_af_vj_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_listungswochen, CAST(rohertrag_ekmep_olk_4n_sa_vj_listungswochen AS NUMERIC) AS rohertrag_ekmep_olk_4n_sa_vj_listungswochen, CAST(kjwo_update AS INT64) AS kjwo_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_tupel_13_wochen`;

-- Table: DBP_DATA.COI_UMP_UMSATZPLAN_HWG
insert into `dbp_data.coi_ump_umsatzplan_hwg` (mandant_id, gj_plan, version_id, wup_id, nb_id, dat_plan, arthiertyp_id, hwg_id, wrg_id, land_level, vs_id, wup_id_referenz, dat_referenz, faktor_kalender, faktor_basis, faktor_wup_referenz, umsatz_netto_basis_1, umsatz_netto_basis_2, umsatz_netto_basis_3, umsatz_netto_plan, wup_geoeffnet_fg, umsatz_netto_plan_vj, umsatz_netto_plan_vj_kt, umsatz_basis_vj, umsatz_basis_vj_kt, umsatz_basis_vvj, umsatz_basis_vvj_kt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(gj_plan AS INT64) AS gj_plan, CAST(version_id AS INT64) AS version_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_plan, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(hwg_id AS INT64) AS hwg_id, wrg_id, land_level, CAST(vs_id AS INT64) AS vs_id, CAST(wup_id_referenz AS INT64) AS wup_id_referenz, dat_referenz, CAST(faktor_kalender AS BIGNUMERIC) AS faktor_kalender, CAST(faktor_basis AS BIGNUMERIC) AS faktor_basis, CAST(faktor_wup_referenz AS BIGNUMERIC) AS faktor_wup_referenz, CAST(umsatz_netto_basis_1 AS NUMERIC) AS umsatz_netto_basis_1, CAST(umsatz_netto_basis_2 AS NUMERIC) AS umsatz_netto_basis_2, CAST(umsatz_netto_basis_3 AS NUMERIC) AS umsatz_netto_basis_3, CAST(umsatz_netto_plan AS NUMERIC) AS umsatz_netto_plan, CAST(wup_geoeffnet_fg AS INT64) AS wup_geoeffnet_fg, CAST(umsatz_netto_plan_vj AS NUMERIC) AS umsatz_netto_plan_vj, CAST(umsatz_netto_plan_vj_kt AS NUMERIC) AS umsatz_netto_plan_vj_kt, CAST(umsatz_basis_vj AS NUMERIC) AS umsatz_basis_vj, CAST(umsatz_basis_vj_kt AS NUMERIC) AS umsatz_basis_vj_kt, CAST(umsatz_basis_vvj AS NUMERIC) AS umsatz_basis_vvj, CAST(umsatz_basis_vvj_kt AS NUMERIC) AS umsatz_basis_vvj_kt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_coi_ump_umsatzplan_hwg`;

-- Table: DBP_DATA.BESCH_LIEF_WUP_SUM
insert into `dbp_data.besch_lief_wup_sum` (dat_lief_soll, kunde_id, lagerort_id, lief_pal_typ_id, lief_typ_id, mandant_id, nb_id, vertr_beleg_typ_id, wup_id, wg_verkett_lief, menge_lief_ist_kolli, anzahl_packstueck, anzahl_position, menge_lief_ist_bme, betrag_lief_ist, menge_lief_soll_bme, menge_lief_soll_kolli, werbeware_id, betrag_lief_soll, wrg_id, mandant_id_kunde, vk_netto_lief_soll, vk_netto_lief_ist, brtvol_ladung_liter, bestellart_id, hu_status_id, brtvol_ladung_liter_gedeckelt, td_update, td_insert)
SELECT dat_lief_soll, kunde_id, lagerort_id, lief_pal_typ_id, lief_typ_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, vertr_beleg_typ_id, CAST(wup_id AS INT64) AS wup_id, CAST(wg_verkett_lief AS INT64) AS wg_verkett_lief, CAST(menge_lief_ist_kolli AS NUMERIC) AS menge_lief_ist_kolli, CAST(anzahl_packstueck AS INT64) AS anzahl_packstueck, CAST(anzahl_position AS INT64) AS anzahl_position, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, CAST(betrag_lief_ist AS NUMERIC) AS betrag_lief_ist, CAST(menge_lief_soll_bme AS NUMERIC) AS menge_lief_soll_bme, CAST(menge_lief_soll_kolli AS NUMERIC) AS menge_lief_soll_kolli, werbeware_id, CAST(betrag_lief_soll AS NUMERIC) AS betrag_lief_soll, wrg_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, CAST(vk_netto_lief_soll AS NUMERIC) AS vk_netto_lief_soll, CAST(vk_netto_lief_ist AS NUMERIC) AS vk_netto_lief_ist, CAST(brtvol_ladung_liter AS NUMERIC) AS brtvol_ladung_liter, bestellart_id, hu_status_id, CAST(brtvol_ladung_liter_gedeckelt AS NUMERIC) AS brtvol_ladung_liter_gedeckelt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_wup_sum`;

-- Table: DBP_DATA.PROTOKOLL_AENDERUNG_BSF
insert into `dbp_data.protokoll_aenderung_bsf` (mandant_id, dat_aenderung, datzeit_aenderung_utc, wup_id, lagernummer_id, bereitstellungsflaeche, doppelbelegung_kz, index_nano, nb_id, transaktion_code, vorgangstyp_id, abbruchbedingung, kunde_id, wgvgrp_id, zlv_bsf_status, referenznummer, bestandart_id, status_verplant_fg, fixe_einplanung_fg, status_verplan_ign_fg, max_kap_bsf, anz_pal_bsf, verplante_kap, bestand_bsf, zlv_stp_ist, fixe_einplanung_markt_fg, lag_aktionssort, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat_aenderung, CAST(datzeit_aenderung_utc AS DATETIME) AS datzeit_aenderung_utc, CAST(wup_id AS INT64) AS wup_id, lagernummer_id, bereitstellungsflaeche, doppelbelegung_kz, CAST(index_nano AS INT64) AS index_nano, CAST(nb_id AS INT64) AS nb_id, transaktion_code, vorgangstyp_id, abbruchbedingung, kunde_id, CAST(wgvgrp_id AS INT64) AS wgvgrp_id, zlv_bsf_status, referenznummer, bestandart_id, CAST(status_verplant_fg AS INT64) AS status_verplant_fg, CAST(fixe_einplanung_fg AS INT64) AS fixe_einplanung_fg, CAST(status_verplan_ign_fg AS INT64) AS status_verplan_ign_fg, CAST(max_kap_bsf AS NUMERIC) AS max_kap_bsf, CAST(anz_pal_bsf AS NUMERIC) AS anz_pal_bsf, CAST(verplante_kap AS NUMERIC) AS verplante_kap, CAST(bestand_bsf AS INT64) AS bestand_bsf, CAST(zlv_stp_ist AS NUMERIC) AS zlv_stp_ist, CAST(fixe_einplanung_markt_fg AS INT64) AS fixe_einplanung_markt_fg, lag_aktionssort, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_protokoll_aenderung_bsf`;

-- Table: DBP_ODS.ODS_BON_ZAHLUNG_OLD
insert into `dbp_ods.ods_bon_zahlung_old` (bon_id, bon_zeile, wup_id, mandant_id, zahlung_typ_id, start_bon_zeile, betrag_zahlung, wrg_id, kpos_zahlung_typ_id, bon_dat, bon_zeile_cashback_referenz, td_insert, td_update)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(zahlung_typ_id AS INT64) AS zahlung_typ_id, CAST(start_bon_zeile AS DATETIME) AS start_bon_zeile, CAST(betrag_zahlung AS NUMERIC) AS betrag_zahlung, wrg_id, kpos_zahlung_typ_id, bon_dat, CAST(bon_zeile_cashback_referenz AS INT64) AS bon_zeile_cashback_referenz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_zahlung_old`;

-- Table: DBP_DATA.ART_WUP_AUTODISPO_FLW_TAG_OLD
insert into `dbp_data.art_wup_autodispo_flw_tag_old` (mandant_id, kunde_id, wup_id, nb_id_kunde, nb_id_lieferant, art_id, dat, we_bearbeitungszeit, planlieferzeit, kdis, verkaufslistung_fg, sa_af_fg, udf_prognose_menge_ungesteuert, fur_prognose_menge_ungesteuert, fur_prognose_menge_gesteuert, fur_prognose_menge_max, menge_abverkauf, ret_bestand, fur_bestand, menge_we_offen, menge_bv, menge_ofc, nullbestand_fg, menge_preisabschriften, menge_totalabschriften, kollifaktor, egalisierungsfaktor, menge_einh_id, servicelevel, optik, menge_we, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id_kunde AS INT64) AS nb_id_kunde, CAST(nb_id_lieferant AS INT64) AS nb_id_lieferant, CAST(art_id AS INT64) AS art_id, dat, CAST(we_bearbeitungszeit AS INT64) AS we_bearbeitungszeit, CAST(planlieferzeit AS INT64) AS planlieferzeit, CAST(kdis AS INT64) AS kdis, CAST(verkaufslistung_fg AS INT64) AS verkaufslistung_fg, CAST(sa_af_fg AS INT64) AS sa_af_fg, CAST(udf_prognose_menge_ungesteuert AS NUMERIC) AS udf_prognose_menge_ungesteuert, CAST(fur_prognose_menge_ungesteuert AS NUMERIC) AS fur_prognose_menge_ungesteuert, CAST(fur_prognose_menge_gesteuert AS NUMERIC) AS fur_prognose_menge_gesteuert, CAST(fur_prognose_menge_max AS NUMERIC) AS fur_prognose_menge_max, CAST(menge_abverkauf AS NUMERIC) AS menge_abverkauf, CAST(ret_bestand AS NUMERIC) AS ret_bestand, CAST(fur_bestand AS NUMERIC) AS fur_bestand, CAST(menge_we_offen AS NUMERIC) AS menge_we_offen, CAST(menge_bv AS NUMERIC) AS menge_bv, CAST(menge_ofc AS NUMERIC) AS menge_ofc, CAST(nullbestand_fg AS INT64) AS nullbestand_fg, CAST(menge_preisabschriften AS NUMERIC) AS menge_preisabschriften, CAST(menge_totalabschriften AS NUMERIC) AS menge_totalabschriften, CAST(kollifaktor AS NUMERIC) AS kollifaktor, CAST(egalisierungsfaktor AS NUMERIC) AS egalisierungsfaktor, menge_einh_id, CAST(servicelevel AS NUMERIC) AS servicelevel, CAST(optik AS NUMERIC) AS optik, CAST(menge_we AS NUMERIC) AS menge_we, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_art_wup_autodispo_flw_tag_old`;

-- Table: DBP_DATA.FLW_LAGERBEW_DET
insert into `dbp_data.flw_lagerbew_det` (flw_art_id, mandant_id, lagerbew_beleg_id, lagerbew_beleg_pos_id, kj, auto_id, flw_lief_id, charge_id, soll_haben_kz, wrg_id, betrag_lagerbew, betrag_lagerbew_altnv, menge_lagerbew_bme, menge_bstmg, best_menge_einh_id, werk_id, empfaenger_id, best_beleg_id, best_beleg_pos_id, menge_erf, lager_bewart_id, auftrag_id, kostenstelle_id, lagerort_id, menge_bestellpreis, bestellpreis_menge_einh_id, erfsngs_menge_einh_id, system_id, td_update, td_insert)
SELECT CAST(flw_art_id AS INT64) AS flw_art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(lagerbew_beleg_pos_id AS INT64) AS lagerbew_beleg_pos_id, CAST(kj AS INT64) AS kj, auto_id, CAST(flw_lief_id AS INT64) AS flw_lief_id, charge_id, soll_haben_kz, wrg_id, CAST(betrag_lagerbew AS NUMERIC) AS betrag_lagerbew, CAST(betrag_lagerbew_altnv AS NUMERIC) AS betrag_lagerbew_altnv, CAST(menge_lagerbew_bme AS NUMERIC) AS menge_lagerbew_bme, CAST(menge_bstmg AS NUMERIC) AS menge_bstmg, best_menge_einh_id, CAST(werk_id AS INT64) AS werk_id, CAST(empfaenger_id AS INT64) AS empfaenger_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(menge_erf AS NUMERIC) AS menge_erf, lager_bewart_id, auftrag_id, kostenstelle_id, lagerort_id, CAST(menge_bestellpreis AS NUMERIC) AS menge_bestellpreis, bestellpreis_menge_einh_id, erfsngs_menge_einh_id, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_lagerbew_det`;

-- Table: DBP_MSI_DATA.LAGERAUFGABE_WE
insert into `dbp_msi_data.lageraufgabe_we` (mandant_id, lagernummer_id, lageraufgabe_id, lageraufgabe_pos_id, best_beleg_id, lief_beleg_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, transportation_unit_id_ext, lagerprozessart_id, status_id, lagerprozess_id, zz_colli_qty, menge_kolli, menge_pal, lagerbereich_id_nach, lagertyp_id_nach, le_typ_id, gewicht_netto, gewicht_brutto, gew_einh_id, volumen, vol_einh_id, dat_mhd, datzeit_we, dat_we, datzeit_erstellung, dat_erstellung, handling_unit_id_nach, handling_unit_guid_nach, handling_unit_id_von, handling_unit_guid_von, bestandsart_id, charge_id, gefahrstoff_fg, aktivitaetsbereich_id, art_guid, menge_ist_bme, menge_ist_ame, rollback_fg, art_id, gp_id, queue_id, datzeit_bestaetigung, dat_bestaetigung, lagertyp_id_von, artikelsortiment_id, lagersortiment_id, distanz_reserve_fixplatz, distanz_bsf_reserve, distanz_hoehe, handling_unit_id_nach_fixplatz, handling_unit_id_nach_bsf, handling_unit_id_nach_hoehe, lagertyp_id_nach_distanz, lagerplatz_id_nach_distanz, lagerplatz_id_nach, lagerplatz_id_von, selbstabhol_fg, lageraufgabe_orig_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(lageraufgabe_id AS INT64) AS lageraufgabe_id, CAST(lageraufgabe_pos_id AS INT64) AS lageraufgabe_pos_id, best_beleg_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, transportation_unit_id_ext, lagerprozessart_id, status_id, lagerprozess_id, CAST(zz_colli_qty AS INT64) AS zz_colli_qty, CAST(menge_kolli AS NUMERIC) AS menge_kolli, CAST(menge_pal AS NUMERIC) AS menge_pal, lagerbereich_id_nach, lagertyp_id_nach, le_typ_id, CAST(gewicht_netto AS NUMERIC) AS gewicht_netto, CAST(gewicht_brutto AS NUMERIC) AS gewicht_brutto, gew_einh_id, CAST(volumen AS NUMERIC) AS volumen, vol_einh_id, dat_mhd, CAST(datzeit_we AS DATETIME) AS datzeit_we, dat_we, CAST(datzeit_erstellung AS DATETIME) AS datzeit_erstellung, dat_erstellung, handling_unit_id_nach, handling_unit_guid_nach, handling_unit_id_von, handling_unit_guid_von, bestandsart_id, charge_id, CAST(gefahrstoff_fg AS INT64) AS gefahrstoff_fg, aktivitaetsbereich_id, art_guid, CAST(menge_ist_bme AS BIGNUMERIC) AS menge_ist_bme, CAST(menge_ist_ame AS BIGNUMERIC) AS menge_ist_ame, CAST(rollback_fg AS INT64) AS rollback_fg, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, queue_id, CAST(datzeit_bestaetigung AS DATETIME) AS datzeit_bestaetigung, dat_bestaetigung, lagertyp_id_von, artikelsortiment_id, lagersortiment_id, CAST(distanz_reserve_fixplatz AS NUMERIC) AS distanz_reserve_fixplatz, CAST(distanz_bsf_reserve AS NUMERIC) AS distanz_bsf_reserve, CAST(distanz_hoehe AS NUMERIC) AS distanz_hoehe, handling_unit_id_nach_fixplatz, handling_unit_id_nach_bsf, handling_unit_id_nach_hoehe, lagertyp_id_nach_distanz, lagerplatz_id_nach_distanz, lagerplatz_id_nach, lagerplatz_id_von, CAST(selbstabhol_fg AS INT64) AS selbstabhol_fg, CAST(lageraufgabe_orig_fg AS INT64) AS lageraufgabe_orig_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_lageraufgabe_we`;

-- Table: DBP_ODS.ODS_BON_BUCHUNGEN
insert into `dbp_ods.ods_bon_buchungen` (bon_id, bon_zeile, buchungsschluessel_id, wup_id, mandant_id, kpos_zahlung_typ_id, dat_booking, bon_dat, start_bon_zeile, kasse_nr, bon_nr, betrag_buchung, kommentar_buchung, td_update, td_insert)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(buchungsschluessel_id AS INT64) AS buchungsschluessel_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, kpos_zahlung_typ_id, dat_booking, bon_dat, start_bon_zeile, CAST(kasse_nr AS INT64) AS kasse_nr, CAST(bon_nr AS INT64) AS bon_nr, CAST(betrag_buchung AS NUMERIC) AS betrag_buchung, kommentar_buchung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_buchungen`;

-- Table: DBP_DATA.FLW_FAKTURA_BELEGFLUSS
insert into `dbp_data.flw_faktura_belegfluss` (mandant_id, lief_beleg_id, lief_beleg_pos_id, folge_beleg_id, folge_beleg_pos_id, folge_beleg_typ_id, lief_beleg_typ_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, CAST(folge_beleg_id AS INT64) AS folge_beleg_id, CAST(folge_beleg_pos_id AS INT64) AS folge_beleg_pos_id, folge_beleg_typ_id, lief_beleg_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_faktura_belegfluss`;

-- Table: DBP_DATA.CRM_L_OPTIN
insert into `dbp_data.crm_l_optin` (crm_optin_id, crm_loyalty_fg, crm_optin_kanal_cd, td_update, td_insert)
SELECT crm_optin_id, CAST(crm_loyalty_fg AS INT64) AS crm_loyalty_fg, crm_optin_kanal_cd, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_crm_l_optin`;

-- Table: DBP_DATA.NFMD_ARTICLE_STORE_CURVES
insert into `dbp_data.nfmd_article_store_curves` (mandant_id, aktion_id, art_id, wup_id, wrg_id, wg_id, kjwo_ww, curve_week_nr, promo_start_dt, selling_price_gross_local_val, stock_initial_cnt, weekly_sales_cnt, cumulated_sales_cnt, weekly_revenue_gross_local_val, weekly_sell_rate, weekly_price_rate, model_execution_tmsp, ai_model_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(wg_id AS INT64) AS wg_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, CAST(curve_week_nr AS INT64) AS curve_week_nr, promo_start_dt, CAST(selling_price_gross_local_val AS NUMERIC) AS selling_price_gross_local_val, CAST(stock_initial_cnt AS INT64) AS stock_initial_cnt, CAST(weekly_sales_cnt AS INT64) AS weekly_sales_cnt, CAST(cumulated_sales_cnt AS INT64) AS cumulated_sales_cnt, CAST(weekly_revenue_gross_local_val AS NUMERIC) AS weekly_revenue_gross_local_val, CAST(weekly_sell_rate AS NUMERIC) AS weekly_sell_rate, CAST(weekly_price_rate AS NUMERIC) AS weekly_price_rate, model_execution_tmsp, ai_model_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_article_store_curves`;

-- Table: DBP_DATA.LADUNGSTRAEGER
insert into `dbp_data.ladungstraeger` (mandant_id, lagernummer_id, art_id, wup_id, nb_id, tour_id, lief_beleg_id, handling_unit_id_ext, kj_lief_beleg, system_id, anz_ladtraeger, status_ladtraeger, dat_erstellung, anz_ladtraeger_orig, anz_ladtraeger_defekt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(tour_id AS INT64) AS tour_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, handling_unit_id_ext, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, CAST(system_id AS INT64) AS system_id, CAST(anz_ladtraeger AS INT64) AS anz_ladtraeger, status_ladtraeger, dat_erstellung, CAST(anz_ladtraeger_orig AS INT64) AS anz_ladtraeger_orig, CAST(anz_ladtraeger_defekt AS INT64) AS anz_ladtraeger_defekt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ladungstraeger`;

-- Table: DBP_ODS.ELS_LEERGUT_KOPF
insert into `dbp_ods.els_leergut_kopf` (barcode_leergut, mandant_id, wup_id, nb_id, bon_dat, wrg_id, bon_tmsp, bon_nr, system_bez, system_typ_bez, system_hersteller_bez, bon_wert, td_update, td_insert)
SELECT barcode_leergut, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, bon_dat, wrg_id, bon_tmsp, CAST(bon_nr AS INT64) AS bon_nr, system_bez, system_typ_bez, system_hersteller_bez, CAST(bon_wert AS NUMERIC) AS bon_wert, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_els_leergut_kopf`;

-- Table: DBP_ODS_ARCHIV.ODS_PROMOTION
insert into `dbp_ods_archiv.ods_promotion` (mandant_id, bon_id, wup_id, bon_zeile, bonuskauf_id, konditionsart_id, promotion_lfd_nr, betrag_promo_brutto, kl_art_id, start_bon_zeile, menge_promo, umsatz_promo_brutto, bon_dat, customer_promotion_fg, promotion_art, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, bon_id, CAST(wup_id AS INT64) AS wup_id, CAST(bon_zeile AS INT64) AS bon_zeile, bonuskauf_id, konditionsart_id, CAST(promotion_lfd_nr AS INT64) AS promotion_lfd_nr, CAST(betrag_promo_brutto AS NUMERIC) AS betrag_promo_brutto, CAST(kl_art_id AS INT64) AS kl_art_id, CAST(start_bon_zeile AS DATETIME) AS start_bon_zeile, CAST(menge_promo AS NUMERIC) AS menge_promo, CAST(umsatz_promo_brutto AS NUMERIC) AS umsatz_promo_brutto, bon_dat, CAST(customer_promotion_fg AS INT64) AS customer_promotion_fg, promotion_art, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_promotion`;

-- Table: DBP_DATA.WUP_KUNDE_ART_DISPORHYTHMUS_LTF_AKT
insert into `dbp_data.wup_kunde_art_disporhythmus_ltf_akt` (mandant_id, wup_id, nb_id, kunde_id, art_id, wg_id, arthiertyp_id, disposition_rhythmus_ltf_id, terminierungsgruppe_1_id, terminierungsgruppe_2_id, terminierungsgruppe_3_id, auslieferungsgruppe_id, disponent_id, wg_verkett_id, ausg_menge_einh_id, we_bearbeitungszeit, planlieferzeit, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(art_id AS INT64) AS art_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, disposition_rhythmus_ltf_id, terminierungsgruppe_1_id, terminierungsgruppe_2_id, terminierungsgruppe_3_id, auslieferungsgruppe_id, disponent_id, CAST(wg_verkett_id AS INT64) AS wg_verkett_id, ausg_menge_einh_id, CAST(we_bearbeitungszeit AS INT64) AS we_bearbeitungszeit, CAST(planlieferzeit AS INT64) AS planlieferzeit, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_kunde_art_disporhythmus_ltf_akt`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_RETOURE
insert into `dbp_ods_archiv.ods_bon_retoure` (bon_id, bon_zeile, kl_art_id, ean_kasse, wg_id, menge, einh_id, umsatz_brutto, mwst_id, erfassung_id, aktion_id, reklamationsgrund_id, reklamationstyp_id, menge_fg, mandant_id, mhd, los_charge, kunden_text, wup_id, art_id_ref, gp_id, start_bon_zeile, talon_id, kpos_erfassung_id, umsatz_brutto_norm, vk_brutto_obb, bon_vorgang_id, barcode_string, bon_dat, barcode_leergut, td_insert, td_update)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(kl_art_id AS INT64) AS kl_art_id, CAST(ean_kasse AS NUMERIC) AS ean_kasse, CAST(wg_id AS INT64) AS wg_id, CAST(menge AS NUMERIC) AS menge, einh_id, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(mwst_id AS INT64) AS mwst_id, erfassung_id, aktion_id, CAST(reklamationsgrund_id AS INT64) AS reklamationsgrund_id, reklamationstyp_id, CAST(menge_fg AS INT64) AS menge_fg, CAST(mandant_id AS INT64) AS mandant_id, mhd, los_charge, kunden_text, CAST(wup_id AS INT64) AS wup_id, CAST(art_id_ref AS INT64) AS art_id_ref, CAST(gp_id AS INT64) AS gp_id, CAST(start_bon_zeile AS DATETIME) AS start_bon_zeile, CAST(talon_id AS NUMERIC) AS talon_id, kpos_erfassung_id, CAST(umsatz_brutto_norm AS NUMERIC) AS umsatz_brutto_norm, CAST(vk_brutto_obb AS NUMERIC) AS vk_brutto_obb, CAST(bon_vorgang_id AS INT64) AS bon_vorgang_id, barcode_string, bon_dat, barcode_leergut, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_retoure`;

-- Table: DBP_ETL_PROCESS.IMS_MAMO_ARTBEW_MO_SUM
insert into `dbp_etl_process.ims_mamo_artbew_mo_sum` (mandant_id, kjmo, wup_id, nb_id, art_id, bewart_id, menge, umsatz_netto, ek_mep, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(bewart_id AS INT64) AS bewart_id, CAST(menge AS NUMERIC) AS menge, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(ek_mep AS NUMERIC) AS ek_mep, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_ims_mamo_artbew_mo_sum`;

-- Table: DBP_DATA.UDF_PROGNOSE_WHATIF
insert into `dbp_data.udf_prognose_whatif` (mandant_id, art_id, wup_id, nb_id, angebot_id, dat_von, dat_bis, menge_prognose_basis, menge_prognose_saison, menge_prognose_feiertag, menge_prognose_preisaenderung, menge_prognose_kaufanreize, menge_prognose_uplift, menge_prognose_werbemittel, menge_prognose_praemienkaufanreize, menge_prognose_kundenkarte, menge_prognose_verfuegbarkeit, menge_prognose_kannibalisierung, menge_prognose_verbund, menge_prognose_faktoren, menge_prognose_gesamt, dat_erstellung, dat_beladung, dat_prognose_werbung_zuletzt_gesteuert, dat_prognose_normal_zuletzt_gesteuert, prognose_offer_nullwert_fg, prognose_preis_nullwert_fg, prognose_preis_faktor_fg, prognose_tactic_nullwert_fg, menge_prognose_faktor_fg, menge_prognose_nullwert_fg, quelle_alt_prioren_fg, anz_prior_gesamt, anz_prior_eigen, anz_prior_ref, anz_prior_hpr, anz_prior_default, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(angebot_id AS INT64) AS angebot_id, dat_von, dat_bis, CAST(menge_prognose_basis AS NUMERIC) AS menge_prognose_basis, CAST(menge_prognose_saison AS NUMERIC) AS menge_prognose_saison, CAST(menge_prognose_feiertag AS NUMERIC) AS menge_prognose_feiertag, CAST(menge_prognose_preisaenderung AS NUMERIC) AS menge_prognose_preisaenderung, CAST(menge_prognose_kaufanreize AS NUMERIC) AS menge_prognose_kaufanreize, CAST(menge_prognose_uplift AS NUMERIC) AS menge_prognose_uplift, CAST(menge_prognose_werbemittel AS NUMERIC) AS menge_prognose_werbemittel, CAST(menge_prognose_praemienkaufanreize AS NUMERIC) AS menge_prognose_praemienkaufanreize, CAST(menge_prognose_kundenkarte AS NUMERIC) AS menge_prognose_kundenkarte, CAST(menge_prognose_verfuegbarkeit AS NUMERIC) AS menge_prognose_verfuegbarkeit, CAST(menge_prognose_kannibalisierung AS NUMERIC) AS menge_prognose_kannibalisierung, CAST(menge_prognose_verbund AS NUMERIC) AS menge_prognose_verbund, CAST(menge_prognose_faktoren AS NUMERIC) AS menge_prognose_faktoren, CAST(menge_prognose_gesamt AS NUMERIC) AS menge_prognose_gesamt, dat_erstellung, dat_beladung, dat_prognose_werbung_zuletzt_gesteuert, dat_prognose_normal_zuletzt_gesteuert, CAST(prognose_offer_nullwert_fg AS INT64) AS prognose_offer_nullwert_fg, CAST(prognose_preis_nullwert_fg AS INT64) AS prognose_preis_nullwert_fg, CAST(prognose_preis_faktor_fg AS INT64) AS prognose_preis_faktor_fg, CAST(prognose_tactic_nullwert_fg AS INT64) AS prognose_tactic_nullwert_fg, CAST(menge_prognose_faktor_fg AS INT64) AS menge_prognose_faktor_fg, CAST(menge_prognose_nullwert_fg AS INT64) AS menge_prognose_nullwert_fg, CAST(quelle_alt_prioren_fg AS INT64) AS quelle_alt_prioren_fg, CAST(anz_prior_gesamt AS INT64) AS anz_prior_gesamt, CAST(anz_prior_eigen AS INT64) AS anz_prior_eigen, CAST(anz_prior_ref AS INT64) AS anz_prior_ref, CAST(anz_prior_hpr AS INT64) AS anz_prior_hpr, CAST(anz_prior_default AS INT64) AS anz_prior_default, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_udf_prognose_whatif`;

-- Table: DBP_DATA.WBS_GEWICHTE_TAG
insert into `dbp_data.wbs_gewichte_tag` (mandant_id, wup_id, nb_id, art_id, aktion_id, dat_von, dat_bis, kategorie, anzahl_faelle, gewicht_tag1, gewicht_tag5, gewicht_tag3, gewicht_tag2, gewicht_tag4, gewicht_tag11, gewicht_tag10, gewicht_tag9, gewicht_tag8, gewicht_tag7, gewicht_tag6, gewicht_tag14, gewicht_tag13, gewicht_tag12, referenziert_fg, wbs_level, wbs_level_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, aktion_id, dat_von, dat_bis, kategorie, CAST(anzahl_faelle AS INT64) AS anzahl_faelle, CAST(gewicht_tag1 AS NUMERIC) AS gewicht_tag1, CAST(gewicht_tag5 AS NUMERIC) AS gewicht_tag5, CAST(gewicht_tag3 AS NUMERIC) AS gewicht_tag3, CAST(gewicht_tag2 AS NUMERIC) AS gewicht_tag2, CAST(gewicht_tag4 AS NUMERIC) AS gewicht_tag4, CAST(gewicht_tag11 AS NUMERIC) AS gewicht_tag11, CAST(gewicht_tag10 AS NUMERIC) AS gewicht_tag10, CAST(gewicht_tag9 AS NUMERIC) AS gewicht_tag9, CAST(gewicht_tag8 AS NUMERIC) AS gewicht_tag8, CAST(gewicht_tag7 AS NUMERIC) AS gewicht_tag7, CAST(gewicht_tag6 AS NUMERIC) AS gewicht_tag6, CAST(gewicht_tag14 AS NUMERIC) AS gewicht_tag14, CAST(gewicht_tag13 AS NUMERIC) AS gewicht_tag13, CAST(gewicht_tag12 AS NUMERIC) AS gewicht_tag12, CAST(referenziert_fg AS INT64) AS referenziert_fg, wbs_level, CAST(wbs_level_id AS INT64) AS wbs_level_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_gewichte_tag`;

-- Table: DBP_DATA.WBS_GEWICHTE_STUNDE
insert into `dbp_data.wbs_gewichte_stunde` (mandant_id, wup_id, nb_id, art_id, aktion_id, dat_von, dat_bis, anzahl_faelle, anzahl_faelle_im_korridor, korridor_level, kategorie, menge_max, menge_min, menge_avg_21tage, anteil_zeitfenster1, anteil_zeitfenster2, referenziert_fg, wbs_level, wbs_level_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, aktion_id, dat_von, dat_bis, CAST(anzahl_faelle AS INT64) AS anzahl_faelle, CAST(anzahl_faelle_im_korridor AS INT64) AS anzahl_faelle_im_korridor, CAST(korridor_level AS INT64) AS korridor_level, kategorie, CAST(menge_max AS INT64) AS menge_max, CAST(menge_min AS INT64) AS menge_min, CAST(menge_avg_21tage AS NUMERIC) AS menge_avg_21tage, CAST(anteil_zeitfenster1 AS NUMERIC) AS anteil_zeitfenster1, CAST(anteil_zeitfenster2 AS NUMERIC) AS anteil_zeitfenster2, CAST(referenziert_fg AS INT64) AS referenziert_fg, wbs_level, CAST(wbs_level_id AS INT64) AS wbs_level_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_gewichte_stunde`;

-- Table: DBP_ODS_ARCHIV.ODS_TALON_DET
insert into `dbp_ods_archiv.ods_talon_det` (mandant_id, talon_id, talon_pos_id, wup_id, kl_art_id, umsatz_brutto, menge, mwst, wg_id, turnover_fg, artbew_fg, aktion_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(talon_id AS NUMERIC) AS talon_id, CAST(talon_pos_id AS INT64) AS talon_pos_id, CAST(wup_id AS INT64) AS wup_id, CAST(kl_art_id AS INT64) AS kl_art_id, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(menge AS NUMERIC) AS menge, CAST(mwst AS NUMERIC) AS mwst, CAST(wg_id AS INT64) AS wg_id, CAST(turnover_fg AS INT64) AS turnover_fg, CAST(artbew_fg AS INT64) AS artbew_fg, aktion_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_talon_det`;

-- Table: DBP_DATA.WBS_ART_AKTION_REF
insert into `dbp_data.wbs_art_aktion_ref` (mandant_id, wup_id, nb_id, art_id, aktion_id, kjwo_von, dat_von, dat_bis, aktion_dauer, wtag_id_von, mandant_id_vz, wup_id_vz, mutter_wb_id, wup_id_ref, nb_id_ref, art_id_ref, faktor_ref, aktion_id_ref, dat_von_ref, dat_bis_ref, aktion_reihenfolge, anz_akt_selbe_dauer, menge_sa_bme_ref, menge_gesamt_bme_ref, zeitraum_korrigierte_menge_ref, zeitraum_menge_af_4wo_ref, sales_fg_ref, in_gruppe_fg, anz_art_in_gruppe, anz_art_in_gruppe_ref, tv_fg_ref, titelseite_fg_ref, rueckseite_fg_ref, gk_fg_ref, vk_aktion_brutto_ref, vk_vor_aktion_brutto_ref, wrg_id, multi_offer_id_fg_ref, bonuskauf_fg_ref, lokale_geschaeftsvorfall_bez_ref, wbs_art_wup_ref_typ_id, berechnete_menge_gesamt_bme_ref, lief_menge_initial_bme_ref, lief_menge_hochrechnung_bme_ref, lief_menge_anteil_prozent_ref, nur_online_fg_ref, kundenkarte_personalisiert_fg_ref, stille_aktion_fg_ref, stille_aktion_mit_menge_fg_ref, werbeflaeche_abschnitt_name_ref, werbeflaeche_thema_bez_ref, fixmenge_fg_ref, fixmenge_wfl_fg_ref, mindestplatzierung_fg_ref, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, aktion_id, CAST(kjwo_von AS INT64) AS kjwo_von, dat_von, dat_bis, CAST(aktion_dauer AS INT64) AS aktion_dauer, CAST(wtag_id_von AS INT64) AS wtag_id_von, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(mutter_wb_id AS INT64) AS mutter_wb_id, CAST(wup_id_ref AS INT64) AS wup_id_ref, CAST(nb_id_ref AS INT64) AS nb_id_ref, CAST(art_id_ref AS INT64) AS art_id_ref, CAST(faktor_ref AS NUMERIC) AS faktor_ref, aktion_id_ref, dat_von_ref, dat_bis_ref, CAST(aktion_reihenfolge AS INT64) AS aktion_reihenfolge, CAST(anz_akt_selbe_dauer AS INT64) AS anz_akt_selbe_dauer, CAST(menge_sa_bme_ref AS NUMERIC) AS menge_sa_bme_ref, CAST(menge_gesamt_bme_ref AS NUMERIC) AS menge_gesamt_bme_ref, CAST(zeitraum_korrigierte_menge_ref AS NUMERIC) AS zeitraum_korrigierte_menge_ref, CAST(zeitraum_menge_af_4wo_ref AS NUMERIC) AS zeitraum_menge_af_4wo_ref, CAST(sales_fg_ref AS INT64) AS sales_fg_ref, CAST(in_gruppe_fg AS INT64) AS in_gruppe_fg, CAST(anz_art_in_gruppe AS INT64) AS anz_art_in_gruppe, CAST(anz_art_in_gruppe_ref AS INT64) AS anz_art_in_gruppe_ref, CAST(tv_fg_ref AS INT64) AS tv_fg_ref, CAST(titelseite_fg_ref AS INT64) AS titelseite_fg_ref, CAST(rueckseite_fg_ref AS INT64) AS rueckseite_fg_ref, CAST(gk_fg_ref AS INT64) AS gk_fg_ref, CAST(vk_aktion_brutto_ref AS NUMERIC) AS vk_aktion_brutto_ref, CAST(vk_vor_aktion_brutto_ref AS NUMERIC) AS vk_vor_aktion_brutto_ref, wrg_id, CAST(multi_offer_id_fg_ref AS INT64) AS multi_offer_id_fg_ref, CAST(bonuskauf_fg_ref AS INT64) AS bonuskauf_fg_ref, lokale_geschaeftsvorfall_bez_ref, CAST(wbs_art_wup_ref_typ_id AS INT64) AS wbs_art_wup_ref_typ_id, CAST(berechnete_menge_gesamt_bme_ref AS NUMERIC) AS berechnete_menge_gesamt_bme_ref, CAST(lief_menge_initial_bme_ref AS NUMERIC) AS lief_menge_initial_bme_ref, CAST(lief_menge_hochrechnung_bme_ref AS NUMERIC) AS lief_menge_hochrechnung_bme_ref, CAST(lief_menge_anteil_prozent_ref AS NUMERIC) AS lief_menge_anteil_prozent_ref, CAST(nur_online_fg_ref AS INT64) AS nur_online_fg_ref, CAST(kundenkarte_personalisiert_fg_ref AS INT64) AS kundenkarte_personalisiert_fg_ref, CAST(stille_aktion_fg_ref AS INT64) AS stille_aktion_fg_ref, CAST(stille_aktion_mit_menge_fg_ref AS INT64) AS stille_aktion_mit_menge_fg_ref, werbeflaeche_abschnitt_name_ref, werbeflaeche_thema_bez_ref, CAST(fixmenge_fg_ref AS INT64) AS fixmenge_fg_ref, CAST(fixmenge_wfl_fg_ref AS INT64) AS fixmenge_wfl_fg_ref, CAST(mindestplatzierung_fg_ref AS INT64) AS mindestplatzierung_fg_ref, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_art_aktion_ref`;

-- Table: DBP_DATA.HANDLING_UNIT_EWM
insert into `dbp_data.handling_unit_ewm` (mandant_id, log_guid, handling_unit_guid, quelle, parent_handling_unit_guid, lageraufgabe_id, handling_unit_id, packmittel_guid, lagernummer_id, lagereinheitentyp_id, gewicht_brutto, gewicht_netto, gewicht_einh_id, eigengewicht, eigengewicht_einh_id, volumen_brutto, volumen_netto, volumen_einh_id, eigenvolumen, eigenvolumen_einh_id, datzeit_lageraufgabe_bestaetigung, anzahl_stellplaetze, menge_gefahrgut, status_id_intern, top_hu_fg, bottom_hu_fg, konsolidierungsgruppe_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, log_guid, handling_unit_guid, quelle, parent_handling_unit_guid, CAST(lageraufgabe_id AS INT64) AS lageraufgabe_id, handling_unit_id, packmittel_guid, lagernummer_id, lagereinheitentyp_id, CAST(gewicht_brutto AS NUMERIC) AS gewicht_brutto, CAST(gewicht_netto AS NUMERIC) AS gewicht_netto, gewicht_einh_id, CAST(eigengewicht AS NUMERIC) AS eigengewicht, eigengewicht_einh_id, CAST(volumen_brutto AS NUMERIC) AS volumen_brutto, CAST(volumen_netto AS NUMERIC) AS volumen_netto, volumen_einh_id, CAST(eigenvolumen AS NUMERIC) AS eigenvolumen, eigenvolumen_einh_id, CAST(datzeit_lageraufgabe_bestaetigung AS DATETIME) AS datzeit_lageraufgabe_bestaetigung, CAST(anzahl_stellplaetze AS NUMERIC) AS anzahl_stellplaetze, CAST(menge_gefahrgut AS NUMERIC) AS menge_gefahrgut, status_id_intern, CAST(top_hu_fg AS INT64) AS top_hu_fg, CAST(bottom_hu_fg AS INT64) AS bottom_hu_fg, konsolidierungsgruppe_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_handling_unit_ewm`;

-- Table: DBP_DATA.FLW_SCHNITT_KOSTEN
insert into `dbp_data.flw_schnitt_kosten` (schnitt_id, sek_schl_typ_id, sek_schl_id, input_typ_id, kosten_block_id, mandant_id, fertig_einzel_kosten_kg, wrg_id, system_id, td_update, td_insert)
SELECT CAST(schnitt_id AS INT64) AS schnitt_id, sek_schl_typ_id, CAST(sek_schl_id AS INT64) AS sek_schl_id, input_typ_id, kosten_block_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(fertig_einzel_kosten_kg AS NUMERIC) AS fertig_einzel_kosten_kg, wrg_id, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_schnitt_kosten`;

-- Table: DBP_DATA.LIEF_BELEGFLUSS_SPLIT
insert into `dbp_data.lief_belegfluss_split` (mandant_id, lief_beleg_id, lief_beleg_gruppe_id, lief_beleg_pos_id, lief_beleg_split_id, lief_beleg_split_pos_id, split_fortschreibung_kz, menge_lief_ist_lme, split_lfd_nr_id, split_vorgang_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(lief_beleg_gruppe_id AS INT64) AS lief_beleg_gruppe_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, CAST(lief_beleg_split_id AS INT64) AS lief_beleg_split_id, CAST(lief_beleg_split_pos_id AS INT64) AS lief_beleg_split_pos_id, split_fortschreibung_kz, CAST(menge_lief_ist_lme AS NUMERIC) AS menge_lief_ist_lme, CAST(split_lfd_nr_id AS INT64) AS split_lfd_nr_id, split_vorgang_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lief_belegfluss_split`;

-- Table: DBP_MSI_DATA.VIS_TAG_BESTAND_WG
insert into `dbp_msi_data.vis_tag_bestand_wg` (mandant_id, wup_id, wg_id, dat, relevant_fg, bezugsweg_id, arthiertyp_id, wrg_id, abt_id, gj, kjmo, kjwo, nb_id, anz_artikel_bestand, anz_artikel_fehlmengen, anz_artikel_nullbestand, anz_artikel_minusbestand, menge_lgbest_erp_frei_bme, menge_lgbest_erp_qual_bme, betrag_vk_netto_frei_bme, betrag_vk_netto_qual_bme, betrag_vk_brutto_frei_bme, betrag_vk_brutto_qual_bme, betrag_mo_anf_vk_ntto_frei_bme, betrag_mo_anf_vk_ntto_qual_bme, betrag_mo_anf_vk_btto_frei_bme, betrag_mo_anf_vk_btto_qual_bme, betrag_d_vmo_vk_ntto_frei_bme, betrag_d_vmo_vk_ntto_qual_bme, betrag_d_vmo_vk_btto_frei_bme, betrag_d_vmo_vk_btto_qual_bme, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(wg_id AS INT64) AS wg_id, dat, CAST(relevant_fg AS INT64) AS relevant_fg, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, wrg_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(nb_id AS INT64) AS nb_id, CAST(anz_artikel_bestand AS INT64) AS anz_artikel_bestand, CAST(anz_artikel_fehlmengen AS INT64) AS anz_artikel_fehlmengen, CAST(anz_artikel_nullbestand AS INT64) AS anz_artikel_nullbestand, CAST(anz_artikel_minusbestand AS INT64) AS anz_artikel_minusbestand, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, CAST(betrag_vk_netto_frei_bme AS NUMERIC) AS betrag_vk_netto_frei_bme, CAST(betrag_vk_netto_qual_bme AS NUMERIC) AS betrag_vk_netto_qual_bme, CAST(betrag_vk_brutto_frei_bme AS NUMERIC) AS betrag_vk_brutto_frei_bme, CAST(betrag_vk_brutto_qual_bme AS NUMERIC) AS betrag_vk_brutto_qual_bme, CAST(betrag_mo_anf_vk_ntto_frei_bme AS NUMERIC) AS betrag_mo_anf_vk_ntto_frei_bme, CAST(betrag_mo_anf_vk_ntto_qual_bme AS NUMERIC) AS betrag_mo_anf_vk_ntto_qual_bme, CAST(betrag_mo_anf_vk_btto_frei_bme AS NUMERIC) AS betrag_mo_anf_vk_btto_frei_bme, CAST(betrag_mo_anf_vk_btto_qual_bme AS NUMERIC) AS betrag_mo_anf_vk_btto_qual_bme, CAST(betrag_d_vmo_vk_ntto_frei_bme AS NUMERIC) AS betrag_d_vmo_vk_ntto_frei_bme, CAST(betrag_d_vmo_vk_ntto_qual_bme AS NUMERIC) AS betrag_d_vmo_vk_ntto_qual_bme, CAST(betrag_d_vmo_vk_btto_frei_bme AS NUMERIC) AS betrag_d_vmo_vk_btto_frei_bme, CAST(betrag_d_vmo_vk_btto_qual_bme AS NUMERIC) AS betrag_d_vmo_vk_btto_qual_bme, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_bestand_wg`;

-- Table: DBP_DATA.FLW_SCHNITT_OUTPUT_KOSTEN
insert into `dbp_data.flw_schnitt_output_kosten` (schnitt_id, sek_schl_typ_id, sek_schl_id, schnitt_pos_id, kosten_block_id, mandant_id, fertig_einzel_kosten_kg, fertig_einzel_kosten_gesamt, wrg_id, system_id, td_update, td_insert)
SELECT CAST(schnitt_id AS INT64) AS schnitt_id, sek_schl_typ_id, CAST(sek_schl_id AS INT64) AS sek_schl_id, CAST(schnitt_pos_id AS INT64) AS schnitt_pos_id, kosten_block_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(fertig_einzel_kosten_kg AS NUMERIC) AS fertig_einzel_kosten_kg, CAST(fertig_einzel_kosten_gesamt AS NUMERIC) AS fertig_einzel_kosten_gesamt, wrg_id, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_schnitt_output_kosten`;

-- Table: DBP_DATA.WUP_DAT_WG_SUM
insert into `dbp_data.wup_dat_wg_sum` (mandant_id, wup_id, nb_id, dat, wg_id, arthiertyp_id, bonanzahl, bonanzahl_pre_pack, bonanzahl_sug, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(bonanzahl_pre_pack AS INT64) AS bonanzahl_pre_pack, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_dat_wg_sum`;

-- Table: DBP_DATA.ART_WUP_STATUS_PERIODE
insert into `dbp_data.art_wup_status_periode` (art_id, mandant_id, wup_id, nb_id, gjmo, menge_bestand_umlag_bme, menge_bestand_transit_bme, menge_bestand_geb_leergut, gjmo_bis, marc_fg, vk_brutto, td_update, td_insert)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gjmo AS INT64) AS gjmo, CAST(menge_bestand_umlag_bme AS NUMERIC) AS menge_bestand_umlag_bme, CAST(menge_bestand_transit_bme AS NUMERIC) AS menge_bestand_transit_bme, CAST(menge_bestand_geb_leergut AS NUMERIC) AS menge_bestand_geb_leergut, CAST(gjmo_bis AS INT64) AS gjmo_bis, CAST(marc_fg AS INT64) AS marc_fg, CAST(vk_brutto AS NUMERIC) AS vk_brutto, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_art_wup_status_periode`;

-- Table: DBP_DATA.AVQ_WERBUNG
insert into `dbp_data.avq_werbung` (mandant_id, wup_id, nb_id, art_id, dat_aktion_von, dat_aktion_bis, kjwo, anz_tage_aktion, wtag_id_start, wtag_id_ende, werbemittel_avq_top_prio_nr, werbeflaechenabschnitt_avq_top_prio_nr, werbeflaechenthema_avq_top_prio_nr, art_mutter_wb_id, posten_wb_id, posten_id, pmr_top_art_fg, werbeprozess_id, aktionsklassifizierung_id, aktionsklassifizierung_det_id, wrg_id, betrag_vk_aktion_brutto, betrag_vk_kcard_brutto, betrag_vor_aktion_brutto, faktor_flaki, mhd_zeitraum, prz_min_restlaufzeit_lager, menge_plan_wbs, menge_plan_upload, wbs_estimation_id, wbs_adjustment_id, menge_bestand_aktionsstart, menge_bestand_aktionsende, menge_ueberbestand, menge_bestand_min_sicherheit, menge_bestand_soll_max, menge_sollbestand, anz_nullbestand_gesamt, anz_nullbestand_tag1, anz_nullbestand_tag1bis3, anz_minusbestand_gesamt, anz_minusbestand_tag1, anz_minusbestand_tag1bis3, anz_exc209_gesamt, anz_exc209_tag1, anz_exc209_tag1bis3, anz_exc214_gesamt, anz_exc214_tag1, anz_exc214_tag1bis3, menge_gesamt, betrag_umsatz_gesamt, menge_historie_af, menge_nur_tag1, menge_tag_1_7bis13, menge_we_gesamt, menge_we_vor_aktion, menge_we_in_aktion, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_aktion_von, dat_aktion_bis, CAST(kjwo AS INT64) AS kjwo, CAST(anz_tage_aktion AS INT64) AS anz_tage_aktion, CAST(wtag_id_start AS INT64) AS wtag_id_start, CAST(wtag_id_ende AS INT64) AS wtag_id_ende, CAST(werbemittel_avq_top_prio_nr AS INT64) AS werbemittel_avq_top_prio_nr, CAST(werbeflaechenabschnitt_avq_top_prio_nr AS INT64) AS werbeflaechenabschnitt_avq_top_prio_nr, CAST(werbeflaechenthema_avq_top_prio_nr AS INT64) AS werbeflaechenthema_avq_top_prio_nr, CAST(art_mutter_wb_id AS INT64) AS art_mutter_wb_id, posten_wb_id, posten_id, CAST(pmr_top_art_fg AS INT64) AS pmr_top_art_fg, CAST(werbeprozess_id AS INT64) AS werbeprozess_id, aktionsklassifizierung_id, CAST(aktionsklassifizierung_det_id AS INT64) AS aktionsklassifizierung_det_id, wrg_id, CAST(betrag_vk_aktion_brutto AS NUMERIC) AS betrag_vk_aktion_brutto, CAST(betrag_vk_kcard_brutto AS NUMERIC) AS betrag_vk_kcard_brutto, CAST(betrag_vor_aktion_brutto AS NUMERIC) AS betrag_vor_aktion_brutto, CAST(faktor_flaki AS NUMERIC) AS faktor_flaki, CAST(mhd_zeitraum AS INT64) AS mhd_zeitraum, CAST(prz_min_restlaufzeit_lager AS INT64) AS prz_min_restlaufzeit_lager, CAST(menge_plan_wbs AS NUMERIC) AS menge_plan_wbs, CAST(menge_plan_upload AS NUMERIC) AS menge_plan_upload, CAST(wbs_estimation_id AS INT64) AS wbs_estimation_id, CAST(wbs_adjustment_id AS INT64) AS wbs_adjustment_id, CAST(menge_bestand_aktionsstart AS NUMERIC) AS menge_bestand_aktionsstart, CAST(menge_bestand_aktionsende AS NUMERIC) AS menge_bestand_aktionsende, CAST(menge_ueberbestand AS NUMERIC) AS menge_ueberbestand, CAST(menge_bestand_min_sicherheit AS NUMERIC) AS menge_bestand_min_sicherheit, CAST(menge_bestand_soll_max AS NUMERIC) AS menge_bestand_soll_max, CAST(menge_sollbestand AS NUMERIC) AS menge_sollbestand, CAST(anz_nullbestand_gesamt AS INT64) AS anz_nullbestand_gesamt, CAST(anz_nullbestand_tag1 AS INT64) AS anz_nullbestand_tag1, CAST(anz_nullbestand_tag1bis3 AS INT64) AS anz_nullbestand_tag1bis3, CAST(anz_minusbestand_gesamt AS INT64) AS anz_minusbestand_gesamt, CAST(anz_minusbestand_tag1 AS INT64) AS anz_minusbestand_tag1, CAST(anz_minusbestand_tag1bis3 AS INT64) AS anz_minusbestand_tag1bis3, CAST(anz_exc209_gesamt AS INT64) AS anz_exc209_gesamt, CAST(anz_exc209_tag1 AS INT64) AS anz_exc209_tag1, CAST(anz_exc209_tag1bis3 AS INT64) AS anz_exc209_tag1bis3, CAST(anz_exc214_gesamt AS INT64) AS anz_exc214_gesamt, CAST(anz_exc214_tag1 AS INT64) AS anz_exc214_tag1, CAST(anz_exc214_tag1bis3 AS INT64) AS anz_exc214_tag1bis3, CAST(menge_gesamt AS NUMERIC) AS menge_gesamt, CAST(betrag_umsatz_gesamt AS NUMERIC) AS betrag_umsatz_gesamt, CAST(menge_historie_af AS NUMERIC) AS menge_historie_af, CAST(menge_nur_tag1 AS NUMERIC) AS menge_nur_tag1, CAST(menge_tag_1_7bis13 AS NUMERIC) AS menge_tag_1_7bis13, CAST(menge_we_gesamt AS NUMERIC) AS menge_we_gesamt, CAST(menge_we_vor_aktion AS NUMERIC) AS menge_we_vor_aktion, CAST(menge_we_in_aktion AS NUMERIC) AS menge_we_in_aktion, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_avq_werbung`;

-- Table: DBP_DATA.BANF_ART_GP_DAT_SUM
insert into `dbp_data.banf_art_gp_dat_sum` (mandant_id, art_id, wup_id, nb_id, gp_id, dat_lief_soll, in_aktion_fg, dat_kalk, vk_brutto, banf_menge_kolli, forecast_menge_kolli, menge_best_kolli, banf_menge_kg, forecast_menge_kg, menge_best_kg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, dat_lief_soll, CAST(in_aktion_fg AS INT64) AS in_aktion_fg, dat_kalk, CAST(vk_brutto AS NUMERIC) AS vk_brutto, CAST(banf_menge_kolli AS NUMERIC) AS banf_menge_kolli, CAST(forecast_menge_kolli AS NUMERIC) AS forecast_menge_kolli, CAST(menge_best_kolli AS NUMERIC) AS menge_best_kolli, CAST(banf_menge_kg AS NUMERIC) AS banf_menge_kg, CAST(forecast_menge_kg AS NUMERIC) AS forecast_menge_kg, CAST(menge_best_kg AS NUMERIC) AS menge_best_kg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_banf_art_gp_dat_sum`;

-- Table: DBP_DATA.TUPEL_MAT_SUBSTITUTE
insert into `dbp_data.tupel_mat_substitute` (tupel_mat_substitute_id, mandant_id, kjwo_update, matching_id_parent, matching_id_substitute, rank_substitute, td_update, td_insert)
SELECT CAST(tupel_mat_substitute_id AS INT64) AS tupel_mat_substitute_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo_update AS INT64) AS kjwo_update, CAST(matching_id_parent AS INT64) AS matching_id_parent, CAST(matching_id_substitute AS INT64) AS matching_id_substitute, CAST(rank_substitute AS INT64) AS rank_substitute, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tupel_mat_substitute`;

-- Table: DBP_DATA.WEWA
insert into `dbp_data.wewa` (mandant_id, wewa_beleg_id, wewa_beleg_pos_id, wewa_jahr, art_id, wup_id, nb_id, gp_id, lager_bewart_id, dat_buch, menge_basis, betrag_ek_netto, status, wrg_id, betrag_vk_netto, konditionsbetrag_zar5, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wewa_beleg_id AS INT64) AS wewa_beleg_id, CAST(wewa_beleg_pos_id AS INT64) AS wewa_beleg_pos_id, CAST(wewa_jahr AS INT64) AS wewa_jahr, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, lager_bewart_id, dat_buch, CAST(menge_basis AS NUMERIC) AS menge_basis, CAST(betrag_ek_netto AS NUMERIC) AS betrag_ek_netto, CAST(status AS INT64) AS status, wrg_id, CAST(betrag_vk_netto AS NUMERIC) AS betrag_vk_netto, CAST(konditionsbetrag_zar5 AS NUMERIC) AS konditionsbetrag_zar5, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wewa`;

-- Table: DBP_MSI_DATA.VIS_MONAT_BESTAND_WG
insert into `dbp_msi_data.vis_monat_bestand_wg` (mandant_id, wup_id, nb_id, kjmo, relevant_fg, bezugsweg_id, arthiertyp_id, wg_id, wrg_id, abt_id, gj, menge_lgbest_erp_frei_bme, menge_lgbest_erp_qual_bme, betrag_vk_netto_frei_bme, betrag_vk_netto_qual_bme, betrag_vk_brutto_frei_bme, betrag_vk_brutto_qual_bme, menge_lgbest_erp_frei_bme_kum, menge_lgbest_erp_qual_bme_kum, betrag_vk_netto_frei_bme_kum, betrag_vk_netto_qual_bme_kum, betrag_vk_brutto_frei_bme_kum, betrag_vk_brutto_qual_bme_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(relevant_fg AS INT64) AS relevant_fg, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, wrg_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, CAST(betrag_vk_netto_frei_bme AS NUMERIC) AS betrag_vk_netto_frei_bme, CAST(betrag_vk_netto_qual_bme AS NUMERIC) AS betrag_vk_netto_qual_bme, CAST(betrag_vk_brutto_frei_bme AS NUMERIC) AS betrag_vk_brutto_frei_bme, CAST(betrag_vk_brutto_qual_bme AS NUMERIC) AS betrag_vk_brutto_qual_bme, CAST(menge_lgbest_erp_frei_bme_kum AS NUMERIC) AS menge_lgbest_erp_frei_bme_kum, CAST(menge_lgbest_erp_qual_bme_kum AS NUMERIC) AS menge_lgbest_erp_qual_bme_kum, CAST(betrag_vk_netto_frei_bme_kum AS NUMERIC) AS betrag_vk_netto_frei_bme_kum, CAST(betrag_vk_netto_qual_bme_kum AS NUMERIC) AS betrag_vk_netto_qual_bme_kum, CAST(betrag_vk_brutto_frei_bme_kum AS NUMERIC) AS betrag_vk_brutto_frei_bme_kum, CAST(betrag_vk_brutto_qual_bme_kum AS NUMERIC) AS betrag_vk_brutto_qual_bme_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_bestand_wg`;

-- Table: DBP_DATA.KAMPAGNE_NACHRICHT_AKTION_DETAIL
insert into `dbp_data.kampagne_nachricht_aktion_detail` (mandant_id, nachricht_workflow_id, nachricht_vorlage_id, kommunikationskanal_id, datzeit_nachricht_aktion, nachricht_aktion_typ_id, personalisierte_url_name, personalisierte_url_txt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, nachricht_workflow_id, nachricht_vorlage_id, CAST(kommunikationskanal_id AS INT64) AS kommunikationskanal_id, CAST(datzeit_nachricht_aktion AS DATETIME) AS datzeit_nachricht_aktion, CAST(nachricht_aktion_typ_id AS INT64) AS nachricht_aktion_typ_id, personalisierte_url_name, personalisierte_url_txt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_kampagne_nachricht_aktion_detail`;

-- Table: DBP_MSI_DATA.EK_USER_ART_ZU
insert into `dbp_msi_data.ek_user_art_zu` (mandant_id, art_id, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ek_user_art_zu`;

-- Table: DBP_DATA.LAGERBESTAND_ATP_PER
insert into `dbp_data.lagerbestand_atp_per` (mandant_id, wup_id, nb_id, art_id, dat_von, dat_bis, menge_lgbest_frei, menge_lgbest_block_werbung, menge_lgbest_block_iwt, menge_lgbest_block_nwbs, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, art_id, dat_von, dat_bis, CAST(menge_lgbest_frei AS NUMERIC) AS menge_lgbest_frei, CAST(menge_lgbest_block_werbung AS NUMERIC) AS menge_lgbest_block_werbung, CAST(menge_lgbest_block_iwt AS NUMERIC) AS menge_lgbest_block_iwt, CAST(menge_lgbest_block_nwbs AS NUMERIC) AS menge_lgbest_block_nwbs, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerbestand_atp_per`;

-- Table: DBP_DATA.TOUR_DET
insert into `dbp_data.tour_det` (mandant_id, nb_id, tour_pos_id, wup_id, tour_id, system_id, mandant_id_kunde, reihenfolge_tour_dispo, lagernummer_id, kunde_id, lief_beleg_id, dat_plan_ankunft, loesch_fg, dat_tourpos_erfasst, kj_lief_beleg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(tour_pos_id AS INT64) AS tour_pos_id, CAST(wup_id AS INT64) AS wup_id, CAST(tour_id AS INT64) AS tour_id, CAST(system_id AS INT64) AS system_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, CAST(reihenfolge_tour_dispo AS INT64) AS reihenfolge_tour_dispo, lagernummer_id, kunde_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, dat_plan_ankunft, CAST(loesch_fg AS INT64) AS loesch_fg, dat_tourpos_erfasst, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tour_det`;

-- Table: DBP_DATA.GUTSCHEIN
insert into `dbp_data.gutschein` (gutschein_id, mandant_id, transaktion_id, zeitstempel, system_id, profil_id, wrg_id, ausgeber_typ_id, betrag_gutschein, ausgeber_id, kostenstelle_id, ereignisquelle_id, geku_ticket_id, td_insert, td_update)
SELECT CAST(gutschein_id AS INT64) AS gutschein_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(transaktion_id AS INT64) AS transaktion_id, zeitstempel, CAST(system_id AS INT64) AS system_id, CAST(profil_id AS INT64) AS profil_id, wrg_id, ausgeber_typ_id, CAST(betrag_gutschein AS NUMERIC) AS betrag_gutschein, ausgeber_id, kostenstelle_id, CAST(ereignisquelle_id AS INT64) AS ereignisquelle_id, CAST(geku_ticket_id AS INT64) AS geku_ticket_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_gutschein`;

-- Table: DBP_DATA.TOUR_PLOMBE_ZIEL
insert into `dbp_data.tour_plombe_ziel` (mandant_id, nb_id, wup_id, tour_id, plombe_id, plombe_prozess_id, plombe_aktivitaet, dat_scan, zeit_scan, info_code, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(tour_id AS INT64) AS tour_id, CAST(plombe_id AS NUMERIC) AS plombe_id, CAST(plombe_prozess_id AS INT64) AS plombe_prozess_id, CAST(plombe_aktivitaet AS INT64) AS plombe_aktivitaet, dat_scan, CAST(zeit_scan AS INT64) AS zeit_scan, CAST(info_code AS INT64) AS info_code, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tour_plombe_ziel`;

-- Table: DBP_DATA.LINBEW_NONMAKS
insert into `dbp_data.linbew_nonmaks` (mandant_id, lin_kurs_id, hr_objekt_id, dat, wup_id, unternehmens_bereich_id, anzahl_kurse_gesamt, anzahl_kurse_abgeschlossen, ki_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lin_kurs_id, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, dat, CAST(wup_id AS INT64) AS wup_id, unternehmens_bereich_id, CAST(anzahl_kurse_gesamt AS INT64) AS anzahl_kurse_gesamt, CAST(anzahl_kurse_abgeschlossen AS INT64) AS anzahl_kurse_abgeschlossen, CAST(ki_fg AS INT64) AS ki_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_linbew_nonmaks`;

-- Table: DBP_DATA.FLW_KUNDE_AUFTRAG_DET
insert into `dbp_data.flw_kunde_auftrag_det` (mandant_id, verkaufs_beleg_id, verkaufs_beleg_pos_id, flw_art_id, verk_menge_einh_id, menge_auftrag_vme_kum, menge_bes_bme_kum, system_id, werk_id, absagegrund_id, nettogew, wert_ek_netto, zwsum_2_betrag, zwsum_4_betrag, sap_art_id_kunde, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verkaufs_beleg_id AS INT64) AS verkaufs_beleg_id, CAST(verkaufs_beleg_pos_id AS INT64) AS verkaufs_beleg_pos_id, CAST(flw_art_id AS INT64) AS flw_art_id, verk_menge_einh_id, CAST(menge_auftrag_vme_kum AS NUMERIC) AS menge_auftrag_vme_kum, CAST(menge_bes_bme_kum AS NUMERIC) AS menge_bes_bme_kum, CAST(system_id AS INT64) AS system_id, CAST(werk_id AS INT64) AS werk_id, absagegrund_id, CAST(nettogew AS NUMERIC) AS nettogew, CAST(wert_ek_netto AS NUMERIC) AS wert_ek_netto, CAST(zwsum_2_betrag AS NUMERIC) AS zwsum_2_betrag, CAST(zwsum_4_betrag AS NUMERIC) AS zwsum_4_betrag, sap_art_id_kunde, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_kunde_auftrag_det`;

-- Table: DBP_DATA.FLW_BESCH_LIEF_DET
insert into `dbp_data.flw_besch_lief_det` (lief_beleg_id, mandant_id, lief_beleg_pos_id, lief_pos_typ_id, flw_art_id, charge_id, menge_lief_ist_bme, verk_menge_einh_id, nettogew, gew_einh_id, menge_lief_ist_lme, flw_vw_id, werk_id, dat_mat_bereitstllg, vorlage_beleg_id, vorlage_beleg_pos_id, system_id, td_insert, td_update)
SELECT CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(lief_beleg_pos_id AS INT64) AS lief_beleg_pos_id, lief_pos_typ_id, CAST(flw_art_id AS INT64) AS flw_art_id, charge_id, CAST(menge_lief_ist_bme AS NUMERIC) AS menge_lief_ist_bme, verk_menge_einh_id, CAST(nettogew AS NUMERIC) AS nettogew, gew_einh_id, CAST(menge_lief_ist_lme AS NUMERIC) AS menge_lief_ist_lme, CAST(flw_vw_id AS INT64) AS flw_vw_id, CAST(werk_id AS INT64) AS werk_id, dat_mat_bereitstllg, CAST(vorlage_beleg_id AS INT64) AS vorlage_beleg_id, CAST(vorlage_beleg_pos_id AS INT64) AS vorlage_beleg_pos_id, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_besch_lief_det`;

-- Table: DBP_DATA.FUR_PROGNOSE_WG_WO_SUM
insert into `dbp_data.fur_prognose_wg_wo_sum` (wg_id, arthiertyp_id, mandant_id, wup_id, nb_id, kjwo_kl, menge_prognose, menge_prognose_bef, menge_prognose_max, menge_af, menge_sa, diff_menge_af_prognose, sum_progn_groesser, sum_menge_af_groesser, menge_af_mittel_3wo, progn_groesser_wo_fg, menge_af_groesser_wo_fg, progn_grosser_wo0_fg, progn_groesser_wo1_fg, progn_groesser_wo2_fg, menge_af_groesser_wo0_fg, menge_af_groesser_wo1_fg, menge_af_groesser_wo2_fg, td_update, td_insert)
SELECT CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjwo_kl AS INT64) AS kjwo_kl, CAST(menge_prognose AS NUMERIC) AS menge_prognose, CAST(menge_prognose_bef AS NUMERIC) AS menge_prognose_bef, CAST(menge_prognose_max AS NUMERIC) AS menge_prognose_max, CAST(menge_af AS NUMERIC) AS menge_af, CAST(menge_sa AS NUMERIC) AS menge_sa, CAST(diff_menge_af_prognose AS NUMERIC) AS diff_menge_af_prognose, CAST(sum_progn_groesser AS INT64) AS sum_progn_groesser, CAST(sum_menge_af_groesser AS INT64) AS sum_menge_af_groesser, CAST(menge_af_mittel_3wo AS NUMERIC) AS menge_af_mittel_3wo, CAST(progn_groesser_wo_fg AS INT64) AS progn_groesser_wo_fg, CAST(menge_af_groesser_wo_fg AS INT64) AS menge_af_groesser_wo_fg, CAST(progn_grosser_wo0_fg AS INT64) AS progn_grosser_wo0_fg, CAST(progn_groesser_wo1_fg AS INT64) AS progn_groesser_wo1_fg, CAST(progn_groesser_wo2_fg AS INT64) AS progn_groesser_wo2_fg, CAST(menge_af_groesser_wo0_fg AS INT64) AS menge_af_groesser_wo0_fg, CAST(menge_af_groesser_wo1_fg AS INT64) AS menge_af_groesser_wo1_fg, CAST(menge_af_groesser_wo2_fg AS INT64) AS menge_af_groesser_wo2_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fur_prognose_wg_wo_sum`;

-- Table: DBP_DATA.T_FACT_IOT_BUILDING
insert into `dbp_data.t_fact_iot_building` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, outdoortemp_condenser_supplyair_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(outdoortemp_condenser_supplyair_meas AS NUMERIC) AS outdoortemp_condenser_supplyair_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_building`;

-- Table: DBP_DATA.AKTION_ART_WUP_ZU_WME_AME
insert into `dbp_data.aktion_art_wup_zu_wme_ame` (mandant_id, aktion_id, art_id, wup_id, nb_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_aktion_art_wup_zu_wme_ame`;

-- Table: DBP_DATA.HANDLING_UNIT_VERWENDUNG
insert into `dbp_data.handling_unit_verwendung` (mandant_id, handle, beleg_typ, beleg_id, datzeit, richtung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, handle, beleg_typ, CAST(beleg_id AS INT64) AS beleg_id, CAST(datzeit AS INT64) AS datzeit, CAST(richtung AS INT64) AS richtung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_handling_unit_verwendung`;

-- Table: DBP_MSI_DATA.BACKSHOP_PROGNOSE
insert into `dbp_msi_data.backshop_prognose` (art_id, mandant_id, wup_id, nb_id, dat, menge_prognose, min_sicherh_bestand, listung_id, aktion_fg, menge_check, anteil_01, anteil_02, anteil_03, anteil_04, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(menge_prognose AS NUMERIC) AS menge_prognose, CAST(min_sicherh_bestand AS NUMERIC) AS min_sicherh_bestand, CAST(listung_id AS INT64) AS listung_id, CAST(aktion_fg AS INT64) AS aktion_fg, CAST(menge_check AS NUMERIC) AS menge_check, CAST(anteil_01 AS NUMERIC) AS anteil_01, CAST(anteil_02 AS NUMERIC) AS anteil_02, CAST(anteil_03 AS NUMERIC) AS anteil_03, CAST(anteil_04 AS NUMERIC) AS anteil_04, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_backshop_prognose`;

-- Table: DBP_DATA.WUP_LAGERNUMMER_BSFLAECHE_PER
insert into `dbp_data.wup_lagernummer_bsflaeche_per` (mandant_id, wup_id, nb_id, lagernummer_id, bsflaeche_id, doppelbelegung_fg, datzeit_von, system_id, datzeit_bis, warenempfaenger_id, warenempfaenger_orig, status_verplant_fg, status_fixe_einplanung_fg, referenznummer, maximale_kapazitaet, verplante_kapazitaet, bestand_bsf, bestandsart, anz_paletten_bsf, we_kapazitaet, tor_id_zugeordnet, status_verplant_ign_fg, anz_sammelpaletten_bsf, anz_bigbox_bsf, belegte_stp_bsf, bsf_status_id, bsf_zone_id, bsf_sperrgrund_id, erhoehte_kapazitaet, kapa_check_ign_fg, tor_blocken_ign_fg, bsf_sperrgrund_manuell, lagerplatz_id, bsf_virtuell_id, wgvgrp_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, CAST(bsflaeche_id AS INT64) AS bsflaeche_id, CAST(doppelbelegung_fg AS INT64) AS doppelbelegung_fg, datzeit_von, CAST(system_id AS INT64) AS system_id, datzeit_bis, CAST(warenempfaenger_id AS INT64) AS warenempfaenger_id, warenempfaenger_orig, CAST(status_verplant_fg AS INT64) AS status_verplant_fg, CAST(status_fixe_einplanung_fg AS INT64) AS status_fixe_einplanung_fg, CAST(referenznummer AS INT64) AS referenznummer, CAST(maximale_kapazitaet AS NUMERIC) AS maximale_kapazitaet, CAST(verplante_kapazitaet AS NUMERIC) AS verplante_kapazitaet, CAST(bestand_bsf AS INT64) AS bestand_bsf, bestandsart, CAST(anz_paletten_bsf AS NUMERIC) AS anz_paletten_bsf, CAST(we_kapazitaet AS NUMERIC) AS we_kapazitaet, tor_id_zugeordnet, CAST(status_verplant_ign_fg AS INT64) AS status_verplant_ign_fg, CAST(anz_sammelpaletten_bsf AS INT64) AS anz_sammelpaletten_bsf, CAST(anz_bigbox_bsf AS INT64) AS anz_bigbox_bsf, CAST(belegte_stp_bsf AS NUMERIC) AS belegte_stp_bsf, bsf_status_id, bsf_zone_id, bsf_sperrgrund_id, CAST(erhoehte_kapazitaet AS INT64) AS erhoehte_kapazitaet, CAST(kapa_check_ign_fg AS INT64) AS kapa_check_ign_fg, CAST(tor_blocken_ign_fg AS INT64) AS tor_blocken_ign_fg, bsf_sperrgrund_manuell, lagerplatz_id, CAST(bsf_virtuell_id AS INT64) AS bsf_virtuell_id, CAST(wgvgrp_id AS INT64) AS wgvgrp_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_lagernummer_bsflaeche_per`;

-- Table: DBP_ODS_ARCHIV.ODS_TALON
insert into `dbp_ods_archiv.ods_talon` (mandant_id, talon_id, wup_id, talon_dat, talon_booking, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(talon_id AS NUMERIC) AS talon_id, CAST(wup_id AS INT64) AS wup_id, talon_dat, talon_booking, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_talon`;

-- Table: DBP_DATA.AVQ_WERBUNG_PMR_DET
insert into `dbp_data.avq_werbung_pmr_det` (mandant_id, wup_id, nb_id, art_id, dat_aktion_von, dat_aktion_bis, angebot_nr, werbemittelkanal_id, werbemittel_id, werbeflaechenthema_cd, werbeflaechenabschnitt_id, aktion_id, dat_sperrung, dat_preisaktivierung, dat_geloescht_sap, kjwo, bby_fg, kdn_fg, kdp_fg, pmr_top_art_fg, werbemittel_avq_prio_nr, werbeflaechenabschnitt_avq_prio_nr, werbeflaechenthema_avq_prio_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_aktion_von, dat_aktion_bis, angebot_nr, werbemittelkanal_id, werbemittel_id, werbeflaechenthema_cd, CAST(werbeflaechenabschnitt_id AS INT64) AS werbeflaechenabschnitt_id, aktion_id, CAST(dat_sperrung AS INT64) AS dat_sperrung, dat_preisaktivierung, dat_geloescht_sap, CAST(kjwo AS INT64) AS kjwo, CAST(bby_fg AS INT64) AS bby_fg, CAST(kdn_fg AS INT64) AS kdn_fg, CAST(kdp_fg AS INT64) AS kdp_fg, CAST(pmr_top_art_fg AS INT64) AS pmr_top_art_fg, CAST(werbemittel_avq_prio_nr AS INT64) AS werbemittel_avq_prio_nr, CAST(werbeflaechenabschnitt_avq_prio_nr AS INT64) AS werbeflaechenabschnitt_avq_prio_nr, CAST(werbeflaechenthema_avq_prio_nr AS INT64) AS werbeflaechenthema_avq_prio_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_avq_werbung_pmr_det`;

-- Table: DBP_ETL_PROCESS.EKC_PREIS_ABSCHRIFTEN
insert into `dbp_etl_process.ekc_preis_abschriften` (mandant_id, art_id, bewart_id, wup_id, nb_id, dat, wrg_id, zek_id, eigenmarke_fg, wup_bereinigt_fg, preis_abschrift_netto, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(bewart_id AS INT64) AS bewart_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, wrg_id, CAST(zek_id AS INT64) AS zek_id, CAST(eigenmarke_fg AS INT64) AS eigenmarke_fg, CAST(wup_bereinigt_fg AS INT64) AS wup_bereinigt_fg, CAST(preis_abschrift_netto AS NUMERIC) AS preis_abschrift_netto, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_etl_process_ekc_preis_abschriften`;

-- Table: DBP_DATA.SSM_WUP_TAG_15MIN_TREIBER
insert into `dbp_data.ssm_wup_tag_15min_treiber` (mandant_id, wup_id, nb_id, dat, zeit_stunde, zeit_15min, treiber_id, wrg_id, wert_15min, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(zeit_15min AS INT64) AS zeit_15min, CAST(treiber_id AS INT64) AS treiber_id, wrg_id, CAST(wert_15min AS NUMERIC) AS wert_15min, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_tag_15min_treiber`;

-- Table: DBP_MSI_DATA.VIS_MONAT_ABSCHRIFTEN_WG
insert into `dbp_msi_data.vis_monat_abschriften_wg` (mandant_id, nb_id, wup_id, wrg_id, arthiertyp_id, wg_id, kjmo, abschriftgruppe_id, abt_id, gj, abschrift_brutto, abschrift_brutto_kum, abschrift_brutto_kvj, abschrift_brutto_kvj_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, CAST(kjmo AS INT64) AS kjmo, CAST(abschriftgruppe_id AS INT64) AS abschriftgruppe_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(abschrift_brutto AS NUMERIC) AS abschrift_brutto, CAST(abschrift_brutto_kum AS NUMERIC) AS abschrift_brutto_kum, CAST(abschrift_brutto_kvj AS NUMERIC) AS abschrift_brutto_kvj, CAST(abschrift_brutto_kvj_kum AS NUMERIC) AS abschrift_brutto_kvj_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_abschriften_wg`;

-- Table: DBP_DATA.LAGERPLATZ_AKTIVITAET_PER
insert into `dbp_data.lagerplatz_aktivitaet_per` (mandant_id, lagernummer_id, lagerplatz_id, aktivitaet_id, dat_von, dat_bis, lfd_nr, aktivitaetsbereich_id, lagertyp_id, lagerbereich_id, gang_id, sort_nr, entfernung_start, gang_laenge, folge_gang_id, entfernung_folgegang, konsolidierungsgruppe_id, org_aktivitaetsbereich_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, lagerplatz_id, aktivitaet_id, dat_von, dat_bis, CAST(lfd_nr AS INT64) AS lfd_nr, aktivitaetsbereich_id, lagertyp_id, lagerbereich_id, CAST(gang_id AS INT64) AS gang_id, CAST(sort_nr AS INT64) AS sort_nr, CAST(entfernung_start AS INT64) AS entfernung_start, CAST(gang_laenge AS INT64) AS gang_laenge, CAST(folge_gang_id AS INT64) AS folge_gang_id, CAST(entfernung_folgegang AS INT64) AS entfernung_folgegang, konsolidierungsgruppe_id, org_aktivitaetsbereich_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_lagerplatz_aktivitaet_per`;

-- Table: DBP_DATA.WBS_ART_AKTION_KORRIGIERTE_MENGE
insert into `dbp_data.wbs_art_aktion_korrigierte_menge` (mandant_id, wup_id, nb_id, art_id, dat_von_aktion, dat_bis_aktion, zeitraum_korrigierte_menge, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_von_aktion, dat_bis_aktion, CAST(zeitraum_korrigierte_menge AS NUMERIC) AS zeitraum_korrigierte_menge, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_art_aktion_korrigierte_menge`;

-- Table: DBP_DATA.COS_BONUSPUNKTE
insert into `dbp_data.cos_bonuspunkte` (crm_konto_id, dat_verfall_bonuspunkte, mandant_id, anz_bonuspunkte, datzeit_update, td_update, td_insert)
SELECT crm_konto_id, dat_verfall_bonuspunkte, CAST(mandant_id AS INT64) AS mandant_id, CAST(anz_bonuspunkte AS INT64) AS anz_bonuspunkte, CAST(datzeit_update AS DATETIME) AS datzeit_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_cos_bonuspunkte`;

-- Table: DBP_DATA.T_FACT_IOT_ERRORMESSAGES
insert into `dbp_data.t_fact_iot_errormessages` (mandant_id, wup_id, device_id, fault_nr, cal_dt, measurement_tmsp, device_type_id, alarm_priority_cd, error_source, error_message, value_cycling, active_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, device_id, fault_nr, cal_dt, CAST(measurement_tmsp AS DATETIME) AS measurement_tmsp, device_type_id, CAST(alarm_priority_cd AS INT64) AS alarm_priority_cd, error_source, error_message, CAST(value_cycling AS INT64) AS value_cycling, CAST(active_fg AS INT64) AS active_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_errormessages`;

-- Table: DBP_DATA.MA_KOSTENSTELLE_LOHNART_ZU_PER
insert into `dbp_data.ma_kostenstelle_lohnart_zu_per` (mandant_id, kostenstelle_id, mitarbeiter_id, lohnart_id, zeitart_id, kjmo, kostenstelle_von_id, kostenstelle_nach_id, abrechnung_fuer_periode, abrechnungstyp_fuer_periode, zahlung_dat, krk_id, abrechnung_in_periode, anzahl_lohnart, system_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kostenstelle_id, mitarbeiter_id, lohnart_id, zeitart_id, CAST(kjmo AS INT64) AS kjmo, kostenstelle_von_id, kostenstelle_nach_id, CAST(abrechnung_fuer_periode AS INT64) AS abrechnung_fuer_periode, abrechnungstyp_fuer_periode, zahlung_dat, krk_id, CAST(abrechnung_in_periode AS INT64) AS abrechnung_in_periode, CAST(anzahl_lohnart AS NUMERIC) AS anzahl_lohnart, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ma_kostenstelle_lohnart_zu_per`;

-- Table: DBP_DATA.LAGERBESTAND_ERP_WG
insert into `dbp_data.lagerbestand_erp_wg` (mandant_id, wup_id, nb_id, lagerort_id, wg_id, arthiertyp_id, dat, menge_lgbest_erp_frei_bme, menge_lgbest_erp_umlag_bme, menge_lgbest_erp_qual_bme, menge_lgbest_erp_nf_charge_bme, menge_lgbest_erp_gesp_bme, menge_lgbest_erp_ret_gesp_bme, menge_lgbest_erp_kolli, menge_lgbest_erp_palette, betrag_lgbest_erp, wrg_id, vk_netto_lgbest_erp, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagerort_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, dat, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_umlag_bme AS NUMERIC) AS menge_lgbest_erp_umlag_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, CAST(menge_lgbest_erp_nf_charge_bme AS NUMERIC) AS menge_lgbest_erp_nf_charge_bme, CAST(menge_lgbest_erp_gesp_bme AS NUMERIC) AS menge_lgbest_erp_gesp_bme, CAST(menge_lgbest_erp_ret_gesp_bme AS NUMERIC) AS menge_lgbest_erp_ret_gesp_bme, CAST(menge_lgbest_erp_kolli AS NUMERIC) AS menge_lgbest_erp_kolli, CAST(menge_lgbest_erp_palette AS NUMERIC) AS menge_lgbest_erp_palette, CAST(betrag_lgbest_erp AS NUMERIC) AS betrag_lgbest_erp, wrg_id, CAST(vk_netto_lgbest_erp AS NUMERIC) AS vk_netto_lgbest_erp, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_lagerbestand_erp_wg`;

-- Table: DBP_DATA.FANQUOTE
insert into `dbp_data.fanquote` (mandant_id, matching_id, kjwo_update, d423_fanquote, a507_umsatz_cardholder, a508_anteil_sa_cardholder, a509_anz_kaeufer, substitute_matching_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(matching_id AS INT64) AS matching_id, CAST(kjwo_update AS INT64) AS kjwo_update, CAST(d423_fanquote AS NUMERIC) AS d423_fanquote, CAST(a507_umsatz_cardholder AS NUMERIC) AS a507_umsatz_cardholder, CAST(a508_anteil_sa_cardholder AS NUMERIC) AS a508_anteil_sa_cardholder, CAST(a509_anz_kaeufer AS INT64) AS a509_anz_kaeufer, substitute_matching_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fanquote`;

-- Table: DBP_DATA.HANDLING_UNIT_BELEG_ZU
insert into `dbp_data.handling_unit_beleg_zu` (mandant_id, quelle, log_guid, handling_unit_guid, beleg_guid, belegtyp_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, quelle, log_guid, handling_unit_guid, beleg_guid, belegtyp_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_handling_unit_beleg_zu`;

-- Table: DBP_DATA.WABI_SUM
insert into `dbp_data.wabi_sum` (art_id, mandant_id, wup_id, nb_id, aktion_id, dat, null_bestand_fg, minus_bestand_fg, null_absatz_fg, null_absatz_tag_1_fg, artbew_menge, man_bestellung_fg, man_bestellung_menge, start_bestand, ende_bestand, menge_absatz_af_mittel, rw_fg, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, aktion_id, dat, CAST(null_bestand_fg AS INT64) AS null_bestand_fg, CAST(minus_bestand_fg AS INT64) AS minus_bestand_fg, CAST(null_absatz_fg AS INT64) AS null_absatz_fg, CAST(null_absatz_tag_1_fg AS INT64) AS null_absatz_tag_1_fg, CAST(artbew_menge AS NUMERIC) AS artbew_menge, CAST(man_bestellung_fg AS INT64) AS man_bestellung_fg, CAST(man_bestellung_menge AS NUMERIC) AS man_bestellung_menge, CAST(start_bestand AS NUMERIC) AS start_bestand, CAST(ende_bestand AS NUMERIC) AS ende_bestand, CAST(menge_absatz_af_mittel AS NUMERIC) AS menge_absatz_af_mittel, CAST(rw_fg AS INT64) AS rw_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wabi_sum`;

-- Table: DBP_DATA.MARKTBESTAND_ERP_DELTA
insert into `dbp_data.marktbestand_erp_delta` (art_id, mandant_id, wup_id, nb_id, dat, menge_lgbest_erp_frei_bme, menge_lgbest_erp_qual_bme, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(menge_lgbest_erp_frei_bme AS NUMERIC) AS menge_lgbest_erp_frei_bme, CAST(menge_lgbest_erp_qual_bme AS NUMERIC) AS menge_lgbest_erp_qual_bme, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_marktbestand_erp_delta`;

-- Table: DBP_DATA.KOSTENSTELLE_HIERARCHIE
insert into `dbp_data.kostenstelle_hierarchie` (mandant_id, krk_id, kjmo, kostenstelle_ebene1_id, kostenstelle_ebene2_id, kostenstelle_ebene3_id, kostenstelle_ebene4_id, kostenstelle_ebene5_id, kostenstelle_ebene6_id, kostenstelle_ebene7_id, kostenstelle_ebene8_id, kostenstelle_ebene9_id, kostenstelle_ebene10_id, kostenstelle_ebene11_id, kostenstelle_ebene12_id, kostenstelle_ebene13_id, kostenstelle_ebene14_id, kostenstelle_ebene15_id, kostenstelle_ebene1_bez, kostenstelle_ebene2_bez, kostenstelle_ebene3_bez, kostenstelle_ebene4_bez, kostenstelle_ebene5_bez, kostenstelle_ebene6_bez, kostenstelle_ebene7_bez, kostenstelle_ebene8_bez, kostenstelle_ebene9_bez, kostenstelle_ebene10_bez, kostenstelle_ebene11_bez, kostenstelle_ebene12_bez, kostenstelle_ebene13_bez, kostenstelle_ebene14_bez, kostenstelle_ebene15_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, krk_id, CAST(kjmo AS INT64) AS kjmo, kostenstelle_ebene1_id, kostenstelle_ebene2_id, kostenstelle_ebene3_id, kostenstelle_ebene4_id, kostenstelle_ebene5_id, kostenstelle_ebene6_id, kostenstelle_ebene7_id, kostenstelle_ebene8_id, kostenstelle_ebene9_id, kostenstelle_ebene10_id, kostenstelle_ebene11_id, kostenstelle_ebene12_id, kostenstelle_ebene13_id, kostenstelle_ebene14_id, kostenstelle_ebene15_id, kostenstelle_ebene1_bez, kostenstelle_ebene2_bez, kostenstelle_ebene3_bez, kostenstelle_ebene4_bez, kostenstelle_ebene5_bez, kostenstelle_ebene6_bez, kostenstelle_ebene7_bez, kostenstelle_ebene8_bez, kostenstelle_ebene9_bez, kostenstelle_ebene10_bez, kostenstelle_ebene11_bez, kostenstelle_ebene12_bez, kostenstelle_ebene13_bez, kostenstelle_ebene14_bez, kostenstelle_ebene15_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_kostenstelle_hierarchie`;

-- Table: DBP_DATA.FLW_ART_WERK_PROGNOSE
insert into `dbp_data.flw_art_werk_prognose` (mandant_id, flw_art_id, werk_id, flw_kunde_id, dat_lief, prognosetyp_id, dat_erstellung_von, prognose_version, version_lfd_nr, dat_erstellung_bis, bestellmenge, dat_bereitstellung, best_menge_einh_id, frueh_spaet_kz, bedarfsplan_id, flw_fg, menge_basis, system_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(flw_art_id AS INT64) AS flw_art_id, CAST(werk_id AS INT64) AS werk_id, CAST(flw_kunde_id AS INT64) AS flw_kunde_id, dat_lief, prognosetyp_id, dat_erstellung_von, CAST(prognose_version AS INT64) AS prognose_version, CAST(version_lfd_nr AS INT64) AS version_lfd_nr, dat_erstellung_bis, CAST(bestellmenge AS NUMERIC) AS bestellmenge, dat_bereitstellung, best_menge_einh_id, frueh_spaet_kz, bedarfsplan_id, CAST(flw_fg AS INT64) AS flw_fg, CAST(menge_basis AS NUMERIC) AS menge_basis, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_art_werk_prognose`;

-- Table: DBP_DATA.WBS_REPLENISHMENT
insert into `dbp_data.wbs_replenishment` (mandant_id, wup_id, nb_id, art_id, diff_tage, kjwo_von, dat_von, dat_bis, wtag_id_von, aktion_id_set, mutter_wb_id, anz_akt_selbe_dauer, aktion_rang, aktion_label, aktion_dat_von, aktion_dat_bis, menge, korrigierte_menge, sales_fg, menge_af_2wo, perc_uplift, wmape, rmse, bias, in_gruppe_fg, tv_fg, titelseite_fg, rueckseite_fg, mit_historie_fg, vk_aktion_brutto, vk_vor_aktion_brutto, anz_art_in_gruppe, anz_art_in_gruppe_referenzperiode, anteil_wup_abvk, abweichung_fg, gk_history_fg, wrg_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(diff_tage AS INT64) AS diff_tage, CAST(kjwo_von AS INT64) AS kjwo_von, dat_von, dat_bis, CAST(wtag_id_von AS INT64) AS wtag_id_von, aktion_id_set, CAST(mutter_wb_id AS INT64) AS mutter_wb_id, CAST(anz_akt_selbe_dauer AS INT64) AS anz_akt_selbe_dauer, CAST(aktion_rang AS INT64) AS aktion_rang, aktion_label, aktion_dat_von, aktion_dat_bis, CAST(menge AS NUMERIC) AS menge, CAST(korrigierte_menge AS NUMERIC) AS korrigierte_menge, CAST(sales_fg AS INT64) AS sales_fg, CAST(menge_af_2wo AS NUMERIC) AS menge_af_2wo, CAST(perc_uplift AS NUMERIC) AS perc_uplift, CAST(wmape AS NUMERIC) AS wmape, CAST(rmse AS NUMERIC) AS rmse, CAST(bias AS NUMERIC) AS bias, CAST(in_gruppe_fg AS INT64) AS in_gruppe_fg, CAST(tv_fg AS INT64) AS tv_fg, CAST(titelseite_fg AS INT64) AS titelseite_fg, CAST(rueckseite_fg AS INT64) AS rueckseite_fg, CAST(mit_historie_fg AS INT64) AS mit_historie_fg, CAST(vk_aktion_brutto AS NUMERIC) AS vk_aktion_brutto, CAST(vk_vor_aktion_brutto AS NUMERIC) AS vk_vor_aktion_brutto, CAST(anz_art_in_gruppe AS INT64) AS anz_art_in_gruppe, CAST(anz_art_in_gruppe_referenzperiode AS INT64) AS anz_art_in_gruppe_referenzperiode, CAST(anteil_wup_abvk AS NUMERIC) AS anteil_wup_abvk, CAST(abweichung_fg AS INT64) AS abweichung_fg, CAST(gk_history_fg AS INT64) AS gk_history_fg, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbs_replenishment`;

-- Table: DBP_DATA.FLW_KALK_PREISE
insert into `dbp_data.flw_kalk_preise` (schnittliste_id, flw_art_id, input_material_typ_id, sek_schl_typ_id, sek_schl_id, mandant_id, system_id, menge, menge_einh_id, menge_dme, dme_einh_id, preis_kg, wrg_id, gesamt_wert, td_insert, td_update)
SELECT CAST(schnittliste_id AS INT64) AS schnittliste_id, CAST(flw_art_id AS INT64) AS flw_art_id, input_material_typ_id, sek_schl_typ_id, CAST(sek_schl_id AS INT64) AS sek_schl_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(menge AS NUMERIC) AS menge, menge_einh_id, CAST(menge_dme AS NUMERIC) AS menge_dme, dme_einh_id, CAST(preis_kg AS NUMERIC) AS preis_kg, wrg_id, CAST(gesamt_wert AS NUMERIC) AS gesamt_wert, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_kalk_preise`;

-- Table: DBP_DATA.FLW_KALK_DENORM
insert into `dbp_data.flw_kalk_denorm` (mandant_id, kalk_id, kalkulationsart_id, bewertung_variante_id, kalk_version_id, dat_kalk, dat_kalk_ab, dat_kalk_bis, flw_art_id, werk_id, mek_rohmaterial, mek_verarbeitungsmaterial, mek_zusaetze, mek_fertigerzeugnis, mek_verpackung, fek_trennprozess, fek_mischprozess, vertriebs_einzelkosten, material_gemeinkosten, fertigungs_gemeinkosten, vertriebs_gemeinkosten, verwaltungs_gemeinkosten, losgroesse, mbew_preis, wrg_id, kalk_variante_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kalk_id AS INT64) AS kalk_id, kalkulationsart_id, bewertung_variante_id, CAST(kalk_version_id AS INT64) AS kalk_version_id, dat_kalk, dat_kalk_ab, dat_kalk_bis, CAST(flw_art_id AS INT64) AS flw_art_id, CAST(werk_id AS INT64) AS werk_id, CAST(mek_rohmaterial AS NUMERIC) AS mek_rohmaterial, CAST(mek_verarbeitungsmaterial AS NUMERIC) AS mek_verarbeitungsmaterial, CAST(mek_zusaetze AS NUMERIC) AS mek_zusaetze, CAST(mek_fertigerzeugnis AS NUMERIC) AS mek_fertigerzeugnis, CAST(mek_verpackung AS NUMERIC) AS mek_verpackung, CAST(fek_trennprozess AS NUMERIC) AS fek_trennprozess, CAST(fek_mischprozess AS NUMERIC) AS fek_mischprozess, CAST(vertriebs_einzelkosten AS NUMERIC) AS vertriebs_einzelkosten, CAST(material_gemeinkosten AS NUMERIC) AS material_gemeinkosten, CAST(fertigungs_gemeinkosten AS NUMERIC) AS fertigungs_gemeinkosten, CAST(vertriebs_gemeinkosten AS NUMERIC) AS vertriebs_gemeinkosten, CAST(verwaltungs_gemeinkosten AS NUMERIC) AS verwaltungs_gemeinkosten, CAST(losgroesse AS NUMERIC) AS losgroesse, CAST(mbew_preis AS NUMERIC) AS mbew_preis, wrg_id, kalk_variante_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_kalk_denorm`;

-- Table: DBP_DATA.REGALACHSE_ART_ZU
insert into `dbp_data.regalachse_art_zu` (mandant_id, regalachse_id, art_id, fachboden_nr, fachboden_pos, regional_kz, kapazitaet, kapazitaet_menge_einh_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regalachse_id AS INT64) AS regalachse_id, CAST(art_id AS INT64) AS art_id, CAST(fachboden_nr AS INT64) AS fachboden_nr, CAST(fachboden_pos AS INT64) AS fachboden_pos, CAST(regional_kz AS INT64) AS regional_kz, CAST(kapazitaet AS NUMERIC) AS kapazitaet, kapazitaet_menge_einh_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regalachse_art_zu`;

-- Table: DBP_DATA.PROBLEMMELDUNG_OBJ_ZU
insert into `dbp_data.problemmeldung_obj_zu` (system_id, mandant_id, problemmeldung_id, zus_obj_id, wert_dec, wert_date, wert_char, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, problemmeldung_id, zus_obj_id, CAST(wert_dec AS NUMERIC) AS wert_dec, wert_date, wert_char, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_problemmeldung_obj_zu`;

-- Table: DBP_DATA.ROHSTOFF_PREISENTWICKLUNG
insert into `dbp_data.rohstoff_preisentwicklung` (rohstoff_nr, dat_rohstoff_preis, rohstoff_einh_name, wrg_id, frequenz_cd, kjwo, preis_rohstoff_max, preis_rohstoff_min, preis_rohstoff_avg, preis_gefuellt_fg, td_update, td_insert)
SELECT rohstoff_nr, dat_rohstoff_preis, rohstoff_einh_name, wrg_id, frequenz_cd, CAST(kjwo AS INT64) AS kjwo, CAST(preis_rohstoff_max AS BIGNUMERIC) AS preis_rohstoff_max, CAST(preis_rohstoff_min AS BIGNUMERIC) AS preis_rohstoff_min, CAST(preis_rohstoff_avg AS BIGNUMERIC) AS preis_rohstoff_avg, CAST(preis_gefuellt_fg AS INT64) AS preis_gefuellt_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rohstoff_preisentwicklung`;

-- Table: DBP_DATA.CRM_L_KUNDE
insert into `dbp_data.crm_l_kunde` (crm_kunde_id, zeit_registrierung, zeit_abmeldung, kundentyp_cd, kundenherkunft_cd, gender_id, geburtsjahr, kunde_statusgrund_id, strasse, wohnort, plz, kunde_mandant_id, geo_gitter_100_nr, geo_gitter_500_nr, geo_gitter_1000_nr, vorzugsfiliale_wup_id, vorzugsfiliale_mandant_id, nb_id, merge_fg, registrierungsfiliale_wup_id, registrierungsfiliale_mandant_id, registrierungsfiliale_nb_id, aktiv_fg, haushaltsgroesse, beschaeftigung_status_id, crm_cidaas_id, td_update, td_insert)
SELECT crm_kunde_id, CAST(zeit_registrierung AS DATETIME) AS zeit_registrierung, CAST(zeit_abmeldung AS DATETIME) AS zeit_abmeldung, kundentyp_cd, kundenherkunft_cd, CAST(gender_id AS INT64) AS gender_id, CAST(geburtsjahr AS INT64) AS geburtsjahr, CAST(kunde_statusgrund_id AS INT64) AS kunde_statusgrund_id, strasse, wohnort, plz, CAST(kunde_mandant_id AS INT64) AS kunde_mandant_id, geo_gitter_100_nr, geo_gitter_500_nr, geo_gitter_1000_nr, CAST(vorzugsfiliale_wup_id AS INT64) AS vorzugsfiliale_wup_id, CAST(vorzugsfiliale_mandant_id AS INT64) AS vorzugsfiliale_mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(merge_fg AS INT64) AS merge_fg, CAST(registrierungsfiliale_wup_id AS INT64) AS registrierungsfiliale_wup_id, CAST(registrierungsfiliale_mandant_id AS INT64) AS registrierungsfiliale_mandant_id, CAST(registrierungsfiliale_nb_id AS INT64) AS registrierungsfiliale_nb_id, CAST(aktiv_fg AS INT64) AS aktiv_fg, haushaltsgroesse, CAST(beschaeftigung_status_id AS INT64) AS beschaeftigung_status_id, crm_cidaas_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_crm_l_kunde`;

-- Table: DBP_DATA.CRM_L_KONTO
insert into `dbp_data.crm_l_konto` (crm_konto_id, crm_kunde_id, crm_konto_typ_id, crm_kundenprogramm_id, zeit_von, zeit_bis, geloescht_fg, crm_konto_nr, td_insert, td_update)
SELECT crm_konto_id, crm_kunde_id, CAST(crm_konto_typ_id AS INT64) AS crm_konto_typ_id, crm_kundenprogramm_id, zeit_von, zeit_bis, CAST(geloescht_fg AS INT64) AS geloescht_fg, CAST(crm_konto_nr AS INT64) AS crm_konto_nr, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_crm_l_konto`;

-- Table: DBP_DATA.VERRECHFALL_KOSTEN
insert into `dbp_data.verrechfall_kosten` (mandant_id, verrechfall_kosten_id, mwst_id, storno_fg, soll_ist_fg, manuelle_erfassung_fg, wrg_id, verrechfall_id, dat_verrechnung_intern, dat_verrechnung_extern, verrechfall_kostenart_id, verrechfall_status_id, betrag_kosten, bemerkung, belosart_fg, zeit_verrechnung_intern, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verrechfall_kosten_id AS INT64) AS verrechfall_kosten_id, CAST(mwst_id AS INT64) AS mwst_id, CAST(storno_fg AS INT64) AS storno_fg, CAST(soll_ist_fg AS INT64) AS soll_ist_fg, CAST(manuelle_erfassung_fg AS INT64) AS manuelle_erfassung_fg, wrg_id, CAST(verrechfall_id AS INT64) AS verrechfall_id, dat_verrechnung_intern, dat_verrechnung_extern, verrechfall_kostenart_id, verrechfall_status_id, CAST(betrag_kosten AS NUMERIC) AS betrag_kosten, bemerkung, CAST(belosart_fg AS INT64) AS belosart_fg, zeit_verrechnung_intern, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_verrechfall_kosten`;

-- Table: DBP_DATA.MHD_ERFASSUNG_WUP_ART
insert into `dbp_data.mhd_erfassung_wup_art` (mandant_id, wup_id, dat_erfassung, dat_mhd, art_id, art_anz, basismenge_einh_id, mhd_erfassung_pruef_fg, listung_fg, dat_erstellung, dat_aenderung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, dat_erfassung, dat_mhd, CAST(art_id AS INT64) AS art_id, CAST(art_anz AS INT64) AS art_anz, basismenge_einh_id, CAST(mhd_erfassung_pruef_fg AS INT64) AS mhd_erfassung_pruef_fg, CAST(listung_fg AS INT64) AS listung_fg, dat_erstellung, dat_aenderung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mhd_erfassung_wup_art`;

-- Table: DBP_MSI_DATA.COS_BONUSPUNKTE_XTRA
insert into `dbp_msi_data.cos_bonuspunkte_xtra` (crm_konto_id, crm_kunde_id, crm_cidaas_id, mandant_id, anz_bonuspunkte, anz_bonuspunkte_blockiert, td_update, td_insert)
SELECT crm_konto_id, crm_kunde_id, crm_cidaas_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(anz_bonuspunkte AS INT64) AS anz_bonuspunkte, CAST(anz_bonuspunkte_blockiert AS INT64) AS anz_bonuspunkte_blockiert, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_cos_bonuspunkte_xtra`;

-- Table: DBP_DATA.TOUR_WE_DET
insert into `dbp_data.tour_we_det` (mandant_id, wup_id, nb_id, lagernummer_id, tour_id, wgvgrp_id, lief_beleg_id, seq_nummer, art_id, kj_lief_beleg, gruppenzone_id, ausschluss_manuell_fg, ausschluss_regel_fg, blockartikel_fg, lagerplatz_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, CAST(tour_id AS INT64) AS tour_id, CAST(wgvgrp_id AS INT64) AS wgvgrp_id, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, CAST(seq_nummer AS INT64) AS seq_nummer, CAST(art_id AS INT64) AS art_id, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, gruppenzone_id, CAST(ausschluss_manuell_fg AS INT64) AS ausschluss_manuell_fg, CAST(ausschluss_regel_fg AS INT64) AS ausschluss_regel_fg, CAST(blockartikel_fg AS INT64) AS blockartikel_fg, lagerplatz_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tour_we_det`;

-- Table: DBP_DATA.WUP_DAT_OWG_SUM
insert into `dbp_data.wup_dat_owg_sum` (mandant_id, wup_id, nb_id, dat, owg_id, arthiertyp_id, bonanzahl, bonanzahl_pre_pack, bonanzahl_sug, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(owg_id AS INT64) AS owg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(bonanzahl_pre_pack AS INT64) AS bonanzahl_pre_pack, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_dat_owg_sum`;

-- Table: DBP_DATA.VZ_BEST_SPLIT
insert into `dbp_data.vz_best_split` (mandant_id, gp_dispo_id, best_beleg_dispo_id, art_dispo_id, bestellart_id, einkaeufer_grp_id, wup_id, nb_id, gp_id, disponent_id, gp_teilsortiment_id, fremd_lagerort_id, art_id, menge_gesamt, menge_iwt_gesamt, menge_normal, menge_iwt, menge_werbung_gesamt, menge_werbung, menge_einh_id, dat_lief_wunsch, kontrakt_beleg_id, kontrakt_beleg_pos_id, best_beleg_id, best_beleg_pos_id, vz_dispo_status_id, palettenfaktor, gewicht_brutto_bme, dat_verfuegbarkeit, faktor_bestme_bme, gewicht_pal, gewicht_gesamt, anz_plaetze_max, gewicht_ladung_max, planlieferzeit, autodispo_fg, wg_id, menge_werbung_gesamt_pal, menge_best_pal, menge_best_werbung_pal, menge_iwt_gesamt_pal, menge_iwt_pal, splitsource_id, menge_bevorratung, bedarfsnummer, ursprungsprozess, best_vor_dispo_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(gp_dispo_id AS INT64) AS gp_dispo_id, CAST(best_beleg_dispo_id AS INT64) AS best_beleg_dispo_id, CAST(art_dispo_id AS INT64) AS art_dispo_id, bestellart_id, einkaeufer_grp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, disponent_id, gp_teilsortiment_id, fremd_lagerort_id, art_id, CAST(menge_gesamt AS INT64) AS menge_gesamt, CAST(menge_iwt_gesamt AS INT64) AS menge_iwt_gesamt, CAST(menge_normal AS INT64) AS menge_normal, CAST(menge_iwt AS INT64) AS menge_iwt, CAST(menge_werbung_gesamt AS INT64) AS menge_werbung_gesamt, CAST(menge_werbung AS INT64) AS menge_werbung, menge_einh_id, dat_lief_wunsch, CAST(kontrakt_beleg_id AS INT64) AS kontrakt_beleg_id, CAST(kontrakt_beleg_pos_id AS INT64) AS kontrakt_beleg_pos_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(vz_dispo_status_id AS INT64) AS vz_dispo_status_id, CAST(palettenfaktor AS INT64) AS palettenfaktor, CAST(gewicht_brutto_bme AS NUMERIC) AS gewicht_brutto_bme, dat_verfuegbarkeit, CAST(faktor_bestme_bme AS NUMERIC) AS faktor_bestme_bme, CAST(gewicht_pal AS INT64) AS gewicht_pal, CAST(gewicht_gesamt AS INT64) AS gewicht_gesamt, CAST(anz_plaetze_max AS INT64) AS anz_plaetze_max, CAST(gewicht_ladung_max AS INT64) AS gewicht_ladung_max, CAST(planlieferzeit AS INT64) AS planlieferzeit, CAST(autodispo_fg AS INT64) AS autodispo_fg, CAST(wg_id AS INT64) AS wg_id, CAST(menge_werbung_gesamt_pal AS NUMERIC) AS menge_werbung_gesamt_pal, CAST(menge_best_pal AS NUMERIC) AS menge_best_pal, CAST(menge_best_werbung_pal AS NUMERIC) AS menge_best_werbung_pal, CAST(menge_iwt_gesamt_pal AS NUMERIC) AS menge_iwt_gesamt_pal, CAST(menge_iwt_pal AS NUMERIC) AS menge_iwt_pal, splitsource_id, CAST(menge_bevorratung AS INT64) AS menge_bevorratung, bedarfsnummer, ursprungsprozess, CAST(best_vor_dispo_id AS INT64) AS best_vor_dispo_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_vz_best_split`;

-- Table: DBP_DATA.PROTOKOLL_VERLADUNG_EWM
insert into `dbp_data.protokoll_verladung_ewm` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, handling_unit_id_ext, datzeit_scan, lagernummer_id, lagersortiment_id, kunde_id, dat_scan, zeit_scan, versandeinheit_id_ext, lief_beleg_id, dat_lief_soll, z_arbeitsgebiet_id, pruef_id, gesamtgewicht_hu, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, handling_unit_id_ext, datzeit_scan, lagernummer_id, lagersortiment_id, CAST(kunde_id AS INT64) AS kunde_id, dat_scan, zeit_scan, versandeinheit_id_ext, CAST(lief_beleg_id AS INT64) AS lief_beleg_id, dat_lief_soll, CAST(z_arbeitsgebiet_id AS INT64) AS z_arbeitsgebiet_id, CAST(pruef_id AS INT64) AS pruef_id, CAST(gesamtgewicht_hu AS NUMERIC) AS gesamtgewicht_hu, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_protokoll_verladung_ewm`;

-- Table: DBP_DATA.FLW_FUR
insert into `dbp_data.flw_fur` (mandant_id, flw_art_id, flw_kunde_id, dat, system_id, menge_sicherheit, menge_plan, dat_erstellung, einh_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(flw_art_id AS INT64) AS flw_art_id, CAST(flw_kunde_id AS INT64) AS flw_kunde_id, dat, CAST(system_id AS INT64) AS system_id, CAST(menge_sicherheit AS NUMERIC) AS menge_sicherheit, CAST(menge_plan AS NUMERIC) AS menge_plan, dat_erstellung, einh_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_fur`;

-- Table: DBP_DATA.INVENTUR_DET_KMO
insert into `dbp_data.inventur_det_kmo` (mandant_id, wup_id, nb_id, zeitpunkt_inv, art_id, wrg_id, menge_inv, bestand_wert, wert_eingabe, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, zeitpunkt_inv, CAST(art_id AS INT64) AS art_id, wrg_id, CAST(menge_inv AS NUMERIC) AS menge_inv, CAST(bestand_wert AS NUMERIC) AS bestand_wert, wert_eingabe, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_inventur_det_kmo`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_FINANCIAL
insert into `dbp_ods_archiv.ods_bon_financial` (bon_id, bon_zeile, mandant_id, umsatz_brutto, financial_grund_id, financial_kommentar, auszahlung_fg, wup_id, start_bon_zeile, bon_dat, td_insert, td_update)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(mandant_id AS INT64) AS mandant_id, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(financial_grund_id AS INT64) AS financial_grund_id, financial_kommentar, CAST(auszahlung_fg AS INT64) AS auszahlung_fg, CAST(wup_id AS INT64) AS wup_id, CAST(start_bon_zeile AS DATETIME) AS start_bon_zeile, bon_dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_financial`;

-- Table: DBP_DATA.TRANSPORTAUFTRAG_EINLAGERSTRATEGIE
insert into `dbp_data.transportauftrag_einlagerstrategie` (mandant_id, transport_beleg_id, lagernummer_id, wup_id, nb_id, entfernung_horz_1, aufschlag_gangwechsel_1, aufschlag_hoehe_1, lagerplatz_typ_aufschlag_1, entfernung_horz_2, aufschlag_gangwechsel_2, aufschlag_hoehe_2, lagerplatz_typ_aufschlag_2, palettensteuerung_indiv_fg, alternative_griffzone_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transport_beleg_id AS INT64) AS transport_beleg_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(entfernung_horz_1 AS NUMERIC) AS entfernung_horz_1, CAST(aufschlag_gangwechsel_1 AS NUMERIC) AS aufschlag_gangwechsel_1, CAST(aufschlag_hoehe_1 AS NUMERIC) AS aufschlag_hoehe_1, CAST(lagerplatz_typ_aufschlag_1 AS NUMERIC) AS lagerplatz_typ_aufschlag_1, CAST(entfernung_horz_2 AS NUMERIC) AS entfernung_horz_2, CAST(aufschlag_gangwechsel_2 AS NUMERIC) AS aufschlag_gangwechsel_2, CAST(aufschlag_hoehe_2 AS NUMERIC) AS aufschlag_hoehe_2, CAST(lagerplatz_typ_aufschlag_2 AS NUMERIC) AS lagerplatz_typ_aufschlag_2, CAST(palettensteuerung_indiv_fg AS INT64) AS palettensteuerung_indiv_fg, CAST(alternative_griffzone_fg AS INT64) AS alternative_griffzone_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportauftrag_einlagerstrategie`;

-- Table: DBP_DATA.BELOS_VORGANG
insert into `dbp_data.belos_vorgang` (mandant_id, belos_vorgang_id, komplettlieferung_fg, loesch_fg, in_time_fg, av_fg, sammel_ladung_fg, nb_id, sendung_gew_einh_id, sendung_vol_einh_id, dat_leistung, dat_zustellung, sendung_id, wup_id, lagerort_id, gp_id, gewicht_sendung, zustellart_id, belos_vorgangart_id, transportauftrag_id, sonderabwicklung_id, belos_adresse_absender_num_id, belos_adresse_abholung_id, belos_adresse_empfaenger_id, belos_adresse_spedition_id, vol_stauraum, debitor_id, anz_unterverpackung, unterverpackung_menge_einh_id, lagernummer_id, system_id, tour_id, belosart_fg, leergut_abh_fg, retouren_fg, industrie_abh_fg, anz_stellplatz, anz_kolli, belos_sendungsstatus_id, rundlauf_transport_fg, fleischwerk_fg, distribution_abr_fg, brtgew_sendung, brtvol_stauraum, anz_stellplatz_belos, k_na_fg, belos_auftrag_id_extern, belos_lieferschein_id, belos_sendung_id_extern, belos_bestell_beleg_id_extern, referenz, mandant_id_debitor, datzeit_sendung_offen, datzeit_ware_versandbereit, datzeit_sendung_beauftragt, datzeit_system_zugestellt, datzeit_abholung_bis, datzeit_zustellung_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(belos_vorgang_id AS INT64) AS belos_vorgang_id, CAST(komplettlieferung_fg AS INT64) AS komplettlieferung_fg, CAST(loesch_fg AS INT64) AS loesch_fg, CAST(in_time_fg AS INT64) AS in_time_fg, CAST(av_fg AS INT64) AS av_fg, CAST(sammel_ladung_fg AS INT64) AS sammel_ladung_fg, CAST(nb_id AS INT64) AS nb_id, sendung_gew_einh_id, sendung_vol_einh_id, dat_leistung, dat_zustellung, CAST(sendung_id AS INT64) AS sendung_id, CAST(wup_id AS INT64) AS wup_id, lagerort_id, CAST(gp_id AS INT64) AS gp_id, CAST(gewicht_sendung AS NUMERIC) AS gewicht_sendung, zustellart_id, belos_vorgangart_id, transportauftrag_id, sonderabwicklung_id, CAST(belos_adresse_absender_num_id AS INT64) AS belos_adresse_absender_num_id, belos_adresse_abholung_id, belos_adresse_empfaenger_id, belos_adresse_spedition_id, CAST(vol_stauraum AS NUMERIC) AS vol_stauraum, CAST(debitor_id AS INT64) AS debitor_id, CAST(anz_unterverpackung AS NUMERIC) AS anz_unterverpackung, unterverpackung_menge_einh_id, lagernummer_id, CAST(system_id AS INT64) AS system_id, CAST(tour_id AS INT64) AS tour_id, CAST(belosart_fg AS INT64) AS belosart_fg, CAST(leergut_abh_fg AS INT64) AS leergut_abh_fg, CAST(retouren_fg AS INT64) AS retouren_fg, CAST(industrie_abh_fg AS INT64) AS industrie_abh_fg, CAST(anz_stellplatz AS NUMERIC) AS anz_stellplatz, CAST(anz_kolli AS NUMERIC) AS anz_kolli, CAST(belos_sendungsstatus_id AS INT64) AS belos_sendungsstatus_id, CAST(rundlauf_transport_fg AS INT64) AS rundlauf_transport_fg, CAST(fleischwerk_fg AS INT64) AS fleischwerk_fg, CAST(distribution_abr_fg AS INT64) AS distribution_abr_fg, CAST(brtgew_sendung AS NUMERIC) AS brtgew_sendung, CAST(brtvol_stauraum AS NUMERIC) AS brtvol_stauraum, CAST(anz_stellplatz_belos AS NUMERIC) AS anz_stellplatz_belos, CAST(k_na_fg AS INT64) AS k_na_fg, belos_auftrag_id_extern, belos_lieferschein_id, belos_sendung_id_extern, belos_bestell_beleg_id_extern, referenz, CAST(mandant_id_debitor AS INT64) AS mandant_id_debitor, CAST(datzeit_sendung_offen AS DATETIME) AS datzeit_sendung_offen, CAST(datzeit_ware_versandbereit AS DATETIME) AS datzeit_ware_versandbereit, CAST(datzeit_sendung_beauftragt AS DATETIME) AS datzeit_sendung_beauftragt, CAST(datzeit_system_zugestellt AS DATETIME) AS datzeit_system_zugestellt, CAST(datzeit_abholung_bis AS DATETIME) AS datzeit_abholung_bis, CAST(datzeit_zustellung_bis AS DATETIME) AS datzeit_zustellung_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_belos_vorgang`;

-- Table: DBP_DATA.INVENTUR_WARENVERLUST_DET
insert into `dbp_data.inventur_warenverlust_det` (mandant_id, inventur_id, art_id, wrg_id, betrag_vk_netto, betrag_vk_netto_preisabschrift, betrag_vk_netto_totalabschrift, menge_inventur_diff, betrag_vk_netto_inventur_diff, menge_inventur_diff_diebstahl, betrag_vk_netto_inventur_diff_diebstahl, betrag_vk_netto_inventur_diff_plan, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(inventur_id AS INT64) AS inventur_id, CAST(art_id AS INT64) AS art_id, wrg_id, CAST(betrag_vk_netto AS NUMERIC) AS betrag_vk_netto, CAST(betrag_vk_netto_preisabschrift AS NUMERIC) AS betrag_vk_netto_preisabschrift, CAST(betrag_vk_netto_totalabschrift AS NUMERIC) AS betrag_vk_netto_totalabschrift, CAST(menge_inventur_diff AS NUMERIC) AS menge_inventur_diff, CAST(betrag_vk_netto_inventur_diff AS NUMERIC) AS betrag_vk_netto_inventur_diff, CAST(menge_inventur_diff_diebstahl AS NUMERIC) AS menge_inventur_diff_diebstahl, CAST(betrag_vk_netto_inventur_diff_diebstahl AS NUMERIC) AS betrag_vk_netto_inventur_diff_diebstahl, CAST(betrag_vk_netto_inventur_diff_plan AS NUMERIC) AS betrag_vk_netto_inventur_diff_plan, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_inventur_warenverlust_det`;

-- Table: DBP_DATA.T_FACT_IOT_COMPOUND_PER_HOUR
insert into `dbp_data.t_fact_iot_compound_per_hour` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, liquefactiontemp_actual_meas, liquefactiontemp_setpoint_meas, roomtemp_meas, evaporationtemp_actual_meas, evaporation_pressure_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(liquefactiontemp_actual_meas AS NUMERIC) AS liquefactiontemp_actual_meas, CAST(liquefactiontemp_setpoint_meas AS NUMERIC) AS liquefactiontemp_setpoint_meas, CAST(roomtemp_meas AS NUMERIC) AS roomtemp_meas, CAST(evaporationtemp_actual_meas AS NUMERIC) AS evaporationtemp_actual_meas, CAST(evaporation_pressure_meas AS NUMERIC) AS evaporation_pressure_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_compound_per_hour`;

-- Table: DBP_DATA.KAMPAGNE_KUNDE
insert into `dbp_data.kampagne_kunde` (mandant_id, kampagne_kunde_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kampagne_kunde_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_kampagne_kunde`;

-- Table: DBP_DATA.FUR_ART_WUP_FRP_LTZ_LAUF
insert into `dbp_data.fur_art_wup_frp_ltz_lauf` (mandant_id, wup_id, nb_id, art_id, standardabweichung, klassifikationsmittelwert, drehklasse_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(standardabweichung AS NUMERIC) AS standardabweichung, CAST(klassifikationsmittelwert AS NUMERIC) AS klassifikationsmittelwert, drehklasse_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fur_art_wup_frp_ltz_lauf`;

-- Table: DBP_DATA.FLW_SCHNITT_OUTPUT_DET
insert into `dbp_data.flw_schnitt_output_det` (schnitt_id, sek_schl_typ_id, sek_schl_id, schnitt_pos_id, mandant_id, system_id, flw_art_id, menge_schnitt, wrg_id, betrag_schnitt_output, td_update, td_insert)
SELECT CAST(schnitt_id AS INT64) AS schnitt_id, sek_schl_typ_id, CAST(sek_schl_id AS INT64) AS sek_schl_id, CAST(schnitt_pos_id AS INT64) AS schnitt_pos_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(flw_art_id AS INT64) AS flw_art_id, CAST(menge_schnitt AS NUMERIC) AS menge_schnitt, wrg_id, CAST(betrag_schnitt_output AS NUMERIC) AS betrag_schnitt_output, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_schnitt_output_det`;

-- Table: DBP_DATA.FLW_KUNDE_AUFTRAG_EINTEIL
insert into `dbp_data.flw_kunde_auftrag_einteil` (mandant_id, verkaufs_beleg_id, verkaufs_beleg_pos_id, einteil_id, system_id, dat_einteilung, zeit_einteilung, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verkaufs_beleg_id AS INT64) AS verkaufs_beleg_id, CAST(verkaufs_beleg_pos_id AS INT64) AS verkaufs_beleg_pos_id, CAST(einteil_id AS INT64) AS einteil_id, CAST(system_id AS INT64) AS system_id, dat_einteilung, CAST(zeit_einteilung AS INT64) AS zeit_einteilung, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_kunde_auftrag_einteil`;

-- Table: DBP_DATA.MCX_FEEDBACK
insert into `dbp_data.mcx_feedback` (feedback_id, umfrage_id, befragter_id, frage_id, scale_id, antwort_id, datzeit_abschluss, dat_feedback, abschluss_id, mandant_id, gf_id, wup_id, nb_id, dat, zeitspanne, zeitspanne_id, bonwertspanne, td_update, td_insert)
SELECT CAST(feedback_id AS INT64) AS feedback_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(befragter_id AS INT64) AS befragter_id, CAST(frage_id AS INT64) AS frage_id, CAST(scale_id AS INT64) AS scale_id, CAST(antwort_id AS INT64) AS antwort_id, datzeit_abschluss, dat_feedback, CAST(abschluss_id AS INT64) AS abschluss_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(gf_id AS INT64) AS gf_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, zeitspanne, CAST(zeitspanne_id AS INT64) AS zeitspanne_id, bonwertspanne, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_feedback`;

-- Table: DBP_DATA.AUTODISPO_DIF_TAG
insert into `dbp_data.autodispo_dif_tag` (mandant_id, kunde_id, art_id, dat, dat_ausfuehrung, dif_typ_id, dif_status_id, dif_wert, dif_kommentar, sap_returncode, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kunde_id AS INT64) AS kunde_id, CAST(art_id AS INT64) AS art_id, dat, dat_ausfuehrung, CAST(dif_typ_id AS INT64) AS dif_typ_id, CAST(dif_status_id AS INT64) AS dif_status_id, CAST(dif_wert AS NUMERIC) AS dif_wert, dif_kommentar, sap_returncode, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_autodispo_dif_tag`;

-- Table: DBP_DATA.ORG_EINHEIT_HIERARCHIE
insert into `dbp_data.org_einheit_hierarchie` (mandant_id, hr_objekt_ebene1_id, hr_objekt_ebene2_id, hr_objekt_ebene3_id, hr_objekt_ebene4_id, hr_objekt_ebene5_id, hr_objekt_ebene6_id, hr_objekt_ebene7_id, hr_objekt_ebene8_id, hr_objekt_ebene9_id, hr_objekt_ebene10_id, hr_objekt_ebene11_id, kjmo, spr_id, kostenstelle_id, hr_objekt_ebene1_bez, hr_objekt_ebene2_bez, hr_objekt_ebene3_bez, hr_objekt_ebene4_bez, hr_objekt_ebene5_bez, hr_objekt_ebene6_bez, hr_objekt_ebene7_bez, hr_objekt_ebene8_bez, hr_objekt_ebene9_bez, hr_objekt_ebene10_bez, hr_objekt_ebene11_bez, om_sort_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_ebene1_id AS INT64) AS hr_objekt_ebene1_id, CAST(hr_objekt_ebene2_id AS INT64) AS hr_objekt_ebene2_id, CAST(hr_objekt_ebene3_id AS INT64) AS hr_objekt_ebene3_id, CAST(hr_objekt_ebene4_id AS INT64) AS hr_objekt_ebene4_id, CAST(hr_objekt_ebene5_id AS INT64) AS hr_objekt_ebene5_id, CAST(hr_objekt_ebene6_id AS INT64) AS hr_objekt_ebene6_id, CAST(hr_objekt_ebene7_id AS INT64) AS hr_objekt_ebene7_id, CAST(hr_objekt_ebene8_id AS INT64) AS hr_objekt_ebene8_id, CAST(hr_objekt_ebene9_id AS INT64) AS hr_objekt_ebene9_id, CAST(hr_objekt_ebene10_id AS INT64) AS hr_objekt_ebene10_id, CAST(hr_objekt_ebene11_id AS INT64) AS hr_objekt_ebene11_id, CAST(kjmo AS INT64) AS kjmo, CAST(spr_id AS INT64) AS spr_id, kostenstelle_id, hr_objekt_ebene1_bez, hr_objekt_ebene2_bez, hr_objekt_ebene3_bez, hr_objekt_ebene4_bez, hr_objekt_ebene5_bez, hr_objekt_ebene6_bez, hr_objekt_ebene7_bez, hr_objekt_ebene8_bez, hr_objekt_ebene9_bez, hr_objekt_ebene10_bez, hr_objekt_ebene11_bez, CAST(om_sort_id AS INT64) AS om_sort_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_org_einheit_hierarchie`;

-- Table: DBP_DATA.AUSNAHME_VZ
insert into `dbp_data.ausnahme_vz` (mandant_id, ausnahme_vz_guid, meldungstyp_id, nachrichtenhandler_id, arbeitsgebiet_id, z_arbeitsgebiet_id, nachrichtennummer, art_id, nachrichtenquelle_id, wup_id, nb_id, gp_id, gp_teilsortiment_id, fremd_lagerort_id, best_beleg_id, nachrichtenstatus_id, dat_plan, nachrichtenklasse_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausnahme_vz_guid, meldungstyp_id, nachrichtenhandler_id, arbeitsgebiet_id, CAST(z_arbeitsgebiet_id AS INT64) AS z_arbeitsgebiet_id, CAST(nachrichtennummer AS INT64) AS nachrichtennummer, art_id, nachrichtenquelle_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, gp_teilsortiment_id, fremd_lagerort_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, nachrichtenstatus_id, dat_plan, nachrichtenklasse_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ausnahme_vz`;

-- Table: DBP_DATA.FUR_PROGNOSE_VW_WO_SUM
insert into `dbp_data.fur_prognose_vw_wo_sum` (mandant_id, vw_id, art_id, kjwo_kl, menge_prognose, menge_prognose_bef, menge_prognose_max, menge_af, menge_sa, diff_menge_af_prognose, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vw_id AS INT64) AS vw_id, CAST(art_id AS INT64) AS art_id, CAST(kjwo_kl AS INT64) AS kjwo_kl, CAST(menge_prognose AS NUMERIC) AS menge_prognose, CAST(menge_prognose_bef AS NUMERIC) AS menge_prognose_bef, CAST(menge_prognose_max AS NUMERIC) AS menge_prognose_max, CAST(menge_af AS NUMERIC) AS menge_af, CAST(menge_sa AS NUMERIC) AS menge_sa, CAST(diff_menge_af_prognose AS NUMERIC) AS diff_menge_af_prognose, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_fur_prognose_vw_wo_sum`;

-- Table: DBP_DATA.IN_BEST_BELEGFLUSS
insert into `dbp_data.in_best_belegfluss` (best_beleg_id, mandant_id, best_beleg_pos_id, folge_beleg_id, kj, folge_beleg_pos_id, kontierung_pos_id, vorgart_best_entw_id, dat_buch, betrag_wrbtr, best_entw_typ_id, soll_haben_kz, wrg_id_beleg, td_update, td_insert)
SELECT CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(folge_beleg_id AS INT64) AS folge_beleg_id, CAST(kj AS INT64) AS kj, CAST(folge_beleg_pos_id AS INT64) AS folge_beleg_pos_id, CAST(kontierung_pos_id AS INT64) AS kontierung_pos_id, vorgart_best_entw_id, dat_buch, CAST(betrag_wrbtr AS NUMERIC) AS betrag_wrbtr, best_entw_typ_id, soll_haben_kz, wrg_id_beleg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_in_best_belegfluss`;

-- Table: DBP_DATA.INVENTUR_TERMIN_ART_WUP_ZU_PER
insert into `dbp_data.inventur_termin_art_wup_zu_per` (mandant_id, wup_id, nb_id, dat_plan_zaehlung, art_id, dat_vorletzte_zaehlung, inventurart_int_vorletzte_zaehlung, wrg_id, umsatz_vk_netto_sum, inventur_wert_vk_netto, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_plan_zaehlung, CAST(art_id AS INT64) AS art_id, dat_vorletzte_zaehlung, CAST(inventurart_int_vorletzte_zaehlung AS INT64) AS inventurart_int_vorletzte_zaehlung, wrg_id, CAST(umsatz_vk_netto_sum AS NUMERIC) AS umsatz_vk_netto_sum, CAST(inventur_wert_vk_netto AS NUMERIC) AS inventur_wert_vk_netto, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_inventur_termin_art_wup_zu_per`;

-- Table: DBP_DATA.BESCH_LIEF_BELOS_VORGANG_ZU
insert into `dbp_data.besch_lief_belos_vorgang_zu` (mandant_id, lief_beleg_id, kj_lief_beleg, dat_lief_soll, belos_vorgang_id, transportation_unit_id, dat_leistung, versandstelle_id, lief_prefix, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lief_beleg_id AS NUMERIC) AS lief_beleg_id, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, dat_lief_soll, CAST(belos_vorgang_id AS INT64) AS belos_vorgang_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, dat_leistung, versandstelle_id, lief_prefix, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_besch_lief_belos_vorgang_zu`;

-- Table: DBP_DATA.WBS_REFERENZARTIKEL
insert into `dbp_data.wbs_referenzartikel` (mandant_id, art_id, ref_art_id, ref_anz_maerkte, avg_vk_brutto, avg_ref_vk_brutto, ref_score_rang, ref_score, diff_vk, diff_absatz, diff_absatz_absolut, diff_absatz_kennz, diff_cosinus, diff_gewicht, diff_wug, aktion_id, ref_ltz_dat_von, dat_von, ltz_dat_von, berechnung_typ, dat_berechnung, selektor_fg, berechnung_subtyp, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(ref_art_id AS INT64) AS ref_art_id, CAST(ref_anz_maerkte AS INT64) AS ref_anz_maerkte, CAST(avg_vk_brutto AS NUMERIC) AS avg_vk_brutto, CAST(avg_ref_vk_brutto AS NUMERIC) AS avg_ref_vk_brutto, CAST(ref_score_rang AS INT64) AS ref_score_rang, CAST(ref_score AS NUMERIC) AS ref_score, CAST(diff_vk AS NUMERIC) AS diff_vk, CAST(diff_absatz AS NUMERIC) AS diff_absatz, CAST(diff_absatz_absolut AS NUMERIC) AS diff_absatz_absolut, diff_absatz_kennz, CAST(diff_cosinus AS NUMERIC) AS diff_cosinus, CAST(diff_gewicht AS NUMERIC) AS diff_gewicht, CAST(diff_wug AS NUMERIC) AS diff_wug, aktion_id, ref_ltz_dat_von, dat_von, ltz_dat_von, berechnung_typ, CAST(dat_berechnung AS DATETIME) AS dat_berechnung, CAST(selektor_fg AS INT64) AS selektor_fg, berechnung_subtyp, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_referenzartikel`;

-- Table: DBP_DATA.CRM_VORGANG
insert into `dbp_data.crm_vorgang` (mandant_id, crm_vorgang_id, crm_prozess_id, wup_id, nb_id, crm_emotion_id, crm_eingangskanal_id, crm_prioritaet_id, crm_status_id, crm_schaedlingsart_id, crm_eigenmarke_id, crm_themenbaum_lv2_id, ticketnummer, etiketten_text, ticket_text, foto_fg, fremdkoerper_fg, charge, art_id, gtin_id, gp_art_id, wg_id, dat_start, dat_ende, dat_aenderung, vorgangnummer, standardloesung_fg, dat_start_processing, dat_end_processing, crm_magicword_id, dat_best_before, zek_id, gp_id, subassortment, apollo, crm_brand_id, td_update, td_insert, dauer_fb_bearbeitungszeit, dauer_gesamt_bearbeitungszeit)
SELECT CAST(mandant_id AS INT64) AS mandant_id, crm_vorgang_id, CAST(crm_prozess_id AS INT64) AS crm_prozess_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(crm_emotion_id AS INT64) AS crm_emotion_id, CAST(crm_eingangskanal_id AS INT64) AS crm_eingangskanal_id, CAST(crm_prioritaet_id AS INT64) AS crm_prioritaet_id, CAST(crm_status_id AS INT64) AS crm_status_id, CAST(crm_schaedlingsart_id AS INT64) AS crm_schaedlingsart_id, CAST(crm_eigenmarke_id AS INT64) AS crm_eigenmarke_id, crm_themenbaum_lv2_id, ticketnummer, etiketten_text, ticket_text, CAST(foto_fg AS INT64) AS foto_fg, CAST(fremdkoerper_fg AS INT64) AS fremdkoerper_fg, charge, CAST(art_id AS INT64) AS art_id, CAST(gtin_id AS NUMERIC) AS gtin_id, gp_art_id, CAST(wg_id AS INT64) AS wg_id, dat_start, dat_ende, dat_aenderung, vorgangnummer, CAST(standardloesung_fg AS INT64) AS standardloesung_fg, dat_start_processing, dat_end_processing, crm_magicword_id, dat_best_before, zek_id, CAST(gp_id AS INT64) AS gp_id, subassortment, apollo, crm_brand_id, td_update, td_insert, CAST(dauer_fb_bearbeitungszeit AS INT64) AS dauer_fb_bearbeitungszeit, CAST(dauer_gesamt_bearbeitungszeit AS INT64) AS dauer_gesamt_bearbeitungszeit
FROM `snowflake_snapshots.kfl_dbp_data_crm_vorgang`;

-- Table: DBP_DATA.OBLIGO_PER
insert into `dbp_data.obligo_per` (mandant_id, krk_id, psp_id, kostenart_id, obligo_version_id, obligo_wrg_typ_id, gj, buchungsperiode_id, ref_beleg_id, ref_beleg_pos_id, ref_belegart_id, ref_termin_pos_id, ref_kontierung_id, ref_objektart_id, dat_von, in_lief_id, ref_beleg_typ_id, auftrag_id, dat_bis, loesch_id, betrag, wrg_id, menge, menge_einh_id, dat_buch, dat_beleg, buchungskreis_id, in_art_id, anlage_id, anlage_sub_id, kostenstelle_id, sparte_id, berichts_position_invest_id, berichts_position_it_id, psp_id_char_alt, bestell_text, betrag_plan, bedarf_nr, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, krk_id, CAST(psp_id AS INT64) AS psp_id, kostenart_id, obligo_version_id, obligo_wrg_typ_id, CAST(gj AS INT64) AS gj, CAST(buchungsperiode_id AS INT64) AS buchungsperiode_id, CAST(ref_beleg_id AS INT64) AS ref_beleg_id, CAST(ref_beleg_pos_id AS INT64) AS ref_beleg_pos_id, ref_belegart_id, CAST(ref_termin_pos_id AS INT64) AS ref_termin_pos_id, CAST(ref_kontierung_id AS INT64) AS ref_kontierung_id, ref_objektart_id, dat_von, CAST(in_lief_id AS INT64) AS in_lief_id, ref_beleg_typ_id, auftrag_id, dat_bis, loesch_id, CAST(betrag AS NUMERIC) AS betrag, wrg_id, CAST(menge AS NUMERIC) AS menge, menge_einh_id, dat_buch, dat_beleg, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, CAST(in_art_id AS INT64) AS in_art_id, anlage_id, CAST(anlage_sub_id AS INT64) AS anlage_sub_id, kostenstelle_id, CAST(sparte_id AS INT64) AS sparte_id, CAST(berichts_position_invest_id AS INT64) AS berichts_position_invest_id, CAST(berichts_position_it_id AS INT64) AS berichts_position_it_id, psp_id_char_alt, bestell_text, CAST(betrag_plan AS NUMERIC) AS betrag_plan, bedarf_nr, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_obligo_per`;

-- Table: DBP_DATA.MHD_WAELZPLAN_WUP_ART
insert into `dbp_data.mhd_waelzplan_wup_art` (mandant_id, wup_id, kjwo, art_id, waelzplan_pruef_id, wiederholungsrhythmus_wochen, kjwo_wiederholung, dat_aenderung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(kjwo AS INT64) AS kjwo, CAST(art_id AS INT64) AS art_id, CAST(waelzplan_pruef_id AS INT64) AS waelzplan_pruef_id, CAST(wiederholungsrhythmus_wochen AS INT64) AS wiederholungsrhythmus_wochen, CAST(kjwo_wiederholung AS INT64) AS kjwo_wiederholung, dat_aenderung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mhd_waelzplan_wup_art`;

-- Table: DBP_DATA.TRANSPORT_LEISTUNG_SUM
insert into `dbp_data.transport_leistung_sum` (lagernummer_id, mandant_id, von_lagertyp_id, nach_lagertyp_id, wup_id, nb_id, leist_empfaenger_sap_id, leist_empfaenger_gruppe_id, dat_leistung, transport_gv_id, gp_id, menge_kolli, zeit_sekunden, zeit_ruest_sekunden, zeit_pause_sekunden, anzahl_transportauftrag, anzahl_versandblock, anzahl_ruestzeit, anzahl_pause, td_insert, td_update)
SELECT lagernummer_id, CAST(mandant_id AS INT64) AS mandant_id, von_lagertyp_id, nach_lagertyp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, leist_empfaenger_sap_id, leist_empfaenger_gruppe_id, dat_leistung, CAST(transport_gv_id AS INT64) AS transport_gv_id, CAST(gp_id AS INT64) AS gp_id, CAST(menge_kolli AS NUMERIC) AS menge_kolli, CAST(zeit_sekunden AS INT64) AS zeit_sekunden, CAST(zeit_ruest_sekunden AS INT64) AS zeit_ruest_sekunden, CAST(zeit_pause_sekunden AS INT64) AS zeit_pause_sekunden, CAST(anzahl_transportauftrag AS INT64) AS anzahl_transportauftrag, CAST(anzahl_versandblock AS INT64) AS anzahl_versandblock, CAST(anzahl_ruestzeit AS INT64) AS anzahl_ruestzeit, CAST(anzahl_pause AS INT64) AS anzahl_pause, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_transport_leistung_sum`;

-- Table: DBP_DATA.WUP_ZEIT
insert into `dbp_data.wup_zeit` (dat, wup_id, mandant_id, nb_id, umsatz_brutto, bonanzahl, zeit_stunde, zeit_minute, td_insert, td_update)
SELECT dat, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(zeit_minute AS INT64) AS zeit_minute, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_zeit`;

-- Table: DBP_DATA.FLW_LAGERBEW
insert into `dbp_data.flw_lagerbew` (mandant_id, lagerbew_beleg_id, kj, vorgangsart_id, dat_beleg, dat_buch, dat_erfasst, ref_lagerbew_beleg_id, zeit_erfasst, belegkopftext, system_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(kj AS INT64) AS kj, vorgangsart_id, dat_beleg, dat_buch, dat_erfasst, ref_lagerbew_beleg_id, CAST(zeit_erfasst AS INT64) AS zeit_erfasst, belegkopftext, CAST(system_id AS INT64) AS system_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_lagerbew`;

-- Table: DBP_MSI_DATA.VIS_MONAT_UMSATZ_WG
insert into `dbp_msi_data.vis_monat_umsatz_wg` (mandant_id, wup_id, nb_id, wrg_id, kjmo, arthiertyp_id, wg_id, abt_id, gj, ums_netto, ums_netto_kvj, ums_netto_kvvj, ums_netto_plan, ums_brutto, ums_brutto_kvj, menge_absatz, menge_absatz_kvj, menge_absatz_kvvj, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, wrg_id, CAST(kjmo AS INT64) AS kjmo, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(ums_netto AS NUMERIC) AS ums_netto, CAST(ums_netto_kvj AS NUMERIC) AS ums_netto_kvj, CAST(ums_netto_kvvj AS NUMERIC) AS ums_netto_kvvj, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_brutto AS NUMERIC) AS ums_brutto, CAST(ums_brutto_kvj AS NUMERIC) AS ums_brutto_kvj, CAST(menge_absatz AS NUMERIC) AS menge_absatz, CAST(menge_absatz_kvj AS NUMERIC) AS menge_absatz_kvj, CAST(menge_absatz_kvvj AS NUMERIC) AS menge_absatz_kvvj, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_umsatz_wg`;

-- Table: DBP_DATA.IN_BESCH_BEST_DET
insert into `dbp_data.in_besch_best_det` (best_beleg_id, best_beleg_pos_id, mandant_id, in_art_id, menge_best_bme, best_menge_einh_id, best_preis_menge_einh_id, loesch_id, werk_id, retourenpos_fg, dupli_fg, besch_pos_typ_id, system_id, nettopreis, betrag_pos_netto_best_wrg, endrech_fg, rech_plan_id, bsak_dat_buch, menge_bme, unterposition_typ_id, in_wg_id, k_shop_fg, wrg_id, td_update, td_insert)
SELECT CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(in_art_id AS INT64) AS in_art_id, CAST(menge_best_bme AS NUMERIC) AS menge_best_bme, best_menge_einh_id, best_preis_menge_einh_id, loesch_id, CAST(werk_id AS INT64) AS werk_id, CAST(retourenpos_fg AS INT64) AS retourenpos_fg, CAST(dupli_fg AS INT64) AS dupli_fg, besch_pos_typ_id, CAST(system_id AS INT64) AS system_id, CAST(nettopreis AS NUMERIC) AS nettopreis, CAST(betrag_pos_netto_best_wrg AS NUMERIC) AS betrag_pos_netto_best_wrg, CAST(endrech_fg AS INT64) AS endrech_fg, CAST(rech_plan_id AS INT64) AS rech_plan_id, bsak_dat_buch, CAST(menge_bme AS NUMERIC) AS menge_bme, unterposition_typ_id, in_wg_id, CAST(k_shop_fg AS INT64) AS k_shop_fg, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_in_besch_best_det`;

-- Table: DBP_DATA.TOUR_PLOMBE_START
insert into `dbp_data.tour_plombe_start` (mandant_id, tour_id, plombe_id, plombe_pos_id, nb_id, wup_id, plombe_vorgang_id, dat_erfasst, zeit_erfasst, storno_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tour_id AS INT64) AS tour_id, CAST(plombe_id AS NUMERIC) AS plombe_id, CAST(plombe_pos_id AS INT64) AS plombe_pos_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, plombe_vorgang_id, dat_erfasst, CAST(zeit_erfasst AS INT64) AS zeit_erfasst, CAST(storno_fg AS INT64) AS storno_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tour_plombe_start`;

-- Table: DBP_DATA.WBS_AKTION_ART_WUP_MENGE
insert into `dbp_data.wbs_aktion_art_wup_menge` (mandant_id, wup_id, wup_id_vz, nb_id, nb_id_vz, art_id, dat_ab, dat_bis, bonuskauf_promotionstyp, dat_lief_split, bestellmenge_final_ame, menge_initial_ame, menge_wbs, init_lief_modus_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(nb_id AS INT64) AS nb_id, CAST(nb_id_vz AS INT64) AS nb_id_vz, CAST(art_id AS INT64) AS art_id, dat_ab, dat_bis, bonuskauf_promotionstyp, dat_lief_split, CAST(bestellmenge_final_ame AS NUMERIC) AS bestellmenge_final_ame, CAST(menge_initial_ame AS NUMERIC) AS menge_initial_ame, CAST(menge_wbs AS NUMERIC) AS menge_wbs, init_lief_modus_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_aktion_art_wup_menge`;

-- Table: DBP_DATA.REGIO_ART_GP_WUP_ZU
insert into `dbp_data.regio_art_gp_wup_zu` (mandant_id, regio_stufe_id, gp_id, art_id, wup_id, nb_id, regio_polygon_id, versendet_fg, loesch_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regio_stufe_id AS INT64) AS regio_stufe_id, CAST(gp_id AS INT64) AS gp_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(regio_polygon_id AS INT64) AS regio_polygon_id, CAST(versendet_fg AS INT64) AS versendet_fg, CAST(loesch_fg AS INT64) AS loesch_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regio_art_gp_wup_zu`;

-- Table: DBP_DATA.KOSTENRECHNUNG
insert into `dbp_data.kostenrechnung` (krk_id, kostenart_id, pc_id, plan_fg, planvariante_id, buchungsperiode_id, gj, buchungskreis_id_ker, system_id, wrg_id, mandant_id, kostenrechnung_betrag, kj_ker_mo_id, td_insert, td_update)
SELECT krk_id, kostenart_id, pc_id, CAST(plan_fg AS INT64) AS plan_fg, planvariante_id, CAST(buchungsperiode_id AS INT64) AS buchungsperiode_id, CAST(gj AS INT64) AS gj, buchungskreis_id_ker, CAST(system_id AS INT64) AS system_id, wrg_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(kostenrechnung_betrag AS NUMERIC) AS kostenrechnung_betrag, CAST(kj_ker_mo_id AS INT64) AS kj_ker_mo_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_kostenrechnung`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_STATUS
insert into `dbp_data.transportation_unit_status` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, status_id, statuswert, datzeit_buchung, statusgrund, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, status_id, statuswert, CAST(datzeit_buchung AS DATETIME) AS datzeit_buchung, statusgrund, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_status`;

-- Table: DBP_ODS.ODS_BON_KASSEN_INFORMATIONEN
insert into `dbp_ods.ods_bon_kassen_informationen` (bon_id, wup_id, mandant_id, bon_dat, kasse_name, kassen_untertyp, bargeld_abwicklung, umsatz_brutto, bonanzahl, waage_aktiv_fg, td_update, td_insert)
SELECT bon_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, bon_dat, kasse_name, kassen_untertyp, bargeld_abwicklung, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(waage_aktiv_fg AS INT64) AS waage_aktiv_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_kassen_informationen`;

-- Table: DBP_DATA.BEST_BELEGFLUSS_BNK
insert into `dbp_data.best_belegfluss_bnk` (mandant_id, best_beleg_id, best_beleg_pos_id, folge_beleg_id, folge_beleg_pos_id, kj, kond_stufe_id, kond_zaehl_id, vorgart_best_entw_id, best_entw_typ_id, betrag_kondition, soll_haben_kz, ref_lagerbew_beleg_id, gp_id, dat_erfasst, konditionsart_id, wrg_id, dat_buch, system_id, betrag_wrbtr, zeit_erfasst, soll_haben_kko, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(best_beleg_id AS INT64) AS best_beleg_id, CAST(best_beleg_pos_id AS INT64) AS best_beleg_pos_id, CAST(folge_beleg_id AS INT64) AS folge_beleg_id, CAST(folge_beleg_pos_id AS INT64) AS folge_beleg_pos_id, CAST(kj AS INT64) AS kj, CAST(kond_stufe_id AS INT64) AS kond_stufe_id, CAST(kond_zaehl_id AS INT64) AS kond_zaehl_id, vorgart_best_entw_id, best_entw_typ_id, CAST(betrag_kondition AS NUMERIC) AS betrag_kondition, soll_haben_kz, ref_lagerbew_beleg_id, CAST(gp_id AS INT64) AS gp_id, dat_erfasst, konditionsart_id, wrg_id, dat_buch, CAST(system_id AS INT64) AS system_id, CAST(betrag_wrbtr AS NUMERIC) AS betrag_wrbtr, CAST(zeit_erfasst AS INT64) AS zeit_erfasst, soll_haben_kko, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_best_belegfluss_bnk`;

-- Table: DBP_DATA.T_FACT_IOT_BUILDING_PER_HOUR
insert into `dbp_data.t_fact_iot_building_per_hour` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, outdoortemp_condenser_supplyair_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(outdoortemp_condenser_supplyair_meas AS NUMERIC) AS outdoortemp_condenser_supplyair_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_building_per_hour`;

-- Table: DBP_DATA.PALETTEN_KONTROLLE
insert into `dbp_data.paletten_kontrolle` (mandant_id, nb_id, wup_id, art_id, handling_unit_id, fehler_lfd_nr, system_id, waqfk_fehler_id, waqfk_kennziffer_id, zlv_merkmal, lagernummer_id, menge_waqfk_kolli_soll, menge_waqfk_kolli_ist, dat_quittierung, dat_kontrolle, sap_user_benutzer, kunde_id, sap_user_kontrolle, mandant_id_kunde, dat_lief_soll, betrag_vk_netto_soll, betrag_vk_netto_ist, wrg_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(art_id AS INT64) AS art_id, CAST(handling_unit_id AS INT64) AS handling_unit_id, CAST(fehler_lfd_nr AS INT64) AS fehler_lfd_nr, CAST(system_id AS INT64) AS system_id, CAST(waqfk_fehler_id AS INT64) AS waqfk_fehler_id, CAST(waqfk_kennziffer_id AS INT64) AS waqfk_kennziffer_id, zlv_merkmal, lagernummer_id, CAST(menge_waqfk_kolli_soll AS NUMERIC) AS menge_waqfk_kolli_soll, CAST(menge_waqfk_kolli_ist AS NUMERIC) AS menge_waqfk_kolli_ist, dat_quittierung, dat_kontrolle, sap_user_benutzer, kunde_id, sap_user_kontrolle, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, dat_lief_soll, CAST(betrag_vk_netto_soll AS NUMERIC) AS betrag_vk_netto_soll, CAST(betrag_vk_netto_ist AS NUMERIC) AS betrag_vk_netto_ist, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_paletten_kontrolle`;

-- Table: DBP_PROCESS.ARTBEW_WG_SUM_TP2
insert into `dbp_process.artbew_wg_sum_tp2` (mandant_id, wup_id, nb_id, wg_id, wg_art_fg, dat, posten_id, menge, umsatz_netto, ek_brutto, ek_netto, ek_nettonetto, ek_kal_basis, ek_mep, einstandspreis, logistikkostenzuschlag, ek_netto_bnk, ek_netto_bnk_sachk, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_id AS INT64) AS wg_id, CAST(wg_art_fg AS INT64) AS wg_art_fg, dat, posten_id, CAST(menge AS NUMERIC) AS menge, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(ek_brutto AS NUMERIC) AS ek_brutto, CAST(ek_netto AS NUMERIC) AS ek_netto, CAST(ek_nettonetto AS NUMERIC) AS ek_nettonetto, CAST(ek_kal_basis AS NUMERIC) AS ek_kal_basis, CAST(ek_mep AS NUMERIC) AS ek_mep, CAST(einstandspreis AS NUMERIC) AS einstandspreis, CAST(logistikkostenzuschlag AS NUMERIC) AS logistikkostenzuschlag, CAST(ek_netto_bnk AS NUMERIC) AS ek_netto_bnk, CAST(ek_netto_bnk_sachk AS NUMERIC) AS ek_netto_bnk_sachk, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_process_artbew_wg_sum_tp2`;

-- Table: DBP_DATA.WUP_LAGEREINHEIT_PER
insert into `dbp_data.wup_lagereinheit_per` (mandant_id, lagereinheit_id, datzeit_von, datzeit_bis, wup_id, nb_id, lagernummer_id, lagertyp_id, dat_letzte_bewegung, spurnummer, lager_einheiten_typ, system_id, lagerplatz_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lagereinheit_id AS INT64) AS lagereinheit_id, datzeit_von, datzeit_bis, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, lagertyp_id, dat_letzte_bewegung, CAST(spurnummer AS INT64) AS spurnummer, lager_einheiten_typ, CAST(system_id AS INT64) AS system_id, lagerplatz_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_lagereinheit_per`;

-- Table: DBP_DATA.SSM_WUP_TAG_TREIBER
insert into `dbp_data.ssm_wup_tag_treiber` (mandant_id, wup_id, nb_id, dat, treiber_id, wrg_id, wert_tag, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(treiber_id AS INT64) AS treiber_id, wrg_id, CAST(wert_tag AS NUMERIC) AS wert_tag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_tag_treiber`;

-- Table: DBP_DATA.WARENVERFUEGBARKEIT_WUP_ART_STUNDE
insert into `dbp_data.warenverfuegbarkeit_wup_art_stunde` (mandant_id, wup_id, nb_id, art_id, dat_auswertung, zeit_stunde, bewart_id, anz_bon_artikel, menge_verkauft, anz_bon_gesamt, ausverkauft_fg, eckartikel_fg, topseller_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_auswertung, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(bewart_id AS INT64) AS bewart_id, CAST(anz_bon_artikel AS INT64) AS anz_bon_artikel, CAST(menge_verkauft AS NUMERIC) AS menge_verkauft, CAST(anz_bon_gesamt AS INT64) AS anz_bon_gesamt, CAST(ausverkauft_fg AS INT64) AS ausverkauft_fg, CAST(eckartikel_fg AS INT64) AS eckartikel_fg, CAST(topseller_fg AS INT64) AS topseller_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_warenverfuegbarkeit_wup_art_stunde`;

-- Table: DBP_DATA.MDL_FEEDBACK
insert into `dbp_data.mdl_feedback` (feedback_id, frage_id, antwort_id, dat_feedback, dat_einkauf, zeitspanne_einkauf_id, mandant_id, gf_id, wup_id, nb_id, de_wup_load_fg, td_update, td_insert)
SELECT feedback_id, CAST(frage_id AS INT64) AS frage_id, CAST(antwort_id AS INT64) AS antwort_id, dat_feedback, dat_einkauf, CAST(zeitspanne_einkauf_id AS INT64) AS zeitspanne_einkauf_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(gf_id AS INT64) AS gf_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(de_wup_load_fg AS INT64) AS de_wup_load_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mdl_feedback`;

-- Table: DBP_DATA.UMBEWERTUNG_DET
insert into `dbp_data.umbewertung_det` (mandant_id, pae_beleg_id, kj, pae_beleg_pos_id, art_id, bewertungskreis_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(pae_beleg_id AS INT64) AS pae_beleg_id, CAST(kj AS INT64) AS kj, CAST(pae_beleg_pos_id AS INT64) AS pae_beleg_pos_id, CAST(art_id AS INT64) AS art_id, bewertungskreis_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_umbewertung_det`;

-- Table: DBP_ODS_ARCHIV.ODS_COUPON
insert into `dbp_ods_archiv.ods_coupon` (bon_id, bon_zeile, coupon_id, coupon_zeile, coupon_menge, coupon_betrag, coupon_kz, mandant_id, wup_id, bon_dat, td_insert, td_update)
SELECT bon_id, CAST(bon_zeile AS INT64) AS bon_zeile, CAST(coupon_id AS INT64) AS coupon_id, CAST(coupon_zeile AS INT64) AS coupon_zeile, CAST(coupon_menge AS NUMERIC) AS coupon_menge, CAST(coupon_betrag AS NUMERIC) AS coupon_betrag, CAST(coupon_kz AS INT64) AS coupon_kz, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, bon_dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_coupon`;

-- Table: DBP_DATA.SSM_WUP_TAG_STUNDE_TREIBER
insert into `dbp_data.ssm_wup_tag_stunde_treiber` (mandant_id, wup_id, nb_id, dat, zeit_stunde, treiber_id, wrg_id, wert_tag, wert_stunde, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(treiber_id AS INT64) AS treiber_id, wrg_id, CAST(wert_tag AS NUMERIC) AS wert_tag, CAST(wert_stunde AS NUMERIC) AS wert_stunde, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_tag_stunde_treiber`;

-- Table: DBP_DATA.UMBEWERTUNG_PERIODE
insert into `dbp_data.umbewertung_periode` (mandant_id, pae_beleg_id, kj, pae_beleg_pos_id, gjmo, periodenart_id, dat_buch, menge_bestand_bme_alt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(pae_beleg_id AS INT64) AS pae_beleg_id, CAST(kj AS INT64) AS kj, CAST(pae_beleg_pos_id AS INT64) AS pae_beleg_pos_id, CAST(gjmo AS INT64) AS gjmo, periodenart_id, dat_buch, CAST(menge_bestand_bme_alt AS NUMERIC) AS menge_bestand_bme_alt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_umbewertung_periode`;

-- Table: DBP_DATA.RUECKFUEHRUNG_LT
insert into `dbp_data.rueckfuehrung_lt` (mandant_id, tour_id, wup_id, nb_id, art_id, lagerbew_beleg_id, kj, lfnr, mandant_id_lager, wup_id_lager, nb_id_lager, dat_buch, menge_bme, td_update, td_insert, anz_stp, wertstoffturm_nr)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tour_id AS INT64) AS tour_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(kj AS INT64) AS kj, CAST(lfnr AS INT64) AS lfnr, CAST(mandant_id_lager AS INT64) AS mandant_id_lager, CAST(wup_id_lager AS INT64) AS wup_id_lager, CAST(nb_id_lager AS INT64) AS nb_id_lager, dat_buch, CAST(menge_bme AS NUMERIC) AS menge_bme, td_update, td_insert, CAST(anz_stp AS NUMERIC) AS anz_stp, CAST(wertstoffturm_nr AS INT64) AS wertstoffturm_nr
FROM `snowflake_snapshots.kfl_dbp_data_rueckfuehrung_lt`;

-- Table: DBP_DATA.VERRECHFALL
insert into `dbp_data.verrechfall` (mandant_id, verrechfall_id, belos_adresse_empfaenger_id, belos_vorgang_id, verrechfallart_id, wrg_id, storno_fg, betrag_pauschalfracht, betrag_fracht, verrechfall_status_id, belos_leistungsart_id, kunde_fg, fracht_satz_prz, fracht_satz_prz_pro_einh, teilstrecke_nr, belosart_fg, belos_adresse_rechnung_uid, belos_adresse_rechnung_id, belos_adresse_rechnung_name, belos_adresse_steuerung_uid, belos_adresse_steuerung_id, belos_adresse_steuerung_name, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verrechfall_id AS INT64) AS verrechfall_id, belos_adresse_empfaenger_id, CAST(belos_vorgang_id AS INT64) AS belos_vorgang_id, verrechfallart_id, wrg_id, CAST(storno_fg AS INT64) AS storno_fg, CAST(betrag_pauschalfracht AS NUMERIC) AS betrag_pauschalfracht, CAST(betrag_fracht AS NUMERIC) AS betrag_fracht, verrechfall_status_id, CAST(belos_leistungsart_id AS INT64) AS belos_leistungsart_id, CAST(kunde_fg AS INT64) AS kunde_fg, CAST(fracht_satz_prz AS NUMERIC) AS fracht_satz_prz, CAST(fracht_satz_prz_pro_einh AS NUMERIC) AS fracht_satz_prz_pro_einh, CAST(teilstrecke_nr AS INT64) AS teilstrecke_nr, CAST(belosart_fg AS INT64) AS belosart_fg, CAST(belos_adresse_rechnung_uid AS INT64) AS belos_adresse_rechnung_uid, belos_adresse_rechnung_id, belos_adresse_rechnung_name, CAST(belos_adresse_steuerung_uid AS INT64) AS belos_adresse_steuerung_uid, belos_adresse_steuerung_id, belos_adresse_steuerung_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_verrechfall`;

-- Table: DBP_DATA.WUP_DAT_HWG_SUM
insert into `dbp_data.wup_dat_hwg_sum` (mandant_id, wup_id, nb_id, dat, hwg_id, arthiertyp_id, bonanzahl, bonanzahl_pre_pack, bonanzahl_sug, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(hwg_id AS INT64) AS hwg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(bonanzahl_pre_pack AS INT64) AS bonanzahl_pre_pack, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_dat_hwg_sum`;

-- Table: DBP_DATA.WABI
insert into `dbp_data.wabi` (mandant_id, aktion_id, aktion_thema_id, wup_id, nb_id, art_id, faktor_abbildung, faktor_aktion_haeufigkeit, aktion_thema_id_basis, faktor_wochenbedarf, dat_von_folgewerbung, menge_kolli_fix, anz_wup, anz_wup_folgewerbung, faktor_gesamt, faktor_kalender, faktor_kannibal, kjwo_basis, menge_platz_min, faktor_menge, menge_berechnet, faktor_preis, wup_id_ref, nb_id_ref, art_id_ref, faktor_art_ref, faktor_wup_ref, faktor_saison, faktor_sonst, wg_betreuer_text, basisaktion_text, manager_text, info_text, einflussfaktor_text, ursprung_basismenge, siebz_dreiss_art_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, aktion_thema_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(faktor_abbildung AS INT64) AS faktor_abbildung, CAST(faktor_aktion_haeufigkeit AS INT64) AS faktor_aktion_haeufigkeit, aktion_thema_id_basis, CAST(faktor_wochenbedarf AS INT64) AS faktor_wochenbedarf, dat_von_folgewerbung, CAST(menge_kolli_fix AS NUMERIC) AS menge_kolli_fix, CAST(anz_wup AS INT64) AS anz_wup, CAST(anz_wup_folgewerbung AS INT64) AS anz_wup_folgewerbung, CAST(faktor_gesamt AS INT64) AS faktor_gesamt, CAST(faktor_kalender AS INT64) AS faktor_kalender, CAST(faktor_kannibal AS INT64) AS faktor_kannibal, CAST(kjwo_basis AS INT64) AS kjwo_basis, CAST(menge_platz_min AS NUMERIC) AS menge_platz_min, CAST(faktor_menge AS INT64) AS faktor_menge, CAST(menge_berechnet AS NUMERIC) AS menge_berechnet, CAST(faktor_preis AS INT64) AS faktor_preis, CAST(wup_id_ref AS INT64) AS wup_id_ref, CAST(nb_id_ref AS INT64) AS nb_id_ref, CAST(art_id_ref AS INT64) AS art_id_ref, CAST(faktor_art_ref AS INT64) AS faktor_art_ref, CAST(faktor_wup_ref AS INT64) AS faktor_wup_ref, CAST(faktor_saison AS INT64) AS faktor_saison, CAST(faktor_sonst AS INT64) AS faktor_sonst, wg_betreuer_text, basisaktion_text, manager_text, info_text, einflussfaktor_text, ursprung_basismenge, CAST(siebz_dreiss_art_fg AS INT64) AS siebz_dreiss_art_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wabi`;

-- Table: DBP_DATA.TS_WBS_ART_AKTION_MARKT
insert into `dbp_data.ts_wbs_art_aktion_markt` (mandant_id, wup_id, nb_id, art_id, aktion_id, angebot_nr, dat_von, dat_bis, gk_fg, menge_mindestplatzierung_bme, top_gk_fg, fixmenge_wfl_bme, adjustment_id, max_kapa_fg, dat_letzte_nachversorgung, max_kapa_endbestand_proz, rest_von_normalbestand_proz, kjwo, nachversorgung_schwellwert_pal_abrundung_proz, nachversorgung_schwellwert_pal_aufrundung_proz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, aktion_id, angebot_nr, dat_von, dat_bis, CAST(gk_fg AS INT64) AS gk_fg, CAST(menge_mindestplatzierung_bme AS NUMERIC) AS menge_mindestplatzierung_bme, CAST(top_gk_fg AS INT64) AS top_gk_fg, CAST(fixmenge_wfl_bme AS NUMERIC) AS fixmenge_wfl_bme, adjustment_id, max_kapa_fg, dat_letzte_nachversorgung, max_kapa_endbestand_proz, rest_von_normalbestand_proz, kjwo, nachversorgung_schwellwert_pal_abrundung_proz, nachversorgung_schwellwert_pal_aufrundung_proz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_wbs_art_aktion_markt`;

-- Table: DBP_DATA.WUP_SOLLSTUNDENMODELL_TAG
insert into `dbp_data.wup_sollstundenmodell_tag` (mandant_id, wup_id, nb_id, dat, zeit_stunde, treiber_id, wrg_id, wert_tag, wert_stunde, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(treiber_id AS INT64) AS treiber_id, wrg_id, CAST(wert_tag AS NUMERIC) AS wert_tag, CAST(wert_stunde AS NUMERIC) AS wert_stunde, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_sollstundenmodell_tag`;

-- Table: DBP_DATA.TMS_AUFTRAG_STATISTIK
insert into `dbp_data.tms_auftrag_statistik` (mandant_id, system_id, tms_auftrag_id, tms_auftrag_pos_id, auftrag_statistik_lfd_nr, lief_beleg_id, kj_lief_beleg, lieferkunde_tms_gp_id, lieferkunde_tms_gp_typ_cd, tms_tour_id, dat_tour, betrag_kostenanteil, tms_rech_beleg_id, dat_rechnung, dat_leistung, abrechnungslauf_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_auftrag_id, CAST(tms_auftrag_pos_id AS INT64) AS tms_auftrag_pos_id, CAST(auftrag_statistik_lfd_nr AS INT64) AS auftrag_statistik_lfd_nr, CAST(lief_beleg_id AS NUMERIC) AS lief_beleg_id, CAST(kj_lief_beleg AS INT64) AS kj_lief_beleg, lieferkunde_tms_gp_id, lieferkunde_tms_gp_typ_cd, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(betrag_kostenanteil AS BIGNUMERIC) AS betrag_kostenanteil, CAST(tms_rech_beleg_id AS INT64) AS tms_rech_beleg_id, dat_rechnung, dat_leistung, CAST(abrechnungslauf_id AS INT64) AS abrechnungslauf_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_auftrag_statistik`;

-- Table: DBP_DATA.STANDZEITEN_WE
insert into `dbp_data.standzeiten_we` (lagerplatz_id_ta1, lagernummer_id_ta1, mandant_id, lagertyp_id_ta1, wup_id, nb_id, art_id, lagerplatz_id_ta2, lagernummer_id_ta2, lagertyp_id_ta2, lagerort_id, dat_erstellung, datzeit_quittierung_we, datzeit_quittierung_einl, lager_einheit_id, dat_entnahme_quittierung_ta1, zeit_entnahme_quittierung_ta1, dat_entnahme_quittierung_ta2, zeit_entnahme_quittierung_ta2, datzeit_entn_quittierung_we, datzeit_entn_quittierung_einl, td_insert, td_update)
SELECT lagerplatz_id_ta1, lagernummer_id_ta1, CAST(mandant_id AS INT64) AS mandant_id, lagertyp_id_ta1, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, lagerplatz_id_ta2, lagernummer_id_ta2, lagertyp_id_ta2, lagerort_id, dat_erstellung, datzeit_quittierung_we, datzeit_quittierung_einl, lager_einheit_id, dat_entnahme_quittierung_ta1, CAST(zeit_entnahme_quittierung_ta1 AS INT64) AS zeit_entnahme_quittierung_ta1, dat_entnahme_quittierung_ta2, CAST(zeit_entnahme_quittierung_ta2 AS INT64) AS zeit_entnahme_quittierung_ta2, CAST(datzeit_entn_quittierung_we AS DATETIME) AS datzeit_entn_quittierung_we, CAST(datzeit_entn_quittierung_einl AS DATETIME) AS datzeit_entn_quittierung_einl, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_standzeiten_we`;

-- Table: DBP_MSI_DATA.VIS_MONAT_FWWS_WUP
insert into `dbp_msi_data.vis_monat_fwws_wup` (mandant_id, nb_id, wup_id, gp_id, kjmo, akt_gj, akt_mo, gj, mo_kj, anz_buchung_masch, anz_vorgang_ohne, anz_wa_nicht_gemeldet, anz_buchung_gs, anz_we_nicht_gemeldet, anz_buchung_rech, sum_buchung_masch, sum_vorgang_ohne, sum_wa_nicht_gemeldet, sum_buchung_gs, sum_we_nicht_gemeldet, sum_buchung_rech, anz_buchung_masch_kum, anz_vorgang_ohne_kum, anz_wa_nicht_gemeldet_kum, anz_buchung_gs_kum, anz_we_nicht_gemeldet_kum, anz_buchung_rech_kum, sum_buchung_masch_kum, sum_vorgang_ohne_kum, sum_wa_nicht_gemeldet_kum, sum_buchung_gs_kum, sum_we_nicht_gemeldet_kum, sum_buchung_rech_kum, anz_rech_pos, anz_rech_pos_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(gp_id AS INT64) AS gp_id, CAST(kjmo AS INT64) AS kjmo, CAST(akt_gj AS INT64) AS akt_gj, CAST(akt_mo AS INT64) AS akt_mo, CAST(gj AS INT64) AS gj, CAST(mo_kj AS INT64) AS mo_kj, CAST(anz_buchung_masch AS INT64) AS anz_buchung_masch, CAST(anz_vorgang_ohne AS INT64) AS anz_vorgang_ohne, CAST(anz_wa_nicht_gemeldet AS INT64) AS anz_wa_nicht_gemeldet, CAST(anz_buchung_gs AS INT64) AS anz_buchung_gs, CAST(anz_we_nicht_gemeldet AS INT64) AS anz_we_nicht_gemeldet, CAST(anz_buchung_rech AS INT64) AS anz_buchung_rech, CAST(sum_buchung_masch AS INT64) AS sum_buchung_masch, CAST(sum_vorgang_ohne AS INT64) AS sum_vorgang_ohne, CAST(sum_wa_nicht_gemeldet AS INT64) AS sum_wa_nicht_gemeldet, CAST(sum_buchung_gs AS INT64) AS sum_buchung_gs, CAST(sum_we_nicht_gemeldet AS INT64) AS sum_we_nicht_gemeldet, CAST(sum_buchung_rech AS INT64) AS sum_buchung_rech, CAST(anz_buchung_masch_kum AS INT64) AS anz_buchung_masch_kum, CAST(anz_vorgang_ohne_kum AS INT64) AS anz_vorgang_ohne_kum, CAST(anz_wa_nicht_gemeldet_kum AS INT64) AS anz_wa_nicht_gemeldet_kum, CAST(anz_buchung_gs_kum AS INT64) AS anz_buchung_gs_kum, CAST(anz_we_nicht_gemeldet_kum AS INT64) AS anz_we_nicht_gemeldet_kum, CAST(anz_buchung_rech_kum AS INT64) AS anz_buchung_rech_kum, CAST(sum_buchung_masch_kum AS INT64) AS sum_buchung_masch_kum, CAST(sum_vorgang_ohne_kum AS INT64) AS sum_vorgang_ohne_kum, CAST(sum_wa_nicht_gemeldet_kum AS INT64) AS sum_wa_nicht_gemeldet_kum, CAST(sum_buchung_gs_kum AS INT64) AS sum_buchung_gs_kum, CAST(sum_we_nicht_gemeldet_kum AS INT64) AS sum_we_nicht_gemeldet_kum, CAST(sum_buchung_rech_kum AS INT64) AS sum_buchung_rech_kum, CAST(anz_rech_pos AS INT64) AS anz_rech_pos, CAST(anz_rech_pos_kum AS INT64) AS anz_rech_pos_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_fwws_wup`;

-- Table: DBP_DATA.TMS_AUFTRAG_BESCHRAENKUNG_ZU
insert into `dbp_data.tms_auftrag_beschraenkung_zu` (mandant_id, system_id, tms_auftrag_id, tms_auftrag_pos_id, tms_beschraenkung_id, tms_beschraenkung_pos_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_auftrag_id, CAST(tms_auftrag_pos_id AS INT64) AS tms_auftrag_pos_id, CAST(tms_beschraenkung_id AS INT64) AS tms_beschraenkung_id, CAST(tms_beschraenkung_pos_nr AS INT64) AS tms_beschraenkung_pos_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_auftrag_beschraenkung_zu`;

-- Table: DBP_DATA.TOUR_DET_ZLV_VTTKL
insert into `dbp_data.tour_det_zlv_vttkl` (mandant_id, nb_id, wup_id, tour_id, kl_tour_pos_id, lagernummer_id, kunde_id, mandant_id_kunde, status_tour, rundlauf_markt_fg, zeit_plan_ankunft, menge_stp_geraeumt, cd_fg, wgvgrp_id, dat_tour, zeit_relevant_fg, oug_tour_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(tour_id AS INT64) AS tour_id, CAST(kl_tour_pos_id AS INT64) AS kl_tour_pos_id, lagernummer_id, kunde_id, CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, status_tour, CAST(rundlauf_markt_fg AS INT64) AS rundlauf_markt_fg, CAST(zeit_plan_ankunft AS INT64) AS zeit_plan_ankunft, CAST(menge_stp_geraeumt AS NUMERIC) AS menge_stp_geraeumt, CAST(cd_fg AS INT64) AS cd_fg, CAST(wgvgrp_id AS INT64) AS wgvgrp_id, dat_tour, CAST(zeit_relevant_fg AS INT64) AS zeit_relevant_fg, CAST(oug_tour_fg AS INT64) AS oug_tour_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tour_det_zlv_vttkl`;

-- Table: DBP_MSI_DATA.TUPEL_MAT_FORECAST
insert into `dbp_msi_data.tupel_mat_forecast` (id, mandant_id, a500_kjwo_update, matching_id, a51_listung_sst_pflege, a52_listung_k_sst_pflege, a426_ost_basis_pflege, a427_ost_gross_pflege, a428_sued_ost_pflege, a429_sued_west_pflege, a430_west_pflege, a431_nord_pflege, a411_stk_rohertrag_pflege, a412_umsatz_brutto_hochrechnung, a413_absatz_hochrechnung, a414_rohertrag_hochrechnung, a415_kannibalisierungsfaktor, a50_listungsaktion, listing_proposal_pflege, execution_timestamp, td_update, td_insert)
SELECT id, CAST(mandant_id AS INT64) AS mandant_id, CAST(a500_kjwo_update AS INT64) AS a500_kjwo_update, CAST(matching_id AS INT64) AS matching_id, CAST(a51_listung_sst_pflege AS INT64) AS a51_listung_sst_pflege, a52_listung_k_sst_pflege, a426_ost_basis_pflege, a427_ost_gross_pflege, a428_sued_ost_pflege, a429_sued_west_pflege, a430_west_pflege, a431_nord_pflege, CAST(a411_stk_rohertrag_pflege AS NUMERIC) AS a411_stk_rohertrag_pflege, CAST(a412_umsatz_brutto_hochrechnung AS NUMERIC) AS a412_umsatz_brutto_hochrechnung, CAST(a413_absatz_hochrechnung AS NUMERIC) AS a413_absatz_hochrechnung, CAST(a414_rohertrag_hochrechnung AS NUMERIC) AS a414_rohertrag_hochrechnung, CAST(a415_kannibalisierungsfaktor AS NUMERIC) AS a415_kannibalisierungsfaktor, a50_listungsaktion, listing_proposal_pflege, CAST(execution_timestamp AS DATETIME) AS execution_timestamp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_tupel_mat_forecast`;

-- Table: DBP_DATA.BESCH_RECH_DET_KONT
insert into `dbp_data.besch_rech_det_kont` (rech_beleg_id, rech_beleg_kont_pos_id, gj, system_id, mandant_id, kontierungsblock_nr, row_grund_id, dat_row, menge, basismenge_einh_id, sap_mwst_id, art_id, betrag_beleg, dat_bezug, buch_grund_int_id, buch_grund_ext_id, menge_gp_best, betrag_gp_best, gp_fehlerart_id, korrekturart_id, betrag_gp_fehler_netto, rech_kontoart_id, sperrgrund_betrag_fg, wup_id, nb_id, betrag_netto, retourenpos_fg, wg_id, arthiertyp_id, sachkonto_id, td_insert, td_update, wrg_id)
SELECT CAST(rech_beleg_id AS INT64) AS rech_beleg_id, CAST(rech_beleg_kont_pos_id AS INT64) AS rech_beleg_kont_pos_id, CAST(gj AS INT64) AS gj, CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(kontierungsblock_nr AS INT64) AS kontierungsblock_nr, row_grund_id, dat_row, CAST(menge AS NUMERIC) AS menge, basismenge_einh_id, sap_mwst_id, CAST(art_id AS INT64) AS art_id, CAST(betrag_beleg AS NUMERIC) AS betrag_beleg, dat_bezug, buch_grund_int_id, buch_grund_ext_id, CAST(menge_gp_best AS NUMERIC) AS menge_gp_best, CAST(betrag_gp_best AS NUMERIC) AS betrag_gp_best, gp_fehlerart_id, korrekturart_id, CAST(betrag_gp_fehler_netto AS NUMERIC) AS betrag_gp_fehler_netto, rech_kontoart_id, CAST(sperrgrund_betrag_fg AS INT64) AS sperrgrund_betrag_fg, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(betrag_netto AS NUMERIC) AS betrag_netto, CAST(retourenpos_fg AS INT64) AS retourenpos_fg, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, sachkonto_id, td_insert, td_update, wrg_id
FROM `snowflake_snapshots.kfl_dbp_data_besch_rech_det_kont`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_TOR_ZU
insert into `dbp_data.transportation_unit_tor_zu` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, lagernummer_id, tor_id, tor_sr_act_id, datzeit_start_ist, datzeit_ende_ist, gp_id, wup_id, nb_id, konsolidierungsgruppe_id, spur_kapazitaet, spur_voll_fg, spur_planung_quittiert_fg, spurgruppe_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, lagernummer_id, tor_id, CAST(tor_sr_act_id AS INT64) AS tor_sr_act_id, CAST(datzeit_start_ist AS DATETIME) AS datzeit_start_ist, CAST(datzeit_ende_ist AS DATETIME) AS datzeit_ende_ist, CAST(gp_id AS INT64) AS gp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, konsolidierungsgruppe_id, CAST(spur_kapazitaet AS NUMERIC) AS spur_kapazitaet, CAST(spur_voll_fg AS INT64) AS spur_voll_fg, CAST(spur_planung_quittiert_fg AS INT64) AS spur_planung_quittiert_fg, CAST(spurgruppe_id AS INT64) AS spurgruppe_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_tor_zu`;

-- Table: DBP_DATA.MA_LOHNART_ZU_PER
insert into `dbp_data.ma_lohnart_zu_per` (mandant_id, mitarbeiter_id, lohnart_id, kjmo, dat_von, dat_bis, stunden_lohnart, system_id, kostenstelle_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_id, lohnart_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, CAST(stunden_lohnart AS NUMERIC) AS stunden_lohnart, CAST(system_id AS INT64) AS system_id, kostenstelle_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_lohnart_zu_per`;

-- Table: DBP_MSI_DATA.VIS_TAG_UMSATZ_ABT
insert into `dbp_msi_data.vis_tag_umsatz_abt` (mandant_id, dat, nb_id, wup_id, arthiertyp_id, wrg_id, abt_id, kjmo, kjwo, ums_netto, ums_netto_wvj, ums_netto_wvvj, ums_netto_kvj, ums_netto_kvvj, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, wrg_id, CAST(abt_id AS INT64) AS abt_id, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(ums_netto AS NUMERIC) AS ums_netto, CAST(ums_netto_wvj AS NUMERIC) AS ums_netto_wvj, CAST(ums_netto_wvvj AS NUMERIC) AS ums_netto_wvvj, CAST(ums_netto_kvj AS NUMERIC) AS ums_netto_kvj, CAST(ums_netto_kvvj AS NUMERIC) AS ums_netto_kvvj, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_umsatz_abt`;

-- Table: DBP_DATA.RETAIL_STORE_CUSTOMER_REVIEW
insert into `dbp_data.retail_store_customer_review` (ext_system_name, ext_customer_review_id, ext_retail_company_id, wup_id, nb_id, mandant_id, ext_store_id, review_tmsp, review_rating, review_native_txt, review_english_txt, review_status_cd, td_update, td_insert)
SELECT ext_system_name, ext_customer_review_id, CAST(ext_retail_company_id AS INT64) AS ext_retail_company_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(ext_store_id AS INT64) AS ext_store_id, review_tmsp, CAST(review_rating AS NUMERIC) AS review_rating, review_native_txt, review_english_txt, review_status_cd, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_retail_store_customer_review`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_LAGERTOR_ZU
insert into `dbp_data.transportation_unit_lagertor_zu` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, ladegruppe_versandstelle_id, lagertor_id, datzeit_erstelliung, tor_distanz_gewichtung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, ladegruppe_versandstelle_id, lagertor_id, CAST(datzeit_erstelliung AS DATETIME) AS datzeit_erstelliung, CAST(tor_distanz_gewichtung AS NUMERIC) AS tor_distanz_gewichtung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_lagertor_zu`;

-- Table: DBP_DATA.MITARBEITERBEW
insert into `dbp_data.mitarbeiterbew` (mitarbeiter_id, kjmo, mandant_id, abwesenheit_tage, soll_stunden_monat, abr_stunden_monat, langzeit_abwesend_fg, neu_mitarbeiter_fg, krank_tage, teilzeit_fg, hr_objekt_id, ma_status_id, geschlecht_id, tarifgebiet_id, shr_ma_funktion_id, tarifart_id, unternehmens_bereich_id, gehalts_region_id, haus_kategorie_id, haupt_mitarbeiter_id, soll_kalender_tage, resturlaub_vj, resturlaub_akt_kj, anspruch_urlaub_akt_kj, langzeit_krank_fg, mutterschutz_fg, beschaeftigungs_verbot_fg, aushilfe_fg, elternzeit_fg, grundwehrdienst_fg, atz_kz, freigestellt_fg, impatriates_fg, externe_fg, azubi_fg, ma_eintritt_kz, ma_austritt_kz, fluktuation_kz, ki_fg, genommen_urlaub, inventur_aushilfe_fg, tip_austraeger_fg, tip_kontrolleur_fg, tip_gebietsbetreuer_fg, diplomand_praktikant_fg, praktikant_o_entgeld_fg, expatriates_fg, hinterbliebene_fg, versorgungsbezieher_fg, soll_arbeitstage, sb_prozent, arbeitszeit_anteil, abwesenheit_arbeitstage_bez, abwesenheit_arbeitstage_unbez, arb_stunden_tag, krank_tage_arbeitstage, anz_arbeits_unfall, vertragsende_fg, untermonatlich_fg, aushilfe_nicht_gearbeitet_fg, abwesenheit_stunden, sonstige_abwesenheit_fg, pflege_fg, krankheit_unfall_fg, langzeit_abwesenheit_tage, langzeit_abwesenheit_tage_kum, langzeit_min_dat, langzeit_abwesenheit_grund, stichtag_fg, dat_letzte_abwesenheit, mitarbeiter_alter, td_update, td_insert)
SELECT mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, CAST(mandant_id AS INT64) AS mandant_id, CAST(abwesenheit_tage AS NUMERIC) AS abwesenheit_tage, CAST(soll_stunden_monat AS NUMERIC) AS soll_stunden_monat, CAST(abr_stunden_monat AS NUMERIC) AS abr_stunden_monat, CAST(langzeit_abwesend_fg AS INT64) AS langzeit_abwesend_fg, CAST(neu_mitarbeiter_fg AS INT64) AS neu_mitarbeiter_fg, CAST(krank_tage AS NUMERIC) AS krank_tage, CAST(teilzeit_fg AS INT64) AS teilzeit_fg, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, ma_status_id, CAST(geschlecht_id AS INT64) AS geschlecht_id, tarifgebiet_id, shr_ma_funktion_id, tarifart_id, unternehmens_bereich_id, gehalts_region_id, haus_kategorie_id, haupt_mitarbeiter_id, CAST(soll_kalender_tage AS NUMERIC) AS soll_kalender_tage, CAST(resturlaub_vj AS NUMERIC) AS resturlaub_vj, CAST(resturlaub_akt_kj AS NUMERIC) AS resturlaub_akt_kj, CAST(anspruch_urlaub_akt_kj AS NUMERIC) AS anspruch_urlaub_akt_kj, CAST(langzeit_krank_fg AS INT64) AS langzeit_krank_fg, CAST(mutterschutz_fg AS INT64) AS mutterschutz_fg, CAST(beschaeftigungs_verbot_fg AS INT64) AS beschaeftigungs_verbot_fg, CAST(aushilfe_fg AS INT64) AS aushilfe_fg, CAST(elternzeit_fg AS INT64) AS elternzeit_fg, CAST(grundwehrdienst_fg AS INT64) AS grundwehrdienst_fg, CAST(atz_kz AS INT64) AS atz_kz, CAST(freigestellt_fg AS INT64) AS freigestellt_fg, CAST(impatriates_fg AS INT64) AS impatriates_fg, CAST(externe_fg AS INT64) AS externe_fg, CAST(azubi_fg AS INT64) AS azubi_fg, CAST(ma_eintritt_kz AS INT64) AS ma_eintritt_kz, CAST(ma_austritt_kz AS INT64) AS ma_austritt_kz, CAST(fluktuation_kz AS INT64) AS fluktuation_kz, CAST(ki_fg AS INT64) AS ki_fg, CAST(genommen_urlaub AS NUMERIC) AS genommen_urlaub, CAST(inventur_aushilfe_fg AS INT64) AS inventur_aushilfe_fg, CAST(tip_austraeger_fg AS INT64) AS tip_austraeger_fg, CAST(tip_kontrolleur_fg AS INT64) AS tip_kontrolleur_fg, CAST(tip_gebietsbetreuer_fg AS INT64) AS tip_gebietsbetreuer_fg, CAST(diplomand_praktikant_fg AS INT64) AS diplomand_praktikant_fg, CAST(praktikant_o_entgeld_fg AS INT64) AS praktikant_o_entgeld_fg, CAST(expatriates_fg AS INT64) AS expatriates_fg, CAST(hinterbliebene_fg AS INT64) AS hinterbliebene_fg, CAST(versorgungsbezieher_fg AS INT64) AS versorgungsbezieher_fg, CAST(soll_arbeitstage AS NUMERIC) AS soll_arbeitstage, CAST(sb_prozent AS INT64) AS sb_prozent, CAST(arbeitszeit_anteil AS NUMERIC) AS arbeitszeit_anteil, CAST(abwesenheit_arbeitstage_bez AS NUMERIC) AS abwesenheit_arbeitstage_bez, CAST(abwesenheit_arbeitstage_unbez AS NUMERIC) AS abwesenheit_arbeitstage_unbez, CAST(arb_stunden_tag AS NUMERIC) AS arb_stunden_tag, CAST(krank_tage_arbeitstage AS NUMERIC) AS krank_tage_arbeitstage, CAST(anz_arbeits_unfall AS INT64) AS anz_arbeits_unfall, CAST(vertragsende_fg AS INT64) AS vertragsende_fg, CAST(untermonatlich_fg AS INT64) AS untermonatlich_fg, CAST(aushilfe_nicht_gearbeitet_fg AS INT64) AS aushilfe_nicht_gearbeitet_fg, CAST(abwesenheit_stunden AS NUMERIC) AS abwesenheit_stunden, CAST(sonstige_abwesenheit_fg AS INT64) AS sonstige_abwesenheit_fg, CAST(pflege_fg AS INT64) AS pflege_fg, CAST(krankheit_unfall_fg AS INT64) AS krankheit_unfall_fg, CAST(langzeit_abwesenheit_tage AS NUMERIC) AS langzeit_abwesenheit_tage, CAST(langzeit_abwesenheit_tage_kum AS NUMERIC) AS langzeit_abwesenheit_tage_kum, langzeit_min_dat, langzeit_abwesenheit_grund, CAST(stichtag_fg AS INT64) AS stichtag_fg, dat_letzte_abwesenheit, CAST(mitarbeiter_alter AS INT64) AS mitarbeiter_alter, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mitarbeiterbew`;

-- Table: DBP_MSI_DATA.VIS_TAG_FWWS_WUP
insert into `dbp_msi_data.vis_tag_fwws_wup` (mandant_id, dat, wup_id, nb_id, zaehl_grund_id, akt_gj, akt_mo, akt_wo, akt_tag, gj, kjmo, kjwo, mo_kj, wtag_id, anz_artikel_bestand, anz_gezaehlt, anz_zaehlauftrag, sum_artikel_bestand, sum_gezaehlt, sum_zaehlauftrag, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, zaehl_grund_id, CAST(akt_gj AS INT64) AS akt_gj, CAST(akt_mo AS INT64) AS akt_mo, CAST(akt_wo AS INT64) AS akt_wo, CAST(akt_tag AS INT64) AS akt_tag, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(mo_kj AS INT64) AS mo_kj, CAST(wtag_id AS INT64) AS wtag_id, CAST(anz_artikel_bestand AS INT64) AS anz_artikel_bestand, CAST(anz_gezaehlt AS INT64) AS anz_gezaehlt, CAST(anz_zaehlauftrag AS INT64) AS anz_zaehlauftrag, CAST(sum_artikel_bestand AS INT64) AS sum_artikel_bestand, CAST(sum_gezaehlt AS INT64) AS sum_gezaehlt, CAST(sum_zaehlauftrag AS INT64) AS sum_zaehlauftrag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_fwws_wup`;

-- Table: DBP_DATA.NETTOSTUNDEN_BEREICH
insert into `dbp_data.nettostunden_bereich` (mandant_id, wup_id, nb_id, dat, hr_objekt_bereich_id, stunden, quelle_id, stunden_typ_fg, dat_zeit_aenderung, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(hr_objekt_bereich_id AS INT64) AS hr_objekt_bereich_id, CAST(stunden AS NUMERIC) AS stunden, CAST(quelle_id AS INT64) AS quelle_id, CAST(stunden_typ_fg AS INT64) AS stunden_typ_fg, dat_zeit_aenderung, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_nettostunden_bereich`;

-- Table: DBP_DATA.NFMD_ARTICLE_STORE_SCORECARD
insert into `dbp_data.nfmd_article_store_scorecard` (mandant_id, aktion_id, art_id, wup_id, discount_type_name, wrg_id, wg_id, kjwo_ww, promo_start_dt, selling_price_gross_local_val, promo_stores_cnt, parameter_config, promo_week_sell_rate, model_price_gross_local_val, sales_promo_week_cnt, model_discount_opt_rate, sales_total_cnt, stock_initial_cnt, current_discount_rate, current_week_nr, current_sell_rate, remaining_weeks_cnt, remaining_stock_cnt, total_revenue_gross_local_val, revenue_last_week_gross_local_val, model_execution_tmsp, ai_model_id, curve_type_cd, rule_created_dt, is_in_experiment_fg, experiment_group_cd, experiment_stores_cnt, display_art_id, rule_decision_record, sell_ratio_wk12, sell_ratio_wk123, orig_promo_start_dt, orig_promo_end_dt, orig_promo_cycle_type_name, second_discount_start_dt, second_discount_end_dt, discount_base_gross_local_val, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, discount_type_name, wrg_id, CAST(wg_id AS INT64) AS wg_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, promo_start_dt, CAST(selling_price_gross_local_val AS NUMERIC) AS selling_price_gross_local_val, CAST(promo_stores_cnt AS INT64) AS promo_stores_cnt, parameter_config, CAST(promo_week_sell_rate AS NUMERIC) AS promo_week_sell_rate, CAST(model_price_gross_local_val AS NUMERIC) AS model_price_gross_local_val, CAST(sales_promo_week_cnt AS INT64) AS sales_promo_week_cnt, CAST(model_discount_opt_rate AS NUMERIC) AS model_discount_opt_rate, CAST(sales_total_cnt AS INT64) AS sales_total_cnt, CAST(stock_initial_cnt AS INT64) AS stock_initial_cnt, CAST(current_discount_rate AS NUMERIC) AS current_discount_rate, CAST(current_week_nr AS INT64) AS current_week_nr, CAST(current_sell_rate AS NUMERIC) AS current_sell_rate, CAST(remaining_weeks_cnt AS INT64) AS remaining_weeks_cnt, CAST(remaining_stock_cnt AS INT64) AS remaining_stock_cnt, CAST(total_revenue_gross_local_val AS NUMERIC) AS total_revenue_gross_local_val, CAST(revenue_last_week_gross_local_val AS NUMERIC) AS revenue_last_week_gross_local_val, model_execution_tmsp, ai_model_id, CAST(curve_type_cd AS INT64) AS curve_type_cd, rule_created_dt, CAST(is_in_experiment_fg AS INT64) AS is_in_experiment_fg, experiment_group_cd, CAST(experiment_stores_cnt AS INT64) AS experiment_stores_cnt, CAST(display_art_id AS INT64) AS display_art_id, rule_decision_record, CAST(sell_ratio_wk12 AS NUMERIC) AS sell_ratio_wk12, CAST(sell_ratio_wk123 AS NUMERIC) AS sell_ratio_wk123, orig_promo_start_dt, orig_promo_end_dt, orig_promo_cycle_type_name, second_discount_start_dt, second_discount_end_dt, CAST(discount_base_gross_local_val AS NUMERIC) AS discount_base_gross_local_val, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_article_store_scorecard`;

-- Table: DBP_DATA.TOUR_WE
insert into `dbp_data.tour_we` (mandant_id, wup_id, nb_id, lagernummer_id, tour_id, wgvgrp_id, tor_gruene_wiese_id, tor_gruene_wiese_datum, tor_gruene_wiese_zeit, tor_best_verfuegbar_id, tor_best_verfuegbar_datum, tor_best_verfuegbar_zeit, tor_verplant_id, tor_verplant_datum, tor_verplant_zeit, planungsart_id, artikeltyp_we, dat_letzte_neuberechnung, zeit_letzte_neuberechnung, kritische_zone_status_id, we_message_status_id, anz_stellplaetze, anz_artikel, lagerplatz_gruene_wiese_id, entfernung_tor_gruene_wiese, wgvgrp_gruene_wiese_id, lagerplatz_best_verfuegbar_id, entfernung_tor_best_verfuegbar, wgvgrp_best_verfuegbar_id, lagerplatz_verplant_id, entfernung_tor_verplant, wgvgrp_verplant_id, mit_anlieferung_fg, mit_blockartikel_fg, mit_blockartikel_kein_lgpla_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, CAST(tour_id AS INT64) AS tour_id, CAST(wgvgrp_id AS INT64) AS wgvgrp_id, CAST(tor_gruene_wiese_id AS INT64) AS tor_gruene_wiese_id, tor_gruene_wiese_datum, tor_gruene_wiese_zeit, CAST(tor_best_verfuegbar_id AS INT64) AS tor_best_verfuegbar_id, tor_best_verfuegbar_datum, tor_best_verfuegbar_zeit, CAST(tor_verplant_id AS INT64) AS tor_verplant_id, tor_verplant_datum, tor_verplant_zeit, planungsart_id, artikeltyp_we, dat_letzte_neuberechnung, zeit_letzte_neuberechnung, CAST(kritische_zone_status_id AS INT64) AS kritische_zone_status_id, CAST(we_message_status_id AS INT64) AS we_message_status_id, CAST(anz_stellplaetze AS INT64) AS anz_stellplaetze, CAST(anz_artikel AS INT64) AS anz_artikel, lagerplatz_gruene_wiese_id, CAST(entfernung_tor_gruene_wiese AS NUMERIC) AS entfernung_tor_gruene_wiese, CAST(wgvgrp_gruene_wiese_id AS INT64) AS wgvgrp_gruene_wiese_id, lagerplatz_best_verfuegbar_id, CAST(entfernung_tor_best_verfuegbar AS NUMERIC) AS entfernung_tor_best_verfuegbar, CAST(wgvgrp_best_verfuegbar_id AS INT64) AS wgvgrp_best_verfuegbar_id, lagerplatz_verplant_id, CAST(entfernung_tor_verplant AS NUMERIC) AS entfernung_tor_verplant, CAST(wgvgrp_verplant_id AS INT64) AS wgvgrp_verplant_id, CAST(mit_anlieferung_fg AS INT64) AS mit_anlieferung_fg, CAST(mit_blockartikel_fg AS INT64) AS mit_blockartikel_fg, CAST(mit_blockartikel_kein_lgpla_fg AS INT64) AS mit_blockartikel_kein_lgpla_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tour_we`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_KUNDE
insert into `dbp_data.transportation_unit_kunde` (mandant_id, kunde_id, kunde_num_id, dat_tour, wup_id, plantour_id, transportation_unit_id, kj_transportation_unit, tour_pos_id, zeit_plan_ankunft, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kunde_id, CAST(kunde_num_id AS INT64) AS kunde_num_id, dat_tour, CAST(wup_id AS INT64) AS wup_id, CAST(plantour_id AS INT64) AS plantour_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(tour_pos_id AS INT64) AS tour_pos_id, zeit_plan_ankunft, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_kunde`;

-- Table: DBP_MSI_DATA.VIS_TAG_FWWS_GP_WG
insert into `dbp_msi_data.vis_tag_fwws_gp_wg` (mandant_id, wup_id, gp_id, dat, wg_id, arthiertyp_id, nb_id, abt_id, gj, kjmo, kjwo, akt_tag, anz_bestell_aenderung, anz_bestell_manuell, anz_bestell_vorschlag, sum_bestell_aenderung, sum_bestell_manuell, sum_bestell_vorschlag, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(gp_id AS INT64) AS gp_id, dat, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(nb_id AS INT64) AS nb_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(akt_tag AS INT64) AS akt_tag, CAST(anz_bestell_aenderung AS INT64) AS anz_bestell_aenderung, CAST(anz_bestell_manuell AS INT64) AS anz_bestell_manuell, CAST(anz_bestell_vorschlag AS INT64) AS anz_bestell_vorschlag, CAST(sum_bestell_aenderung AS INT64) AS sum_bestell_aenderung, CAST(sum_bestell_manuell AS INT64) AS sum_bestell_manuell, CAST(sum_bestell_vorschlag AS INT64) AS sum_bestell_vorschlag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_fwws_gp_wg`;

-- Table: DBP_DATA.WUP_WETTER_TAG_STUNDE
insert into `dbp_data.wup_wetter_tag_stunde` (mandant_id, wup_id, nb_id, dat, zeit_stunde, datzeit_letztes_update, temperatur, wetterzustand_id, windgeschwindigkeit, regenrisiko, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, datzeit_letztes_update, CAST(temperatur AS INT64) AS temperatur, CAST(wetterzustand_id AS INT64) AS wetterzustand_id, CAST(windgeschwindigkeit AS INT64) AS windgeschwindigkeit, CAST(regenrisiko AS INT64) AS regenrisiko, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_wetter_tag_stunde`;

-- Table: DBP_DATA.TRANSPORTAUFTRAG_ABBRUCH
insert into `dbp_data.transportauftrag_abbruch` (transport_beleg_id, mandant_id, lagernummer_id, wup_id, nb_id, abbr_pos_id, dat_abbr, zeit_abbr, ebene_wechsel_fg, td_update, td_insert)
SELECT CAST(transport_beleg_id AS INT64) AS transport_beleg_id, CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(abbr_pos_id AS INT64) AS abbr_pos_id, dat_abbr, CAST(zeit_abbr AS INT64) AS zeit_abbr, CAST(ebene_wechsel_fg AS INT64) AS ebene_wechsel_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportauftrag_abbruch`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_AKTIVITAET
insert into `dbp_data.transportation_unit_aktivitaet` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, aktivitaet_richtung_id, anlieferung_id, mercareon_kommentar_tdl, mercareon_kommentar_kl, leerpal_entscheidung_id, anz_pal_platz, ladung_begrenzung_fg, kommentar, kfz_kennzeichen, temp_frische_rel_fg, temp_frische, temp_frische_nok_fg, temp_frische_korr, temp_oug_rel_fg, temp_oug, temp_oug_nok_fg, temp_oug_korr, temp_tkk_rel_fg, temp_tkk, temp_tkk_nok_fg, temp_tkk_korr, temp_einh_id, nutzung_grund_id, sortimentsreihenfolge, ladung_gew, ladung_gew_einh_id, ladung_vol, ladung_vol_einh_id, dat_tour, menge_gefahrgut, belos_tourart_id, belos_tourstatus_id, belos_tourart_subtyp, belos_adresse_spedition_id, belos_sonderabwicklung_id, belos_sonderabwicklung_ugk_fg, belos_sonderabwicklung_gk_fg, belos_sonderabwicklung_tg_fg, belos_sonderabwicklung_tiko_fg, datzeit_start_plan, datzeit_start_ist, datzeit_ende_plan, datzeit_ende_ist, datzeit_route, route_kz, route_quelle, tour_office_fg, tour_classification, belos_rundlauf_transport_fg, belos_fleischwerk_fg, belos_distribution_abr_fg, belos_industrie_abh_fg, belos_adresse_absender_num_id, lagernummer_id, datzeit_anlage, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, aktivitaet_richtung_id, anlieferung_id, mercareon_kommentar_tdl, mercareon_kommentar_kl, leerpal_entscheidung_id, CAST(anz_pal_platz AS NUMERIC) AS anz_pal_platz, CAST(ladung_begrenzung_fg AS INT64) AS ladung_begrenzung_fg, kommentar, kfz_kennzeichen, CAST(temp_frische_rel_fg AS INT64) AS temp_frische_rel_fg, temp_frische, CAST(temp_frische_nok_fg AS INT64) AS temp_frische_nok_fg, CAST(temp_frische_korr AS INT64) AS temp_frische_korr, CAST(temp_oug_rel_fg AS INT64) AS temp_oug_rel_fg, CAST(temp_oug AS INT64) AS temp_oug, CAST(temp_oug_nok_fg AS INT64) AS temp_oug_nok_fg, CAST(temp_oug_korr AS INT64) AS temp_oug_korr, CAST(temp_tkk_rel_fg AS INT64) AS temp_tkk_rel_fg, CAST(temp_tkk AS INT64) AS temp_tkk, CAST(temp_tkk_nok_fg AS INT64) AS temp_tkk_nok_fg, temp_tkk_korr, temp_einh_id, nutzung_grund_id, sortimentsreihenfolge, CAST(ladung_gew AS NUMERIC) AS ladung_gew, ladung_gew_einh_id, CAST(ladung_vol AS NUMERIC) AS ladung_vol, ladung_vol_einh_id, dat_tour, CAST(menge_gefahrgut AS NUMERIC) AS menge_gefahrgut, CAST(belos_tourart_id AS INT64) AS belos_tourart_id, CAST(belos_tourstatus_id AS INT64) AS belos_tourstatus_id, CAST(belos_tourart_subtyp AS INT64) AS belos_tourart_subtyp, belos_adresse_spedition_id, belos_sonderabwicklung_id, CAST(belos_sonderabwicklung_ugk_fg AS INT64) AS belos_sonderabwicklung_ugk_fg, CAST(belos_sonderabwicklung_gk_fg AS INT64) AS belos_sonderabwicklung_gk_fg, CAST(belos_sonderabwicklung_tg_fg AS INT64) AS belos_sonderabwicklung_tg_fg, CAST(belos_sonderabwicklung_tiko_fg AS INT64) AS belos_sonderabwicklung_tiko_fg, CAST(datzeit_start_plan AS DATETIME) AS datzeit_start_plan, CAST(datzeit_start_ist AS DATETIME) AS datzeit_start_ist, CAST(datzeit_ende_plan AS DATETIME) AS datzeit_ende_plan, CAST(datzeit_ende_ist AS DATETIME) AS datzeit_ende_ist, CAST(datzeit_route AS DATETIME) AS datzeit_route, route_kz, route_quelle, CAST(tour_office_fg AS INT64) AS tour_office_fg, tour_classification, CAST(belos_rundlauf_transport_fg AS INT64) AS belos_rundlauf_transport_fg, CAST(belos_fleischwerk_fg AS INT64) AS belos_fleischwerk_fg, CAST(belos_distribution_abr_fg AS INT64) AS belos_distribution_abr_fg, CAST(belos_industrie_abh_fg AS INT64) AS belos_industrie_abh_fg, CAST(belos_adresse_absender_num_id AS INT64) AS belos_adresse_absender_num_id, lagernummer_id, CAST(datzeit_anlage AS DATETIME) AS datzeit_anlage, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_aktivitaet`;

-- Table: DBP_DATA.UMBEWERTUNG_WERTE
insert into `dbp_data.umbewertung_werte` (mandant_id, pae_beleg_id, kj, pae_beleg_pos_id, gjmo, wrg_bewertung_typ_id, wert_bestand, wert_bestand_alt, wert_bestand_s_preis, wert_bestand_s_preis_alt, gld_alt, standard_preis_alt, gld_neu, standard_preis_neu, preis_steuer_kz, preis_faktor, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(pae_beleg_id AS INT64) AS pae_beleg_id, CAST(kj AS INT64) AS kj, CAST(pae_beleg_pos_id AS INT64) AS pae_beleg_pos_id, CAST(gjmo AS INT64) AS gjmo, wrg_bewertung_typ_id, CAST(wert_bestand AS NUMERIC) AS wert_bestand, CAST(wert_bestand_alt AS NUMERIC) AS wert_bestand_alt, CAST(wert_bestand_s_preis AS NUMERIC) AS wert_bestand_s_preis, CAST(wert_bestand_s_preis_alt AS NUMERIC) AS wert_bestand_s_preis_alt, CAST(gld_alt AS NUMERIC) AS gld_alt, CAST(standard_preis_alt AS NUMERIC) AS standard_preis_alt, CAST(gld_neu AS NUMERIC) AS gld_neu, CAST(standard_preis_neu AS NUMERIC) AS standard_preis_neu, preis_steuer_kz, CAST(preis_faktor AS INT64) AS preis_faktor, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_umbewertung_werte`;

-- Table: DBP_ODS.SCANS_PRO_MINUTE
insert into `dbp_ods.scans_pro_minute` (mandant_id, wup_id, nb_id, kassierer_nr, kjwo, dat, anz_artikel, registrierzeit, scans_pro_minute, gew_durchschnitt, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, kassierer_nr, CAST(kjwo AS INT64) AS kjwo, dat, CAST(anz_artikel AS INT64) AS anz_artikel, CAST(registrierzeit AS INT64) AS registrierzeit, CAST(scans_pro_minute AS NUMERIC) AS scans_pro_minute, CAST(gew_durchschnitt AS NUMERIC) AS gew_durchschnitt, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_scans_pro_minute`;

-- Table: DBP_DATA.VIS_MENGEN_KORREKTUR_LISTE
insert into `dbp_data.vis_mengen_korrektur_liste` (mandant_id, wup_id, nb_id, dat_we, dat_aenderung, problemcode_id, mkl_beleg_id, kj, mkl_beleg_pos_id, art_id, gp_id, ref_beleg_id, verursacher_id, menge_we, we_menge_einh_id, retoure_fg, menge_kor, kor_menge_einh_id, anzeigen_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_we, dat_aenderung, problemcode_id, CAST(mkl_beleg_id AS INT64) AS mkl_beleg_id, CAST(kj AS INT64) AS kj, CAST(mkl_beleg_pos_id AS INT64) AS mkl_beleg_pos_id, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, ref_beleg_id, CAST(verursacher_id AS INT64) AS verursacher_id, CAST(menge_we AS NUMERIC) AS menge_we, we_menge_einh_id, CAST(retoure_fg AS INT64) AS retoure_fg, CAST(menge_kor AS NUMERIC) AS menge_kor, kor_menge_einh_id, CAST(anzeigen_fg AS INT64) AS anzeigen_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_mengen_korrektur_liste`;

-- Table: DBP_DATA.REGALACHSE
insert into `dbp_data.regalachse` (mandant_id, regalachse_id, layoutbaustein_id, layoutbaustein_version, dat_von, dat_bis, fbb_nr, platzierungsstufe_id, wup_id, nb_id, achsgruppe_id, regalachse_flaeche, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regalachse_id AS INT64) AS regalachse_id, CAST(layoutbaustein_id AS INT64) AS layoutbaustein_id, CAST(layoutbaustein_version AS INT64) AS layoutbaustein_version, dat_von, dat_bis, fbb_nr, platzierungsstufe_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(achsgruppe_id AS INT64) AS achsgruppe_id, CAST(regalachse_flaeche AS NUMERIC) AS regalachse_flaeche, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regalachse`;

-- Table: DBP_DATA.VIS_PUK_MONAT_KOMMENTAR
insert into `dbp_data.vis_puk_monat_kommentar` (mandant_id, kjmo, kennzahl_id, puk_typ_id, puk_id, puk_parent_id, ursache_kjmo, massnahme_kjmo, zeit_aktualisierung, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(kennzahl_id AS INT64) AS kennzahl_id, CAST(puk_typ_id AS INT64) AS puk_typ_id, CAST(puk_id AS INT64) AS puk_id, CAST(puk_parent_id AS INT64) AS puk_parent_id, ursache_kjmo, massnahme_kjmo, zeit_aktualisierung, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_puk_monat_kommentar`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT
insert into `dbp_data.transportation_unit` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_id_ext, lime_id, lime_id_ausgepackt, handling_unit_guid, transportmittel, eigentuemer, frachtfuehrer, scac, max_anz_siegel, fahrzeugnummer_intern, land_kfz_kennzeichen, kfz_kennzeichen, tu_permanent_fg, tu_head_fg, tor_vorbeladen_fg, lkw_vorgekuehlt_fg, rundlauf_fg, hu_gewicht, hu_gewicht_menge_einh_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, transportation_unit_id_ext, lime_id, lime_id_ausgepackt, handling_unit_guid, transportmittel, eigentuemer, frachtfuehrer, scac, CAST(max_anz_siegel AS INT64) AS max_anz_siegel, fahrzeugnummer_intern, land_kfz_kennzeichen, kfz_kennzeichen, tu_permanent_fg, tu_head_fg, tor_vorbeladen_fg, lkw_vorgekuehlt_fg, rundlauf_fg, CAST(hu_gewicht AS NUMERIC) AS hu_gewicht, hu_gewicht_menge_einh_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit`;

-- Table: DBP_DATA.T_FACT_IOT_SETPOINT_PER_DAY
insert into `dbp_data.t_fact_iot_setpoint_per_day` (mandant_id, wup_id, nb_id, dat_von, dat_bis, device_id, supply_airtemp_meas, return_airtemp_meas, liquefactiontemp_meas, liquefactiontemp_compound_meas, temp_meas, defrost_limittemp_meas, lowtemp_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_von, dat_bis, device_id, CAST(supply_airtemp_meas AS NUMERIC) AS supply_airtemp_meas, CAST(return_airtemp_meas AS NUMERIC) AS return_airtemp_meas, CAST(liquefactiontemp_meas AS NUMERIC) AS liquefactiontemp_meas, CAST(liquefactiontemp_compound_meas AS NUMERIC) AS liquefactiontemp_compound_meas, CAST(temp_meas AS NUMERIC) AS temp_meas, CAST(defrost_limittemp_meas AS NUMERIC) AS defrost_limittemp_meas, CAST(lowtemp_meas AS NUMERIC) AS lowtemp_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_setpoint_per_day`;

-- Table: DBP_DATA.MK_ART_WUP_ZEITFENSTER
insert into `dbp_data.mk_art_wup_zeitfenster` (wup_id, nb_id, mandant_id, art_id, wtag_id, zeitfenster_id, aktion_fg, dat_von, dat_bis, avg_menge, anz_tage_in_aktion, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wtag_id AS INT64) AS wtag_id, CAST(zeitfenster_id AS INT64) AS zeitfenster_id, CAST(aktion_fg AS INT64) AS aktion_fg, dat_von, dat_bis, CAST(avg_menge AS NUMERIC) AS avg_menge, CAST(anz_tage_in_aktion AS INT64) AS anz_tage_in_aktion, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mk_art_wup_zeitfenster`;

-- Table: DBP_ODS.ODS_BON_KOPF_UPD_KUNDENKARTE
insert into `dbp_ods.ods_bon_kopf_upd_kundenkarte` (bon_id, bon_dat, wup_id, bon_end_date, kundenkarte_id, insert_date, mandant_id, bon_day, td_insert, td_update)
SELECT bon_id, bon_dat, CAST(wup_id AS INT64) AS wup_id, bon_end_date, kundenkarte_id, insert_date, CAST(mandant_id AS INT64) AS mandant_id, CAST(bon_day AS INT64) AS bon_day, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_kopf_upd_kundenkarte`;

-- Table: DBP_DATA.UMBEWERTUNG
insert into `dbp_data.umbewertung` (mandant_id, pae_beleg_id, kj, dat_beleg, dat_erfasst, zeit_erfasst, beleg_user_name, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(pae_beleg_id AS INT64) AS pae_beleg_id, CAST(kj AS INT64) AS kj, dat_beleg, dat_erfasst, CAST(zeit_erfasst AS INT64) AS zeit_erfasst, beleg_user_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_umbewertung`;

-- Table: DBP_DATA.MA_KONTINGENT_ZU_PER
insert into `dbp_data.ma_kontingent_zu_per` (mandant_id, mitarbeiter_id, kjmo, kontingent_id, dat_von, dat_bis, anz_kontingent, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, kontingent_id, dat_von, dat_bis, CAST(anz_kontingent AS NUMERIC) AS anz_kontingent, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_kontingent_zu_per`;

-- Table: DBP_DATA.WUP_DAT_ABT_SUM
insert into `dbp_data.wup_dat_abt_sum` (mandant_id, wup_id, nb_id, dat, abt_id, arthiertyp_id, bonanzahl, bonanzahl_pre_pack, bonanzahl_sug, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(abt_id AS INT64) AS abt_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(bonanzahl_pre_pack AS INT64) AS bonanzahl_pre_pack, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_dat_abt_sum`;

-- Table: DBP_DATA.MK_ART_WUP_AUSWAHL
insert into `dbp_data.mk_art_wup_auswahl` (wup_id, nb_id, mandant_id, art_id, wtag_id, aktion_fg, dat_von, dat_bis, avg_menge, aktiv_fg, anz_tage_0verkauf, anz_tage_in_aktion, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(wtag_id AS INT64) AS wtag_id, CAST(aktion_fg AS INT64) AS aktion_fg, dat_von, dat_bis, CAST(avg_menge AS NUMERIC) AS avg_menge, CAST(aktiv_fg AS INT64) AS aktiv_fg, CAST(anz_tage_0verkauf AS INT64) AS anz_tage_0verkauf, CAST(anz_tage_in_aktion AS INT64) AS anz_tage_in_aktion, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mk_art_wup_auswahl`;

-- Table: DBP_DATA.RUECKFUEHRUNG_EPS_PAL_ART
insert into `dbp_data.rueckfuehrung_eps_pal_art` (mandant_id, handling_unit_id_ext, art_id, dat_erfassung, menge, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, handling_unit_id_ext, CAST(art_id AS INT64) AS art_id, dat_erfassung, CAST(menge AS INT64) AS menge, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rueckfuehrung_eps_pal_art`;

-- Table: DBP_DATA.FLW_ART_BEWERTUNGSKREIS_PER
insert into `dbp_data.flw_art_bewertungskreis_per` (mandant_id, flw_art_id, dat_von, bewertungskreis_id, system_id, dat_bis, preis_steuer_kz, gld, standard_preis, preis_faktor, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(flw_art_id AS INT64) AS flw_art_id, dat_von, bewertungskreis_id, CAST(system_id AS INT64) AS system_id, dat_bis, preis_steuer_kz, CAST(gld AS NUMERIC) AS gld, CAST(standard_preis AS NUMERIC) AS standard_preis, CAST(preis_faktor AS INT64) AS preis_faktor, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_flw_art_bewertungskreis_per`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_CARRIER_LOG
insert into `dbp_data.transportation_unit_carrier_log` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, beleg_id, handling_unit_guid, art_guid, ladungstraeger_status_id, anz_ladungstraeger, anz_ladungstraeger_defekt, anz_ladungstraeger_tausch, anz_ladungstraeger_defekt_tausch, ladungstraeger_einh_id, datzeit_erstellung, datzeit_aenderung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, CAST(beleg_id AS INT64) AS beleg_id, handling_unit_guid, art_guid, ladungstraeger_status_id, CAST(anz_ladungstraeger AS INT64) AS anz_ladungstraeger, CAST(anz_ladungstraeger_defekt AS INT64) AS anz_ladungstraeger_defekt, CAST(anz_ladungstraeger_tausch AS INT64) AS anz_ladungstraeger_tausch, CAST(anz_ladungstraeger_defekt_tausch AS INT64) AS anz_ladungstraeger_defekt_tausch, ladungstraeger_einh_id, CAST(datzeit_erstellung AS DATETIME) AS datzeit_erstellung, CAST(datzeit_aenderung AS DATETIME) AS datzeit_aenderung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_carrier_log`;

-- Table: DBP_MSI_DATA.KAMPAGNE_EMAIL_DOMAIN_MO_SUM
insert into `dbp_msi_data.kampagne_email_domain_mo_sum` (mandant_id, kjmo, email_domain_name, anz_kunde_gesamt, anz_kunde_gesendet, rate_kunde_gesendet, anz_kunde_blockiert, rate_kunde_blockiert, anz_kunde_zugestellt, rate_kunde_zugestellt, anz_kunde_bounced_soft, rate_kunde_bounced_soft, anz_kunde_bounced_hard, rate_kunde_bounced_hard, anz_kunde_geoeffnet, rate_kunde_geoeffnet_zugestellt, anz_kunde_geklickt, rate_kunde_geklickt_gesendet, rate_kunde_geklickt_geoeffnet, rate_kunde_geklickt_zugestellt, anz_kunde_spam, rate_kunde_spam, anz_kunde_abgemeldet, rate_kunde_abgemeldet, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, email_domain_name, CAST(anz_kunde_gesamt AS INT64) AS anz_kunde_gesamt, CAST(anz_kunde_gesendet AS INT64) AS anz_kunde_gesendet, CAST(rate_kunde_gesendet AS NUMERIC) AS rate_kunde_gesendet, CAST(anz_kunde_blockiert AS INT64) AS anz_kunde_blockiert, CAST(rate_kunde_blockiert AS NUMERIC) AS rate_kunde_blockiert, CAST(anz_kunde_zugestellt AS INT64) AS anz_kunde_zugestellt, CAST(rate_kunde_zugestellt AS NUMERIC) AS rate_kunde_zugestellt, CAST(anz_kunde_bounced_soft AS INT64) AS anz_kunde_bounced_soft, CAST(rate_kunde_bounced_soft AS NUMERIC) AS rate_kunde_bounced_soft, CAST(anz_kunde_bounced_hard AS INT64) AS anz_kunde_bounced_hard, CAST(rate_kunde_bounced_hard AS NUMERIC) AS rate_kunde_bounced_hard, CAST(anz_kunde_geoeffnet AS INT64) AS anz_kunde_geoeffnet, CAST(rate_kunde_geoeffnet_zugestellt AS NUMERIC) AS rate_kunde_geoeffnet_zugestellt, CAST(anz_kunde_geklickt AS INT64) AS anz_kunde_geklickt, CAST(rate_kunde_geklickt_gesendet AS NUMERIC) AS rate_kunde_geklickt_gesendet, CAST(rate_kunde_geklickt_geoeffnet AS NUMERIC) AS rate_kunde_geklickt_geoeffnet, CAST(rate_kunde_geklickt_zugestellt AS NUMERIC) AS rate_kunde_geklickt_zugestellt, CAST(anz_kunde_spam AS INT64) AS anz_kunde_spam, CAST(rate_kunde_spam AS NUMERIC) AS rate_kunde_spam, CAST(anz_kunde_abgemeldet AS INT64) AS anz_kunde_abgemeldet, CAST(rate_kunde_abgemeldet AS NUMERIC) AS rate_kunde_abgemeldet, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_kampagne_email_domain_mo_sum`;

-- Table: DBP_MSI_DATA.VIS_MONAT_UMSATZ_ABT
insert into `dbp_msi_data.vis_monat_umsatz_abt` (mandant_id, wup_id, nb_id, wrg_id, kjmo, abt_id, arthiertyp_id, gj, akt_gj, akt_mo, mo_kj, ums_netto, ums_netto_kvj, ums_netto_kvvj, ums_netto_plan, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, wrg_id, CAST(kjmo AS INT64) AS kjmo, CAST(abt_id AS INT64) AS abt_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(gj AS INT64) AS gj, CAST(akt_gj AS INT64) AS akt_gj, CAST(akt_mo AS INT64) AS akt_mo, CAST(mo_kj AS INT64) AS mo_kj, CAST(ums_netto AS NUMERIC) AS ums_netto, CAST(ums_netto_kvj AS NUMERIC) AS ums_netto_kvj, CAST(ums_netto_kvvj AS NUMERIC) AS ums_netto_kvvj, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_umsatz_abt`;

-- Table: DBP_DATA.WUP_WETTER_TAG
insert into `dbp_data.wup_wetter_tag` (mandant_id, wup_id, nb_id, dat, datzeit_letztes_update, temperatur_min, temperatur_max, sonne_aufgang, sonne_untergang, dauer_sonnenschein, mond_aufgang, mond_untergang, daemmerung_start, daemmerung_ende, mondphase_id, windrichtung_id, windrichtung_schema_id, windgeschwindigkeit_max, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, datzeit_letztes_update, CAST(temperatur_min AS INT64) AS temperatur_min, CAST(temperatur_max AS INT64) AS temperatur_max, sonne_aufgang, sonne_untergang, CAST(dauer_sonnenschein AS INT64) AS dauer_sonnenschein, mond_aufgang, mond_untergang, daemmerung_start, daemmerung_ende, CAST(mondphase_id AS INT64) AS mondphase_id, CAST(windrichtung_id AS INT64) AS windrichtung_id, CAST(windrichtung_schema_id AS INT64) AS windrichtung_schema_id, CAST(windgeschwindigkeit_max AS INT64) AS windgeschwindigkeit_max, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_wetter_tag`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_MANUAL_PRICE_RELEASE
insert into `dbp_msi_view_nfmd.ts_nfmd_manual_price_release` (mandant_id, aktion_id, art_id, wup_id, discount_type_name, kjwo_ww, wrg_id, manual_promo_price_gross_local_val, model_price_gross_local_val, manual_promo_price_dt, last_transfer_tmsp, user_id, dwh_created_tmsp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, discount_type_name, CAST(kjwo_ww AS INT64) AS kjwo_ww, wrg_id, CAST(manual_promo_price_gross_local_val AS NUMERIC) AS manual_promo_price_gross_local_val, CAST(model_price_gross_local_val AS NUMERIC) AS model_price_gross_local_val, manual_promo_price_dt, last_transfer_tmsp, user_id, dwh_created_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_manual_price_release`;

-- Table: DBP_DATA.TECHN_PLATZ_PER
insert into `dbp_data.techn_platz_per` (techn_platz_id, dat_von, dat_bis, techn_platz_ebene_id, land_id, mandant_id, teil_oeffentl_fg, region_id, system_id, buchungskreis_id, kostenstelle_id, krk_id, techn_platz_typ_id, psp_id, werk_instandhaltung_plan, adresse_name1, adresse_name2, wup_stadt, wup_plz, wup_str, wup_id, nb_id, td_insert, td_update)
SELECT techn_platz_id, dat_von, dat_bis, CAST(techn_platz_ebene_id AS INT64) AS techn_platz_ebene_id, land_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(teil_oeffentl_fg AS INT64) AS teil_oeffentl_fg, CAST(region_id AS INT64) AS region_id, CAST(system_id AS INT64) AS system_id, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, kostenstelle_id, krk_id, techn_platz_typ_id, psp_id, werk_instandhaltung_plan, adresse_name1, adresse_name2, wup_stadt, wup_plz, wup_str, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_techn_platz_per`;

-- Table: DBP_DATA.MA_DATUMSART_ZU_PER
insert into `dbp_data.ma_datumsart_zu_per` (mandant_id, datumsart_id, mitarbeiter_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, datumsart_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_datumsart_zu_per`;

-- Table: DBP_ODS.ODS_WPUFIB
insert into `dbp_ods.ods_wpufib` (wup_id, mandant_id, dat_booking, zahlungsmittel_id, buchungsschluessel_id, aggr_nr, group_nr, record_nr, wrg_id, betrag, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, dat_booking, zahlungsmittel_id, buchungsschluessel_id, CAST(aggr_nr AS INT64) AS aggr_nr, CAST(group_nr AS INT64) AS group_nr, CAST(record_nr AS INT64) AS record_nr, wrg_id, CAST(betrag AS NUMERIC) AS betrag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_wpufib`;

-- Table: DBP_DATA.VIS_MONAT_INVENTUR_DIFF
insert into `dbp_data.vis_monat_inventur_diff` (kjmo, mandant_id, wup_id, wg_id, arthiertyp_id, custom_1_id, custom_2_id, custom_3_id, custom_4_id, ums_brutto_ist_hfm, betrag_inv_diff_brutto_hfm, ums_brutto_plan_hfm, betrag_inv_diff_plan_hfm, menge_end_bestand_hfm, bestand_berechnet_fg, betrag_abschr_brutto_hfm, td_insert, td_update)
SELECT CAST(kjmo AS INT64) AS kjmo, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, custom_1_id, custom_2_id, custom_3_id, custom_4_id, CAST(ums_brutto_ist_hfm AS NUMERIC) AS ums_brutto_ist_hfm, CAST(betrag_inv_diff_brutto_hfm AS NUMERIC) AS betrag_inv_diff_brutto_hfm, CAST(ums_brutto_plan_hfm AS NUMERIC) AS ums_brutto_plan_hfm, CAST(betrag_inv_diff_plan_hfm AS NUMERIC) AS betrag_inv_diff_plan_hfm, CAST(menge_end_bestand_hfm AS NUMERIC) AS menge_end_bestand_hfm, CAST(bestand_berechnet_fg AS INT64) AS bestand_berechnet_fg, CAST(betrag_abschr_brutto_hfm AS NUMERIC) AS betrag_abschr_brutto_hfm, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_monat_inventur_diff`;

-- Table: DBP_DATA.WUP_PLAN_TAG
insert into `dbp_data.wup_plan_tag` (wup_id, nb_id, mandant_id, dat, plan_tag_fg, umsatz_netto_plan, wrg_id, umsatz_netto_plan_extern, menge_absatz_ohne_pfand_plan, td_update, td_insert)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(plan_tag_fg AS INT64) AS plan_tag_fg, CAST(umsatz_netto_plan AS NUMERIC) AS umsatz_netto_plan, wrg_id, CAST(umsatz_netto_plan_extern AS NUMERIC) AS umsatz_netto_plan_extern, CAST(menge_absatz_ohne_pfand_plan AS NUMERIC) AS menge_absatz_ohne_pfand_plan, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_plan_tag`;

-- Table: DBP_DATA.MA_PERS_TEILBEREICH_ZU_PER
insert into `dbp_data.ma_pers_teilbereich_zu_per` (mandant_id, pers_teilbereich_id, mitarbeiter_id, kjmo, buchungskreis_id, pers_bereich_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, pers_teilbereich_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, pers_bereich_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_pers_teilbereich_zu_per`;

-- Table: DBP_DATA.PC_PC_GRP_ZU
insert into `dbp_data.pc_pc_grp_zu` (pc_id, system_id, mandant_id, krk_id, pc_grp_id, pc_hiertyp_id, td_insert, td_update)
SELECT pc_id, CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, krk_id, pc_grp_id, CAST(pc_hiertyp_id AS INT64) AS pc_hiertyp_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_pc_pc_grp_zu`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_DE
insert into `dbp_data.wup_stunden_tag_de` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_de`;

-- Table: DBP_DATA.TMS_TOUR_DET
insert into `dbp_data.tms_tour_det` (mandant_id, system_id, tms_tour_id, dat_tour, tms_tour_pos_id, tms_tour_pos_lfd_nr, tms_tour_reihenfolge_nr, lieferkunde_tms_gp_id, lieferkunde_tms_gp_typ_cd, gewicht_kg, volumen_cbm, anz_stellplatz, dat_ankunft, datzeit_ankunft, datzeit_abfahrt, dauer_umtauschzeit_min, dauer_fahrzeit_min, entfernung_fahrt_km, dauer_pause_min, dauer_fahrzeit_nachfolger_min, entfernung_nachfolger_km, entfernung_lager_km, dauer_fahrt_lager_min, maut_km, gewicht_kg_retoure, volumen_cbm_retoure, anz_stellplatz_retoure, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(tms_tour_pos_id AS INT64) AS tms_tour_pos_id, CAST(tms_tour_pos_lfd_nr AS INT64) AS tms_tour_pos_lfd_nr, CAST(tms_tour_reihenfolge_nr AS INT64) AS tms_tour_reihenfolge_nr, lieferkunde_tms_gp_id, lieferkunde_tms_gp_typ_cd, CAST(gewicht_kg AS NUMERIC) AS gewicht_kg, CAST(volumen_cbm AS NUMERIC) AS volumen_cbm, CAST(anz_stellplatz AS NUMERIC) AS anz_stellplatz, dat_ankunft, CAST(datzeit_ankunft AS DATETIME) AS datzeit_ankunft, CAST(datzeit_abfahrt AS DATETIME) AS datzeit_abfahrt, CAST(dauer_umtauschzeit_min AS INT64) AS dauer_umtauschzeit_min, CAST(dauer_fahrzeit_min AS INT64) AS dauer_fahrzeit_min, CAST(entfernung_fahrt_km AS INT64) AS entfernung_fahrt_km, CAST(dauer_pause_min AS INT64) AS dauer_pause_min, CAST(dauer_fahrzeit_nachfolger_min AS NUMERIC) AS dauer_fahrzeit_nachfolger_min, CAST(entfernung_nachfolger_km AS NUMERIC) AS entfernung_nachfolger_km, CAST(entfernung_lager_km AS NUMERIC) AS entfernung_lager_km, CAST(dauer_fahrt_lager_min AS NUMERIC) AS dauer_fahrt_lager_min, CAST(maut_km AS NUMERIC) AS maut_km, CAST(gewicht_kg_retoure AS NUMERIC) AS gewicht_kg_retoure, CAST(volumen_cbm_retoure AS NUMERIC) AS volumen_cbm_retoure, CAST(anz_stellplatz_retoure AS NUMERIC) AS anz_stellplatz_retoure, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_tour_det`;

-- Table: DBP_DATA.MA_KOSTENSTELLE_ZU_PER
insert into `dbp_data.ma_kostenstelle_zu_per` (mandant_id, system_id, kostenstelle_id, mitarbeiter_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, kostenstelle_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_kostenstelle_zu_per`;

-- Table: DBP_DATA.TEKU_BERICHT_DET_PER
insert into `dbp_data.teku_bericht_det_per` (teku_antwort_id, dat_von, dat_bis, teku_antwort_note, teku_antwort_bez, teku_bericht_id, teku_fragestellung_id, td_insert, td_update)
SELECT CAST(teku_antwort_id AS INT64) AS teku_antwort_id, dat_von, dat_bis, CAST(teku_antwort_note AS NUMERIC) AS teku_antwort_note, teku_antwort_bez, CAST(teku_bericht_id AS INT64) AS teku_bericht_id, CAST(teku_fragestellung_id AS INT64) AS teku_fragestellung_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_bericht_det_per`;

-- Table: DBP_DATA.MA_KREIS_ZU_PER
insert into `dbp_data.ma_kreis_zu_per` (mandant_id, mitarbeiter_kreis_id, mitarbeiter_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_kreis_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_kreis_zu_per`;

-- Table: DBP_ODS_ARCHIV.ODS_WPUFIB
insert into `dbp_ods_archiv.ods_wpufib` (wup_id, mandant_id, dat_booking, zahlungsmittel_id, buchungsschluessel_id, aggr_nr, group_nr, record_nr, wrg_id, betrag, td_update, td_insert)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, dat_booking, zahlungsmittel_id, buchungsschluessel_id, CAST(aggr_nr AS INT64) AS aggr_nr, CAST(group_nr AS INT64) AS group_nr, CAST(record_nr AS INT64) AS record_nr, wrg_id, CAST(betrag AS NUMERIC) AS betrag, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_wpufib`;

-- Table: DBP_DATA.TMS_RECHNUNG_DET
insert into `dbp_data.tms_rechnung_det` (mandant_id, system_id, tms_rech_beleg_id, tms_rech_beleg_pos_id, tms_rech_pos_lfd_nr, dat_tms_rech_beleg, preis_einzel, betrag_vor_rabattabzug, betrag_netto, mwst, tms_konto_id, bewertungseinheit_cd, tms_rech_org_pos_id, tms_rech_pos_txt, tms_rech_pos_leist_typ_cd, tms_rech_pos_leist_typ_bez, menge_effektiv, menge_frachtpflichtig, tms_tour_id, dat_tour, bewertungseinheit_id, reklamation_fg, bearbeitet_fg, reklamation_txt, tms_rech_pos_referenz_lfd_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_rech_beleg_id AS INT64) AS tms_rech_beleg_id, tms_rech_beleg_pos_id, CAST(tms_rech_pos_lfd_nr AS INT64) AS tms_rech_pos_lfd_nr, dat_tms_rech_beleg, CAST(preis_einzel AS NUMERIC) AS preis_einzel, CAST(betrag_vor_rabattabzug AS NUMERIC) AS betrag_vor_rabattabzug, CAST(betrag_netto AS NUMERIC) AS betrag_netto, CAST(mwst AS NUMERIC) AS mwst, CAST(tms_konto_id AS INT64) AS tms_konto_id, bewertungseinheit_cd, CAST(tms_rech_org_pos_id AS INT64) AS tms_rech_org_pos_id, tms_rech_pos_txt, tms_rech_pos_leist_typ_cd, tms_rech_pos_leist_typ_bez, CAST(menge_effektiv AS NUMERIC) AS menge_effektiv, CAST(menge_frachtpflichtig AS NUMERIC) AS menge_frachtpflichtig, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(bewertungseinheit_id AS INT64) AS bewertungseinheit_id, CAST(reklamation_fg AS INT64) AS reklamation_fg, CAST(bearbeitet_fg AS INT64) AS bearbeitet_fg, reklamation_txt, CAST(tms_rech_pos_referenz_lfd_nr AS INT64) AS tms_rech_pos_referenz_lfd_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_rechnung_det`;

-- Table: DBP_DATA.MA_GRUPPE_ZU_PER
insert into `dbp_data.ma_gruppe_zu_per` (mandant_id, mitarbeiter_gruppe_id, mitarbeiter_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_gruppe_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_gruppe_zu_per`;

-- Table: DBP_DATA.ANGEBOT
insert into `dbp_data.angebot` (mandant_id, angebot_nr, dat_angebot_gueltig_von, dat_angebot_gueltig_bis, kjwo_ww, angebot_name, angebot_beschreibung_txt, angebot_status_id, angebot_typ_cd, anz_angebot_limit, geschaeftsvorfall_id, hauptangebot_fg, hauptangebot_nr, bonuskauf_fg, bonuskauf_id, konditionsart_id, aktion_id, bewart_id, aktion_typ_id, markt_version_txt, anz_market_version, transfer_status_id, akzeptiert_fg, angebot_geloescht_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, angebot_nr, dat_angebot_gueltig_von, dat_angebot_gueltig_bis, CAST(kjwo_ww AS INT64) AS kjwo_ww, angebot_name, angebot_beschreibung_txt, CAST(angebot_status_id AS INT64) AS angebot_status_id, angebot_typ_cd, CAST(anz_angebot_limit AS INT64) AS anz_angebot_limit, geschaeftsvorfall_id, CAST(hauptangebot_fg AS INT64) AS hauptangebot_fg, hauptangebot_nr, CAST(bonuskauf_fg AS INT64) AS bonuskauf_fg, bonuskauf_id, konditionsart_id, aktion_id, CAST(bewart_id AS INT64) AS bewart_id, aktion_typ_id, markt_version_txt, CAST(anz_market_version AS INT64) AS anz_market_version, CAST(transfer_status_id AS INT64) AS transfer_status_id, CAST(akzeptiert_fg AS INT64) AS akzeptiert_fg, CAST(angebot_geloescht_fg AS INT64) AS angebot_geloescht_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_angebot`;

-- Table: DBP_DATA.FLW_KONDIT_DET
insert into `dbp_data.flw_kondit_det` (mandant_id, kondition_id, kondition_pos_id, kondition_applikation_id, konditionsart_id, betrag_kondition, kondition_einh_id, kondition_preis_einh_id, kondition_menge_einh_id, system_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kondition_id AS INT64) AS kondition_id, CAST(kondition_pos_id AS INT64) AS kondition_pos_id, kondition_applikation_id, konditionsart_id, CAST(betrag_kondition AS NUMERIC) AS betrag_kondition, kondition_einh_id, CAST(kondition_preis_einh_id AS INT64) AS kondition_preis_einh_id, kondition_menge_einh_id, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_flw_kondit_det`;

-- Table: DBP_DATA.TS_AUTODISPO_DIF
insert into `dbp_data.ts_autodispo_dif` (mandant_id_kunde, wup_id_kunde, nb_id_kunde, mandant_id_vz, wup_id_vz, nb_id_vz, frische_manager_id, art_id, vs_id, vkl_id, wg_id, art_gruppe_id, dat_von, dat_bis, sa_af_fg, dif_funktion_id, dif_typ_id, menge_einh_id, dif_status_id, dif_wert, dif_kommentar, dif_timestamp, art_cluster_id, wup_cluster_id, werbegruppe_fleisch, dateiname, dat_upload, td_update, td_insert)
SELECT CAST(mandant_id_kunde AS INT64) AS mandant_id_kunde, CAST(wup_id_kunde AS INT64) AS wup_id_kunde, CAST(nb_id_kunde AS INT64) AS nb_id_kunde, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(nb_id_vz AS INT64) AS nb_id_vz, CAST(frische_manager_id AS INT64) AS frische_manager_id, CAST(art_id AS INT64) AS art_id, CAST(vs_id AS INT64) AS vs_id, CAST(vkl_id AS INT64) AS vkl_id, CAST(wg_id AS INT64) AS wg_id, art_gruppe_id, dat_von, dat_bis, CAST(sa_af_fg AS INT64) AS sa_af_fg, dif_funktion_id, CAST(dif_typ_id AS INT64) AS dif_typ_id, menge_einh_id, CAST(dif_status_id AS INT64) AS dif_status_id, CAST(dif_wert AS NUMERIC) AS dif_wert, dif_kommentar, dif_timestamp, CAST(art_cluster_id AS INT64) AS art_cluster_id, CAST(wup_cluster_id AS INT64) AS wup_cluster_id, werbegruppe_fleisch, dateiname, dat_upload, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_autodispo_dif`;

-- Table: DBP_DATA.MA_PERSONALBEREICH_ZU_PER
insert into `dbp_data.ma_personalbereich_zu_per` (system_id, mandant_id, buchungskreis_id, mitarbeiter_id, kjmo, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_personalbereich_zu_per`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_STORNO
insert into `dbp_ods_archiv.ods_bon_storno` (bon_id, bon_dat, mandant_id, wup_id, bon_nr, kasse_nr, datei_name, td_insert, td_update)
SELECT bon_id, bon_dat, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(bon_nr AS INT64) AS bon_nr, CAST(kasse_nr AS INT64) AS kasse_nr, datei_name, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_storno`;

-- Table: DBP_DATA.COS_BONUSKAUF
insert into `dbp_data.cos_bonuskauf` (mandant_id, bonuskauf_id, wrg_id, bonuskauf_name, bonuskauf_typ, bonuskauf_kategorie_bez, gamification_fg, bonuskauf_rabatt_wert, bonuskauf_rabatt_prozent, anz_punkte_zu_zahlend, wg_id, dat_von, dat_bis, bonuskauf_bez, max_einloesung, aktiv_loyalty_gesamt_fg, voraktiviert_fg, aktiv_loyalty_digital_fg, aktiv_loyalty_physisch_fg, anz_max_einkauf, anz_min_artikel, min_umsatz_bedingung, min_umsatz_artikel, min_umsatz_bedingung_transaktion, dat_von_bedingung, dat_bis_bedingung, mindestfrequenz_bedingung, anz_min_kauf_bby_artikel, anz_min_zahlen_bby_artikel, gratis_menge_bby, zuweisung_neukunde_fg, anz_top_kunden, anz_aktuelle_kunden, bonuskauf_deaktivieren_fg, umsatz_aktivierung_brutto, bonuskauf_regel, kauf_mit_punkte_fg, konditionsart_id, bonuskauf_promotionstyp, geschaeftsvorfall_id, vk_brutto, vk_aktion_brutto_loyalty, betrag_promo_prozent, vk_aktion_brutto, bonuskauf_partner_fg, bonuskauf_smp_fg, nur_marktplatz_fg, bonuskauf_anbieter_name, bonuskauf_code_generierung_typ_id, bonuskauf_code_typ_id, sichtbar_in_app_fg, sichtbar_in_web_fg, sichtbar_in_ssc_fg, sichtbar_in_marktplatz_fg, sichtbar_in_kampagne_fg, bonuskauf_vorteilsregeln_txt, bonuskauf_konditionen_txt, datzeit_von_extern_einloesung, datzeit_bis_extern_einloesung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, bonuskauf_id, wrg_id, bonuskauf_name, bonuskauf_typ, bonuskauf_kategorie_bez, CAST(gamification_fg AS INT64) AS gamification_fg, CAST(bonuskauf_rabatt_wert AS NUMERIC) AS bonuskauf_rabatt_wert, CAST(bonuskauf_rabatt_prozent AS NUMERIC) AS bonuskauf_rabatt_prozent, CAST(anz_punkte_zu_zahlend AS INT64) AS anz_punkte_zu_zahlend, CAST(wg_id AS INT64) AS wg_id, CAST(dat_von AS DATETIME) AS dat_von, CAST(dat_bis AS DATETIME) AS dat_bis, bonuskauf_bez, CAST(max_einloesung AS INT64) AS max_einloesung, CAST(aktiv_loyalty_gesamt_fg AS INT64) AS aktiv_loyalty_gesamt_fg, CAST(voraktiviert_fg AS INT64) AS voraktiviert_fg, CAST(aktiv_loyalty_digital_fg AS INT64) AS aktiv_loyalty_digital_fg, CAST(aktiv_loyalty_physisch_fg AS INT64) AS aktiv_loyalty_physisch_fg, CAST(anz_max_einkauf AS INT64) AS anz_max_einkauf, CAST(anz_min_artikel AS INT64) AS anz_min_artikel, CAST(min_umsatz_bedingung AS NUMERIC) AS min_umsatz_bedingung, CAST(min_umsatz_artikel AS NUMERIC) AS min_umsatz_artikel, CAST(min_umsatz_bedingung_transaktion AS NUMERIC) AS min_umsatz_bedingung_transaktion, CAST(dat_von_bedingung AS DATETIME) AS dat_von_bedingung, CAST(dat_bis_bedingung AS DATETIME) AS dat_bis_bedingung, CAST(mindestfrequenz_bedingung AS INT64) AS mindestfrequenz_bedingung, CAST(anz_min_kauf_bby_artikel AS INT64) AS anz_min_kauf_bby_artikel, CAST(anz_min_zahlen_bby_artikel AS INT64) AS anz_min_zahlen_bby_artikel, CAST(gratis_menge_bby AS INT64) AS gratis_menge_bby, CAST(zuweisung_neukunde_fg AS INT64) AS zuweisung_neukunde_fg, CAST(anz_top_kunden AS INT64) AS anz_top_kunden, CAST(anz_aktuelle_kunden AS INT64) AS anz_aktuelle_kunden, CAST(bonuskauf_deaktivieren_fg AS INT64) AS bonuskauf_deaktivieren_fg, CAST(umsatz_aktivierung_brutto AS NUMERIC) AS umsatz_aktivierung_brutto, bonuskauf_regel, CAST(kauf_mit_punkte_fg AS INT64) AS kauf_mit_punkte_fg, konditionsart_id, bonuskauf_promotionstyp, geschaeftsvorfall_id, CAST(vk_brutto AS NUMERIC) AS vk_brutto, CAST(vk_aktion_brutto_loyalty AS NUMERIC) AS vk_aktion_brutto_loyalty, CAST(betrag_promo_prozent AS NUMERIC) AS betrag_promo_prozent, CAST(vk_aktion_brutto AS NUMERIC) AS vk_aktion_brutto, CAST(bonuskauf_partner_fg AS INT64) AS bonuskauf_partner_fg, CAST(bonuskauf_smp_fg AS INT64) AS bonuskauf_smp_fg, CAST(nur_marktplatz_fg AS INT64) AS nur_marktplatz_fg, bonuskauf_anbieter_name, CAST(bonuskauf_code_generierung_typ_id AS INT64) AS bonuskauf_code_generierung_typ_id, CAST(bonuskauf_code_typ_id AS INT64) AS bonuskauf_code_typ_id, CAST(sichtbar_in_app_fg AS INT64) AS sichtbar_in_app_fg, CAST(sichtbar_in_web_fg AS INT64) AS sichtbar_in_web_fg, CAST(sichtbar_in_ssc_fg AS INT64) AS sichtbar_in_ssc_fg, CAST(sichtbar_in_marktplatz_fg AS INT64) AS sichtbar_in_marktplatz_fg, CAST(sichtbar_in_kampagne_fg AS INT64) AS sichtbar_in_kampagne_fg, bonuskauf_vorteilsregeln_txt, bonuskauf_konditionen_txt, CAST(datzeit_von_extern_einloesung AS DATETIME) AS datzeit_von_extern_einloesung, CAST(datzeit_bis_extern_einloesung AS DATETIME) AS datzeit_bis_extern_einloesung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_cos_bonuskauf`;

-- Table: DBP_DATA.MA_HIERARCHIE_ZU_PER
insert into `dbp_data.ma_hierarchie_zu_per` (ma_id, ma_mutter_id, dat_von, dat_bis, mandant_id, wup_id, ma_hierarchie_ebene_id, td_update, td_insert)
SELECT CAST(ma_id AS INT64) AS ma_id, CAST(ma_mutter_id AS INT64) AS ma_mutter_id, dat_von, dat_bis, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, ma_hierarchie_ebene_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ma_hierarchie_zu_per`;

-- Table: DBP_DATA.PALETTEN_KONTROLLE_GEWICHT
insert into `dbp_data.paletten_kontrolle_gewicht` (mandant_id, lagernummer_id, wup_id, nb_id, handling_unit_id, handling_unit_id_traeger, status_id, gewicht_ist, gewicht_soll, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(handling_unit_id AS INT64) AS handling_unit_id, CAST(handling_unit_id_traeger AS INT64) AS handling_unit_id_traeger, CAST(status_id AS INT64) AS status_id, CAST(gewicht_ist AS NUMERIC) AS gewicht_ist, CAST(gewicht_soll AS NUMERIC) AS gewicht_soll, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_paletten_kontrolle_gewicht`;

-- Table: DBP_DATA.SB_BEURTEIL_BEREICHSNOTE
insert into `dbp_data.sb_beurteil_bereichsnote` (bereichsnote_id, mandant_id, beurteilung_id, note_bereich, eindruck_bereich, beurteilung_bereich_id, td_insert, td_update)
SELECT CAST(bereichsnote_id AS INT64) AS bereichsnote_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(beurteilung_id AS INT64) AS beurteilung_id, CAST(note_bereich AS NUMERIC) AS note_bereich, eindruck_bereich, CAST(beurteilung_bereich_id AS INT64) AS beurteilung_bereich_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_bereichsnote`;

-- Table: DBP_DATA.WUP_ABSCHOEPFUNG
insert into `dbp_data.wup_abschoepfung` (wup_id, mandant_id, dat, nb_id, betrag_markt_vor_geldabhlg, betrag_geldabhlg, betrag_markt_nach_geldabhlg, betrag_tresor_nach_geldabhlg, betrag_schieb_nach_geldabhlg, betrag_geldabholg_90_prozent, betrag_diff_90_prozent, quote_geldabhlg, wrg_id, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(nb_id AS INT64) AS nb_id, CAST(betrag_markt_vor_geldabhlg AS NUMERIC) AS betrag_markt_vor_geldabhlg, CAST(betrag_geldabhlg AS NUMERIC) AS betrag_geldabhlg, CAST(betrag_markt_nach_geldabhlg AS NUMERIC) AS betrag_markt_nach_geldabhlg, CAST(betrag_tresor_nach_geldabhlg AS NUMERIC) AS betrag_tresor_nach_geldabhlg, CAST(betrag_schieb_nach_geldabhlg AS NUMERIC) AS betrag_schieb_nach_geldabhlg, CAST(betrag_geldabholg_90_prozent AS NUMERIC) AS betrag_geldabholg_90_prozent, CAST(betrag_diff_90_prozent AS NUMERIC) AS betrag_diff_90_prozent, CAST(quote_geldabhlg AS NUMERIC) AS quote_geldabhlg, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_abschoepfung`;

-- Table: DBP_DATA.PMR_ANGEBOT_WERBEMITTEL_WERBEFLAECHE_ZU
insert into `dbp_data.pmr_angebot_werbemittel_werbeflaeche_zu` (angebot_id, mandant_id, werbemittel_art_id, werbemittel_id, werbeflaeche_abschnitt_name, werbeflaeche_thema_id, werbeflaeche_thema_bez, td_update, td_insert)
SELECT CAST(angebot_id AS INT64) AS angebot_id, CAST(mandant_id AS INT64) AS mandant_id, werbemittel_art_id, CAST(werbemittel_id AS INT64) AS werbemittel_id, werbeflaeche_abschnitt_name, werbeflaeche_thema_id, werbeflaeche_thema_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_pmr_angebot_werbemittel_werbeflaeche_zu`;

-- Table: DBP_DATA.TMS_AUFTRAG_DET
insert into `dbp_data.tms_auftrag_det` (mandant_id, system_id, tms_auftrag_id, tms_auftrag_unter_id, tms_auftrag_pos_id, tms_auftrag_det_lfd_nr, art_id, orig_art_nr, menge_kommissioniert, status_fertig_cd, tms_transportmittel_id, anz_transportmittel, wareneingang_beleg_id, dat_wareneingang, tms_auftrag_orig_id, tms_auftrag_orig_unter_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_auftrag_id, CAST(tms_auftrag_unter_id AS INT64) AS tms_auftrag_unter_id, tms_auftrag_pos_id, CAST(tms_auftrag_det_lfd_nr AS INT64) AS tms_auftrag_det_lfd_nr, CAST(art_id AS INT64) AS art_id, orig_art_nr, CAST(menge_kommissioniert AS NUMERIC) AS menge_kommissioniert, status_fertig_cd, CAST(tms_transportmittel_id AS INT64) AS tms_transportmittel_id, CAST(anz_transportmittel AS INT64) AS anz_transportmittel, wareneingang_beleg_id, dat_wareneingang, tms_auftrag_orig_id, CAST(tms_auftrag_orig_unter_id AS INT64) AS tms_auftrag_orig_unter_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_auftrag_det`;

-- Table: DBP_DATA.T_FACT_IOT_AIR_MONITOR_PER_HOUR
insert into `dbp_data.t_fact_iot_air_monitor_per_hour` (mandant_id, wup_id, nb_id, cal_dt, device_id, measurement_tm, hygrometertemp_meas, hygrometerhumidity_meas, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, cal_dt, device_id, measurement_tm, CAST(hygrometertemp_meas AS NUMERIC) AS hygrometertemp_meas, CAST(hygrometerhumidity_meas AS NUMERIC) AS hygrometerhumidity_meas, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_fact_iot_air_monitor_per_hour`;

-- Table: DBP_DATA.RUECKFUEHRUNG_EPS_PAL
insert into `dbp_data.rueckfuehrung_eps_pal` (mandant_id, handling_unit_id_ext, tour_id, wup_id, nb_id, kunde_id, dat_erfassung, best_beleg_id_eps, dat_verladung, dat_mengenrueckmeldung, lagerbew_beleg_id_vz, lagerbew_kj_vz, lagerbew_beleg_id_kunde, lagerbew_kj_kunde, manuelle_erf_fg, keine_filialentlastung_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, handling_unit_id_ext, CAST(tour_id AS INT64) AS tour_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, kunde_id, dat_erfassung, CAST(best_beleg_id_eps AS INT64) AS best_beleg_id_eps, dat_verladung, dat_mengenrueckmeldung, CAST(lagerbew_beleg_id_vz AS INT64) AS lagerbew_beleg_id_vz, CAST(lagerbew_kj_vz AS INT64) AS lagerbew_kj_vz, CAST(lagerbew_beleg_id_kunde AS INT64) AS lagerbew_beleg_id_kunde, CAST(lagerbew_kj_kunde AS INT64) AS lagerbew_kj_kunde, CAST(manuelle_erf_fg AS INT64) AS manuelle_erf_fg, CAST(keine_filialentlastung_fg AS INT64) AS keine_filialentlastung_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rueckfuehrung_eps_pal`;

-- Table: DBP_DATA.SHR_KENNZAHLEN
insert into `dbp_data.shr_kennzahlen` (mandant_id, kjmo, hr_objekt_id, anz_kopf_ist, anz_kopf_vj, anz_kopf_gjkum_ist, anz_kopf_gjkum_vj, abr_stunden_mo_ist, abr_stunden_mo_vj, abwesenheit_tage_ist, abwesenheit_tage_vj, abwesenheit_tage_gjkum_ist, abwesenheit_tage_gjkum_vj, soll_stunden_mo_ist, soll_stunden_mo_vj, soll_stunden_mo_an_ist, soll_stunden_mo_an_vj, soll_stunden_mo_ag_ist, soll_stunden_mo_ag_vj, soll_stunden_mo_gjkum_ist, soll_stunden_mo_gjkum_vj, soll_stunden_mo_an_gjkum_ist, soll_stunden_mo_an_gjkum_vj, soll_stunden_mo_ag_gjkum_ist, soll_stunden_mo_ag_gjkum_vj, shr_freigabe_fg, anz_austritt_extern_neu_kum, anz_eintritt_extern_kum, anz_kopf_sdl_kum_gj, anz_kopf_sdl_kum, anz_austritt_extern_kum_gj, genommen_urlaub_kum_kj, anz_eintritt_extern_minus6, anz_austritt_extern_neu, ueberstunden_kum_gj, arb_stunden_tag_kum_gj, soll_arbeitstage_kum_gj, krank_arbeitstage_kum_gj, anz_stunden_mvst_kum_gj, anz_teilzeit_kum_gj, anspruch_urlaub_kum_gj, genommen_urlaub_kum_gj, anz_frau_kum_gj, anz_frau_fuehrungskraft_kum_gj, abwesenheit_stunden_kum_gj, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, CAST(anz_kopf_ist AS NUMERIC) AS anz_kopf_ist, CAST(anz_kopf_vj AS NUMERIC) AS anz_kopf_vj, CAST(anz_kopf_gjkum_ist AS NUMERIC) AS anz_kopf_gjkum_ist, CAST(anz_kopf_gjkum_vj AS NUMERIC) AS anz_kopf_gjkum_vj, CAST(abr_stunden_mo_ist AS NUMERIC) AS abr_stunden_mo_ist, CAST(abr_stunden_mo_vj AS NUMERIC) AS abr_stunden_mo_vj, CAST(abwesenheit_tage_ist AS NUMERIC) AS abwesenheit_tage_ist, CAST(abwesenheit_tage_vj AS NUMERIC) AS abwesenheit_tage_vj, CAST(abwesenheit_tage_gjkum_ist AS NUMERIC) AS abwesenheit_tage_gjkum_ist, CAST(abwesenheit_tage_gjkum_vj AS NUMERIC) AS abwesenheit_tage_gjkum_vj, CAST(soll_stunden_mo_ist AS NUMERIC) AS soll_stunden_mo_ist, CAST(soll_stunden_mo_vj AS NUMERIC) AS soll_stunden_mo_vj, CAST(soll_stunden_mo_an_ist AS NUMERIC) AS soll_stunden_mo_an_ist, CAST(soll_stunden_mo_an_vj AS NUMERIC) AS soll_stunden_mo_an_vj, CAST(soll_stunden_mo_ag_ist AS NUMERIC) AS soll_stunden_mo_ag_ist, CAST(soll_stunden_mo_ag_vj AS NUMERIC) AS soll_stunden_mo_ag_vj, CAST(soll_stunden_mo_gjkum_ist AS NUMERIC) AS soll_stunden_mo_gjkum_ist, CAST(soll_stunden_mo_gjkum_vj AS NUMERIC) AS soll_stunden_mo_gjkum_vj, CAST(soll_stunden_mo_an_gjkum_ist AS NUMERIC) AS soll_stunden_mo_an_gjkum_ist, CAST(soll_stunden_mo_an_gjkum_vj AS NUMERIC) AS soll_stunden_mo_an_gjkum_vj, CAST(soll_stunden_mo_ag_gjkum_ist AS NUMERIC) AS soll_stunden_mo_ag_gjkum_ist, CAST(soll_stunden_mo_ag_gjkum_vj AS NUMERIC) AS soll_stunden_mo_ag_gjkum_vj, CAST(shr_freigabe_fg AS INT64) AS shr_freigabe_fg, CAST(anz_austritt_extern_neu_kum AS NUMERIC) AS anz_austritt_extern_neu_kum, CAST(anz_eintritt_extern_kum AS NUMERIC) AS anz_eintritt_extern_kum, CAST(anz_kopf_sdl_kum_gj AS NUMERIC) AS anz_kopf_sdl_kum_gj, CAST(anz_kopf_sdl_kum AS NUMERIC) AS anz_kopf_sdl_kum, CAST(anz_austritt_extern_kum_gj AS NUMERIC) AS anz_austritt_extern_kum_gj, CAST(genommen_urlaub_kum_kj AS NUMERIC) AS genommen_urlaub_kum_kj, CAST(anz_eintritt_extern_minus6 AS NUMERIC) AS anz_eintritt_extern_minus6, CAST(anz_austritt_extern_neu AS NUMERIC) AS anz_austritt_extern_neu, CAST(ueberstunden_kum_gj AS NUMERIC) AS ueberstunden_kum_gj, CAST(arb_stunden_tag_kum_gj AS NUMERIC) AS arb_stunden_tag_kum_gj, CAST(soll_arbeitstage_kum_gj AS NUMERIC) AS soll_arbeitstage_kum_gj, CAST(krank_arbeitstage_kum_gj AS NUMERIC) AS krank_arbeitstage_kum_gj, CAST(anz_stunden_mvst_kum_gj AS NUMERIC) AS anz_stunden_mvst_kum_gj, CAST(anz_teilzeit_kum_gj AS NUMERIC) AS anz_teilzeit_kum_gj, CAST(anspruch_urlaub_kum_gj AS NUMERIC) AS anspruch_urlaub_kum_gj, CAST(genommen_urlaub_kum_gj AS NUMERIC) AS genommen_urlaub_kum_gj, CAST(anz_frau_kum_gj AS NUMERIC) AS anz_frau_kum_gj, CAST(anz_frau_fuehrungskraft_kum_gj AS NUMERIC) AS anz_frau_fuehrungskraft_kum_gj, CAST(abwesenheit_stunden_kum_gj AS NUMERIC) AS abwesenheit_stunden_kum_gj, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_shr_kennzahlen`;

-- Table: DBP_DATA.TMS_TOUR
insert into `dbp_data.tms_tour` (mandant_id, system_id, tms_tour_id, dat_tour, tms_tour_lfd_nr, transportation_unit_id_ext, tms_tourart_id, tms_tourtyp_id, tms_tourstatus_id, tms_tour_bez, anz_stopp, anz_stellplatz, tms_fahrzeug_id, tms_fahrzeugtyp_id, tms_trailer_id, tms_trailer_typ_id, spedition_tms_gp_id, spedition_tms_gp_typ_cd, temperaturgruppe_id, gutschrift_erstellt_fg, startlager_tms_gp_id, startlager_tms_gp_typ_cd, ziellager_tms_gp_id, ziellager_tms_gp_typ_cd, maut_km, leer_km, anz_aenderung, betrag_fixkosten, tms_tour_dispostelle_id, tms_tourart_detail_id, tms_tour_richtungsart_id, sortiment_temperaturgruppe_id, tms_tour_strategisch_id, td_update, td_insert, antriebsart_id)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_tour_id AS INT64) AS tms_tour_id, dat_tour, CAST(tms_tour_lfd_nr AS INT64) AS tms_tour_lfd_nr, transportation_unit_id_ext, tms_tourart_id, CAST(tms_tourtyp_id AS INT64) AS tms_tourtyp_id, CAST(tms_tourstatus_id AS INT64) AS tms_tourstatus_id, tms_tour_bez, CAST(anz_stopp AS INT64) AS anz_stopp, CAST(anz_stellplatz AS INT64) AS anz_stellplatz, tms_fahrzeug_id, CAST(tms_fahrzeugtyp_id AS INT64) AS tms_fahrzeugtyp_id, tms_trailer_id, CAST(tms_trailer_typ_id AS INT64) AS tms_trailer_typ_id, spedition_tms_gp_id, spedition_tms_gp_typ_cd, temperaturgruppe_id, CAST(gutschrift_erstellt_fg AS INT64) AS gutschrift_erstellt_fg, startlager_tms_gp_id, startlager_tms_gp_typ_cd, ziellager_tms_gp_id, ziellager_tms_gp_typ_cd, CAST(maut_km AS INT64) AS maut_km, CAST(leer_km AS INT64) AS leer_km, CAST(anz_aenderung AS INT64) AS anz_aenderung, CAST(betrag_fixkosten AS NUMERIC) AS betrag_fixkosten, CAST(tms_tour_dispostelle_id AS INT64) AS tms_tour_dispostelle_id, CAST(tms_tourart_detail_id AS INT64) AS tms_tourart_detail_id, CAST(tms_tour_richtungsart_id AS INT64) AS tms_tour_richtungsart_id, CAST(sortiment_temperaturgruppe_id AS INT64) AS sortiment_temperaturgruppe_id, CAST(tms_tour_strategisch_id AS INT64) AS tms_tour_strategisch_id, td_update, td_insert, antriebsart_id
FROM `snowflake_snapshots.kfl_dbp_data_tms_tour`;

-- Table: DBP_DATA.IMMO_L_PARTNER
insert into `dbp_data.immo_l_partner` (partner_id, anrede, vorname, nachname, gebiet_id, verbund_kz, strasse, haus_nr, plz, ort, land, td_update, td_insert)
SELECT partner_id, anrede, vorname, nachname, CAST(gebiet_id AS INT64) AS gebiet_id, verbund_kz, strasse, haus_nr, plz, ort, land, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_partner`;

-- Table: DBP_DATA.TS_MENGENAENDERUNGEN_WRITEBACK
insert into `dbp_data.ts_mengenaenderungen_writeback` (mandant_id, aktion_id, art_id, dat_von, dat_bis, angebot_id, dat_beladung, menge_ohne_bestand_genehmigt_fg, menge_mit_bestand_genehmigt_fg, werbeaenderung_menge_uebertragen, fixmenge_wfl_bme, menge_mindestplatzierung_cluster_1_ame, menge_mindestplatzierung_cluster_2_ame, menge_mindestplatzierung_cluster_3_ame, wfl_menge_geprueft_fg, wfl_nutzer_kommentar_txt, estimation_id, init_lief_clear_stock_id, adjustment_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, dat_von, dat_bis, CAST(angebot_id AS INT64) AS angebot_id, dat_beladung, CAST(menge_ohne_bestand_genehmigt_fg AS INT64) AS menge_ohne_bestand_genehmigt_fg, CAST(menge_mit_bestand_genehmigt_fg AS INT64) AS menge_mit_bestand_genehmigt_fg, CAST(werbeaenderung_menge_uebertragen AS NUMERIC) AS werbeaenderung_menge_uebertragen, CAST(fixmenge_wfl_bme AS INT64) AS fixmenge_wfl_bme, CAST(menge_mindestplatzierung_cluster_1_ame AS INT64) AS menge_mindestplatzierung_cluster_1_ame, CAST(menge_mindestplatzierung_cluster_2_ame AS INT64) AS menge_mindestplatzierung_cluster_2_ame, CAST(menge_mindestplatzierung_cluster_3_ame AS INT64) AS menge_mindestplatzierung_cluster_3_ame, CAST(wfl_menge_geprueft_fg AS INT64) AS wfl_menge_geprueft_fg, wfl_nutzer_kommentar_txt, CAST(estimation_id AS INT64) AS estimation_id, CAST(init_lief_clear_stock_id AS INT64) AS init_lief_clear_stock_id, CAST(adjustment_id AS INT64) AS adjustment_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_mengenaenderungen_writeback`;

-- Table: DBP_PROCESS.BF_BONS_KPIM_AKT_KMO
insert into `dbp_process.bf_bons_kpim_akt_kmo` (mandant_id, wup_id, dat, bons, bon_zeilen, bons_af, bons_sa, bons_akt, ges_umsatz_af, ges_umsatz_sa, ges_umsatz_akt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, dat, CAST(bons AS INT64) AS bons, CAST(bon_zeilen AS INT64) AS bon_zeilen, CAST(bons_af AS INT64) AS bons_af, CAST(bons_sa AS INT64) AS bons_sa, CAST(bons_akt AS INT64) AS bons_akt, CAST(ges_umsatz_af AS NUMERIC) AS ges_umsatz_af, CAST(ges_umsatz_sa AS NUMERIC) AS ges_umsatz_sa, CAST(ges_umsatz_akt AS NUMERIC) AS ges_umsatz_akt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_process_bf_bons_kpim_akt_kmo`;

-- Table: DBP_DATA.RPM_FIN_GRUPPE
insert into `dbp_data.rpm_fin_gruppe` (fin_gruppe_hierarchie_id, fin_kat_hierarchie_id, fin_gruppe_id, fin_kategorie_id, fin_gruppe_version_id, fin_gruppe_version_dat, td_update, td_insert)
SELECT fin_gruppe_hierarchie_id, fin_kat_hierarchie_id, fin_gruppe_id, fin_kategorie_id, fin_gruppe_version_id, fin_gruppe_version_dat, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_fin_gruppe`;

-- Table: DBP_DATA.RPM_ELEMENT_PER
insert into `dbp_data.rpm_element_per` (dat_von, rpm_hierarchie_id, rpm_immobilie_id, projekt_id, dat_bis, rpm_status_id, wrg_id, dat_start_prognose, dat_start_plan, dat_start, dat_ende_prognose, dat_ende_plan, dat_ende, land_id, mandant_id, strasse, wup_id, nb_id, bereich_name, wup_standort, plz, expansionauftrag_nr, eigenentw, angebot_nr, auftraggeber_name, objekt_planer_name, gj_umbvorschl, rpm_projekt_typ_id, rpm_phase_id, testmarkt_fg, massnahmentyp_id, besitzverhaeltnis_id, td_update, td_insert)
SELECT dat_von, rpm_hierarchie_id, rpm_immobilie_id, projekt_id, dat_bis, CAST(rpm_status_id AS INT64) AS rpm_status_id, wrg_id, dat_start_prognose, dat_start_plan, dat_start, dat_ende_prognose, dat_ende_plan, dat_ende, land_id, CAST(mandant_id AS INT64) AS mandant_id, strasse, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, bereich_name, wup_standort, plz, expansionauftrag_nr, eigenentw, angebot_nr, auftraggeber_name, objekt_planer_name, CAST(gj_umbvorschl AS INT64) AS gj_umbvorschl, rpm_projekt_typ_id, rpm_phase_id, CAST(testmarkt_fg AS INT64) AS testmarkt_fg, CAST(massnahmentyp_id AS INT64) AS massnahmentyp_id, besitzverhaeltnis_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_element_per`;

-- Table: DBP_PROCESS.BF_BONS_KPIM_AKT
insert into `dbp_process.bf_bons_kpim_akt` (mandant_id, wup_id, dat, bons, bon_zeilen, bons_af, bons_sa, bons_akt, ges_umsatz_af, ges_umsatz_sa, ges_umsatz_akt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, dat, CAST(bons AS INT64) AS bons, CAST(bon_zeilen AS INT64) AS bon_zeilen, CAST(bons_af AS INT64) AS bons_af, CAST(bons_sa AS INT64) AS bons_sa, CAST(bons_akt AS INT64) AS bons_akt, CAST(ges_umsatz_af AS NUMERIC) AS ges_umsatz_af, CAST(ges_umsatz_sa AS NUMERIC) AS ges_umsatz_sa, CAST(ges_umsatz_akt AS NUMERIC) AS ges_umsatz_akt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_process_bf_bons_kpim_akt`;

-- Table: DBP_DATA.VIS_MONAT_SHR_WUP_FUNKTGR_UPLOAD
insert into `dbp_data.vis_monat_shr_wup_funktgr_upload` (mandant_id, wup_id, nb_id, kjmo, shr_ma_funktion_gruppe_id, anz_kopf_gesamt, anz_kopf_ohne_lza, anz_kopf_teilzeit, anz_kopf_eintritte, anz_vzk_gesamt, anz_vzk_eintritt, anz_stunden_vertrag, anz_tage_urlaub_rest_vj_kj, anz_tage_urlaub_anspruch_akt_kj, anz_tage_urlaub_genommen_kj_kum, anz_tage_urlaub_abgeltung_kj_kum, anz_stunden_zuschlag_feiertag, anz_stunden_zuschlag_mehr, anz_stunden_zuschlag_spaet_nacht, anz_stunden_zuschlag_wochenende, anz_stunden_mehr_geleistet, anz_tage_krank, anz_tage_arbeit_soll, anz_kopf_fluktuation, anz_kopf_austritte, anz_vzk_fluktuation, anz_vzk_austritt, anz_monate_00, anz_kopf_bzg_monate_00_03, anz_kopf_bzg_monate_03_06, anz_kopf_bzg_monate_06_12, anz_kopf_bzg_monate_12_36, anz_kopf_bzg_monate_36, anz_austritt_00, anz_austritt_00_03, anz_austritt_03_06, anz_austritt_06_12, anz_austritt_12_36, anz_austritt_36, anz_austritt_trw, anz_austritt_vtg, anz_austritt_an, anz_austritt_ag, anz_stunden_mehr_bezahlt, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(shr_ma_funktion_gruppe_id AS INT64) AS shr_ma_funktion_gruppe_id, CAST(anz_kopf_gesamt AS NUMERIC) AS anz_kopf_gesamt, CAST(anz_kopf_ohne_lza AS NUMERIC) AS anz_kopf_ohne_lza, CAST(anz_kopf_teilzeit AS NUMERIC) AS anz_kopf_teilzeit, CAST(anz_kopf_eintritte AS NUMERIC) AS anz_kopf_eintritte, CAST(anz_vzk_gesamt AS NUMERIC) AS anz_vzk_gesamt, CAST(anz_vzk_eintritt AS NUMERIC) AS anz_vzk_eintritt, CAST(anz_stunden_vertrag AS NUMERIC) AS anz_stunden_vertrag, CAST(anz_tage_urlaub_rest_vj_kj AS NUMERIC) AS anz_tage_urlaub_rest_vj_kj, CAST(anz_tage_urlaub_anspruch_akt_kj AS NUMERIC) AS anz_tage_urlaub_anspruch_akt_kj, CAST(anz_tage_urlaub_genommen_kj_kum AS NUMERIC) AS anz_tage_urlaub_genommen_kj_kum, CAST(anz_tage_urlaub_abgeltung_kj_kum AS NUMERIC) AS anz_tage_urlaub_abgeltung_kj_kum, CAST(anz_stunden_zuschlag_feiertag AS NUMERIC) AS anz_stunden_zuschlag_feiertag, CAST(anz_stunden_zuschlag_mehr AS NUMERIC) AS anz_stunden_zuschlag_mehr, CAST(anz_stunden_zuschlag_spaet_nacht AS NUMERIC) AS anz_stunden_zuschlag_spaet_nacht, CAST(anz_stunden_zuschlag_wochenende AS NUMERIC) AS anz_stunden_zuschlag_wochenende, CAST(anz_stunden_mehr_geleistet AS NUMERIC) AS anz_stunden_mehr_geleistet, CAST(anz_tage_krank AS NUMERIC) AS anz_tage_krank, CAST(anz_tage_arbeit_soll AS NUMERIC) AS anz_tage_arbeit_soll, CAST(anz_kopf_fluktuation AS NUMERIC) AS anz_kopf_fluktuation, CAST(anz_kopf_austritte AS NUMERIC) AS anz_kopf_austritte, CAST(anz_vzk_fluktuation AS NUMERIC) AS anz_vzk_fluktuation, CAST(anz_vzk_austritt AS NUMERIC) AS anz_vzk_austritt, CAST(anz_monate_00 AS NUMERIC) AS anz_monate_00, CAST(anz_kopf_bzg_monate_00_03 AS NUMERIC) AS anz_kopf_bzg_monate_00_03, CAST(anz_kopf_bzg_monate_03_06 AS NUMERIC) AS anz_kopf_bzg_monate_03_06, CAST(anz_kopf_bzg_monate_06_12 AS NUMERIC) AS anz_kopf_bzg_monate_06_12, CAST(anz_kopf_bzg_monate_12_36 AS NUMERIC) AS anz_kopf_bzg_monate_12_36, CAST(anz_kopf_bzg_monate_36 AS NUMERIC) AS anz_kopf_bzg_monate_36, CAST(anz_austritt_00 AS NUMERIC) AS anz_austritt_00, CAST(anz_austritt_00_03 AS NUMERIC) AS anz_austritt_00_03, CAST(anz_austritt_03_06 AS NUMERIC) AS anz_austritt_03_06, CAST(anz_austritt_06_12 AS NUMERIC) AS anz_austritt_06_12, CAST(anz_austritt_12_36 AS NUMERIC) AS anz_austritt_12_36, CAST(anz_austritt_36 AS NUMERIC) AS anz_austritt_36, CAST(anz_austritt_trw AS NUMERIC) AS anz_austritt_trw, CAST(anz_austritt_vtg AS NUMERIC) AS anz_austritt_vtg, CAST(anz_austritt_an AS NUMERIC) AS anz_austritt_an, CAST(anz_austritt_ag AS NUMERIC) AS anz_austritt_ag, CAST(anz_stunden_mehr_bezahlt AS NUMERIC) AS anz_stunden_mehr_bezahlt, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_monat_shr_wup_funktgr_upload`;

-- Table: DBP_DATA.VIS_RW
insert into `dbp_data.vis_rw` (mandant_id, wup_id, art_id, rw, rw_counter, reload_rw, reload_rw_counter, pruef_datum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(art_id AS INT64) AS art_id, CAST(rw AS NUMERIC) AS rw, CAST(rw_counter AS INT64) AS rw_counter, CAST(reload_rw AS NUMERIC) AS reload_rw, CAST(reload_rw_counter AS INT64) AS reload_rw_counter, pruef_datum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_rw`;

-- Table: DBP_DATA.RUECKFUEHRUNG_LT_GRUND
insert into `dbp_data.rueckfuehrung_lt_grund` (mandant_id, tour_id, wup_id, nb_id, art_id, lagerbew_beleg_id, kj, lfnr, rueck_grund_id, dat_buch, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tour_id AS INT64) AS tour_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(lagerbew_beleg_id AS INT64) AS lagerbew_beleg_id, CAST(kj AS INT64) AS kj, CAST(lfnr AS INT64) AS lfnr, CAST(rueck_grund_id AS INT64) AS rueck_grund_id, dat_buch, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rueckfuehrung_lt_grund`;

-- Table: DBP_DATA.ORG_EINHEIT_ZU_PER
insert into `dbp_data.org_einheit_zu_per` (hr_objekt_id_zu, richtung_kz, relat, kjmo, mandant_id, hr_objekt_id, dat_von, dat_bis, system_id, td_insert, td_update)
SELECT hr_objekt_id_zu, richtung_kz, relat, CAST(kjmo AS INT64) AS kjmo, CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, dat_von, dat_bis, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_org_einheit_zu_per`;

-- Table: DBP_DATA.PLANTOUR
insert into `dbp_data.plantour` (mandant_id, wup_id, nb_id, plantour_id, tour_id, trailer_fg, trailer_id, dat_trailer, zeit_trailer, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(plantour_id AS INT64) AS plantour_id, CAST(tour_id AS INT64) AS tour_id, CAST(trailer_fg AS INT64) AS trailer_fg, trailer_id, dat_trailer, zeit_trailer, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_plantour`;

-- Table: DBP_DATA.IMS_MAMO_WUP_KJWO_SUM
insert into `dbp_data.ims_mamo_wup_kjwo_sum` (mandant_id, wup_id, nb_id, hwg_id, kjwo, zaehler_woche, umsatz_netto, umsatz_netto_kum, umsatz_netto_vp, umsatz_netto_vp_kum, umsatz_netto_sa, umsatz_netto_sa_kum, umsatz_netto_sa_vp, umsatz_netto_sa_vp_kum, ek_mep, ek_mep_kum, ek_mep_vp, ek_mep_vp_kum, bonanzahl_sug, bonanzahl_sug_kum, bonanzahl_sug_vp, bonanzahl_sug_vp_kum, vis_netto_stunden, vis_netto_stunden_kum, vis_netto_stunden_vp, vis_netto_stunden_vp_kum, vis_umsatz_netto, vis_umsatz_netto_kum, vis_umsatz_netto_vp, vis_umsatz_netto_vp_kum, preis_abschrift_netto, preis_abschrift_netto_kum, preis_abschrift_netto_vp, preis_abschrift_netto_vp_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(kjwo AS INT64) AS kjwo, CAST(zaehler_woche AS INT64) AS zaehler_woche, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(umsatz_netto_kum AS NUMERIC) AS umsatz_netto_kum, CAST(umsatz_netto_vp AS NUMERIC) AS umsatz_netto_vp, CAST(umsatz_netto_vp_kum AS NUMERIC) AS umsatz_netto_vp_kum, CAST(umsatz_netto_sa AS NUMERIC) AS umsatz_netto_sa, CAST(umsatz_netto_sa_kum AS NUMERIC) AS umsatz_netto_sa_kum, CAST(umsatz_netto_sa_vp AS NUMERIC) AS umsatz_netto_sa_vp, CAST(umsatz_netto_sa_vp_kum AS NUMERIC) AS umsatz_netto_sa_vp_kum, CAST(ek_mep AS NUMERIC) AS ek_mep, CAST(ek_mep_kum AS NUMERIC) AS ek_mep_kum, CAST(ek_mep_vp AS NUMERIC) AS ek_mep_vp, CAST(ek_mep_vp_kum AS NUMERIC) AS ek_mep_vp_kum, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, CAST(bonanzahl_sug_kum AS INT64) AS bonanzahl_sug_kum, CAST(bonanzahl_sug_vp AS INT64) AS bonanzahl_sug_vp, CAST(bonanzahl_sug_vp_kum AS INT64) AS bonanzahl_sug_vp_kum, CAST(vis_netto_stunden AS INT64) AS vis_netto_stunden, CAST(vis_netto_stunden_kum AS INT64) AS vis_netto_stunden_kum, CAST(vis_netto_stunden_vp AS INT64) AS vis_netto_stunden_vp, CAST(vis_netto_stunden_vp_kum AS INT64) AS vis_netto_stunden_vp_kum, CAST(vis_umsatz_netto AS NUMERIC) AS vis_umsatz_netto, CAST(vis_umsatz_netto_kum AS NUMERIC) AS vis_umsatz_netto_kum, CAST(vis_umsatz_netto_vp AS NUMERIC) AS vis_umsatz_netto_vp, CAST(vis_umsatz_netto_vp_kum AS NUMERIC) AS vis_umsatz_netto_vp_kum, CAST(preis_abschrift_netto AS NUMERIC) AS preis_abschrift_netto, CAST(preis_abschrift_netto_kum AS NUMERIC) AS preis_abschrift_netto_kum, CAST(preis_abschrift_netto_vp AS NUMERIC) AS preis_abschrift_netto_vp, CAST(preis_abschrift_netto_vp_kum AS NUMERIC) AS preis_abschrift_netto_vp_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_wup_kjwo_sum`;

-- Table: DBP_DATA.MK_ZEROVERKAUF
insert into `dbp_data.mk_zeroverkauf` (wup_id, nb_id, mandant_id, art_id, dat, zeitfenster_id, aktion_fg, art_fehlgrund_id, menge_lgbest, datzeit_letzter_abverkauf, art_fehlgrund_text, dat_erfasst, melde_fg, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, dat, CAST(zeitfenster_id AS INT64) AS zeitfenster_id, CAST(aktion_fg AS INT64) AS aktion_fg, CAST(art_fehlgrund_id AS INT64) AS art_fehlgrund_id, CAST(menge_lgbest AS NUMERIC) AS menge_lgbest, datzeit_letzter_abverkauf, art_fehlgrund_text, dat_erfasst, CAST(melde_fg AS INT64) AS melde_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mk_zeroverkauf`;

-- Table: DBP_DATA.RUECKSENDUNG
insert into `dbp_data.ruecksendung` (mandant_id, ruecksendung_beleg_id, wa_wup_id, wa_nb_id, we_wup_id, we_nb_id, we_gp_id, dat_lief, ruecksendung_status_id, anz_palette, gefahrstoff_fg, ruecksendung_typ_kz, dat_aenderung, dat_erstellung, bezugsweg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ruecksendung_beleg_id AS INT64) AS ruecksendung_beleg_id, CAST(wa_wup_id AS INT64) AS wa_wup_id, CAST(wa_nb_id AS INT64) AS wa_nb_id, CAST(we_wup_id AS INT64) AS we_wup_id, CAST(we_nb_id AS INT64) AS we_nb_id, CAST(we_gp_id AS INT64) AS we_gp_id, dat_lief, CAST(ruecksendung_status_id AS INT64) AS ruecksendung_status_id, CAST(anz_palette AS INT64) AS anz_palette, CAST(gefahrstoff_fg AS INT64) AS gefahrstoff_fg, ruecksendung_typ_kz, dat_aenderung, dat_erstellung, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ruecksendung`;

-- Table: DBP_DATA.IMS_MAMO_WUP_QUALIFIER_KJWO_SUM
insert into `dbp_data.ims_mamo_wup_qualifier_kjwo_sum` (mandant_id, wup_id, nb_id, qualifier_id, hwg_id, kjwo, zaehler_woche, umsatz_netto, umsatz_netto_kum, umsatz_netto_vp, umsatz_netto_vp_kum, umsatz_netto_sa, umsatz_netto_sa_kum, umsatz_netto_sa_vp, umsatz_netto_sa_vp_kum, ek_mep, ek_mep_kum, ek_mep_vp, ek_mep_vp_kum, bonanzahl_sug, bonanzahl_sug_kum, bonanzahl_sug_vp, bonanzahl_sug_vp_kum, vis_netto_stunden, vis_netto_stunden_kum, vis_netto_stunden_vp, vis_netto_stunden_vp_kum, vis_umsatz_netto, vis_umsatz_netto_kum, vis_umsatz_netto_vp, vis_umsatz_netto_vp_kum, preis_abschrift_netto, preis_abschrift_netto_kum, preis_abschrift_netto_vp, preis_abschrift_netto_vp_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(qualifier_id AS INT64) AS qualifier_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(kjwo AS INT64) AS kjwo, CAST(zaehler_woche AS INT64) AS zaehler_woche, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(umsatz_netto_kum AS NUMERIC) AS umsatz_netto_kum, CAST(umsatz_netto_vp AS NUMERIC) AS umsatz_netto_vp, CAST(umsatz_netto_vp_kum AS NUMERIC) AS umsatz_netto_vp_kum, CAST(umsatz_netto_sa AS NUMERIC) AS umsatz_netto_sa, CAST(umsatz_netto_sa_kum AS NUMERIC) AS umsatz_netto_sa_kum, CAST(umsatz_netto_sa_vp AS NUMERIC) AS umsatz_netto_sa_vp, CAST(umsatz_netto_sa_vp_kum AS NUMERIC) AS umsatz_netto_sa_vp_kum, CAST(ek_mep AS NUMERIC) AS ek_mep, CAST(ek_mep_kum AS NUMERIC) AS ek_mep_kum, CAST(ek_mep_vp AS NUMERIC) AS ek_mep_vp, CAST(ek_mep_vp_kum AS NUMERIC) AS ek_mep_vp_kum, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, CAST(bonanzahl_sug_kum AS INT64) AS bonanzahl_sug_kum, CAST(bonanzahl_sug_vp AS INT64) AS bonanzahl_sug_vp, CAST(bonanzahl_sug_vp_kum AS INT64) AS bonanzahl_sug_vp_kum, CAST(vis_netto_stunden AS INT64) AS vis_netto_stunden, CAST(vis_netto_stunden_kum AS INT64) AS vis_netto_stunden_kum, CAST(vis_netto_stunden_vp AS INT64) AS vis_netto_stunden_vp, CAST(vis_netto_stunden_vp_kum AS INT64) AS vis_netto_stunden_vp_kum, CAST(vis_umsatz_netto AS NUMERIC) AS vis_umsatz_netto, CAST(vis_umsatz_netto_kum AS NUMERIC) AS vis_umsatz_netto_kum, CAST(vis_umsatz_netto_vp AS NUMERIC) AS vis_umsatz_netto_vp, CAST(vis_umsatz_netto_vp_kum AS NUMERIC) AS vis_umsatz_netto_vp_kum, CAST(preis_abschrift_netto AS NUMERIC) AS preis_abschrift_netto, CAST(preis_abschrift_netto_kum AS NUMERIC) AS preis_abschrift_netto_kum, CAST(preis_abschrift_netto_vp AS NUMERIC) AS preis_abschrift_netto_vp, CAST(preis_abschrift_netto_vp_kum AS NUMERIC) AS preis_abschrift_netto_vp_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_wup_qualifier_kjwo_sum`;

-- Table: DBP_DATA.SB_BEURTEIL_DETAILNOTE
insert into `dbp_data.sb_beurteil_detailnote` (detailnote_id, mandant_id, bereichsnote_id, note_detail, eindruck_detail, beurteilung_detail_id, td_insert, td_update)
SELECT CAST(detailnote_id AS INT64) AS detailnote_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(bereichsnote_id AS INT64) AS bereichsnote_id, CAST(note_detail AS NUMERIC) AS note_detail, eindruck_detail, CAST(beurteilung_detail_id AS INT64) AS beurteilung_detail_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_detailnote`;

-- Table: DBP_DATA.SORTIMENT_KL_WG_VERTEILUNG
insert into `dbp_data.sortiment_kl_wg_verteilung` (mandant_id, kjmo, kl_uwg_id, kl_wg_id, kl_owg_id, nielsen_umsatz_anteil_owg, nielsen_umsatz_anteil_uwg, nielsen_artikel_anteil_owg, nielsen_artikel_anteil_uwg, kl_umsatz_anteil_owg, kl_umsatz_anteil_uwg, kl_artikel_anteil_owg, kl_artikel_anteil_uwg, kl_ertrag_anteil_owg, kl_ertrag_anteil_uwg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(kl_uwg_id AS INT64) AS kl_uwg_id, CAST(kl_wg_id AS INT64) AS kl_wg_id, CAST(kl_owg_id AS INT64) AS kl_owg_id, CAST(nielsen_umsatz_anteil_owg AS NUMERIC) AS nielsen_umsatz_anteil_owg, CAST(nielsen_umsatz_anteil_uwg AS NUMERIC) AS nielsen_umsatz_anteil_uwg, CAST(nielsen_artikel_anteil_owg AS NUMERIC) AS nielsen_artikel_anteil_owg, CAST(nielsen_artikel_anteil_uwg AS NUMERIC) AS nielsen_artikel_anteil_uwg, CAST(kl_umsatz_anteil_owg AS NUMERIC) AS kl_umsatz_anteil_owg, CAST(kl_umsatz_anteil_uwg AS NUMERIC) AS kl_umsatz_anteil_uwg, CAST(kl_artikel_anteil_owg AS NUMERIC) AS kl_artikel_anteil_owg, CAST(kl_artikel_anteil_uwg AS NUMERIC) AS kl_artikel_anteil_uwg, CAST(kl_ertrag_anteil_owg AS NUMERIC) AS kl_ertrag_anteil_owg, CAST(kl_ertrag_anteil_uwg AS NUMERIC) AS kl_ertrag_anteil_uwg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sortiment_kl_wg_verteilung`;

-- Table: DBP_DATA.UMLAGERUNG
insert into `dbp_data.umlagerung` (mandant_id, wa_lagerbew_beleg_id, wa_lagerbew_beleg_kj, wa_wup_id, wa_nb_id, dat_buchung_wa, we_lagerbew_beleg_id, we_lagerbew_beleg_kj, we_wup_id, we_nb_id, dat_buchung_we, wrg_id, umlagerung_status_kz, anz_beleg_pos, vk_netto, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wa_lagerbew_beleg_id AS INT64) AS wa_lagerbew_beleg_id, CAST(wa_lagerbew_beleg_kj AS INT64) AS wa_lagerbew_beleg_kj, CAST(wa_wup_id AS INT64) AS wa_wup_id, CAST(wa_nb_id AS INT64) AS wa_nb_id, dat_buchung_wa, CAST(we_lagerbew_beleg_id AS INT64) AS we_lagerbew_beleg_id, CAST(we_lagerbew_beleg_kj AS INT64) AS we_lagerbew_beleg_kj, CAST(we_wup_id AS INT64) AS we_wup_id, CAST(we_nb_id AS INT64) AS we_nb_id, dat_buchung_we, wrg_id, umlagerung_status_kz, CAST(anz_beleg_pos AS INT64) AS anz_beleg_pos, CAST(vk_netto AS NUMERIC) AS vk_netto, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_umlagerung`;

-- Table: DBP_DATA.WUP_PLAN_KJMO_OWG
insert into `dbp_data.wup_plan_kjmo_owg` (wup_id, nb_id, mandant_id, kjmo, hwg_id, wrg_id, umsatz_netto_plan, abschriften_netto_operativ_plan, betrag_vk_netto_inventur_diff_plan, td_update, td_insert)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(hwg_id AS INT64) AS hwg_id, wrg_id, CAST(umsatz_netto_plan AS NUMERIC) AS umsatz_netto_plan, CAST(abschriften_netto_operativ_plan AS NUMERIC) AS abschriften_netto_operativ_plan, CAST(betrag_vk_netto_inventur_diff_plan AS NUMERIC) AS betrag_vk_netto_inventur_diff_plan, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_plan_kjmo_owg`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_PL
insert into `dbp_data.wup_stunden_tag_pl` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_pl`;

-- Table: DBP_DATA.TP_OBJEKT_STATUS_PER
insert into `dbp_data.tp_objekt_status_per` (mandant_id, tp_objekt_nr, tp_objekt_status_id, dat_von, dat_bis, tp_objekt_id, tp_objekt_status_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, tp_objekt_nr, tp_objekt_status_id, dat_von, dat_bis, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, CAST(tp_objekt_status_fg AS INT64) AS tp_objekt_status_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_objekt_status_per`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_ARTICLE_STORE_PRICE
insert into `dbp_msi_view_nfmd.ts_nfmd_article_store_price` (mandant_id, aktion_id, art_id, wup_id, discount_type_name, kjwo_ww, wrg_id, manual_promo_price_gross_local_val, user_id, dwh_created_tmsp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id AS INT64) AS wup_id, discount_type_name, CAST(kjwo_ww AS INT64) AS kjwo_ww, wrg_id, CAST(manual_promo_price_gross_local_val AS NUMERIC) AS manual_promo_price_gross_local_val, user_id, dwh_created_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_article_store_price`;

-- Table: DBP_DATA.SORTIMENT_WG_VERTEILUNG
insert into `dbp_data.sortiment_wg_verteilung` (mandant_id, kjmo, wg_id, wug_id, hwg_id, owg_id, nielsen_umsatz_anteil_owg, nielsen_umsatz_anteil_uwg, nielsen_artikel_anteil_owg, nielsen_artikel_anteil_uwg, kl_umsatz_anteil_owg, kl_umsatz_anteil_uwg, kl_artikel_anteil_owg, kl_artikel_anteil_uwg, kl_ertrag_anteil_owg, kl_ertrag_anteil_uwg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(wg_id AS INT64) AS wg_id, CAST(wug_id AS INT64) AS wug_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(owg_id AS INT64) AS owg_id, CAST(nielsen_umsatz_anteil_owg AS NUMERIC) AS nielsen_umsatz_anteil_owg, CAST(nielsen_umsatz_anteil_uwg AS NUMERIC) AS nielsen_umsatz_anteil_uwg, CAST(nielsen_artikel_anteil_owg AS NUMERIC) AS nielsen_artikel_anteil_owg, CAST(nielsen_artikel_anteil_uwg AS NUMERIC) AS nielsen_artikel_anteil_uwg, CAST(kl_umsatz_anteil_owg AS NUMERIC) AS kl_umsatz_anteil_owg, CAST(kl_umsatz_anteil_uwg AS NUMERIC) AS kl_umsatz_anteil_uwg, CAST(kl_artikel_anteil_owg AS NUMERIC) AS kl_artikel_anteil_owg, CAST(kl_artikel_anteil_uwg AS NUMERIC) AS kl_artikel_anteil_uwg, CAST(kl_ertrag_anteil_owg AS NUMERIC) AS kl_ertrag_anteil_owg, CAST(kl_ertrag_anteil_uwg AS NUMERIC) AS kl_ertrag_anteil_uwg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_sortiment_wg_verteilung`;

-- Table: DBP_DATA.RPM_FIN_KATEGORIE
insert into `dbp_data.rpm_fin_kategorie` (fin_kat_hierarchie_id, fin_kategorie_id, rpm_hierarchie_id, fin_kat_version_id, fin_kat_version_dat, td_insert, td_update)
SELECT fin_kat_hierarchie_id, fin_kategorie_id, rpm_hierarchie_id, fin_kat_version_id, fin_kat_version_dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_rpm_fin_kategorie`;

-- Table: DBP_DATA.ABRECHNUNGSQUALITAET
insert into `dbp_data.abrechnungsqualitaet` (kjmo, gp_id, system_id, mandant_id, einkaufsorganisation_id, rechnung_anz, rechnung_netto, rechnung_maschinell_anz, rechnung_manuell_anz, belastungsanzeigen_anz, belastungsanzeigen_netto, rueckbelastungsanzeigen_anz, rueckbelastungsanzeigen_netto, td_update, td_insert)
SELECT CAST(kjmo AS INT64) AS kjmo, CAST(gp_id AS INT64) AS gp_id, CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(einkaufsorganisation_id AS INT64) AS einkaufsorganisation_id, CAST(rechnung_anz AS INT64) AS rechnung_anz, CAST(rechnung_netto AS NUMERIC) AS rechnung_netto, CAST(rechnung_maschinell_anz AS INT64) AS rechnung_maschinell_anz, CAST(rechnung_manuell_anz AS INT64) AS rechnung_manuell_anz, CAST(belastungsanzeigen_anz AS INT64) AS belastungsanzeigen_anz, CAST(belastungsanzeigen_netto AS NUMERIC) AS belastungsanzeigen_netto, CAST(rueckbelastungsanzeigen_anz AS INT64) AS rueckbelastungsanzeigen_anz, CAST(rueckbelastungsanzeigen_netto AS NUMERIC) AS rueckbelastungsanzeigen_netto, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_abrechnungsqualitaet`;

-- Table: DBP_DATA.HYDRA_RUESTZEIT
insert into `dbp_data.hydra_ruestzeit` (mandant_id, pers_teilbereich_id, dat, praemiengrp_id, transport_gv_id, lagernummer_id, ewm_fg, dauer_ist, dauer_ruest, dauer_wechsel, dauer_sonstiges, abrechnung_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, pers_teilbereich_id, dat, praemiengrp_id, transport_gv_id, lagernummer_id, CAST(ewm_fg AS INT64) AS ewm_fg, CAST(dauer_ist AS NUMERIC) AS dauer_ist, CAST(dauer_ruest AS NUMERIC) AS dauer_ruest, CAST(dauer_wechsel AS NUMERIC) AS dauer_wechsel, CAST(dauer_sonstiges AS NUMERIC) AS dauer_sonstiges, CAST(abrechnung_fg AS INT64) AS abrechnung_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_hydra_ruestzeit`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_RO
insert into `dbp_data.wup_stunden_tag_ro` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_ro`;

-- Table: DBP_DATA.TMS_RECHNUNG
insert into `dbp_data.tms_rechnung` (mandant_id, system_id, tms_rech_beleg_id, tms_rech_lfd_nr, dat_tms_rech_beleg, empfaenger_tms_gp_id, empfaenger_tms_gp_typ_cd, tms_rech_beleg_status_id, wrg_id, tms_rech_sammelbeleg_id, abrechnungslauf_id, tms_rech_storno_beleg_id, dat_storno, storno_fg, manueller_beleg_fg, freigegeben_fg, gedruckt_fg, tms_dispostelle_id, ersteller_tms_gp_id, ersteller_tms_gp_typ_cd, tms_rech_beleg_typ_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_rech_beleg_id AS INT64) AS tms_rech_beleg_id, CAST(tms_rech_lfd_nr AS INT64) AS tms_rech_lfd_nr, dat_tms_rech_beleg, empfaenger_tms_gp_id, empfaenger_tms_gp_typ_cd, CAST(tms_rech_beleg_status_id AS INT64) AS tms_rech_beleg_status_id, wrg_id, tms_rech_sammelbeleg_id, CAST(abrechnungslauf_id AS INT64) AS abrechnungslauf_id, CAST(tms_rech_storno_beleg_id AS INT64) AS tms_rech_storno_beleg_id, dat_storno, CAST(storno_fg AS INT64) AS storno_fg, CAST(manueller_beleg_fg AS INT64) AS manueller_beleg_fg, CAST(freigegeben_fg AS INT64) AS freigegeben_fg, CAST(gedruckt_fg AS INT64) AS gedruckt_fg, CAST(tms_dispostelle_id AS INT64) AS tms_dispostelle_id, ersteller_tms_gp_id, ersteller_tms_gp_typ_cd, CAST(tms_rech_beleg_typ_id AS INT64) AS tms_rech_beleg_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_rechnung`;

-- Table: DBP_DATA.TP_OBJEKT_MERKMAL
insert into `dbp_data.tp_objekt_merkmal` (mandant_id, tp_merkmal_id, tp_objekt_id, dat_von, tp_merkmal_klasse_id, tp_merkmalwert, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tp_merkmal_id AS INT64) AS tp_merkmal_id, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, dat_von, CAST(tp_merkmal_klasse_id AS INT64) AS tp_merkmal_klasse_id, tp_merkmalwert, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tp_objekt_merkmal`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_CZ
insert into `dbp_data.wup_stunden_tag_cz` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_cz`;

-- Table: DBP_MSI_DATA.VIS_MONAT_ABSCHRIFTEN_WUP
insert into `dbp_msi_data.vis_monat_abschriften_wup` (mandant_id, nb_id, wup_id, wrg_id, kjmo, abschriftgruppe_id, gj, abschrift_brutto, abschrift_brutto_kum, abschrift_brutto_kvj, abschrift_brutto_kvj_kum, ums_brutto, ums_brutto_kum, ums_brutto_kvj, ums_brutto_kvj_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(kjmo AS INT64) AS kjmo, CAST(abschriftgruppe_id AS INT64) AS abschriftgruppe_id, CAST(gj AS INT64) AS gj, CAST(abschrift_brutto AS NUMERIC) AS abschrift_brutto, CAST(abschrift_brutto_kum AS NUMERIC) AS abschrift_brutto_kum, CAST(abschrift_brutto_kvj AS NUMERIC) AS abschrift_brutto_kvj, CAST(abschrift_brutto_kvj_kum AS NUMERIC) AS abschrift_brutto_kvj_kum, CAST(ums_brutto AS NUMERIC) AS ums_brutto, CAST(ums_brutto_kum AS NUMERIC) AS ums_brutto_kum, CAST(ums_brutto_kvj AS NUMERIC) AS ums_brutto_kvj, CAST(ums_brutto_kvj_kum AS NUMERIC) AS ums_brutto_kvj_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_abschriften_wup`;

-- Table: DBP_DATA.RPM_FIN_PLAN
insert into `dbp_data.rpm_fin_plan` (fin_gruppe_hierarchie_id, dat_start, rpm_plantyp_id, dat_von, wrg_id, mandant_id, betrag, dat_bis, td_update, td_insert)
SELECT fin_gruppe_hierarchie_id, dat_start, CAST(rpm_plantyp_id AS INT64) AS rpm_plantyp_id, dat_von, wrg_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(betrag AS NUMERIC) AS betrag, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_fin_plan`;

-- Table: DBP_DATA.MA_HR_MASSNAHME_ZU_PER
insert into `dbp_data.ma_hr_massnahme_zu_per` (mandant_id, hr_massnahme_grund_id, hr_massnahme_id, mitarbeiter_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, hr_massnahme_grund_id, hr_massnahme_id, mitarbeiter_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_hr_massnahme_zu_per`;

-- Table: DBP_ODS.ODS_BON_KUNDE_PROGNOSE
insert into `dbp_ods.ods_bon_kunde_prognose` (mandant_id, wup_id, nb_id, dat, zeit_stunde, zeit_minute, anz_kunden, anz_kunden_prognose, anz_kunden_prognose_dyn, anz_kassen_offen, anz_kassen_prognose, anz_kassen_prognose_dyn, datzeit_update, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(zeit_stunde AS INT64) AS zeit_stunde, CAST(zeit_minute AS INT64) AS zeit_minute, CAST(anz_kunden AS INT64) AS anz_kunden, CAST(anz_kunden_prognose AS NUMERIC) AS anz_kunden_prognose, CAST(anz_kunden_prognose_dyn AS NUMERIC) AS anz_kunden_prognose_dyn, CAST(anz_kassen_offen AS INT64) AS anz_kassen_offen, CAST(anz_kassen_prognose AS INT64) AS anz_kassen_prognose, CAST(anz_kassen_prognose_dyn AS INT64) AS anz_kassen_prognose_dyn, datzeit_update, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_kunde_prognose`;

-- Table: DBP_DATA.TMS_RECHNUNG_DET_ZU
insert into `dbp_data.tms_rechnung_det_zu` (mandant_id, system_id, tms_rech_beleg_id, tms_rech_beleg_pos_id, tms_rech_bezug_lfd_nr, bezugsart_id, bezug_schluessel_nr, tms_ref_nr, tms_ref_unter_nr, tms_ref_pos_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_rech_beleg_id AS INT64) AS tms_rech_beleg_id, tms_rech_beleg_pos_id, CAST(tms_rech_bezug_lfd_nr AS INT64) AS tms_rech_bezug_lfd_nr, CAST(bezugsart_id AS INT64) AS bezugsart_id, bezug_schluessel_nr, tms_ref_nr, tms_ref_unter_nr, tms_ref_pos_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_rechnung_det_zu`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_KOSTEN
insert into `dbp_data.transportation_unit_kosten` (mandant_id, wup_id, nb_id, transportation_unit_id, kj_transportation_unit, wrg_id, betrag_diesel, betrag_strom, betrag_gas, betrag_maut, betrag_kuehlung, betrag_sonstiges, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, wrg_id, CAST(betrag_diesel AS NUMERIC) AS betrag_diesel, CAST(betrag_strom AS NUMERIC) AS betrag_strom, CAST(betrag_gas AS NUMERIC) AS betrag_gas, CAST(betrag_maut AS NUMERIC) AS betrag_maut, CAST(betrag_kuehlung AS NUMERIC) AS betrag_kuehlung, CAST(betrag_sonstiges AS NUMERIC) AS betrag_sonstiges, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_kosten`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_PER
insert into `dbp_data.immo_mietvertrag_per` (mandant_id, mv_intreno, dat_miet_beginn, mietvertrag_nr, mv_objekt_nr, vertragsart_id, branche_id, man_vermietungsauftrag_id, anschluss_mietvertrag, anlass_zwvermietung_id, partner_id, mv_option, dat_kuend_eingang_bis, dat_kuend_berechnet_zum, kuend_partei, kuend_frist, dat_miet_ende, anz_laufzeit_monate, dat_ankuendigung_bis, dat_naechstes_vertragsende, dat_naechstm_eigene_kuendigung, dat_naechstm_partner_kuendigung, mv_option_bez, buchungskreis_id, mietvertrag_nr_alt, dat_aktivierung, vertragsgegenstand_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, dat_miet_beginn, mietvertrag_nr, mv_objekt_nr, CAST(vertragsart_id AS INT64) AS vertragsart_id, CAST(branche_id AS INT64) AS branche_id, CAST(man_vermietungsauftrag_id AS INT64) AS man_vermietungsauftrag_id, anschluss_mietvertrag, CAST(anlass_zwvermietung_id AS INT64) AS anlass_zwvermietung_id, partner_id, mv_option, dat_kuend_eingang_bis, dat_kuend_berechnet_zum, kuend_partei, kuend_frist, dat_miet_ende, CAST(anz_laufzeit_monate AS INT64) AS anz_laufzeit_monate, dat_ankuendigung_bis, dat_naechstes_vertragsende, dat_naechstm_eigene_kuendigung, dat_naechstm_partner_kuendigung, mv_option_bez, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, mietvertrag_nr_alt, dat_aktivierung, CAST(vertragsgegenstand_id AS INT64) AS vertragsgegenstand_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_per`;

-- Table: DBP_DATA.ORG_EINHEIT_PER
insert into `dbp_data.org_einheit_per` (mandant_id, hr_objekt_id, kjmo, dat_von, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, CAST(kjmo AS INT64) AS kjmo, dat_von, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_org_einheit_per`;

-- Table: DBP_DATA.PMR_ANGEBOT_BESCHREIBUNG
insert into `dbp_data.pmr_angebot_beschreibung` (angebot_id, angebot_beschreibung, td_update, td_insert)
SELECT CAST(angebot_id AS INT64) AS angebot_id, angebot_beschreibung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_pmr_angebot_beschreibung`;

-- Table: DBP_DATA.RPM_ELEMENT_SPR_ZU
insert into `dbp_data.rpm_element_spr_zu` (rpm_element_id, spr_id, dat_von, rpm_element_bez, rpm_element_langtext, td_update, td_insert)
SELECT rpm_element_id, CAST(spr_id AS INT64) AS spr_id, dat_von, rpm_element_bez, rpm_element_langtext, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_element_spr_zu`;

-- Table: DBP_MSI_DATA.VIS_MONAT_GP_WUP_PROBLEME
insert into `dbp_msi_data.vis_monat_gp_wup_probleme` (mandant_id, kjmo, wup_id, nb_id, gp_id, problemcode_id, anz_fehler, anz_fehler_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(gp_id AS INT64) AS gp_id, problemcode_id, CAST(anz_fehler AS INT64) AS anz_fehler, CAST(anz_fehler_kum AS INT64) AS anz_fehler_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_gp_wup_probleme`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_UMSATZVEREINBARUNG_PER
insert into `dbp_data.immo_mietvertrag_umsatzvereinbarung_per` (mandant_id, mv_intreno, melderegel, version, kjmo, rhythmus_art, dat_meldungsintervall_von, dat_meldungsintervall_bis, wrg_id, umsatzkennung, nullumsatz, umsatz_netto, umsatz_brutto, erfasser, dat_ersterfassung, dat_letzte_bearbeitung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, melderegel, version, CAST(kjmo AS INT64) AS kjmo, rhythmus_art, dat_meldungsintervall_von, dat_meldungsintervall_bis, wrg_id, umsatzkennung, nullumsatz, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, erfasser, dat_ersterfassung, dat_letzte_bearbeitung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_umsatzvereinbarung_per`;

-- Table: DBP_DATA.RPM_HIER_BED_KONZEPT_ZU_PER
insert into `dbp_data.rpm_hier_bed_konzept_zu_per` (bedienkonzept_id, rpm_hierarchie_id, dat_von, rpm_tab_id, dat_bis, dat_bedienkonzept, bedienkonzept_auspr_id, td_update, td_insert)
SELECT CAST(bedienkonzept_id AS INT64) AS bedienkonzept_id, rpm_hierarchie_id, dat_von, CAST(rpm_tab_id AS INT64) AS rpm_tab_id, dat_bis, dat_bedienkonzept, CAST(bedienkonzept_auspr_id AS INT64) AS bedienkonzept_auspr_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_hier_bed_konzept_zu_per`;

-- Table: DBP_DATA.TMS_AUFTRAG_TEXT
insert into `dbp_data.tms_auftrag_text` (mandant_id, system_id, tms_auftrag_text_id, tms_satzart_id, tms_auftrag_id, tms_auftrag_unter_id, tms_text_typ_cd, auftrag_txt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_auftrag_text_id AS INT64) AS tms_auftrag_text_id, CAST(tms_satzart_id AS INT64) AS tms_satzart_id, tms_auftrag_id, CAST(tms_auftrag_unter_id AS INT64) AS tms_auftrag_unter_id, tms_text_typ_cd, auftrag_txt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_auftrag_text`;

-- Table: DBP_DATA.TMS_AUFTRAG_VERPACKUNG
insert into `dbp_data.tms_auftrag_verpackung` (mandant_id, system_id, tms_verpackung_id, tms_verpackung_lfd_nr, tms_auftrag_id, tms_auftrag_unter_id, tms_transportmittel_id, anz_verpackung, tms_verpackung_bem_txt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_verpackung_id AS INT64) AS tms_verpackung_id, tms_verpackung_lfd_nr, tms_auftrag_id, CAST(tms_auftrag_unter_id AS INT64) AS tms_auftrag_unter_id, CAST(tms_transportmittel_id AS INT64) AS tms_transportmittel_id, CAST(anz_verpackung AS INT64) AS anz_verpackung, tms_verpackung_bem_txt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_auftrag_verpackung`;

-- Table: DBP_DATA.TP_OBJEKT_ADRESSE_ZU_PER
insert into `dbp_data.tp_objekt_adresse_zu_per` (mandant_id, tp_objekt_id, werk_id, standort_id, tp_objekt_sort_id, dat_von, dat_bis, instandhaltung_werk_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, CAST(werk_id AS INT64) AS werk_id, standort_id, tp_objekt_sort_id, dat_von, dat_bis, CAST(instandhaltung_werk_id AS INT64) AS instandhaltung_werk_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_objekt_adresse_zu_per`;

-- Table: DBP_DATA.TP_OBJEKT_SPR_ZU
insert into `dbp_data.tp_objekt_spr_zu` (mandant_id, tp_objekt_id, spr_id, tp_objekt_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, CAST(spr_id AS INT64) AS spr_id, tp_objekt_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_objekt_spr_zu`;

-- Table: DBP_DATA.T_DIM_IOT_DEVICE
insert into `dbp_data.t_dim_iot_device` (device_id, device_number, device_model, device_location, td_update, td_insert)
SELECT device_id, device_number, device_model, device_location, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_t_dim_iot_device`;

-- Table: DBP_DATA.PREDICT_COMPETITORS_KAUFLAND_ZU
insert into `dbp_data.predict_competitors_kaufland_zu` (google_place_id, kjmo, mandant_id, wup_id, airline_distance, td_update, td_insert)
SELECT google_place_id, CAST(kjmo AS INT64) AS kjmo, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(airline_distance AS NUMERIC) AS airline_distance, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_predict_competitors_kaufland_zu`;

-- Table: DBP_DATA.SB_BEURTEILUNG
insert into `dbp_data.sb_beurteilung` (beurteilung_id, beurteiler_id, mandant_id, wup_id, note_gesamt, eindruck_gesamt, dat_beurteilung, zeit_beurteilung, hl_anwesend_fg, chef_tag_fg, hotday_fg, frueh_kz, tf_fg, dat_erfassung, loesch_fg, pep_fg, kennzahl_fg, sb_checkliste_typ_id, td_insert, td_update)
SELECT CAST(beurteilung_id AS INT64) AS beurteilung_id, CAST(beurteiler_id AS INT64) AS beurteiler_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(note_gesamt AS NUMERIC) AS note_gesamt, eindruck_gesamt, dat_beurteilung, CAST(zeit_beurteilung AS INT64) AS zeit_beurteilung, CAST(hl_anwesend_fg AS INT64) AS hl_anwesend_fg, CAST(chef_tag_fg AS INT64) AS chef_tag_fg, CAST(hotday_fg AS INT64) AS hotday_fg, frueh_kz, CAST(tf_fg AS INT64) AS tf_fg, dat_erfassung, CAST(loesch_fg AS INT64) AS loesch_fg, CAST(pep_fg AS INT64) AS pep_fg, CAST(kennzahl_fg AS INT64) AS kennzahl_fg, CAST(sb_checkliste_typ_id AS INT64) AS sb_checkliste_typ_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteilung`;

-- Table: DBP_DATA.TECHN_PLATZ_SPR_ZU_PER
insert into `dbp_data.techn_platz_spr_zu_per` (techn_platz_id, spr_id, dat_von, dat_bis, tech_platz_bez, td_insert, td_update)
SELECT techn_platz_id, CAST(spr_id AS INT64) AS spr_id, dat_von, dat_bis, tech_platz_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_techn_platz_spr_zu_per`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_SK
insert into `dbp_data.wup_stunden_tag_sk` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_sk`;

-- Table: DBP_MSI_DATA.KAMPAGNE_VORLAGE_MO_SUM
insert into `dbp_msi_data.kampagne_vorlage_mo_sum` (mandant_id, kampagne_id, kjmo, nachricht_vorlage_id, kommunikationskanal_id, nachricht_subvorlage_name_liste_txt, kampagne_name, dat_kampagne_von, kampagne_rhythmus_typ_id, kampagne_version_nr, nachricht_vorlage_titel_txt, nachricht_vorlage_txt, nachricht_vorlage_url_txt, nachricht_vorlage_bild_id, anz_kampagne_kunde_gesamt, anz_kunde_gesendet, rate_kunde_gesendet, anz_kunde_blockiert, rate_kunde_blockiert, anz_kunde_zugestellt, rate_kunde_zugestellt, anz_kunde_bounced_soft, rate_kunde_bounced_soft, anz_kunde_bounced_hard, rate_kunde_bounced_hard, anz_kunde_geoeffnet, rate_kunde_geoeffnet_zugestellt, anz_kunde_geklickt, rate_kunde_geklickt_gesendet, rate_kunde_geklickt_geoeffnet, rate_kunde_geklickt_zugestellt, anz_kunde_spam, rate_kunde_spam, anz_kunde_abgemeldet, rate_kunde_abgemeldet, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kampagne_id, CAST(kjmo AS INT64) AS kjmo, nachricht_vorlage_id, CAST(kommunikationskanal_id AS INT64) AS kommunikationskanal_id, nachricht_subvorlage_name_liste_txt, kampagne_name, dat_kampagne_von, CAST(kampagne_rhythmus_typ_id AS INT64) AS kampagne_rhythmus_typ_id, CAST(kampagne_version_nr AS INT64) AS kampagne_version_nr, nachricht_vorlage_titel_txt, nachricht_vorlage_txt, nachricht_vorlage_url_txt, nachricht_vorlage_bild_id, CAST(anz_kampagne_kunde_gesamt AS INT64) AS anz_kampagne_kunde_gesamt, CAST(anz_kunde_gesendet AS INT64) AS anz_kunde_gesendet, CAST(rate_kunde_gesendet AS NUMERIC) AS rate_kunde_gesendet, CAST(anz_kunde_blockiert AS INT64) AS anz_kunde_blockiert, CAST(rate_kunde_blockiert AS NUMERIC) AS rate_kunde_blockiert, CAST(anz_kunde_zugestellt AS INT64) AS anz_kunde_zugestellt, CAST(rate_kunde_zugestellt AS NUMERIC) AS rate_kunde_zugestellt, CAST(anz_kunde_bounced_soft AS INT64) AS anz_kunde_bounced_soft, CAST(rate_kunde_bounced_soft AS NUMERIC) AS rate_kunde_bounced_soft, CAST(anz_kunde_bounced_hard AS INT64) AS anz_kunde_bounced_hard, CAST(rate_kunde_bounced_hard AS NUMERIC) AS rate_kunde_bounced_hard, CAST(anz_kunde_geoeffnet AS INT64) AS anz_kunde_geoeffnet, CAST(rate_kunde_geoeffnet_zugestellt AS NUMERIC) AS rate_kunde_geoeffnet_zugestellt, CAST(anz_kunde_geklickt AS INT64) AS anz_kunde_geklickt, CAST(rate_kunde_geklickt_gesendet AS NUMERIC) AS rate_kunde_geklickt_gesendet, CAST(rate_kunde_geklickt_geoeffnet AS NUMERIC) AS rate_kunde_geklickt_geoeffnet, CAST(rate_kunde_geklickt_zugestellt AS NUMERIC) AS rate_kunde_geklickt_zugestellt, CAST(anz_kunde_spam AS INT64) AS anz_kunde_spam, CAST(rate_kunde_spam AS NUMERIC) AS rate_kunde_spam, CAST(anz_kunde_abgemeldet AS INT64) AS anz_kunde_abgemeldet, CAST(rate_kunde_abgemeldet AS NUMERIC) AS rate_kunde_abgemeldet, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_kampagne_vorlage_mo_sum`;

-- Table: DBP_MSI_DATA.USER_WUP_ZU
insert into `dbp_msi_data.user_wup_zu` (user_id, mandant_id, wup_id, td_insert, td_update)
SELECT user_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_wup_zu`;

-- Table: DBP_ODS_ARCHIV.ODS_BON_KASSENABSCHLUSS
insert into `dbp_ods_archiv.ods_bon_kassenabschluss` (bon_id, bon_dat, wup_id, mandant_id, anz_kunden, umsatz_brutto, anz_kunden_imbiss, td_insert, td_update)
SELECT bon_id, bon_dat, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(anz_kunden AS INT64) AS anz_kunden, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(anz_kunden_imbiss AS INT64) AS anz_kunden_imbiss, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_bon_kassenabschluss`;

-- Table: DBP_DATA.IMMO_MIETOBJEKT
insert into `dbp_data.immo_mietobjekt` (mandant_id, mo_intreno, mo_objekt_nr, mo_smenr, branche_id, mo_typ_id, mo_art_kz, mo_nutzung_id, we_intreno, dat_mo_gueltig_von, dat_mo_gueltig_bis, gebaeude_nr, dat_akqu_vor_ort, dat_akqu_wettbewerber, dat_akqu_ansprache_filialist, dat_akqu_ansprache_mieter, dat_akqu_info_hl_ma_praemie, dat_akqu_flaeche_verblendung, dat_akqu_teambesprechung, dat_akqu_angebot_homepage, dat_akqu_internetrecherche, dat_akqu_spanntranspar_geb, dat_akqu_inserat_tageszeitung, dat_akqu_inserat_tip, dat_akqu_telefon, dat_akqu_amt_wirtschaftsfoerderung, dat_akqu_suche_biete, dat_akqu_internetauktion, dat_akqu_sonstige, akqu_ergebnis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mo_intreno, mo_objekt_nr, mo_smenr, CAST(branche_id AS INT64) AS branche_id, CAST(mo_typ_id AS INT64) AS mo_typ_id, mo_art_kz, CAST(mo_nutzung_id AS INT64) AS mo_nutzung_id, we_intreno, dat_mo_gueltig_von, dat_mo_gueltig_bis, CAST(gebaeude_nr AS INT64) AS gebaeude_nr, dat_akqu_vor_ort, dat_akqu_wettbewerber, dat_akqu_ansprache_filialist, dat_akqu_ansprache_mieter, dat_akqu_info_hl_ma_praemie, dat_akqu_flaeche_verblendung, dat_akqu_teambesprechung, dat_akqu_angebot_homepage, dat_akqu_internetrecherche, dat_akqu_spanntranspar_geb, dat_akqu_inserat_tageszeitung, dat_akqu_inserat_tip, dat_akqu_telefon, dat_akqu_amt_wirtschaftsfoerderung, dat_akqu_suche_biete, dat_akqu_internetauktion, dat_akqu_sonstige, akqu_ergebnis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietobjekt`;

-- Table: DBP_DATA.PMR_ANGEBOT_WERBEMITTEL_ZU
insert into `dbp_data.pmr_angebot_werbemittel_zu` (mandant_id, angebot_id, werbemittel_art_id, werbemittel_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(angebot_id AS INT64) AS angebot_id, werbemittel_art_id, CAST(werbemittel_id AS INT64) AS werbemittel_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_pmr_angebot_werbemittel_zu`;

-- Table: DBP_DATA.PSP_ELEMENT
insert into `dbp_data.psp_element` (psp_id, system_id, projekt_id, projektart_id, kostenstelle_id, pc_id, krk_id, wup_id, nb_id, buchungskreis_id, benutzerfeld_1, benutzerfeld_2, benutzerfeld_4, dat_von, last_upd_dat, geschaeftsbereich_id, it_relevant_fg, psp_bez, mandant_id, td_insert, td_update)
SELECT psp_id, CAST(system_id AS INT64) AS system_id, projekt_id, CAST(projektart_id AS INT64) AS projektart_id, kostenstelle_id, pc_id, krk_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, benutzerfeld_1, benutzerfeld_2, benutzerfeld_4, dat_von, last_upd_dat, geschaeftsbereich_id, CAST(it_relevant_fg AS INT64) AS it_relevant_fg, psp_bez, CAST(mandant_id AS INT64) AS mandant_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_psp_element`;

-- Table: DBP_DATA.WUPCAL_MO_SUM
insert into `dbp_data.wupcal_mo_sum` (wup_id, mandant_id, nb_id, kjmo, gjmo, anzahl_oeff_tage, offen, bonanzahl, anzahl_lief_tage, bonanzahl_gastro, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(gjmo AS INT64) AS gjmo, CAST(anzahl_oeff_tage AS INT64) AS anzahl_oeff_tage, CAST(offen AS INT64) AS offen, CAST(bonanzahl AS INT64) AS bonanzahl, CAST(anzahl_lief_tage AS INT64) AS anzahl_lief_tage, CAST(bonanzahl_gastro AS INT64) AS bonanzahl_gastro, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wupcal_mo_sum`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_BG
insert into `dbp_data.wup_stunden_tag_bg` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_bg`;

-- Table: DBP_MSI_DATA.SORT_SOLL_LISTUNG
insert into `dbp_msi_data.sort_soll_listung` (mandant_id, art_id, sm_id, anzahl, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(sm_id AS INT64) AS sm_id, CAST(anzahl AS INT64) AS anzahl, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_sort_soll_listung`;

-- Table: DBP_DATA.IMMO_MV_PARTNER_ROLLE_ZU
insert into `dbp_data.immo_mv_partner_rolle_zu` (mandant_id, mv_intreno, rolle_kz, partner_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, rolle_kz, partner_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mv_partner_rolle_zu`;

-- Table: DBP_DATA.PREDICT_GOOGLE_REVIEW_COMPETITORS
insert into `dbp_data.predict_google_review_competitors` (google_place_id, kjmo, predict_review_count, predict_rating_avg, td_update, td_insert)
SELECT google_place_id, CAST(kjmo AS INT64) AS kjmo, CAST(predict_review_count AS INT64) AS predict_review_count, CAST(predict_rating_avg AS NUMERIC) AS predict_rating_avg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_predict_google_review_competitors`;

-- Table: DBP_DATA.RPM_HIERARCHIE_ZU_PER
insert into `dbp_data.rpm_hierarchie_zu_per` (rpm_hierarchie_id, dat_von, dat_bis, rpm_bereich_id, rpm_ebene_id, rpm_hierarchie_mutter_id, td_insert, td_update)
SELECT rpm_hierarchie_id, dat_von, dat_bis, rpm_bereich_id, CAST(rpm_ebene_id AS INT64) AS rpm_ebene_id, rpm_hierarchie_mutter_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_rpm_hierarchie_zu_per`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_HR
insert into `dbp_data.wup_stunden_tag_hr` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_hr`;

-- Table: DBP_MSI_DATA.VIS_MONAT_KER_WUP
insert into `dbp_msi_data.vis_monat_ker_wup` (mandant_id, nb_id, wup_id, wrg_id, kjmo, ker_lv, ker_id, vvj_jahr, vj_jahr, plan_jahr, vj_kum, ist_kum, plan_kum, vj, ist, plan, ums_vvj_jahr, ums_vj_jahr, ums_plan_jahr, ums_vj_kum, ums_ist_kum, ums_plan_kum, ums_vj, ums_ist, ums_plan, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(kjmo AS INT64) AS kjmo, CAST(ker_lv AS INT64) AS ker_lv, ker_id, CAST(vvj_jahr AS NUMERIC) AS vvj_jahr, CAST(vj_jahr AS NUMERIC) AS vj_jahr, CAST(plan_jahr AS NUMERIC) AS plan_jahr, CAST(vj_kum AS NUMERIC) AS vj_kum, CAST(ist_kum AS NUMERIC) AS ist_kum, CAST(plan_kum AS NUMERIC) AS plan_kum, CAST(vj AS NUMERIC) AS vj, CAST(ist AS NUMERIC) AS ist, CAST(plan AS NUMERIC) AS plan, CAST(ums_vvj_jahr AS NUMERIC) AS ums_vvj_jahr, CAST(ums_vj_jahr AS NUMERIC) AS ums_vj_jahr, CAST(ums_plan_jahr AS NUMERIC) AS ums_plan_jahr, CAST(ums_vj_kum AS NUMERIC) AS ums_vj_kum, CAST(ums_ist_kum AS NUMERIC) AS ums_ist_kum, CAST(ums_plan_kum AS NUMERIC) AS ums_plan_kum, CAST(ums_vj AS NUMERIC) AS ums_vj, CAST(ums_ist AS NUMERIC) AS ums_ist, CAST(ums_plan AS NUMERIC) AS ums_plan, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_ker_wup`;

-- Table: DBP_MSI_DATA.VIS_MONAT_SHR_WUP
insert into `dbp_msi_data.vis_monat_shr_wup` (mandant_id, wup_id, nb_id, kjmo, stunden_arztbesuch, stunden_aushilfen, stunden_azubi, stunden_bezahlte_pausen, stunden_brutto, stunden_entlastung_azubi, stunden_entlastung_praktikanten, stunden_extern, stunden_feiertag, stunden_freistellung, stunden_freizeitausgleich, stunden_grund, stunden_krank, stunden_krank_bezahlt, stunden_mehr_abgrenzung, stunden_mehr_geleistet, stunden_mehrarbeit, stunden_netto, stunden_praktikanten, stunden_schulung, stunden_soll, stunden_urlaub, stunden_versetzung_abgegeben, stunden_versetzung_erhalten, stunden_zuschlag_feiertag, stunden_zuschlag_mehr, stunden_zuschlag_spaet_nacht, stunden_zuschlag_wochenende, stunden_umbau, stunden_minus_aufbau, stunden_minus_abbau, stunden_sonstige, tage_urlaub_abgeltung_kj_kum, tage_urlaub_anspruch_akt_kj, tage_urlaub_genommen_kj_kum, tage_urlaub_rest_vj_kj, kopf_extern, tage_krank, tage_arbeit_soll, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(stunden_arztbesuch AS NUMERIC) AS stunden_arztbesuch, CAST(stunden_aushilfen AS NUMERIC) AS stunden_aushilfen, CAST(stunden_azubi AS NUMERIC) AS stunden_azubi, CAST(stunden_bezahlte_pausen AS NUMERIC) AS stunden_bezahlte_pausen, CAST(stunden_brutto AS NUMERIC) AS stunden_brutto, CAST(stunden_entlastung_azubi AS NUMERIC) AS stunden_entlastung_azubi, CAST(stunden_entlastung_praktikanten AS NUMERIC) AS stunden_entlastung_praktikanten, CAST(stunden_extern AS NUMERIC) AS stunden_extern, CAST(stunden_feiertag AS NUMERIC) AS stunden_feiertag, CAST(stunden_freistellung AS NUMERIC) AS stunden_freistellung, CAST(stunden_freizeitausgleich AS NUMERIC) AS stunden_freizeitausgleich, CAST(stunden_grund AS NUMERIC) AS stunden_grund, CAST(stunden_krank AS NUMERIC) AS stunden_krank, CAST(stunden_krank_bezahlt AS NUMERIC) AS stunden_krank_bezahlt, CAST(stunden_mehr_abgrenzung AS NUMERIC) AS stunden_mehr_abgrenzung, CAST(stunden_mehr_geleistet AS NUMERIC) AS stunden_mehr_geleistet, CAST(stunden_mehrarbeit AS NUMERIC) AS stunden_mehrarbeit, CAST(stunden_netto AS NUMERIC) AS stunden_netto, CAST(stunden_praktikanten AS NUMERIC) AS stunden_praktikanten, CAST(stunden_schulung AS NUMERIC) AS stunden_schulung, CAST(stunden_soll AS NUMERIC) AS stunden_soll, CAST(stunden_urlaub AS NUMERIC) AS stunden_urlaub, CAST(stunden_versetzung_abgegeben AS NUMERIC) AS stunden_versetzung_abgegeben, CAST(stunden_versetzung_erhalten AS NUMERIC) AS stunden_versetzung_erhalten, CAST(stunden_zuschlag_feiertag AS NUMERIC) AS stunden_zuschlag_feiertag, CAST(stunden_zuschlag_mehr AS NUMERIC) AS stunden_zuschlag_mehr, CAST(stunden_zuschlag_spaet_nacht AS NUMERIC) AS stunden_zuschlag_spaet_nacht, CAST(stunden_zuschlag_wochenende AS NUMERIC) AS stunden_zuschlag_wochenende, CAST(stunden_umbau AS NUMERIC) AS stunden_umbau, CAST(stunden_minus_aufbau AS NUMERIC) AS stunden_minus_aufbau, CAST(stunden_minus_abbau AS NUMERIC) AS stunden_minus_abbau, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(tage_urlaub_abgeltung_kj_kum AS NUMERIC) AS tage_urlaub_abgeltung_kj_kum, CAST(tage_urlaub_anspruch_akt_kj AS NUMERIC) AS tage_urlaub_anspruch_akt_kj, CAST(tage_urlaub_genommen_kj_kum AS NUMERIC) AS tage_urlaub_genommen_kj_kum, CAST(tage_urlaub_rest_vj_kj AS NUMERIC) AS tage_urlaub_rest_vj_kj, CAST(kopf_extern AS NUMERIC) AS kopf_extern, CAST(tage_krank AS NUMERIC) AS tage_krank, CAST(tage_arbeit_soll AS NUMERIC) AS tage_arbeit_soll, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_shr_wup`;

-- Table: DBP_MSI_DATA.VIS_TAG_RETOUREN_WG
insert into `dbp_msi_data.vis_tag_retouren_wg` (mandant_id, wup_id, nb_id, arthiertyp_id, wg_id, dat, wrg_id, reklamationsgrund_id, abt_id, gj, kjmo, kjwo, vk_menge_re, vk_netto_re, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, dat, wrg_id, CAST(reklamationsgrund_id AS INT64) AS reklamationsgrund_id, CAST(abt_id AS INT64) AS abt_id, CAST(gj AS INT64) AS gj, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo AS INT64) AS kjwo, CAST(vk_menge_re AS NUMERIC) AS vk_menge_re, CAST(vk_netto_re AS NUMERIC) AS vk_netto_re, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_tag_retouren_wg`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_SICHERHEIT
insert into `dbp_data.immo_mietvertrag_sicherheit` (mandant_id, mv_intreno, sicherheit_lfd_nr, beschreibung, sicherheit_typ, dat_bis, betrag_soll, soll_wrg_id, betrag_ist, ist_wrg_id, dat_eingeloest_am, dat_rueckgabe_am, dat_eingang_am, dat_uebergabe_am, buergschaft_nr, buergschaft_grund, rueckgabe_voraussetzung, bank_id, kaution_bez, dat_ausstellung_am, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, CAST(sicherheit_lfd_nr AS INT64) AS sicherheit_lfd_nr, beschreibung, CAST(sicherheit_typ AS INT64) AS sicherheit_typ, dat_bis, CAST(betrag_soll AS NUMERIC) AS betrag_soll, soll_wrg_id, CAST(betrag_ist AS NUMERIC) AS betrag_ist, ist_wrg_id, dat_eingeloest_am, dat_rueckgabe_am, dat_eingang_am, dat_uebergabe_am, buergschaft_nr, buergschaft_grund, rueckgabe_voraussetzung, bank_id, kaution_bez, dat_ausstellung_am, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_sicherheit`;

-- Table: DBP_DATA.KMR_PRUEFPROGRAMM_HAUPTBEREICH
insert into `dbp_data.kmr_pruefprogramm_hauptbereich` (amx_system_id, hauptbereich_id, pruefung_id, pruefprogramm_id, kapitel_nr, sort_nr, fehlerverdacht_fg, hauptbereich_bez, gepr_prozess_id, ergebnis, ergebnis_berechnet, ergebnis_manuell, td_update, td_insert)
SELECT CAST(amx_system_id AS INT64) AS amx_system_id, CAST(hauptbereich_id AS INT64) AS hauptbereich_id, CAST(pruefung_id AS INT64) AS pruefung_id, CAST(pruefprogramm_id AS INT64) AS pruefprogramm_id, kapitel_nr, CAST(sort_nr AS INT64) AS sort_nr, CAST(fehlerverdacht_fg AS INT64) AS fehlerverdacht_fg, hauptbereich_bez, CAST(gepr_prozess_id AS INT64) AS gepr_prozess_id, CAST(ergebnis AS INT64) AS ergebnis, CAST(ergebnis_berechnet AS INT64) AS ergebnis_berechnet, CAST(ergebnis_manuell AS INT64) AS ergebnis_manuell, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_kmr_pruefprogramm_hauptbereich`;

-- Table: DBP_DATA.TP_OBJEKT_STATUS_SPR_ZU
insert into `dbp_data.tp_objekt_status_spr_zu` (mandant_id, tp_objekt_status_id, spr_id, tp_objekt_status_kbez, tp_objekt_status_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, tp_objekt_status_id, CAST(spr_id AS INT64) AS spr_id, tp_objekt_status_kbez, tp_objekt_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_objekt_status_spr_zu`;

-- Table: DBP_DATA.WUP_ART_GP_KORREKTUR
insert into `dbp_data.wup_art_gp_korrektur` (mandant_id, wup_id, nb_id, art_id, dat_vk, dat_korrektur, gp_alt_id, gp_neu_id, bq_findung_alt_id, bq_findung_neu_id, menge_vk_bme, betrag_umsatz_netto, betrag_ek_netto_alt, betrag_ek_netto_neu, betrag_ek_mep_alt, betrag_ek_mep_neu, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_vk, dat_korrektur, CAST(gp_alt_id AS INT64) AS gp_alt_id, CAST(gp_neu_id AS INT64) AS gp_neu_id, CAST(bq_findung_alt_id AS INT64) AS bq_findung_alt_id, CAST(bq_findung_neu_id AS INT64) AS bq_findung_neu_id, CAST(menge_vk_bme AS NUMERIC) AS menge_vk_bme, CAST(betrag_umsatz_netto AS NUMERIC) AS betrag_umsatz_netto, CAST(betrag_ek_netto_alt AS NUMERIC) AS betrag_ek_netto_alt, CAST(betrag_ek_netto_neu AS NUMERIC) AS betrag_ek_netto_neu, CAST(betrag_ek_mep_alt AS NUMERIC) AS betrag_ek_mep_alt, CAST(betrag_ek_mep_neu AS NUMERIC) AS betrag_ek_mep_neu, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_art_gp_korrektur`;

-- Table: DBP_ETL_PROCESS.PERSONALSTD
insert into `dbp_etl_process.personalstd` (mandant_id, wup_id, nb_id, kjmo, stunden_ist, stunden_plan, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(stunden_ist AS NUMERIC) AS stunden_ist, CAST(stunden_plan AS INT64) AS stunden_plan, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_personalstd`;

-- Table: DBP_ODS.ODS_BON_KOPF_UPD_KUNDENKARTE_WUP_2600
insert into `dbp_ods.ods_bon_kopf_upd_kundenkarte_wup_2600` (bon_id, bon_dat, wup_id, bon_end_date, kundenkarte_id, insert_date, mandant_id, bon_day, td_update, td_insert)
SELECT bon_id, bon_dat, CAST(wup_id AS INT64) AS wup_id, bon_end_date, kundenkarte_id, insert_date, CAST(mandant_id AS INT64) AS mandant_id, CAST(bon_day AS INT64) AS bon_day, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_ods_bon_kopf_upd_kundenkarte_wup_2600`;

-- Table: DBP_ODS_ARCHIV.ODS_FINANZ01
insert into `dbp_ods_archiv.ods_finanz01` (mandant_id, wup_id, fin_booking, buchungsart_id, buchungsschluessel_id, zahlungsmittel_id, beleg_lfd_nr, dat_booking, betrag, bemerkung2, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, fin_booking, buchungsart_id, CAST(buchungsschluessel_id AS INT64) AS buchungsschluessel_id, CAST(zahlungsmittel_id AS INT64) AS zahlungsmittel_id, CAST(beleg_lfd_nr AS INT64) AS beleg_lfd_nr, dat_booking, CAST(betrag AS NUMERIC) AS betrag, bemerkung2, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_archiv_ods_finanz01`;

-- Table: DBP_DATA.IMMO_MIETOBJEKT_MESSUNG
insert into `dbp_data.immo_mietobjekt_messung` (mandant_id, mo_intreno, bemessung_art_id, dat_bis, dat_von, groesse, groesse_einheit, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mo_intreno, bemessung_art_id, dat_bis, dat_von, CAST(groesse AS NUMERIC) AS groesse, groesse_einheit, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietobjekt_messung`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_MO_ZU_PER
insert into `dbp_data.immo_mietvertrag_mo_zu_per` (mandant_id, mv_intreno, mo_intreno, dat_von, dat_bis, zuordnung_info_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, mo_intreno, dat_von, dat_bis, zuordnung_info_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_mo_zu_per`;

-- Table: DBP_DATA.IMMO_MO_STATUS_PER
insert into `dbp_data.immo_mo_status_per` (mandant_id, mo_status_id, mo_intreno, mv_intreno, dat_status_von, dat_status_bis, dat_uebergabe, dat_rueckgabe, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_status_id AS INT64) AS mo_status_id, mo_intreno, mv_intreno, dat_status_von, dat_status_bis, dat_uebergabe, dat_rueckgabe, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mo_status_per`;

-- Table: DBP_DATA.IMS_INVEST_PLAN_DET
insert into `dbp_data.ims_invest_plan_det` (gj, mandant_id, hr_plan_gesamt_kz, excel_zeile, berichts_pos_invest_grp_id, in_massnahme_typ_id, plan_betrag, wrg_id, sparte_id, psp_id, td_update, td_insert)
SELECT CAST(gj AS INT64) AS gj, CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_plan_gesamt_kz AS INT64) AS hr_plan_gesamt_kz, CAST(excel_zeile AS INT64) AS excel_zeile, CAST(berichts_pos_invest_grp_id AS INT64) AS berichts_pos_invest_grp_id, in_massnahme_typ_id, CAST(plan_betrag AS NUMERIC) AS plan_betrag, wrg_id, CAST(sparte_id AS INT64) AS sparte_id, CAST(psp_id AS INT64) AS psp_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_invest_plan_det`;

-- Table: DBP_DATA.IN_KOSTEN_PROGNOSE
insert into `dbp_data.in_kosten_prognose` (mandant_id, in_projekt_id, psp_id, in_wg_id, kosten_prognose_version_id, betrag_kosten_prognose, betrag_mmk_prognose, betrag_zea_prognose, wrg_id, dat_kosten_prognose_version, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(in_projekt_id AS INT64) AS in_projekt_id, CAST(psp_id AS INT64) AS psp_id, in_wg_id, kosten_prognose_version_id, CAST(betrag_kosten_prognose AS NUMERIC) AS betrag_kosten_prognose, CAST(betrag_mmk_prognose AS NUMERIC) AS betrag_mmk_prognose, CAST(betrag_zea_prognose AS NUMERIC) AS betrag_zea_prognose, wrg_id, dat_kosten_prognose_version, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_in_kosten_prognose`;

-- Table: DBP_DATA.ORG_EINHEIT_SPR_ZU
insert into `dbp_data.org_einheit_spr_zu` (mandant_id, hr_objekt_id, spr_id, hr_objekt_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_id AS INT64) AS hr_objekt_id, CAST(spr_id AS INT64) AS spr_id, hr_objekt_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_org_einheit_spr_zu`;

-- Table: DBP_DATA.PLATZIERUNGSWG_FLAECHE_FLACHETYP_ZU
insert into `dbp_data.platzierungswg_flaeche_flachetyp_zu` (mandant_id, platzierungswg_id, ginfo_flaeche_id, ginfo_flaeche_typ_id, techn_platz_id, flaeche_quelle_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(platzierungswg_id AS INT64) AS platzierungswg_id, ginfo_flaeche_id, ginfo_flaeche_typ_id, techn_platz_id, CAST(flaeche_quelle_id AS INT64) AS flaeche_quelle_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_platzierungswg_flaeche_flachetyp_zu`;

-- Table: DBP_DATA.PLATZIERUNGSWG_WUP_ZU
insert into `dbp_data.platzierungswg_wup_zu` (mandant_id, platzierungswg_id, wup_id, nb_id, sm_id, anz_artikel, menge_soll_flaeche_regio, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(platzierungswg_id AS INT64) AS platzierungswg_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(sm_id AS INT64) AS sm_id, CAST(anz_artikel AS INT64) AS anz_artikel, CAST(menge_soll_flaeche_regio AS NUMERIC) AS menge_soll_flaeche_regio, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_platzierungswg_wup_zu`;

-- Table: DBP_DATA.PREDICT_COMPETITORS
insert into `dbp_data.predict_competitors` (google_place_id, mandant_id, competitor_name, wup_name, wup_str, wup_standort, laengengrad, breitengrad, td_update, td_insert)
SELECT google_place_id, CAST(mandant_id AS INT64) AS mandant_id, competitor_name, wup_name, wup_str, wup_standort, CAST(laengengrad AS BIGNUMERIC) AS laengengrad, CAST(breitengrad AS BIGNUMERIC) AS breitengrad, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_predict_competitors`;

-- Table: DBP_DATA.REGIO_POLYGON_ART_GP_ZU
insert into `dbp_data.regio_polygon_art_gp_zu` (mandant_id, regio_stufe_id, regio_polygon_id, art_id, gp_id, genehmigt_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regio_stufe_id AS INT64) AS regio_stufe_id, CAST(regio_polygon_id AS INT64) AS regio_polygon_id, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, CAST(genehmigt_fg AS INT64) AS genehmigt_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regio_polygon_art_gp_zu`;

-- Table: DBP_DATA.RETAIL_STORE
insert into `dbp_data.retail_store` (ext_system_name, ext_store_id, retail_store_name, retail_store_address, breitengrad, laengengrad, ext_retail_company_id, wup_id, mandant_id, nb_id, competitor_wup_id, td_update, td_insert)
SELECT ext_system_name, CAST(ext_store_id AS INT64) AS ext_store_id, retail_store_name, retail_store_address, CAST(breitengrad AS BIGNUMERIC) AS breitengrad, CAST(laengengrad AS BIGNUMERIC) AS laengengrad, CAST(ext_retail_company_id AS INT64) AS ext_retail_company_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, competitor_wup_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_retail_store`;

-- Table: DBP_DATA.ROHSTOFF
insert into `dbp_data.rohstoff` (rohstoff_nr, rohstoff_basis_einh_name, rohstoff_bez, rohstoff_kfl_bez, rohstoff_beschreibung_txt, rohstoff_qualitaet_txt, rohstoff_herkunftsort_name, rohstoff_lieferort_name, rohstoff_quell_bez, td_update, td_insert)
SELECT rohstoff_nr, rohstoff_basis_einh_name, rohstoff_bez, rohstoff_kfl_bez, rohstoff_beschreibung_txt, rohstoff_qualitaet_txt, rohstoff_herkunftsort_name, rohstoff_lieferort_name, rohstoff_quell_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rohstoff`;

-- Table: DBP_DATA.RPM_FELD_ZU_PER
insert into `dbp_data.rpm_feld_zu_per` (rpm_hierarchie_id, rpm_feld_id, rpm_tab_id, dat_von, dat_bis, rpm_gewichtung, rpm_feld_auspr_id, td_update, td_insert)
SELECT rpm_hierarchie_id, CAST(rpm_feld_id AS INT64) AS rpm_feld_id, CAST(rpm_tab_id AS INT64) AS rpm_tab_id, dat_von, dat_bis, CAST(rpm_gewichtung AS INT64) AS rpm_gewichtung, CAST(rpm_feld_auspr_id AS INT64) AS rpm_feld_auspr_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_feld_zu_per`;

-- Table: DBP_DATA.SB_BEURTEIL_BRCH_GRUND_ZU
insert into `dbp_data.sb_beurteil_brch_grund_zu` (sb_grund_id, mandant_id, bereichsnote_id, td_insert, td_update)
SELECT CAST(sb_grund_id AS INT64) AS sb_grund_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(bereichsnote_id AS INT64) AS bereichsnote_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_brch_grund_zu`;

-- Table: DBP_DATA.TP_L_OBJEKT
insert into `dbp_data.tp_l_objekt` (mandant_id, tp_objekt_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_l_objekt`;

-- Table: DBP_DATA.TRANSPORTATION_UNIT_LT
insert into `dbp_data.transportation_unit_lt` (mandant_id, transportation_unit_id, kj_transportation_unit, transportation_unit_sr_act_id, beleg_id, at_guid, menge_defekt_tortausch, menge_gesamt, menge_gesamt_tortausch, menge_einh_id, datzeit_erstelliung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportation_unit_id AS INT64) AS transportation_unit_id, CAST(kj_transportation_unit AS INT64) AS kj_transportation_unit, CAST(transportation_unit_sr_act_id AS INT64) AS transportation_unit_sr_act_id, beleg_id, at_guid, CAST(menge_defekt_tortausch AS INT64) AS menge_defekt_tortausch, CAST(menge_gesamt AS INT64) AS menge_gesamt, CAST(menge_gesamt_tortausch AS INT64) AS menge_gesamt_tortausch, menge_einh_id, CAST(datzeit_erstelliung AS DATETIME) AS datzeit_erstelliung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transportation_unit_lt`;

-- Table: DBP_DATA.VIS_TAG_TKS_SORTE
insert into `dbp_data.vis_tag_tks_sorte` (mandant_id, wup_id, nb_id, dat, tks_sorte_id, tks_sorte_bez, ums_netto, ums_brutto, menge_liter, anz_kunde, wrg_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(tks_sorte_id AS INT64) AS tks_sorte_id, tks_sorte_bez, CAST(ums_netto AS NUMERIC) AS ums_netto, CAST(ums_brutto AS NUMERIC) AS ums_brutto, CAST(menge_liter AS NUMERIC) AS menge_liter, CAST(anz_kunde AS INT64) AS anz_kunde, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_tag_tks_sorte`;

-- Table: DBP_DATA.WUP_LAGERNUMMER_BSFLAECHE_VIRTUELL_PER
insert into `dbp_data.wup_lagernummer_bsflaeche_virtuell_per` (mandant_id, wup_id, nb_id, lagernummer_id, bsflaeche_id, doppelbelegung_fg, dat_von, dat_bis, bsf_virtuell_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_id, CAST(bsflaeche_id AS INT64) AS bsflaeche_id, CAST(doppelbelegung_fg AS INT64) AS doppelbelegung_fg, dat_von, dat_bis, CAST(bsf_virtuell_fg AS INT64) AS bsf_virtuell_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_lagernummer_bsflaeche_virtuell_per`;

-- Table: DBP_DATA.WUP_WUP_ZU
insert into `dbp_data.wup_wup_zu` (wup_id, nb_id, mandant_id, wup_id_ref, nb_id_ref, mandant_id_ref, entfernung_km, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id_ref AS INT64) AS wup_id_ref, CAST(nb_id_ref AS INT64) AS nb_id_ref, CAST(mandant_id_ref AS INT64) AS mandant_id_ref, CAST(entfernung_km AS NUMERIC) AS entfernung_km, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_wup_zu`;

-- Table: DBP_MSI_DATA.CHECK_BLACKBERRY
insert into `dbp_msi_data.check_blackberry` (dat, mandant_id, lieferquote_real, lieferquote_def, datenquote_real, datenquote_def, bb_fg, check_fg, umsatz_ist, umsatz_vj, umsatz_plan, umsatz_vortag, umsatz_vorwoche, kunden_ist, kunden_vj, td_insert, td_update)
SELECT dat, CAST(mandant_id AS INT64) AS mandant_id, CAST(lieferquote_real AS NUMERIC) AS lieferquote_real, CAST(lieferquote_def AS NUMERIC) AS lieferquote_def, CAST(datenquote_real AS NUMERIC) AS datenquote_real, CAST(datenquote_def AS NUMERIC) AS datenquote_def, CAST(bb_fg AS INT64) AS bb_fg, CAST(check_fg AS INT64) AS check_fg, CAST(umsatz_ist AS NUMERIC) AS umsatz_ist, CAST(umsatz_vj AS NUMERIC) AS umsatz_vj, CAST(umsatz_plan AS NUMERIC) AS umsatz_plan, CAST(umsatz_vortag AS NUMERIC) AS umsatz_vortag, CAST(umsatz_vorwoche AS NUMERIC) AS umsatz_vorwoche, CAST(kunden_ist AS INT64) AS kunden_ist, CAST(kunden_vj AS INT64) AS kunden_vj, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_check_blackberry`;

-- Table: DBP_MSI_DATA.ODS_BON_ABHOL_LISTE
insert into `dbp_msi_data.ods_bon_abhol_liste` (bon_id, mandant_id, wup_id, zeitstempel_druck, td_insert, td_update)
SELECT bon_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, zeitstempel_druck, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ods_bon_abhol_liste`;

-- Table: DBP_MSI_DATA.VIS_MONAT_SHR_WUP_FUNKTGR
insert into `dbp_msi_data.vis_monat_shr_wup_funktgr` (mandant_id, wup_id, nb_id, kjmo, shr_ma_funktion_gruppe_id, kopf_gesamt, kopf_eintritte, kopf_austritte, kopf_teilzeit, kopf_austritte_bereinigt, stunden_vertrag, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(shr_ma_funktion_gruppe_id AS INT64) AS shr_ma_funktion_gruppe_id, CAST(kopf_gesamt AS NUMERIC) AS kopf_gesamt, CAST(kopf_eintritte AS NUMERIC) AS kopf_eintritte, CAST(kopf_austritte AS NUMERIC) AS kopf_austritte, CAST(kopf_teilzeit AS NUMERIC) AS kopf_teilzeit, CAST(kopf_austritte_bereinigt AS NUMERIC) AS kopf_austritte_bereinigt, CAST(stunden_vertrag AS NUMERIC) AS stunden_vertrag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_shr_wup_funktgr`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_PROPOSED_DECISION
insert into `dbp_msi_view_nfmd.ts_nfmd_proposed_decision` (mandant_id, aktion_id, art_id, kjwo_ww, dwh_created_tmsp, user_id, markdown_decision_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, dwh_created_tmsp, user_id, CAST(markdown_decision_id AS INT64) AS markdown_decision_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_proposed_decision`;

-- Table: DBP_DATA.IMMO_MIETOBJEKT_KONDITION_PER
insert into `dbp_data.immo_mietobjekt_kondition_per` (mandant_id, mo_intreno, dat_von, konditionsart_id, mo_objekt_nr, dat_bis, wrg_id, miete_per_anno, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mo_intreno, dat_von, konditionsart_id, mo_objekt_nr, dat_bis, wrg_id, CAST(miete_per_anno AS NUMERIC) AS miete_per_anno, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietobjekt_kondition_per`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_KONDITION_PER
insert into `dbp_data.immo_mietvertrag_kondition_per` (mandant_id, mv_intreno, mo_intreno, dat_von, konditionsart_id, dat_bis, wrg_id, miete_per_anno, miete_umsatz_prozent, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, mo_intreno, dat_von, konditionsart_id, dat_bis, wrg_id, CAST(miete_per_anno AS NUMERIC) AS miete_per_anno, CAST(miete_umsatz_prozent AS NUMERIC) AS miete_umsatz_prozent, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_kondition_per`;

-- Table: DBP_DATA.IMS_MAMO_WUP_MO_SUM
insert into `dbp_data.ims_mamo_wup_mo_sum` (mandant_id, wup_id, nb_id, hwg_id, kjmo, zaehler_monat, umsatz_netto, umsatz_netto_kum, umsatz_netto_vp, umsatz_netto_vp_kum, umsatz_netto_sa, umsatz_netto_sa_kum, umsatz_netto_sa_vp, umsatz_netto_sa_vp_kum, ek_mep, ek_mep_kum, ek_mep_vp, ek_mep_vp_kum, bonanzahl_sug, bonanzahl_sug_kum, bonanzahl_sug_vp, bonanzahl_sug_vp_kum, vis_netto_stunden, vis_netto_stunden_kum, vis_netto_stunden_vp, vis_netto_stunden_vp_kum, vis_umsatz_netto, vis_umsatz_netto_kum, vis_umsatz_netto_vp, vis_umsatz_netto_vp_kum, preis_abschrift_netto, preis_abschrift_netto_kum, preis_abschrift_netto_vp, preis_abschrift_netto_vp_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(kjmo AS INT64) AS kjmo, CAST(zaehler_monat AS INT64) AS zaehler_monat, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(umsatz_netto_kum AS NUMERIC) AS umsatz_netto_kum, CAST(umsatz_netto_vp AS NUMERIC) AS umsatz_netto_vp, CAST(umsatz_netto_vp_kum AS NUMERIC) AS umsatz_netto_vp_kum, CAST(umsatz_netto_sa AS NUMERIC) AS umsatz_netto_sa, CAST(umsatz_netto_sa_kum AS NUMERIC) AS umsatz_netto_sa_kum, CAST(umsatz_netto_sa_vp AS NUMERIC) AS umsatz_netto_sa_vp, CAST(umsatz_netto_sa_vp_kum AS NUMERIC) AS umsatz_netto_sa_vp_kum, CAST(ek_mep AS NUMERIC) AS ek_mep, CAST(ek_mep_kum AS NUMERIC) AS ek_mep_kum, CAST(ek_mep_vp AS NUMERIC) AS ek_mep_vp, CAST(ek_mep_vp_kum AS NUMERIC) AS ek_mep_vp_kum, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, CAST(bonanzahl_sug_kum AS INT64) AS bonanzahl_sug_kum, CAST(bonanzahl_sug_vp AS INT64) AS bonanzahl_sug_vp, CAST(bonanzahl_sug_vp_kum AS INT64) AS bonanzahl_sug_vp_kum, CAST(vis_netto_stunden AS INT64) AS vis_netto_stunden, CAST(vis_netto_stunden_kum AS INT64) AS vis_netto_stunden_kum, CAST(vis_netto_stunden_vp AS INT64) AS vis_netto_stunden_vp, CAST(vis_netto_stunden_vp_kum AS INT64) AS vis_netto_stunden_vp_kum, CAST(vis_umsatz_netto AS NUMERIC) AS vis_umsatz_netto, CAST(vis_umsatz_netto_kum AS NUMERIC) AS vis_umsatz_netto_kum, CAST(vis_umsatz_netto_vp AS NUMERIC) AS vis_umsatz_netto_vp, CAST(vis_umsatz_netto_vp_kum AS NUMERIC) AS vis_umsatz_netto_vp_kum, CAST(preis_abschrift_netto AS NUMERIC) AS preis_abschrift_netto, CAST(preis_abschrift_netto_kum AS NUMERIC) AS preis_abschrift_netto_kum, CAST(preis_abschrift_netto_vp AS NUMERIC) AS preis_abschrift_netto_vp, CAST(preis_abschrift_netto_vp_kum AS NUMERIC) AS preis_abschrift_netto_vp_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_wup_mo_sum`;

-- Table: DBP_DATA.IMS_MAMO_WUP_QUALIFIER_MO_SUM
insert into `dbp_data.ims_mamo_wup_qualifier_mo_sum` (mandant_id, wup_id, nb_id, qualifier_id, hwg_id, kjmo, zaehler_monat, umsatz_netto, umsatz_netto_kum, umsatz_netto_vp, umsatz_netto_vp_kum, umsatz_netto_sa, umsatz_netto_sa_kum, umsatz_netto_sa_vp, umsatz_netto_sa_vp_kum, ek_mep, ek_mep_kum, ek_mep_vp, ek_mep_vp_kum, bonanzahl_sug, bonanzahl_sug_kum, bonanzahl_sug_vp, bonanzahl_sug_vp_kum, vis_netto_stunden, vis_netto_stunden_kum, vis_netto_stunden_vp, vis_netto_stunden_vp_kum, vis_umsatz_netto, vis_umsatz_netto_kum, vis_umsatz_netto_vp, vis_umsatz_netto_vp_kum, preis_abschrift_netto, preis_abschrift_netto_kum, preis_abschrift_netto_vp, preis_abschrift_netto_vp_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(qualifier_id AS INT64) AS qualifier_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(kjmo AS INT64) AS kjmo, CAST(zaehler_monat AS INT64) AS zaehler_monat, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(umsatz_netto_kum AS NUMERIC) AS umsatz_netto_kum, CAST(umsatz_netto_vp AS NUMERIC) AS umsatz_netto_vp, CAST(umsatz_netto_vp_kum AS NUMERIC) AS umsatz_netto_vp_kum, CAST(umsatz_netto_sa AS NUMERIC) AS umsatz_netto_sa, CAST(umsatz_netto_sa_kum AS NUMERIC) AS umsatz_netto_sa_kum, CAST(umsatz_netto_sa_vp AS NUMERIC) AS umsatz_netto_sa_vp, CAST(umsatz_netto_sa_vp_kum AS NUMERIC) AS umsatz_netto_sa_vp_kum, CAST(ek_mep AS NUMERIC) AS ek_mep, CAST(ek_mep_kum AS NUMERIC) AS ek_mep_kum, CAST(ek_mep_vp AS NUMERIC) AS ek_mep_vp, CAST(ek_mep_vp_kum AS NUMERIC) AS ek_mep_vp_kum, CAST(bonanzahl_sug AS INT64) AS bonanzahl_sug, CAST(bonanzahl_sug_kum AS INT64) AS bonanzahl_sug_kum, CAST(bonanzahl_sug_vp AS INT64) AS bonanzahl_sug_vp, CAST(bonanzahl_sug_vp_kum AS INT64) AS bonanzahl_sug_vp_kum, CAST(vis_netto_stunden AS INT64) AS vis_netto_stunden, CAST(vis_netto_stunden_kum AS INT64) AS vis_netto_stunden_kum, CAST(vis_netto_stunden_vp AS INT64) AS vis_netto_stunden_vp, CAST(vis_netto_stunden_vp_kum AS INT64) AS vis_netto_stunden_vp_kum, CAST(vis_umsatz_netto AS NUMERIC) AS vis_umsatz_netto, CAST(vis_umsatz_netto_kum AS NUMERIC) AS vis_umsatz_netto_kum, CAST(vis_umsatz_netto_vp AS NUMERIC) AS vis_umsatz_netto_vp, CAST(vis_umsatz_netto_vp_kum AS NUMERIC) AS vis_umsatz_netto_vp_kum, CAST(preis_abschrift_netto AS NUMERIC) AS preis_abschrift_netto, CAST(preis_abschrift_netto_kum AS NUMERIC) AS preis_abschrift_netto_kum, CAST(preis_abschrift_netto_vp AS NUMERIC) AS preis_abschrift_netto_vp, CAST(preis_abschrift_netto_vp_kum AS NUMERIC) AS preis_abschrift_netto_vp_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_wup_qualifier_mo_sum`;

-- Table: DBP_DATA.IMS_PSP_ELE_SYSSTAT_ZU
insert into `dbp_data.ims_psp_ele_sysstat_zu` (mandant_id, psp_id, systemstatus_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(psp_id AS INT64) AS psp_id, systemstatus_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ims_psp_ele_sysstat_zu`;

-- Table: DBP_DATA.MA_HIERARCHIE_MA_ZU_PER
insert into `dbp_data.ma_hierarchie_ma_zu_per` (mandant_id, ma_hierarchie_id, dat_von, ma_hierarchie_typ_id, ma_id, ma_funktion_id, dat_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ma_hierarchie_id AS INT64) AS ma_hierarchie_id, dat_von, CAST(ma_hierarchie_typ_id AS INT64) AS ma_hierarchie_typ_id, CAST(ma_id AS INT64) AS ma_id, ma_funktion_id, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_hierarchie_ma_zu_per`;

-- Table: DBP_DATA.NACHHALTIGKEITSLOGO_ART_ZU
insert into `dbp_data.nachhaltigkeitslogo_art_zu` (mandant_id, art_id, nachhaltigkeitslogo_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_id AS INT64) AS art_id, CAST(nachhaltigkeitslogo_id AS INT64) AS nachhaltigkeitslogo_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_nachhaltigkeitslogo_art_zu`;

-- Table: DBP_DATA.NFMD_ART_PROMOTION
insert into `dbp_data.nfmd_art_promotion` (mandant_id, aktion_id, art_id, wrg_id, kjwo_ww, promo_start_dt, promo_stores_cnt, selling_price_gross_local_val, wg_id, sales_total_cnt, stock_initial_cnt, sales_promo_week_cnt, promo_week_sell_rate, current_sell_rate, remaining_stock_cnt, model_execution_tmsp, ai_model_id, next_promo_start_dt, display_art_id, sell_ratio_wk12, sell_ratio_wk123, orig_promo_start_dt, orig_promo_end_dt, orig_promo_cycle_type_name, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, wrg_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, promo_start_dt, CAST(promo_stores_cnt AS INT64) AS promo_stores_cnt, CAST(selling_price_gross_local_val AS NUMERIC) AS selling_price_gross_local_val, CAST(wg_id AS INT64) AS wg_id, CAST(sales_total_cnt AS INT64) AS sales_total_cnt, CAST(stock_initial_cnt AS INT64) AS stock_initial_cnt, CAST(sales_promo_week_cnt AS INT64) AS sales_promo_week_cnt, CAST(promo_week_sell_rate AS NUMERIC) AS promo_week_sell_rate, CAST(current_sell_rate AS NUMERIC) AS current_sell_rate, CAST(remaining_stock_cnt AS INT64) AS remaining_stock_cnt, model_execution_tmsp, ai_model_id, next_promo_start_dt, CAST(display_art_id AS INT64) AS display_art_id, CAST(sell_ratio_wk12 AS NUMERIC) AS sell_ratio_wk12, CAST(sell_ratio_wk123 AS NUMERIC) AS sell_ratio_wk123, orig_promo_start_dt, orig_promo_end_dt, orig_promo_cycle_type_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_art_promotion`;

-- Table: DBP_DATA.PREDICT_GOOGLE_REVIEW_KAUFLAND
insert into `dbp_data.predict_google_review_kaufland` (google_place_id, kjmo, mandant_id, wup_id, predict_review_count, predict_rating_avg, td_update, td_insert)
SELECT google_place_id, CAST(kjmo AS INT64) AS kjmo, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(predict_review_count AS INT64) AS predict_review_count, CAST(predict_rating_avg AS NUMERIC) AS predict_rating_avg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_predict_google_review_kaufland`;

-- Table: DBP_DATA.PROFIT_CENTER_SPR_ZU
insert into `dbp_data.profit_center_spr_zu` (pc_id, spr_id, mandant_id, krk_id, system_id, pc_bez, td_insert, td_update)
SELECT pc_id, CAST(spr_id AS INT64) AS spr_id, CAST(mandant_id AS INT64) AS mandant_id, krk_id, CAST(system_id AS INT64) AS system_id, pc_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_profit_center_spr_zu`;

-- Table: DBP_DATA.PROMOTION_EVENT
insert into `dbp_data.promotion_event` (mandant_id, promotion_event_id, dat_promotion_event_gueltig_von, dat_promotion_event_gueltig_bis, werbemittel_id, werbemittelkanal_id, werbethema_id, werbeflaechenthema_cd, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(promotion_event_id AS INT64) AS promotion_event_id, dat_promotion_event_gueltig_von, dat_promotion_event_gueltig_bis, CAST(werbemittel_id AS INT64) AS werbemittel_id, CAST(werbemittelkanal_id AS INT64) AS werbemittelkanal_id, CAST(werbethema_id AS INT64) AS werbethema_id, werbeflaechenthema_cd, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_promotion_event`;

-- Table: DBP_DATA.SB_BEURTEIL_DET_GRUND_ZU
insert into `dbp_data.sb_beurteil_det_grund_zu` (sb_grund_id, mandant_id, detailnote_id, td_insert, td_update)
SELECT CAST(sb_grund_id AS INT64) AS sb_grund_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(detailnote_id AS INT64) AS detailnote_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_det_grund_zu`;

-- Table: DBP_DATA.SSM_WUP_CLUSTER_PROZESS_ZU
insert into `dbp_data.ssm_wup_cluster_prozess_zu` (mandant_id, wup_id, nb_id, ssm_cluster_id, ssm_prozess_id, dat_von, dat_bis, wup_bereich_id, wup_abt_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(ssm_cluster_id AS INT64) AS ssm_cluster_id, CAST(ssm_prozess_id AS INT64) AS ssm_prozess_id, dat_von, dat_bis, CAST(wup_bereich_id AS INT64) AS wup_bereich_id, CAST(wup_abt_id AS INT64) AS wup_abt_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_cluster_prozess_zu`;

-- Table: DBP_DATA.TMS_GP
insert into `dbp_data.tms_gp` (mandant_id, system_id, tms_gp_id, tms_gp_typ_cd, tms_gp_lfd_nr, tms_gp_name, tms_gp_altnv_name, tms_gp_strasse, tms_gp_ort_name, tms_gp_plz, tms_land_cd, sperr_fg, sammelbeleg_id, tms_standorttyp_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_gp_id, tms_gp_typ_cd, CAST(tms_gp_lfd_nr AS INT64) AS tms_gp_lfd_nr, tms_gp_name, tms_gp_altnv_name, tms_gp_strasse, tms_gp_ort_name, tms_gp_plz, tms_land_cd, CAST(sperr_fg AS INT64) AS sperr_fg, CAST(sammelbeleg_id AS INT64) AS sammelbeleg_id, CAST(tms_standorttyp_id AS INT64) AS tms_standorttyp_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_gp`;

-- Table: DBP_DATA.TP_L_TECHN_PLATZ
insert into `dbp_data.tp_l_techn_platz` (techn_platz_id, td_update, td_insert)
SELECT techn_platz_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tp_l_techn_platz`;

-- Table: DBP_DATA.TP_MERKMALART_SPR_ZU
insert into `dbp_data.tp_merkmalart_spr_zu` (tp_merkmalart_id, spr_id, tp_merkmal_id, mandant_id, tp_merkmalart_bez, td_insert, td_update)
SELECT CAST(tp_merkmalart_id AS INT64) AS tp_merkmalart_id, CAST(spr_id AS INT64) AS spr_id, CAST(tp_merkmal_id AS INT64) AS tp_merkmal_id, CAST(mandant_id AS INT64) AS mandant_id, tp_merkmalart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tp_merkmalart_spr_zu`;

-- Table: DBP_DATA.WERBEWOCHE_KL_VVT
insert into `dbp_data.werbewoche_kl_vvt` (mandant_id, dat, akt_kjwo_ww, akt_kjwo_ww_komplett, kjwo_ww, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(akt_kjwo_ww AS INT64) AS akt_kjwo_ww, CAST(akt_kjwo_ww_komplett AS INT64) AS akt_kjwo_ww_komplett, CAST(kjwo_ww AS INT64) AS kjwo_ww, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_werbewoche_kl_vvt`;

-- Table: DBP_DATA.WPL_FFAKTOR
insert into `dbp_data.wpl_ffaktor` (mandant_id, platzierungsstufe_id, platzierungswg_id, faktor, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, platzierungsstufe_id, CAST(platzierungswg_id AS INT64) AS platzierungswg_id, CAST(faktor AS NUMERIC) AS faktor, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wpl_ffaktor`;

-- Table: DBP_DATA.WUP_ENTFERNUNGSMATRIX
insert into `dbp_data.wup_entfernungsmatrix` (wup_id_a, wup_id_b, nb_id_a, nb_id_b, mandant_id_a, mandant_id_b, distanz_fahrweg_km, dauer_fahrzeit_min, maut_km, td_update, td_insert)
SELECT CAST(wup_id_a AS INT64) AS wup_id_a, CAST(wup_id_b AS INT64) AS wup_id_b, CAST(nb_id_a AS INT64) AS nb_id_a, CAST(nb_id_b AS INT64) AS nb_id_b, CAST(mandant_id_a AS INT64) AS mandant_id_a, CAST(mandant_id_b AS INT64) AS mandant_id_b, CAST(distanz_fahrweg_km AS NUMERIC) AS distanz_fahrweg_km, CAST(dauer_fahrzeit_min AS INT64) AS dauer_fahrzeit_min, CAST(maut_km AS NUMERIC) AS maut_km, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_entfernungsmatrix`;

-- Table: DBP_DATA.WUP_PER
insert into `dbp_data.wup_per` (wup_id, nb_id, mandant_id, kjmo, verkaufsflaeche, betriebsflaeche, konzessionaersflaeche, parkplatz_anz_ges, parkplatz_anz_kl, eigentum_fg, einwohner_anz_1km, einwohner_anz_einzug, getraenkemarkt_fg, standort_typ_id, lage_id, kundenfaktor, preiskategorie_food, preiskategorie_nonfood, sortkategorie_food, sortkategorie_nonfood, auflage_tip, wrg_id, mietrentabiltaet, breakevenumsatz, systemrentabilitaet, umsatz_ea, umsatz_woche, verkaufs_ebene_bez, parken_bez, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(verkaufsflaeche AS NUMERIC) AS verkaufsflaeche, CAST(betriebsflaeche AS NUMERIC) AS betriebsflaeche, CAST(konzessionaersflaeche AS NUMERIC) AS konzessionaersflaeche, CAST(parkplatz_anz_ges AS INT64) AS parkplatz_anz_ges, CAST(parkplatz_anz_kl AS INT64) AS parkplatz_anz_kl, CAST(eigentum_fg AS INT64) AS eigentum_fg, CAST(einwohner_anz_1km AS INT64) AS einwohner_anz_1km, CAST(einwohner_anz_einzug AS INT64) AS einwohner_anz_einzug, CAST(getraenkemarkt_fg AS INT64) AS getraenkemarkt_fg, CAST(standort_typ_id AS INT64) AS standort_typ_id, CAST(lage_id AS INT64) AS lage_id, CAST(kundenfaktor AS BIGNUMERIC) AS kundenfaktor, CAST(preiskategorie_food AS INT64) AS preiskategorie_food, CAST(preiskategorie_nonfood AS INT64) AS preiskategorie_nonfood, CAST(sortkategorie_food AS INT64) AS sortkategorie_food, CAST(sortkategorie_nonfood AS INT64) AS sortkategorie_nonfood, CAST(auflage_tip AS INT64) AS auflage_tip, wrg_id, CAST(mietrentabiltaet AS NUMERIC) AS mietrentabiltaet, CAST(breakevenumsatz AS NUMERIC) AS breakevenumsatz, CAST(systemrentabilitaet AS NUMERIC) AS systemrentabilitaet, CAST(umsatz_ea AS NUMERIC) AS umsatz_ea, CAST(umsatz_woche AS NUMERIC) AS umsatz_woche, verkaufs_ebene_bez, parken_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_per`;

-- Table: DBP_DATA.WUP_PLAN_TAG_CO_V2
insert into `dbp_data.wup_plan_tag_co_v2` (wup_id, nb_id, mandant_id, dat, regression_faktor_var, regression_faktor_fix, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(regression_faktor_var AS NUMERIC) AS regression_faktor_var, CAST(regression_faktor_fix AS NUMERIC) AS regression_faktor_fix, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_plan_tag_co_v2`;

-- Table: DBP_DATA_CENTER.VAUS_INTRANET
insert into `dbp_data_center.vaus_intranet` (wup_id, mandant_kbez, landessprache_fg, wup_standort, region_name, vaus_wup_name, vsvt_bez, dat_eroeffnung, dat_bis, wup_str, wup_plz, wup_stadt, markttyp_kategorie_id, uebernahme_von, firma_id, firma_bez, firma_plz, firma_ort, firma_strasse, wup_telefon, wup_fax, mo_oez, di_oez, mi_oez, do_oez, fr_oez, sa_oez, so_oez, glv_anrede, glv_vorname, glv_name, stv_glv_anrede, stv_glv_vorname, stv_glv_name, gl_anrede, gl_vorname, gl_name, gl_mobil_tel, gf_anrede, gf_vorname, gf_name, gf_email, gf_mobil_tel, vkl_anrede, vkl_vorname, vkl_name, vkl_email, vkl_mobil_tel, hl_anrede, hl_vorname, hl_name, fm_anrede, fm_vorname, fm_name, fm_email, fm_mobil_tel, betreuer_be, betreuer_vermietung, rpsb_anrede, rpsb_vorname, rpsb_name, anz_parkpl, parkhaus_kz, parkdeck_fg, bed_fleisch_fg, bed_fleisch_dat, bed_wurst_fg, bed_wurst_dat, bed_gefl_fg, bed_gefl_dat, bed_kaese_fg, bed_kaese_dat, bed_fisch_bez, bed_fisch_dat, system_backshop, bed_backshop_dat, bed_feink_fg, bed_feink_dat, bed_bulk_fg, bed_bulk_dat, bed_bedins_fg, bed_imbiss_fg, getraenkemarkt_fg, tankstelle_vorh_fg, tankstelle_eigen_fg, anz_parkpl_behind, anz_parkpl_eltern_kind, parkpl_eben_kz, parkpl_dach_kz, parkpl_dach_mg_kz, tiefgarage_eg_kz, tiefgarage_mg_kz, td_update, td_insert)
SELECT CAST(wup_id AS INT64) AS wup_id, mandant_kbez, CAST(landessprache_fg AS INT64) AS landessprache_fg, wup_standort, region_name, vaus_wup_name, vsvt_bez, dat_eroeffnung, dat_bis, wup_str, wup_plz, wup_stadt, markttyp_kategorie_id, uebernahme_von, CAST(firma_id AS INT64) AS firma_id, firma_bez, firma_plz, firma_ort, firma_strasse, wup_telefon, wup_fax, mo_oez, di_oez, mi_oez, do_oez, fr_oez, sa_oez, so_oez, glv_anrede, glv_vorname, glv_name, stv_glv_anrede, stv_glv_vorname, stv_glv_name, gl_anrede, gl_vorname, gl_name, gl_mobil_tel, gf_anrede, gf_vorname, gf_name, gf_email, gf_mobil_tel, vkl_anrede, vkl_vorname, vkl_name, vkl_email, vkl_mobil_tel, hl_anrede, hl_vorname, hl_name, fm_anrede, fm_vorname, fm_name, fm_email, fm_mobil_tel, betreuer_be, betreuer_vermietung, rpsb_anrede, rpsb_vorname, rpsb_name, CAST(anz_parkpl AS INT64) AS anz_parkpl, CAST(parkhaus_kz AS INT64) AS parkhaus_kz, CAST(parkdeck_fg AS INT64) AS parkdeck_fg, CAST(bed_fleisch_fg AS INT64) AS bed_fleisch_fg, bed_fleisch_dat, CAST(bed_wurst_fg AS INT64) AS bed_wurst_fg, bed_wurst_dat, CAST(bed_gefl_fg AS INT64) AS bed_gefl_fg, bed_gefl_dat, CAST(bed_kaese_fg AS INT64) AS bed_kaese_fg, bed_kaese_dat, bed_fisch_bez, bed_fisch_dat, system_backshop, bed_backshop_dat, CAST(bed_feink_fg AS INT64) AS bed_feink_fg, bed_feink_dat, CAST(bed_bulk_fg AS INT64) AS bed_bulk_fg, bed_bulk_dat, CAST(bed_bedins_fg AS INT64) AS bed_bedins_fg, CAST(bed_imbiss_fg AS INT64) AS bed_imbiss_fg, CAST(getraenkemarkt_fg AS INT64) AS getraenkemarkt_fg, CAST(tankstelle_vorh_fg AS INT64) AS tankstelle_vorh_fg, CAST(tankstelle_eigen_fg AS INT64) AS tankstelle_eigen_fg, CAST(anz_parkpl_behind AS INT64) AS anz_parkpl_behind, CAST(anz_parkpl_eltern_kind AS INT64) AS anz_parkpl_eltern_kind, CAST(parkpl_eben_kz AS INT64) AS parkpl_eben_kz, CAST(parkpl_dach_kz AS INT64) AS parkpl_dach_kz, CAST(parkpl_dach_mg_kz AS INT64) AS parkpl_dach_mg_kz, CAST(tiefgarage_eg_kz AS INT64) AS tiefgarage_eg_kz, CAST(tiefgarage_mg_kz AS INT64) AS tiefgarage_mg_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_center_vaus_intranet`;

-- Table: DBP_ETL_PROCESS.PERSONALKOSTEN
insert into `dbp_etl_process.personalkosten` (mandant_id, wup_id, nb_id, kjmo, kosten_ist, abgr_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(kosten_ist AS NUMERIC) AS kosten_ist, CAST(abgr_fg AS INT64) AS abgr_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_etl_process_personalkosten`;

-- Table: DBP_MSI_DATA.DBA_CROSS
insert into `dbp_msi_data.dba_cross` (mandant_id, kjwo_update, matching_id, var_sst_tool_fg, var_w_tool_fg, var_n_tool_fg, var_ob_tool_fg, var_og_tool_fg, var_so_tool_fg, var_sw_tool_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo_update AS INT64) AS kjwo_update, CAST(matching_id AS INT64) AS matching_id, CAST(var_sst_tool_fg AS INT64) AS var_sst_tool_fg, CAST(var_w_tool_fg AS INT64) AS var_w_tool_fg, CAST(var_n_tool_fg AS INT64) AS var_n_tool_fg, CAST(var_ob_tool_fg AS INT64) AS var_ob_tool_fg, CAST(var_og_tool_fg AS INT64) AS var_og_tool_fg, CAST(var_so_tool_fg AS INT64) AS var_so_tool_fg, CAST(var_sw_tool_fg AS INT64) AS var_sw_tool_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_dba_cross`;

-- Table: DBP_MSI_DATA.ERWARTETE_ENTWICKLUNG
insert into `dbp_msi_data.erwartete_entwicklung` (mandant_id, kjmo, matching_id, sm_id, ksm_id, kjwo_update, wrg_id, kl_wg_id, kl_owg_id, kl_uwg_id, hwg_id, owg_id, wg_id, wug_id, ost_basis_pflege, ost_gross_pflege, sued_ost_pflege, sued_west_pflege, west_pflege, nord_pflege, umsatz_hr, absatz_hr, rohertrag_hr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(matching_id AS INT64) AS matching_id, CAST(sm_id AS INT64) AS sm_id, ksm_id, CAST(kjwo_update AS INT64) AS kjwo_update, wrg_id, CAST(kl_wg_id AS INT64) AS kl_wg_id, CAST(kl_owg_id AS INT64) AS kl_owg_id, CAST(kl_uwg_id AS INT64) AS kl_uwg_id, CAST(hwg_id AS INT64) AS hwg_id, CAST(owg_id AS INT64) AS owg_id, CAST(wg_id AS INT64) AS wg_id, CAST(wug_id AS INT64) AS wug_id, ost_basis_pflege, ost_gross_pflege, sued_ost_pflege, sued_west_pflege, west_pflege, nord_pflege, CAST(umsatz_hr AS NUMERIC) AS umsatz_hr, CAST(absatz_hr AS NUMERIC) AS absatz_hr, CAST(rohertrag_hr AS NUMERIC) AS rohertrag_hr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_erwartete_entwicklung`;

-- Table: DBP_MSI_DATA.IMS_PLAN_ABGRENZUNG
insert into `dbp_msi_data.ims_plan_abgrenzung` (mandant_id, psp_id, gjmo, wrg_id, dat_baubeginn, dat_beginn_einrichtung, dat_beginn_kaelte, dat_stille_eroeffnung, dat_bauabnahme, anz_tage_massnahme_gesamt, anz_tage_massnahme_bis_gjmo, plan_abgrenzung_wert_gesamt, plan_abgrenzung_wert_bis_gjmo, betrag_ist_bis_gjmo, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(psp_id AS INT64) AS psp_id, CAST(gjmo AS INT64) AS gjmo, wrg_id, dat_baubeginn, dat_beginn_einrichtung, dat_beginn_kaelte, dat_stille_eroeffnung, dat_bauabnahme, CAST(anz_tage_massnahme_gesamt AS INT64) AS anz_tage_massnahme_gesamt, CAST(anz_tage_massnahme_bis_gjmo AS INT64) AS anz_tage_massnahme_bis_gjmo, CAST(plan_abgrenzung_wert_gesamt AS NUMERIC) AS plan_abgrenzung_wert_gesamt, CAST(plan_abgrenzung_wert_bis_gjmo AS NUMERIC) AS plan_abgrenzung_wert_bis_gjmo, CAST(betrag_ist_bis_gjmo AS NUMERIC) AS betrag_ist_bis_gjmo, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ims_plan_abgrenzung`;

-- Table: DBP_MSI_DATA.IVS_MIETVTG_FL_ZU_PER_MSI
insert into `dbp_msi_data.ivs_mietvtg_fl_zu_per_msi` (mandant_id, mietvertrag_id, flaeche_id, dat_von, mietvertrag_id_hilfe, dat_bis, vertrag_aktiv_fg, immo_objekt_id, flaeche_typ_id, branche_id, dat_flaeche_uebergabe, dat_flaeche_rueckgabe, nebenkosten_betrag, miete_betrag, nebenkosten_abschlag, miete_umsatz_prozent, miete_referenz_id, mietart_id, dat_frei_flaeche_seit, wrg_id, miete_umsatz_abschlag, investmiete_betrag, sonst_betrag, immo_verw_betrag, flaeche_status_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mietvertrag_id, flaeche_id, dat_von, mietvertrag_id_hilfe, dat_bis, vertrag_aktiv_fg, immo_objekt_id, CAST(flaeche_typ_id AS INT64) AS flaeche_typ_id, branche_id, dat_flaeche_uebergabe, dat_flaeche_rueckgabe, CAST(nebenkosten_betrag AS NUMERIC) AS nebenkosten_betrag, CAST(miete_betrag AS NUMERIC) AS miete_betrag, CAST(nebenkosten_abschlag AS NUMERIC) AS nebenkosten_abschlag, CAST(miete_umsatz_prozent AS NUMERIC) AS miete_umsatz_prozent, miete_referenz_id, mietart_id, dat_frei_flaeche_seit, wrg_id, CAST(miete_umsatz_abschlag AS NUMERIC) AS miete_umsatz_abschlag, CAST(investmiete_betrag AS NUMERIC) AS investmiete_betrag, CAST(sonst_betrag AS NUMERIC) AS sonst_betrag, CAST(immo_verw_betrag AS NUMERIC) AS immo_verw_betrag, CAST(flaeche_status_id AS INT64) AS flaeche_status_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ivs_mietvtg_fl_zu_per_msi`;

-- Table: DBP_MSI_DATA.KOSTENSTELLE_MO_SUM
insert into `dbp_msi_data.kostenstelle_mo_sum` (mandant_id, kjmo, kostenstelle_id, anz_mo_alter_kostenstelle, anz_mo_alter_kostenstelle_fe_i, anz_mo_alter_kostenstelle_fe_ii, anz_mo_alter_kostenstelle_fe_iii, anz_mo_alter_kostenstelle_fe_iv, anz_mo_alter_kostenstelle_fe_v, anz_mo_alter_kostenstelle_fe_vi, anz_mo_alter_kostenstelle_ma, anz_mo_alter_kostenstelle_gender_frau, anz_mo_alter_kostenstelle_gender_mann, anz_mo_alter_kostenstelle_bzg_00_03_mo, anz_mo_alter_kostenstelle_bzg_03_06_mo, anz_mo_alter_kostenstelle_bzg_06_12_mo, anz_mo_alter_kostenstelle_bzg_12_36_mo, anz_mo_alter_kostenstelle_bzg_36_plus_mo, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, kostenstelle_id, CAST(anz_mo_alter_kostenstelle AS INT64) AS anz_mo_alter_kostenstelle, CAST(anz_mo_alter_kostenstelle_fe_i AS INT64) AS anz_mo_alter_kostenstelle_fe_i, CAST(anz_mo_alter_kostenstelle_fe_ii AS INT64) AS anz_mo_alter_kostenstelle_fe_ii, CAST(anz_mo_alter_kostenstelle_fe_iii AS INT64) AS anz_mo_alter_kostenstelle_fe_iii, CAST(anz_mo_alter_kostenstelle_fe_iv AS INT64) AS anz_mo_alter_kostenstelle_fe_iv, CAST(anz_mo_alter_kostenstelle_fe_v AS INT64) AS anz_mo_alter_kostenstelle_fe_v, CAST(anz_mo_alter_kostenstelle_fe_vi AS INT64) AS anz_mo_alter_kostenstelle_fe_vi, CAST(anz_mo_alter_kostenstelle_ma AS INT64) AS anz_mo_alter_kostenstelle_ma, CAST(anz_mo_alter_kostenstelle_gender_frau AS INT64) AS anz_mo_alter_kostenstelle_gender_frau, CAST(anz_mo_alter_kostenstelle_gender_mann AS INT64) AS anz_mo_alter_kostenstelle_gender_mann, CAST(anz_mo_alter_kostenstelle_bzg_00_03_mo AS INT64) AS anz_mo_alter_kostenstelle_bzg_00_03_mo, CAST(anz_mo_alter_kostenstelle_bzg_03_06_mo AS INT64) AS anz_mo_alter_kostenstelle_bzg_03_06_mo, CAST(anz_mo_alter_kostenstelle_bzg_06_12_mo AS INT64) AS anz_mo_alter_kostenstelle_bzg_06_12_mo, CAST(anz_mo_alter_kostenstelle_bzg_12_36_mo AS INT64) AS anz_mo_alter_kostenstelle_bzg_12_36_mo, CAST(anz_mo_alter_kostenstelle_bzg_36_plus_mo AS INT64) AS anz_mo_alter_kostenstelle_bzg_36_plus_mo, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_kostenstelle_mo_sum`;

-- Table: DBP_MSI_DATA.NCS_LOG
insert into `dbp_msi_data.ncs_log` (date_start, service_id, time_start, date_end, time_end, status, service_name, td_insert, td_update)
SELECT date_start, service_id, CAST(time_start AS INT64) AS time_start, date_end, CAST(time_end AS INT64) AS time_end, CAST(status AS INT64) AS status, service_name, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ncs_log`;

-- Table: DBP_MSI_DATA.PC_PC_GRP_DENORM
insert into `dbp_msi_data.pc_pc_grp_denorm` (mandant_id, krk_id, pc_lv1, fg_pc1, fg_end1, pc_lv2, fg_pc2, fg_end2, pc_lv3, fg_pc3, fg_end3, pc_lv4, fg_pc4, fg_end4, pc_lv5, fg_pc5, fg_end5, pc_lv6, fg_pc6, fg_end6, pc_lv7, fg_pc7, fg_end7, pc_lv8, fg_pc8, fg_end8, pc_lv9, fg_pc9, fg_end9, pc_lv10, fg_pc10, fg_end10, pc_lv11, fg_pc11, fg_end11, pc_bez1, pc_bez2, pc_bez3, pc_bez4, pc_bez5, pc_bez6, pc_bez7, pc_bez8, pc_bez9, pc_bez10, pc_bez11, robbies_fett_fg, pc_hiertyp_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, krk_id, pc_lv1, CAST(fg_pc1 AS INT64) AS fg_pc1, CAST(fg_end1 AS INT64) AS fg_end1, pc_lv2, CAST(fg_pc2 AS INT64) AS fg_pc2, CAST(fg_end2 AS INT64) AS fg_end2, pc_lv3, CAST(fg_pc3 AS INT64) AS fg_pc3, CAST(fg_end3 AS INT64) AS fg_end3, pc_lv4, CAST(fg_pc4 AS INT64) AS fg_pc4, CAST(fg_end4 AS INT64) AS fg_end4, pc_lv5, CAST(fg_pc5 AS INT64) AS fg_pc5, CAST(fg_end5 AS INT64) AS fg_end5, pc_lv6, CAST(fg_pc6 AS INT64) AS fg_pc6, CAST(fg_end6 AS INT64) AS fg_end6, pc_lv7, CAST(fg_pc7 AS INT64) AS fg_pc7, CAST(fg_end7 AS INT64) AS fg_end7, pc_lv8, CAST(fg_pc8 AS INT64) AS fg_pc8, CAST(fg_end8 AS INT64) AS fg_end8, pc_lv9, CAST(fg_pc9 AS INT64) AS fg_pc9, CAST(fg_end9 AS INT64) AS fg_end9, pc_lv10, CAST(fg_pc10 AS INT64) AS fg_pc10, CAST(fg_end10 AS INT64) AS fg_end10, pc_lv11, CAST(fg_pc11 AS INT64) AS fg_pc11, CAST(fg_end11 AS INT64) AS fg_end11, pc_bez1, pc_bez2, pc_bez3, pc_bez4, pc_bez5, pc_bez6, pc_bez7, pc_bez8, pc_bez9, pc_bez10, pc_bez11, CAST(robbies_fett_fg AS INT64) AS robbies_fett_fg, CAST(pc_hiertyp_id AS INT64) AS pc_hiertyp_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_pc_pc_grp_denorm`;

-- Table: DBP_MSI_DATA.TS_BESTWERTFORTSCHREIBUNG
insert into `dbp_msi_data.ts_bestwertfortschreibung` (mandant_id, wup_id, nb_id, dat, owg_id, arthiertyp_id, wrg_id, umsatz_plan_brutto_owg, wareneingang_brutto_owg, schlussbestand_vormonat_brutto_owg, datzeit_pflege, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(owg_id AS INT64) AS owg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, wrg_id, CAST(umsatz_plan_brutto_owg AS NUMERIC) AS umsatz_plan_brutto_owg, CAST(wareneingang_brutto_owg AS NUMERIC) AS wareneingang_brutto_owg, CAST(schlussbestand_vormonat_brutto_owg AS NUMERIC) AS schlussbestand_vormonat_brutto_owg, CAST(datzeit_pflege AS DATETIME) AS datzeit_pflege, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_bestwertfortschreibung`;

-- Table: DBP_MSI_DATA.TS_NACHLIEFERUNG
insert into `dbp_msi_data.ts_nachlieferung` (nachlieferung_request_id, gp_exp_name, mandant_id, wup_id, dat_start, art_id, anzahl_dateien, active_fg, ldap_user, gp_id, periodizitaet, datzeit_insert, datzeit_update, td_update, td_insert)
SELECT CAST(nachlieferung_request_id AS INT64) AS nachlieferung_request_id, gp_exp_name, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, dat_start, CAST(art_id AS INT64) AS art_id, CAST(anzahl_dateien AS INT64) AS anzahl_dateien, CAST(active_fg AS INT64) AS active_fg, ldap_user, CAST(gp_id AS INT64) AS gp_id, periodizitaet, CAST(datzeit_insert AS DATETIME) AS datzeit_insert, CAST(datzeit_update AS DATETIME) AS datzeit_update, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_nachlieferung`;

-- Table: DBP_MSI_DATA.WUP_DENORM_PER
insert into `dbp_msi_data.wup_denorm_per` (mandant_id, wup_id, dat_von_bis, gf_gbl_vertrieb_id, vkl_id, hausleiter_id, frische_manager_id, glv_land_id, gl_vertrieb_id, hausleiter_sperr_fg, vkl_sperr_fg, gf_gbl_vertrieb_sperr_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, dat_von_bis, CAST(gf_gbl_vertrieb_id AS INT64) AS gf_gbl_vertrieb_id, CAST(vkl_id AS INT64) AS vkl_id, CAST(hausleiter_id AS INT64) AS hausleiter_id, CAST(frische_manager_id AS INT64) AS frische_manager_id, CAST(glv_land_id AS INT64) AS glv_land_id, CAST(gl_vertrieb_id AS INT64) AS gl_vertrieb_id, CAST(hausleiter_sperr_fg AS INT64) AS hausleiter_sperr_fg, CAST(vkl_sperr_fg AS INT64) AS vkl_sperr_fg, CAST(gf_gbl_vertrieb_sperr_fg AS INT64) AS gf_gbl_vertrieb_sperr_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_wup_denorm_per`;

-- Table: DBP_MSI_VIEW_LOG.TS_TP_OBJEKT_INFO
insert into `dbp_msi_view_log.ts_tp_objekt_info` (mandant_id, tp_objekt_id, tp_objekt_typ, gebaeude_bez, anlage_bez, anlagengruppe_bez, anlagenteil_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(tp_objekt_id AS INT64) AS tp_objekt_id, tp_objekt_typ, gebaeude_bez, anlage_bez, anlagengruppe_bez, anlagenteil_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_ts_tp_objekt_info`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_APPROVED_DECISION
insert into `dbp_msi_view_nfmd.ts_nfmd_approved_decision` (mandant_id, aktion_id, art_id, kjwo_ww, dwh_created_tmsp, user_id, markdown_decision_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, dwh_created_tmsp, user_id, CAST(markdown_decision_id AS INT64) AS markdown_decision_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_approved_decision`;

-- Table: DBP_MSI_VIEW_VIS.TS_VIS_JZG_ZIEL_EINGABE_2025
insert into `dbp_msi_view_vis.ts_vis_jzg_ziel_eingabe_2025` (mandant_id, nb_id, wup_id, wrg_id, gj, metrik_id, typ_id, level_id, wert_eingabe, kommentar_eingabe, zielerreich_eingabe, zeitstempel)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(gj AS INT64) AS gj, CAST(metrik_id AS INT64) AS metrik_id, CAST(typ_id AS INT64) AS typ_id, CAST(level_id AS INT64) AS level_id, CAST(wert_eingabe AS BIGNUMERIC) AS wert_eingabe, kommentar_eingabe, zielerreich_eingabe, zeitstempel
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_vis_jzg_ziel_eingabe_2025`;

-- Table: DBP_SECURITY.LEIST_EMPFAENGER_LDAP_ZU
insert into `dbp_security.leist_empfaenger_ldap_zu` (mandant_id, lagernummer_id, wup_id, nb_id, leist_empfaenger_sap_id, ma_ldap, gp_id, leist_auswerteberechtigt_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, leist_empfaenger_sap_id, ma_ldap, CAST(gp_id AS INT64) AS gp_id, CAST(leist_auswerteberechtigt_fg AS INT64) AS leist_auswerteberechtigt_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_leist_empfaenger_ldap_zu`;

-- Table: DBP_DATA.FRISCHE_INVENTUR
insert into `dbp_data.frische_inventur` (mandant_id, wup_id, nb_id, wg_id, arthiertyp_id, kjmo, wrg_id, anf_bestand_vk_brutto, anf_bestand_ek_netto, we_zl_vk_brutto, we_dezentral_vk_brutto, we_zl_ek_netto, we_dezentral_ek_netto, we_shop_in_shop_ek_netto, abschrift_brutto, werbe_abschrift_brutto, end_bestand_vk_brutto, end_bestand_ek_netto, umsatz_brutto, umsatz_netto, erl_mind_brutto, erl_mind_netto, tkl_lieferung_vk_brutto, tkl_lieferung_ek_netto, we_zl_vk_netto, we_shop_in_shop_vk_netto, geplant_fg, durchgefuehrt_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(kjmo AS INT64) AS kjmo, wrg_id, CAST(anf_bestand_vk_brutto AS NUMERIC) AS anf_bestand_vk_brutto, CAST(anf_bestand_ek_netto AS NUMERIC) AS anf_bestand_ek_netto, CAST(we_zl_vk_brutto AS NUMERIC) AS we_zl_vk_brutto, CAST(we_dezentral_vk_brutto AS NUMERIC) AS we_dezentral_vk_brutto, CAST(we_zl_ek_netto AS NUMERIC) AS we_zl_ek_netto, CAST(we_dezentral_ek_netto AS NUMERIC) AS we_dezentral_ek_netto, CAST(we_shop_in_shop_ek_netto AS NUMERIC) AS we_shop_in_shop_ek_netto, CAST(abschrift_brutto AS NUMERIC) AS abschrift_brutto, CAST(werbe_abschrift_brutto AS NUMERIC) AS werbe_abschrift_brutto, CAST(end_bestand_vk_brutto AS NUMERIC) AS end_bestand_vk_brutto, CAST(end_bestand_ek_netto AS NUMERIC) AS end_bestand_ek_netto, CAST(umsatz_brutto AS NUMERIC) AS umsatz_brutto, CAST(umsatz_netto AS NUMERIC) AS umsatz_netto, CAST(erl_mind_brutto AS NUMERIC) AS erl_mind_brutto, CAST(erl_mind_netto AS NUMERIC) AS erl_mind_netto, CAST(tkl_lieferung_vk_brutto AS NUMERIC) AS tkl_lieferung_vk_brutto, CAST(tkl_lieferung_ek_netto AS NUMERIC) AS tkl_lieferung_ek_netto, CAST(we_zl_vk_netto AS NUMERIC) AS we_zl_vk_netto, CAST(we_shop_in_shop_vk_netto AS NUMERIC) AS we_shop_in_shop_vk_netto, CAST(geplant_fg AS INT64) AS geplant_fg, CAST(durchgefuehrt_fg AS INT64) AS durchgefuehrt_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_frische_inventur`;

-- Table: DBP_DATA.HFM_INVENTUR_TERMIN_OWG_WUP_DETAIL
insert into `dbp_data.hfm_inventur_termin_owg_wup_detail` (mandant_id, wup_id, nb_id, dat_plan_zaehlung, inventurart_int_id, owg_id, arthiertyp_id, dat_vorletzte_zaehlung, wrg_id, anfangsbestand, warenzugang, warenzugang_dzl, warenzugang_dzl_korr, warenzugang_zl, warenzugang_zl_korr, warenzugang_retoure, abschriften_ohne_diebstahl, werbegutschriften, abschriften_operativ, abschriften_ta_vt_sonstige, endbestand_rechnerisch, endbestand_gezaehlt, umsatz_soll, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat_plan_zaehlung, CAST(inventurart_int_id AS INT64) AS inventurart_int_id, CAST(owg_id AS INT64) AS owg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, dat_vorletzte_zaehlung, wrg_id, CAST(anfangsbestand AS NUMERIC) AS anfangsbestand, CAST(warenzugang AS NUMERIC) AS warenzugang, CAST(warenzugang_dzl AS NUMERIC) AS warenzugang_dzl, CAST(warenzugang_dzl_korr AS NUMERIC) AS warenzugang_dzl_korr, CAST(warenzugang_zl AS NUMERIC) AS warenzugang_zl, CAST(warenzugang_zl_korr AS NUMERIC) AS warenzugang_zl_korr, CAST(warenzugang_retoure AS NUMERIC) AS warenzugang_retoure, CAST(abschriften_ohne_diebstahl AS NUMERIC) AS abschriften_ohne_diebstahl, CAST(werbegutschriften AS NUMERIC) AS werbegutschriften, CAST(abschriften_operativ AS NUMERIC) AS abschriften_operativ, CAST(abschriften_ta_vt_sonstige AS NUMERIC) AS abschriften_ta_vt_sonstige, CAST(endbestand_rechnerisch AS NUMERIC) AS endbestand_rechnerisch, CAST(endbestand_gezaehlt AS NUMERIC) AS endbestand_gezaehlt, CAST(umsatz_soll AS NUMERIC) AS umsatz_soll, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_hfm_inventur_termin_owg_wup_detail`;

-- Table: DBP_DATA.HL
insert into `dbp_data.hl` (hl_id, mandant_id, hl_name, td_update, td_insert)
SELECT CAST(hl_id AS INT64) AS hl_id, CAST(mandant_id AS INT64) AS mandant_id, hl_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_hl`;

-- Table: DBP_DATA.HR_MASSNAHME_SPR_ZU
insert into `dbp_data.hr_massnahme_spr_zu` (mandant_id, hr_massnahme_grund_id, hr_massnahme_id, spr_id, hr_massnahme_grund_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, hr_massnahme_grund_id, hr_massnahme_id, CAST(spr_id AS INT64) AS spr_id, hr_massnahme_grund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_hr_massnahme_spr_zu`;

-- Table: DBP_DATA.HYDRA_ZEITERFASSUNG
insert into `dbp_data.hydra_zeiterfassung` (mandant_id, pers_teilbereich_id, dat, dauer, abrechnung_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, pers_teilbereich_id, dat, CAST(dauer AS NUMERIC) AS dauer, CAST(abrechnung_fg AS INT64) AS abrechnung_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_hydra_zeiterfassung`;

-- Table: DBP_DATA.IMMO_L_MO_ART
insert into `dbp_data.immo_l_mo_art` (mandant_id, mo_art_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mo_art_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mo_art`;

-- Table: DBP_DATA.IMMO_L_MO_BEMESSUNG_ART
insert into `dbp_data.immo_l_mo_bemessung_art` (mandant_id, bemessung_art_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, bemessung_art_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mo_bemessung_art`;

-- Table: DBP_DATA.IMMO_L_MO_NUTZUNG
insert into `dbp_data.immo_l_mo_nutzung` (mandant_id, mo_nutzung_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_nutzung_id AS INT64) AS mo_nutzung_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mo_nutzung`;

-- Table: DBP_DATA.IMMO_L_MO_STATUS
insert into `dbp_data.immo_l_mo_status` (mandant_id, mo_status_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_status_id AS INT64) AS mo_status_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mo_status`;

-- Table: DBP_DATA.IMMO_L_MO_TYP
insert into `dbp_data.immo_l_mo_typ` (mandant_id, mo_typ_id, mo_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_typ_id AS INT64) AS mo_typ_id, mo_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mo_typ`;

-- Table: DBP_DATA.IMMO_L_MV_ANLASS_ZWVERMIETUNG
insert into `dbp_data.immo_l_mv_anlass_zwvermietung` (mandant_id, anlass_zwvermietung_id, anlass_zwvermietung_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(anlass_zwvermietung_id AS INT64) AS anlass_zwvermietung_id, anlass_zwvermietung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_mv_anlass_zwvermietung`;

-- Table: DBP_DATA.IMMO_L_REGION
insert into `dbp_data.immo_l_region` (mandant_id, region_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, region_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_region`;

-- Table: DBP_DATA.IMMO_L_ROLLE
insert into `dbp_data.immo_l_rolle` (mandant_id, rolle_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, rolle_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_rolle`;

-- Table: DBP_DATA.IMMO_L_VERTRAGSART
insert into `dbp_data.immo_l_vertragsart` (mandant_id, vertragsart_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vertragsart_id AS INT64) AS vertragsart_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_l_vertragsart`;

-- Table: DBP_DATA.IMMO_MIETVERTRAG_WE_ZU_PER
insert into `dbp_data.immo_mietvertrag_we_zu_per` (mandant_id, mv_intreno, we_intreno, dat_von, dat_bis, zuordnung_info_kz, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mv_intreno, we_intreno, dat_von, dat_bis, zuordnung_info_kz, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mietvertrag_we_zu_per`;

-- Table: DBP_DATA.IMMO_MO_ART_SPR_ZU
insert into `dbp_data.immo_mo_art_spr_zu` (mandant_id, mo_art_kz, spr_id, mo_art_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mo_art_kz, CAST(spr_id AS INT64) AS spr_id, mo_art_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mo_art_spr_zu`;

-- Table: DBP_DATA.IMMO_MO_BEMESSUNG_ART_SPR_ZU
insert into `dbp_data.immo_mo_bemessung_art_spr_zu` (mandant_id, bemessung_art_id, spr_id, bemessung_art_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, bemessung_art_id, CAST(spr_id AS INT64) AS spr_id, bemessung_art_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mo_bemessung_art_spr_zu`;

-- Table: DBP_DATA.IMMO_MO_NUTZUNG_SPR_ZU
insert into `dbp_data.immo_mo_nutzung_spr_zu` (mandant_id, mo_nutzung_id, spr_id, mo_nutzung_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_nutzung_id AS INT64) AS mo_nutzung_id, CAST(spr_id AS INT64) AS spr_id, mo_nutzung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mo_nutzung_spr_zu`;

-- Table: DBP_DATA.IMMO_MO_STATUS_SPR_ZU
insert into `dbp_data.immo_mo_status_spr_zu` (mandant_id, mo_status_id, spr_id, mo_status_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mo_status_id AS INT64) AS mo_status_id, CAST(spr_id AS INT64) AS spr_id, mo_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_mo_status_spr_zu`;

-- Table: DBP_DATA.IMMO_PLANUNG_MIETEINNAHMEN
insert into `dbp_data.immo_planung_mieteinnahmen` (mandant_id, we_intreno, wrg_id, planmiete_per_monat, planmiete_per_qm, planflaeche, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, we_intreno, wrg_id, CAST(planmiete_per_monat AS NUMERIC) AS planmiete_per_monat, CAST(planmiete_per_qm AS NUMERIC) AS planmiete_per_qm, CAST(planflaeche AS NUMERIC) AS planflaeche, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_planung_mieteinnahmen`;

-- Table: DBP_DATA.IMMO_REGION_SPR_ZU
insert into `dbp_data.immo_region_spr_zu` (mandant_id, region_id, spr_id, region_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, region_id, CAST(spr_id AS INT64) AS spr_id, region_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_immo_region_spr_zu`;

-- Table: DBP_DATA.IMMO_ROLLE_SPR_ZU
insert into `dbp_data.immo_rolle_spr_zu` (mandant_id, rolle_kz, spr_id, rolle_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, rolle_kz, CAST(spr_id AS INT64) AS spr_id, rolle_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_rolle_spr_zu`;

-- Table: DBP_DATA.IMMO_WE_PARTNER_ROLLE_ZU_PER
insert into `dbp_data.immo_we_partner_rolle_zu_per` (mandant_id, we_intreno, rolle_kz, dat_von, dat_bis, partner_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, we_intreno, rolle_kz, dat_von, dat_bis, partner_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_immo_we_partner_rolle_zu_per`;

-- Table: DBP_DATA.IMS_ANWENDERSTATUS_SPR_ZU
insert into `dbp_data.ims_anwenderstatus_spr_zu` (mandant_id, anwenderstatus_id, spr_id, anwenderstatus_bez_kurz, anwenderstatus_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, anwenderstatus_id, CAST(spr_id AS INT64) AS spr_id, anwenderstatus_bez_kurz, anwenderstatus_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_anwenderstatus_spr_zu`;

-- Table: DBP_DATA.IMS_L_ANWENDERSTATUS
insert into `dbp_data.ims_l_anwenderstatus` (mandant_id, anwenderstatus_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, anwenderstatus_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_l_anwenderstatus`;

-- Table: DBP_DATA.IMS_MAMO_QUALIFIER_REF_WUP_ZU
insert into `dbp_data.ims_mamo_qualifier_ref_wup_zu` (mandant_id, ref_wup_id, nb_id, qualifier_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ref_wup_id AS INT64) AS ref_wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(qualifier_id AS INT64) AS qualifier_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_qualifier_ref_wup_zu`;

-- Table: DBP_DATA.IMS_MAMO_WUP_QUALIFIER_ZU
insert into `dbp_data.ims_mamo_wup_qualifier_zu` (mandant_id, wup_id, nb_id, qualifier_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(qualifier_id AS INT64) AS qualifier_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_mamo_wup_qualifier_zu`;

-- Table: DBP_DATA.IMS_PROJEKT_TYP_SPR_ZU
insert into `dbp_data.ims_projekt_typ_spr_zu` (mandant_id, ims_projekt_typ_id, spr_id, ims_projekt_typ_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ims_projekt_typ_id, CAST(spr_id AS INT64) AS spr_id, ims_projekt_typ_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_projekt_typ_spr_zu`;

-- Table: DBP_DATA.IMS_STANDORT
insert into `dbp_data.ims_standort` (mandant_id, standort_id, wup_id, nb_id, standort_name, dat_eroeffnung, eigentum_kz, umzugsfiliale_fg, neu_standort_fg, ginfo_markt_typ, umsatz_ea, verkaufsflaeche, konzessionaersflaeche, betriebsflaeche, sparte_id, datenquelle_kz, wrg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, standort_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, standort_name, dat_eroeffnung, CAST(eigentum_kz AS INT64) AS eigentum_kz, CAST(umzugsfiliale_fg AS INT64) AS umzugsfiliale_fg, CAST(neu_standort_fg AS INT64) AS neu_standort_fg, ginfo_markt_typ, CAST(umsatz_ea AS INT64) AS umsatz_ea, CAST(verkaufsflaeche AS NUMERIC) AS verkaufsflaeche, CAST(konzessionaersflaeche AS NUMERIC) AS konzessionaersflaeche, CAST(betriebsflaeche AS NUMERIC) AS betriebsflaeche, CAST(sparte_id AS INT64) AS sparte_id, CAST(datenquelle_kz AS INT64) AS datenquelle_kz, wrg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ims_standort`;

-- Table: DBP_DATA.IN_L_BUDGET_TYP
insert into `dbp_data.in_l_budget_typ` (in_budget_typ_id, td_update, td_insert)
SELECT in_budget_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_in_l_budget_typ`;

-- Table: DBP_DATA.KORREKTUR_ROHERTRAG_KALK_WUP_ART_ZU_PER
insert into `dbp_data.korrektur_rohertrag_kalk_wup_art_zu_per` (mandant_id, berichtstyp_id, wup_id, nb_id, art_id, gp_id, dat_zeitscheibe, datzeit_erstellung, datzeit_upload, wrg_id, basismenge_einh_id, menge_umsatz_kor, menge_umsatz_a_kor, p1_umsatz, p1_umsatz_kor, p1_umsatz_a_kor, p2_we_kor, p2_we_a_kor, p3_spanne_kor, p3_spanne_a_kor, p4_erg_flw_kor, p4_erg_flw_a_kor, p5_pr_aend_eh_kor, p5_pr_aend_eh_a_kor, p6_spanne_bas_kor, p6_spanne_bas_a_kor, p7_verkalk_bonus_kor, p7_verkalk_bonus_a_kor, p8_bonus_verguetungen_kor, p8_bonus_verguetungen_a_kor, p9_aktions_pv_kor, p9_aktions_pv_a_kor, p10_restanten_pv_kor, p10_restanten_pv_a_kor, p11_pv_kor, p11_pv_a_kor, p12_ek_aktionsrabatt_kor, p12_ek_aktionsrabatt_a_kor, p13_kalkulation_abteilung_kor, p13_kalkulation_abteilung_a_kor, p14_wkz_kor, p14_wkz_a_kor, p15_eak_kor, p15_eak_a_kor, p16_verguetungen_vorjahre_kor, p16_verguetungen_vorjahre_a_kor, p17_verguetungen_spanne_kor, p17_verguetungen_spanne_a_kor, p18_ertrag_export_kor, p18_ertrag_export_a_kor, p19_kalkulation_rest_kor, p19_kalkulation_rest_a_kor, p20_kalkulation_kor, p20_kalkulation_a_kor, p21_aktions_pv_kor, p21_aktions_pv_a_kor, p22_restanten_pv_kor, p22_restanten_pv_a_kor, p23_pv_kor, p23_pv_a_kor, p24_ek_aktionsrabatt_kor, p24_ek_aktionsrabatt_a_kor, p25_kalkulation_nach_pv_kor, p25_kalkulation_nach_pv_a_kor, p26_preisabschriften_vt_kor, p27_restantenverwertung_kor, p28_totalabschrift_vt_kor, p29_totalabschrift_eink_ek_kor, p30_totalabschrift_log_ek_kor, p31_totalabschriften_kor, p32_sonst_totalabschriften_vt_kor, p33_sonst_totalabschriften_ein_kor, p34_sonst_totalabschriften_log_kor, p35_sonst_totalabschriften_kor, p36_erloese_erstatt_totalabsch_kor, p37_abschriften_kor, p38_inventurdiff_geb_vt_kor, p38_a_invdiff_totalabsch_kor, p39_inventurdiff_abgr_vt_kor, p40_inventurdiff_vt_kor, p41_invdiff_geb_log_ek_kor, p42_invdiff_abgr_log_ek_kor, p43_invdiff_log_kor, p44_inventurdifferenzen_kor, p45_preisabschrift_vt_vk_netto_kor, p46_restantenverwertung_vk_net_kor, p47_totalabschrift_vt_ek_kor, p48_totalabschrift_ek_ek_kor, p49_totalabschrift_log_ek_kor, p50_totalabschriften_ek_kor, p51_sonst_totalabschrift_vt_ek_kor, p52_sonst_totalabschrift_ek_ek_kor, p53_sonst_totalabschrif_log_ek_kor, p54_sonstige_abschriften_ek_kor, p55_erloese_erstatt_totalabscr_kor, p56_abschriften_ek_kor, p57_invdiff_gebucht_vt_ek_kor, p57_a_invdiff_totalabsch_ek_kor, p58_invdiff_abgr_vt_ek_kor, p59_invdiff_vertrieb_ek_kor, p60_invdiff_gebucht_logist_ek_kor, p61_invdiff_vertrieb_ek_kor, p62_invdiff_ek_kor, p63_warenverluste_ek_kor, p64_warenverluste_vk_netto_pos_kor, p65_ueberleitung_vkn_zu_ek_kor, p66_bewertungskorrektur_bestan_kor, p67_uebrige_bestanteile_kor, p68_nicht_klaerbare_diff_guv_kor, p69_sonstiger_rohertrag_kor, p70_rohertrag_kor, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, berichtstyp_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, CAST(gp_id AS INT64) AS gp_id, dat_zeitscheibe, datzeit_erstellung, datzeit_upload, wrg_id, basismenge_einh_id, CAST(menge_umsatz_kor AS NUMERIC) AS menge_umsatz_kor, CAST(menge_umsatz_a_kor AS NUMERIC) AS menge_umsatz_a_kor, CAST(p1_umsatz AS NUMERIC) AS p1_umsatz, CAST(p1_umsatz_kor AS NUMERIC) AS p1_umsatz_kor, CAST(p1_umsatz_a_kor AS NUMERIC) AS p1_umsatz_a_kor, CAST(p2_we_kor AS NUMERIC) AS p2_we_kor, CAST(p2_we_a_kor AS NUMERIC) AS p2_we_a_kor, CAST(p3_spanne_kor AS NUMERIC) AS p3_spanne_kor, CAST(p3_spanne_a_kor AS NUMERIC) AS p3_spanne_a_kor, CAST(p4_erg_flw_kor AS NUMERIC) AS p4_erg_flw_kor, CAST(p4_erg_flw_a_kor AS NUMERIC) AS p4_erg_flw_a_kor, CAST(p5_pr_aend_eh_kor AS NUMERIC) AS p5_pr_aend_eh_kor, CAST(p5_pr_aend_eh_a_kor AS NUMERIC) AS p5_pr_aend_eh_a_kor, CAST(p6_spanne_bas_kor AS NUMERIC) AS p6_spanne_bas_kor, CAST(p6_spanne_bas_a_kor AS NUMERIC) AS p6_spanne_bas_a_kor, CAST(p7_verkalk_bonus_kor AS NUMERIC) AS p7_verkalk_bonus_kor, CAST(p7_verkalk_bonus_a_kor AS NUMERIC) AS p7_verkalk_bonus_a_kor, CAST(p8_bonus_verguetungen_kor AS NUMERIC) AS p8_bonus_verguetungen_kor, CAST(p8_bonus_verguetungen_a_kor AS NUMERIC) AS p8_bonus_verguetungen_a_kor, CAST(p9_aktions_pv_kor AS NUMERIC) AS p9_aktions_pv_kor, CAST(p9_aktions_pv_a_kor AS NUMERIC) AS p9_aktions_pv_a_kor, CAST(p10_restanten_pv_kor AS NUMERIC) AS p10_restanten_pv_kor, CAST(p10_restanten_pv_a_kor AS NUMERIC) AS p10_restanten_pv_a_kor, CAST(p11_pv_kor AS NUMERIC) AS p11_pv_kor, CAST(p11_pv_a_kor AS NUMERIC) AS p11_pv_a_kor, CAST(p12_ek_aktionsrabatt_kor AS NUMERIC) AS p12_ek_aktionsrabatt_kor, CAST(p12_ek_aktionsrabatt_a_kor AS NUMERIC) AS p12_ek_aktionsrabatt_a_kor, CAST(p13_kalkulation_abteilung_kor AS NUMERIC) AS p13_kalkulation_abteilung_kor, CAST(p13_kalkulation_abteilung_a_kor AS NUMERIC) AS p13_kalkulation_abteilung_a_kor, CAST(p14_wkz_kor AS NUMERIC) AS p14_wkz_kor, CAST(p14_wkz_a_kor AS NUMERIC) AS p14_wkz_a_kor, CAST(p15_eak_kor AS NUMERIC) AS p15_eak_kor, CAST(p15_eak_a_kor AS NUMERIC) AS p15_eak_a_kor, CAST(p16_verguetungen_vorjahre_kor AS NUMERIC) AS p16_verguetungen_vorjahre_kor, CAST(p16_verguetungen_vorjahre_a_kor AS NUMERIC) AS p16_verguetungen_vorjahre_a_kor, CAST(p17_verguetungen_spanne_kor AS NUMERIC) AS p17_verguetungen_spanne_kor, CAST(p17_verguetungen_spanne_a_kor AS NUMERIC) AS p17_verguetungen_spanne_a_kor, CAST(p18_ertrag_export_kor AS NUMERIC) AS p18_ertrag_export_kor, CAST(p18_ertrag_export_a_kor AS NUMERIC) AS p18_ertrag_export_a_kor, CAST(p19_kalkulation_rest_kor AS NUMERIC) AS p19_kalkulation_rest_kor, CAST(p19_kalkulation_rest_a_kor AS NUMERIC) AS p19_kalkulation_rest_a_kor, CAST(p20_kalkulation_kor AS NUMERIC) AS p20_kalkulation_kor, CAST(p20_kalkulation_a_kor AS NUMERIC) AS p20_kalkulation_a_kor, CAST(p21_aktions_pv_kor AS NUMERIC) AS p21_aktions_pv_kor, CAST(p21_aktions_pv_a_kor AS NUMERIC) AS p21_aktions_pv_a_kor, CAST(p22_restanten_pv_kor AS NUMERIC) AS p22_restanten_pv_kor, CAST(p22_restanten_pv_a_kor AS NUMERIC) AS p22_restanten_pv_a_kor, CAST(p23_pv_kor AS NUMERIC) AS p23_pv_kor, CAST(p23_pv_a_kor AS NUMERIC) AS p23_pv_a_kor, CAST(p24_ek_aktionsrabatt_kor AS NUMERIC) AS p24_ek_aktionsrabatt_kor, CAST(p24_ek_aktionsrabatt_a_kor AS NUMERIC) AS p24_ek_aktionsrabatt_a_kor, CAST(p25_kalkulation_nach_pv_kor AS NUMERIC) AS p25_kalkulation_nach_pv_kor, CAST(p25_kalkulation_nach_pv_a_kor AS NUMERIC) AS p25_kalkulation_nach_pv_a_kor, CAST(p26_preisabschriften_vt_kor AS NUMERIC) AS p26_preisabschriften_vt_kor, CAST(p27_restantenverwertung_kor AS NUMERIC) AS p27_restantenverwertung_kor, CAST(p28_totalabschrift_vt_kor AS NUMERIC) AS p28_totalabschrift_vt_kor, CAST(p29_totalabschrift_eink_ek_kor AS NUMERIC) AS p29_totalabschrift_eink_ek_kor, CAST(p30_totalabschrift_log_ek_kor AS NUMERIC) AS p30_totalabschrift_log_ek_kor, CAST(p31_totalabschriften_kor AS NUMERIC) AS p31_totalabschriften_kor, CAST(p32_sonst_totalabschriften_vt_kor AS NUMERIC) AS p32_sonst_totalabschriften_vt_kor, CAST(p33_sonst_totalabschriften_ein_kor AS NUMERIC) AS p33_sonst_totalabschriften_ein_kor, CAST(p34_sonst_totalabschriften_log_kor AS NUMERIC) AS p34_sonst_totalabschriften_log_kor, CAST(p35_sonst_totalabschriften_kor AS NUMERIC) AS p35_sonst_totalabschriften_kor, CAST(p36_erloese_erstatt_totalabsch_kor AS NUMERIC) AS p36_erloese_erstatt_totalabsch_kor, CAST(p37_abschriften_kor AS NUMERIC) AS p37_abschriften_kor, CAST(p38_inventurdiff_geb_vt_kor AS NUMERIC) AS p38_inventurdiff_geb_vt_kor, CAST(p38_a_invdiff_totalabsch_kor AS NUMERIC) AS p38_a_invdiff_totalabsch_kor, CAST(p39_inventurdiff_abgr_vt_kor AS NUMERIC) AS p39_inventurdiff_abgr_vt_kor, CAST(p40_inventurdiff_vt_kor AS NUMERIC) AS p40_inventurdiff_vt_kor, CAST(p41_invdiff_geb_log_ek_kor AS NUMERIC) AS p41_invdiff_geb_log_ek_kor, CAST(p42_invdiff_abgr_log_ek_kor AS NUMERIC) AS p42_invdiff_abgr_log_ek_kor, CAST(p43_invdiff_log_kor AS NUMERIC) AS p43_invdiff_log_kor, CAST(p44_inventurdifferenzen_kor AS NUMERIC) AS p44_inventurdifferenzen_kor, CAST(p45_preisabschrift_vt_vk_netto_kor AS NUMERIC) AS p45_preisabschrift_vt_vk_netto_kor, CAST(p46_restantenverwertung_vk_net_kor AS NUMERIC) AS p46_restantenverwertung_vk_net_kor, CAST(p47_totalabschrift_vt_ek_kor AS NUMERIC) AS p47_totalabschrift_vt_ek_kor, CAST(p48_totalabschrift_ek_ek_kor AS NUMERIC) AS p48_totalabschrift_ek_ek_kor, CAST(p49_totalabschrift_log_ek_kor AS NUMERIC) AS p49_totalabschrift_log_ek_kor, CAST(p50_totalabschriften_ek_kor AS NUMERIC) AS p50_totalabschriften_ek_kor, CAST(p51_sonst_totalabschrift_vt_ek_kor AS NUMERIC) AS p51_sonst_totalabschrift_vt_ek_kor, CAST(p52_sonst_totalabschrift_ek_ek_kor AS NUMERIC) AS p52_sonst_totalabschrift_ek_ek_kor, CAST(p53_sonst_totalabschrif_log_ek_kor AS NUMERIC) AS p53_sonst_totalabschrif_log_ek_kor, CAST(p54_sonstige_abschriften_ek_kor AS NUMERIC) AS p54_sonstige_abschriften_ek_kor, CAST(p55_erloese_erstatt_totalabscr_kor AS NUMERIC) AS p55_erloese_erstatt_totalabscr_kor, CAST(p56_abschriften_ek_kor AS NUMERIC) AS p56_abschriften_ek_kor, CAST(p57_invdiff_gebucht_vt_ek_kor AS NUMERIC) AS p57_invdiff_gebucht_vt_ek_kor, CAST(p57_a_invdiff_totalabsch_ek_kor AS NUMERIC) AS p57_a_invdiff_totalabsch_ek_kor, CAST(p58_invdiff_abgr_vt_ek_kor AS NUMERIC) AS p58_invdiff_abgr_vt_ek_kor, CAST(p59_invdiff_vertrieb_ek_kor AS NUMERIC) AS p59_invdiff_vertrieb_ek_kor, CAST(p60_invdiff_gebucht_logist_ek_kor AS NUMERIC) AS p60_invdiff_gebucht_logist_ek_kor, CAST(p61_invdiff_vertrieb_ek_kor AS NUMERIC) AS p61_invdiff_vertrieb_ek_kor, CAST(p62_invdiff_ek_kor AS NUMERIC) AS p62_invdiff_ek_kor, CAST(p63_warenverluste_ek_kor AS NUMERIC) AS p63_warenverluste_ek_kor, CAST(p64_warenverluste_vk_netto_pos_kor AS NUMERIC) AS p64_warenverluste_vk_netto_pos_kor, CAST(p65_ueberleitung_vkn_zu_ek_kor AS NUMERIC) AS p65_ueberleitung_vkn_zu_ek_kor, CAST(p66_bewertungskorrektur_bestan_kor AS NUMERIC) AS p66_bewertungskorrektur_bestan_kor, CAST(p67_uebrige_bestanteile_kor AS NUMERIC) AS p67_uebrige_bestanteile_kor, CAST(p68_nicht_klaerbare_diff_guv_kor AS NUMERIC) AS p68_nicht_klaerbare_diff_guv_kor, CAST(p69_sonstiger_rohertrag_kor AS NUMERIC) AS p69_sonstiger_rohertrag_kor, CAST(p70_rohertrag_kor AS NUMERIC) AS p70_rohertrag_kor, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_korrektur_rohertrag_kalk_wup_art_zu_per`;

-- Table: DBP_DATA.L_CROSSDOCKING
insert into `dbp_data.l_crossdocking` (mandant_id, crossdocking_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(crossdocking_id AS INT64) AS crossdocking_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_crossdocking`;

-- Table: DBP_DATA.L_IVN_SORTIMENTSGRUPPE
insert into `dbp_data.l_ivn_sortimentsgruppe` (mandant_id, ivn_sortimentsgruppe_id, ivn_sortimentsgruppe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ivn_sortimentsgruppe_id AS INT64) AS ivn_sortimentsgruppe_id, ivn_sortimentsgruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_ivn_sortimentsgruppe`;

-- Table: DBP_DATA.L_KONDITIONSGRUPPE
insert into `dbp_data.l_konditionsgruppe` (mandant_id, konditionsgruppe_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, konditionsgruppe_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_konditionsgruppe`;

-- Table: DBP_DATA.L_UNTERNMNS_BEREICH
insert into `dbp_data.l_unternmns_bereich` (mandant_id, unternehmens_bereich_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, unternehmens_bereich_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_unternmns_bereich`;

-- Table: DBP_DATA.L_VERRECHFALL_STATUS
insert into `dbp_data.l_verrechfall_status` (mandant_id, verrechfall_status_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechfall_status_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_verrechfall_status`;

-- Table: DBP_DATA.L_VORGANGSART_AG08
insert into `dbp_data.l_vorgangsart_ag08` (system_id, mandant_id, vorgangsart_ag08_id, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, vorgangsart_ag08_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_vorgangsart_ag08`;

-- Table: DBP_DATA.L_VORGANGSKLASSE
insert into `dbp_data.l_vorgangsklasse` (system_id, mandant_id, vorgangsklasse_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, vorgangsklasse_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_vorgangsklasse`;

-- Table: DBP_DATA.L_WBNK
insert into `dbp_data.l_wbnk` (system_id, mandant_id, wbnk_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, wbnk_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wbnk`;

-- Table: DBP_DATA.L_WBNK_GRUPPE
insert into `dbp_data.l_wbnk_gruppe` (system_id, mandant_id, wbnk_gruppe_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wbnk_gruppe_id AS INT64) AS wbnk_gruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wbnk_gruppe`;

-- Table: DBP_DATA.L_WBS_PHASE
insert into `dbp_data.l_wbs_phase` (mandant_id, wbs_phase_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wbs_phase_id AS INT64) AS wbs_phase_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wbs_phase`;

-- Table: DBP_DATA.L_WERBEBEREICH
insert into `dbp_data.l_werbebereich` (mandant_id, werbebereich_cd, werbebereich_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, werbebereich_cd, werbebereich_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbebereich`;

-- Table: DBP_DATA.L_WERBEFLAECHENABSCHNITT
insert into `dbp_data.l_werbeflaechenabschnitt` (mandant_id, werbeflaechenabschnitt_id, werbeflaechenabschnitt_avq_prio_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbeflaechenabschnitt_id AS INT64) AS werbeflaechenabschnitt_id, CAST(werbeflaechenabschnitt_avq_prio_nr AS INT64) AS werbeflaechenabschnitt_avq_prio_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbeflaechenabschnitt`;

-- Table: DBP_DATA.L_WERBEFLAECHENABSCHNITT_AVQ_PRIO
insert into `dbp_data.l_werbeflaechenabschnitt_avq_prio` (mandant_id, werbeflaechenabschnitt_avq_prio_nr, werbeflaechenabschnitt_avq_prio_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbeflaechenabschnitt_avq_prio_nr AS INT64) AS werbeflaechenabschnitt_avq_prio_nr, werbeflaechenabschnitt_avq_prio_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbeflaechenabschnitt_avq_prio`;

-- Table: DBP_DATA.L_WERBEFLAECHENTHEMA
insert into `dbp_data.l_werbeflaechenthema` (mandant_id, werbemittelkanal_id, werbemittel_id, werbeflaechenthema_cd, werbeflaechenthema_bez, werbeflaechenthema_wfl_bez, werbeflaechenthema_avq_prio_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbemittelkanal_id AS INT64) AS werbemittelkanal_id, CAST(werbemittel_id AS INT64) AS werbemittel_id, werbeflaechenthema_cd, werbeflaechenthema_bez, werbeflaechenthema_wfl_bez, CAST(werbeflaechenthema_avq_prio_nr AS INT64) AS werbeflaechenthema_avq_prio_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbeflaechenthema`;

-- Table: DBP_DATA.L_WERBEFLAECHENTHEMA_AVQ_PRIO
insert into `dbp_data.l_werbeflaechenthema_avq_prio` (mandant_id, werbeflaechenthema_avq_prio_nr, werbeflaechenthema_avq_prio_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbeflaechenthema_avq_prio_nr AS INT64) AS werbeflaechenthema_avq_prio_nr, werbeflaechenthema_avq_prio_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbeflaechenthema_avq_prio`;

-- Table: DBP_DATA.L_WERBEKAT
insert into `dbp_data.l_werbekat` (werbe_kat_id, mandant_id, sap_werbe_kat_id, td_insert, td_update)
SELECT CAST(werbe_kat_id AS INT64) AS werbe_kat_id, CAST(mandant_id AS INT64) AS mandant_id, sap_werbe_kat_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_werbekat`;

-- Table: DBP_DATA.L_WERBEMITTEL
insert into `dbp_data.l_werbemittel` (mandant_id, werbemittelkanal_id, werbemittel_id, werbemittel_avq_prio_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, werbemittelkanal_id, werbemittel_id, CAST(werbemittel_avq_prio_nr AS INT64) AS werbemittel_avq_prio_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbemittel`;

-- Table: DBP_DATA.L_WERBEMITTEL_AVQ_PRIO
insert into `dbp_data.l_werbemittel_avq_prio` (mandant_id, werbemittel_avq_prio_nr, werbemittel_avq_prio_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbemittel_avq_prio_nr AS INT64) AS werbemittel_avq_prio_nr, werbemittel_avq_prio_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbemittel_avq_prio`;

-- Table: DBP_DATA.L_WERBEWARE
insert into `dbp_data.l_werbeware` (mandant_id, werbeware_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, werbeware_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_werbeware`;

-- Table: DBP_DATA.L_WERBE_MEDIUM
insert into `dbp_data.l_werbe_medium` (mandant_id, medien_kz, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, medien_kz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_werbe_medium`;

-- Table: DBP_DATA.L_WERBE_TYP
insert into `dbp_data.l_werbe_typ` (mandant_id, werbe_typ_id, wtag_id_start, wtag_id_ende, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbe_typ_id AS INT64) AS werbe_typ_id, CAST(wtag_id_start AS INT64) AS wtag_id_start, CAST(wtag_id_ende AS INT64) AS wtag_id_ende, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_werbe_typ`;

-- Table: DBP_DATA.L_WETTERZUSTAND
insert into `dbp_data.l_wetterzustand` (wetterzustand_id, td_insert, td_update)
SELECT CAST(wetterzustand_id AS INT64) AS wetterzustand_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wetterzustand`;

-- Table: DBP_DATA.L_WEWA_GRUPPE
insert into `dbp_data.l_wewa_gruppe` (system_id, mandant_id, wewa_gruppe_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wewa_gruppe_id AS INT64) AS wewa_gruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wewa_gruppe`;

-- Table: DBP_DATA.L_WE_MESSAGE_STATUS
insert into `dbp_data.l_we_message_status` (mandant_id, we_message_status_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, we_message_status_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_we_message_status`;

-- Table: DBP_DATA.L_WE_STATUS
insert into `dbp_data.l_we_status` (we_status_id, we_status_bez, td_insert, td_update)
SELECT we_status_id, we_status_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_we_status`;

-- Table: DBP_DATA.L_WGVGRUPPE
insert into `dbp_data.l_wgvgruppe` (wgvgrp_id, mandant_id, wup_id, nb_id, td_insert, td_update)
SELECT CAST(wgvgrp_id AS INT64) AS wgvgrp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wgvgruppe`;

-- Table: DBP_DATA.L_WG_HIERARCHIE_EBENE
insert into `dbp_data.l_wg_hierarchie_ebene` (mandant_id, arthiertyp_id, wg_hierarchie_ebene_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_hierarchie_ebene_id AS INT64) AS wg_hierarchie_ebene_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wg_hierarchie_ebene`;

-- Table: DBP_DATA.L_WINDRICHTUNG
insert into `dbp_data.l_windrichtung` (windrichtung_schema_id, windrichtung_id, td_insert, td_update)
SELECT CAST(windrichtung_schema_id AS INT64) AS windrichtung_schema_id, CAST(windrichtung_id AS INT64) AS windrichtung_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_windrichtung`;

-- Table: DBP_DATA.L_WINDRICHTUNG_SCHEMA
insert into `dbp_data.l_windrichtung_schema` (windrichtung_schema_id, windrichtung_schema_bez, td_insert, td_update)
SELECT CAST(windrichtung_schema_id AS INT64) AS windrichtung_schema_id, windrichtung_schema_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_windrichtung_schema`;

-- Table: DBP_DATA.L_WUP_AENDERUNG_GRUND
insert into `dbp_data.l_wup_aenderung_grund` (wup_aenderung_grund_id, td_update, td_insert)
SELECT CAST(wup_aenderung_grund_id AS INT64) AS wup_aenderung_grund_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_wup_aenderung_grund`;

-- Table: DBP_DATA.L_WUP_OEFFNUNG_TYP
insert into `dbp_data.l_wup_oeffnung_typ` (mandant_id, wup_oeffnungs_typ_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_oeffnungs_typ_id AS INT64) AS wup_oeffnungs_typ_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_wup_oeffnung_typ`;

-- Table: DBP_DATA.L_ZAEHL_GRUND
insert into `dbp_data.l_zaehl_grund` (mandant_id, zaehl_grund_id, zaehl_grund_gruppe_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zaehl_grund_id, CAST(zaehl_grund_gruppe_id AS INT64) AS zaehl_grund_gruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_zaehl_grund`;

-- Table: DBP_DATA.L_ZAHLART
insert into `dbp_data.l_zahlart` (system_id, mandant_id, zahlart_id, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, zahlart_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_l_zahlart`;

-- Table: DBP_DATA.L_ZEITFENSTER
insert into `dbp_data.l_zeitfenster` (mandant_id, zeitfenster_id, zeit_von, zeit_bis, report_zeit_von, report_zeit_bis, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(zeitfenster_id AS INT64) AS zeitfenster_id, zeit_von, zeit_bis, report_zeit_von, report_zeit_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_zeitfenster`;

-- Table: DBP_DATA.L_ZUSTELLART
insert into `dbp_data.l_zustellart` (mandant_id, zustellart_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zustellart_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_l_zustellart`;

-- Table: DBP_DATA.MANDANT_GRP
insert into `dbp_data.mandant_grp` (mandantgrp_id, spr_id, mandant_grp_bez, mandant_grp_bez_kurz, td_insert, td_update)
SELECT CAST(mandantgrp_id AS INT64) AS mandantgrp_id, CAST(spr_id AS INT64) AS spr_id, mandant_grp_bez, mandant_grp_bez_kurz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mandant_grp`;

-- Table: DBP_DATA.MANDANT_GRP_ZU
insert into `dbp_data.mandant_grp_zu` (mandantgrp_id, mandant_id, td_insert, td_update)
SELECT CAST(mandantgrp_id AS INT64) AS mandantgrp_id, CAST(mandant_id AS INT64) AS mandant_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mandant_grp_zu`;

-- Table: DBP_DATA.MANDANT_WRG_TYP_ZU
insert into `dbp_data.mandant_wrg_typ_zu` (mandant_id, wrg_typ_id, wrg_id, wrg_typ_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wrg_typ_id AS INT64) AS wrg_typ_id, wrg_id, wrg_typ_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mandant_wrg_typ_zu`;

-- Table: DBP_DATA.MARKANT_SPR_ZU
insert into `dbp_data.markant_spr_zu` (mandant_id, markant_id, spr_id, markant_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, markant_id, CAST(spr_id AS INT64) AS spr_id, markant_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_markant_spr_zu`;

-- Table: DBP_DATA.MARKTMERKMAL_SPR_ZU
insert into `dbp_data.marktmerkmal_spr_zu` (marktmerkmal_id, spr_id, marktmerkmal_bez, marktmerkmal_kbez, td_update, td_insert)
SELECT marktmerkmal_id, CAST(spr_id AS INT64) AS spr_id, marktmerkmal_bez, marktmerkmal_kbez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_marktmerkmal_spr_zu`;

-- Table: DBP_DATA.MARKTMERKMAL_WERT_SPR_ZU
insert into `dbp_data.marktmerkmal_wert_spr_zu` (marktmerkmal_id, marktmerkmal_wert, spr_id, marktmerkmal_wert_bez, marktmerkmal_wert_kbez, td_update, td_insert)
SELECT marktmerkmal_id, marktmerkmal_wert, CAST(spr_id AS INT64) AS spr_id, marktmerkmal_wert_bez, marktmerkmal_wert_kbez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_marktmerkmal_wert_spr_zu`;

-- Table: DBP_DATA.MARKT_LAGERBEREICH_SPR_ZU
insert into `dbp_data.markt_lagerbereich_spr_zu` (mandant_id, markt_lagerbereich_id, spr_id, markt_lagerbereich_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(markt_lagerbereich_id AS INT64) AS markt_lagerbereich_id, CAST(spr_id AS INT64) AS spr_id, markt_lagerbereich_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_markt_lagerbereich_spr_zu`;

-- Table: DBP_DATA.MARKT_VERRAEUMUNG_PRIO_GRUND_SPR_ZU
insert into `dbp_data.markt_verraeumung_prio_grund_spr_zu` (mandant_id, verraeumung_prio_grund_id, spr_id, verraeumung_prio_grund_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verraeumung_prio_grund_id, CAST(spr_id AS INT64) AS spr_id, verraeumung_prio_grund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_markt_verraeumung_prio_grund_spr_zu`;

-- Table: DBP_DATA.MARKT_VZ_ZU
insert into `dbp_data.markt_vz_zu` (mandant_id, vz_wup_id, wup_id, entfernung, direkte_zuordnung_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vz_wup_id AS INT64) AS vz_wup_id, CAST(wup_id AS INT64) AS wup_id, CAST(entfernung AS INT64) AS entfernung, CAST(direkte_zuordnung_fg AS INT64) AS direkte_zuordnung_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_markt_vz_zu`;

-- Table: DBP_DATA.MASSNAHMENART_SPR_ZU
insert into `dbp_data.massnahmenart_spr_zu` (massnahmenart_id, spr_id, massnahmenart_bez, td_insert, td_update)
SELECT CAST(massnahmenart_id AS INT64) AS massnahmenart_id, CAST(spr_id AS INT64) AS spr_id, massnahmenart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_massnahmenart_spr_zu`;

-- Table: DBP_DATA.MASSNAHMENTYP_SPR_ZU
insert into `dbp_data.massnahmentyp_spr_zu` (massnahmentyp_id, spr_id, massnahmentyp_bez, td_update, td_insert)
SELECT CAST(massnahmentyp_id AS INT64) AS massnahmentyp_id, CAST(spr_id AS INT64) AS spr_id, massnahmentyp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_massnahmentyp_spr_zu`;

-- Table: DBP_DATA.MA_FUNKTION_SPR_ZU
insert into `dbp_data.ma_funktion_spr_zu` (mandant_id, ma_funktion_id, spr_id, ma_funktion_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ma_funktion_id, CAST(spr_id AS INT64) AS spr_id, ma_funktion_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ma_funktion_spr_zu`;

-- Table: DBP_DATA.MA_FUNKTION_WUP_ZU
insert into `dbp_data.ma_funktion_wup_zu` (mandant_id, wup_id, ma_id, ma_funktion_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(ma_id AS INT64) AS ma_id, ma_funktion_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ma_funktion_wup_zu`;

-- Table: DBP_DATA.MA_GESCHLECHT_SPR_ZU
insert into `dbp_data.ma_geschlecht_spr_zu` (mandant_id, geschlecht_id, spr_id, geschlecht_bez, anrede_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(geschlecht_id AS INT64) AS geschlecht_id, CAST(spr_id AS INT64) AS spr_id, geschlecht_bez, anrede_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_geschlecht_spr_zu`;

-- Table: DBP_DATA.MA_HIERARCHIE_EBENE_SPR_ZU
insert into `dbp_data.ma_hierarchie_ebene_spr_zu` (mandant_id, ma_hierarchie_ebene_id, spr_id, ma_hierarchie_ebene_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ma_hierarchie_ebene_id, CAST(spr_id AS INT64) AS spr_id, ma_hierarchie_ebene_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_hierarchie_ebene_spr_zu`;

-- Table: DBP_DATA.MA_HIERARCHIE_TYP_SPR_ZU
insert into `dbp_data.ma_hierarchie_typ_spr_zu` (mandant_id, ma_hierarchie_typ_id, spr_id, ma_hierarchie_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ma_hierarchie_typ_id AS INT64) AS ma_hierarchie_typ_id, CAST(spr_id AS INT64) AS spr_id, ma_hierarchie_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_hierarchie_typ_spr_zu`;

-- Table: DBP_DATA.MA_HIER_EB_FKT_WUP_ZU_PER
insert into `dbp_data.ma_hier_eb_fkt_wup_zu_per` (mandant_id, ma_hierarchie_typ_id, ma_hierarchie_id, dat_von, ma_funktion_id, ma_hierarchie_ebene_id, wup_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ma_hierarchie_typ_id AS INT64) AS ma_hierarchie_typ_id, CAST(ma_hierarchie_id AS INT64) AS ma_hierarchie_id, dat_von, ma_funktion_id, ma_hierarchie_ebene_id, CAST(wup_id AS INT64) AS wup_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ma_hier_eb_fkt_wup_zu_per`;

-- Table: DBP_DATA.MCX_ANTWORT_KATEGORIE_ZU
insert into `dbp_data.mcx_antwort_kategorie_zu` (antwort_id, umfrage_id, kat_id, gesamt_fg, td_update, td_insert)
SELECT CAST(antwort_id AS INT64) AS antwort_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(kat_id AS INT64) AS kat_id, CAST(gesamt_fg AS INT64) AS gesamt_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_antwort_kategorie_zu`;

-- Table: DBP_DATA.MCX_ANTWORT_SPR_ZU
insert into `dbp_data.mcx_antwort_spr_zu` (antwort_id, spr_id, umfrage_id, antwort_bez, antwort_datentyp, td_insert, td_update)
SELECT CAST(antwort_id AS INT64) AS antwort_id, CAST(spr_id AS INT64) AS spr_id, CAST(umfrage_id AS INT64) AS umfrage_id, antwort_bez, antwort_datentyp, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_antwort_spr_zu`;

-- Table: DBP_DATA.MCX_BEREICH_INVERS_BEREICH_ZU
insert into `dbp_data.mcx_bereich_invers_bereich_zu` (ber_id, invers_ber_id, umfrage_id, filter_fg, ber_sort, td_insert, td_update)
SELECT CAST(ber_id AS INT64) AS ber_id, CAST(invers_ber_id AS INT64) AS invers_ber_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(filter_fg AS INT64) AS filter_fg, CAST(ber_sort AS INT64) AS ber_sort, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_bereich_invers_bereich_zu`;

-- Table: DBP_DATA.MCX_BEREICH_SPR_ZU
insert into `dbp_data.mcx_bereich_spr_zu` (ber_id, spr_id, ber_bez, td_update, td_insert)
SELECT CAST(ber_id AS INT64) AS ber_id, CAST(spr_id AS INT64) AS spr_id, ber_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_bereich_spr_zu`;

-- Table: DBP_DATA.MCX_FRAGE_SPR_ZU
insert into `dbp_data.mcx_frage_spr_zu` (frage_id, spr_id, umfrage_id, frage_bez, frage_typ, frage_alias, frage_s_code, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(spr_id AS INT64) AS spr_id, CAST(umfrage_id AS INT64) AS umfrage_id, frage_bez, frage_typ, frage_alias, frage_s_code, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_frage_spr_zu`;

-- Table: DBP_DATA.MCX_INVERS_ANTWORT_BEREICH_ZU
insert into `dbp_data.mcx_invers_antwort_bereich_zu` (antwort_id, umfrage_id, invers_ber_id, td_insert, td_update)
SELECT CAST(antwort_id AS INT64) AS antwort_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(invers_ber_id AS INT64) AS invers_ber_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_invers_antwort_bereich_zu`;

-- Table: DBP_DATA.MCX_INVERS_BEREICH_SPR_ZU
insert into `dbp_data.mcx_invers_bereich_spr_zu` (invers_ber_id, spr_id, invers_ber_bez, invers_ber_bez_2, td_insert, td_update)
SELECT CAST(invers_ber_id AS INT64) AS invers_ber_id, CAST(spr_id AS INT64) AS spr_id, invers_ber_bez, invers_ber_bez_2, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_invers_bereich_spr_zu`;

-- Table: DBP_DATA.MCX_INVERS_KATEGORIE_SPR_ZU
insert into `dbp_data.mcx_invers_kategorie_spr_zu` (invers_kat_id, spr_id, invers_kat_bez, invers_kat_bez_2, td_insert, td_update)
SELECT CAST(invers_kat_id AS INT64) AS invers_kat_id, CAST(spr_id AS INT64) AS spr_id, invers_kat_bez, invers_kat_bez_2, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_invers_kategorie_spr_zu`;

-- Table: DBP_DATA.MCX_KATEGORIE_SPR_ZU
insert into `dbp_data.mcx_kategorie_spr_zu` (kat_id, spr_id, kat_bez, td_update, td_insert)
SELECT CAST(kat_id AS INT64) AS kat_id, CAST(spr_id AS INT64) AS spr_id, kat_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_kategorie_spr_zu`;

-- Table: DBP_DATA.MCX_L_ABSCHLUSSSTATUS
insert into `dbp_data.mcx_l_abschlussstatus` (abschluss_id, umfrage_id, abschluss_bez, td_update, td_insert)
SELECT CAST(abschluss_id AS INT64) AS abschluss_id, CAST(umfrage_id AS INT64) AS umfrage_id, abschluss_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_abschlussstatus`;

-- Table: DBP_DATA.MCX_L_ANTWORT
insert into `dbp_data.mcx_l_antwort` (antwort_id, umfrage_id, frage_id, scale_id, antwort_gewichtung, datzeit_aend, td_update, td_insert)
SELECT CAST(antwort_id AS INT64) AS antwort_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(frage_id AS INT64) AS frage_id, CAST(scale_id AS INT64) AS scale_id, CAST(antwort_gewichtung AS INT64) AS antwort_gewichtung, datzeit_aend, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_antwort`;

-- Table: DBP_DATA.MCX_L_ANTWORT_OK_FG
insert into `dbp_data.mcx_l_antwort_ok_fg` (antwort_id, umfrage_id, ok_fg, td_update, td_insert)
SELECT CAST(antwort_id AS INT64) AS antwort_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(ok_fg AS INT64) AS ok_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_antwort_ok_fg`;

-- Table: DBP_DATA.MCX_L_BEREICH
insert into `dbp_data.mcx_l_bereich` (ber_id, umfrage_id, td_update, td_insert)
SELECT CAST(ber_id AS INT64) AS ber_id, CAST(umfrage_id AS INT64) AS umfrage_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_bereich`;

-- Table: DBP_DATA.MCX_L_FRAGE
insert into `dbp_data.mcx_l_frage` (frage_id, umfrage_id, frage_ex_typ, frage_status, td_update, td_insert)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(frage_ex_typ AS INT64) AS frage_ex_typ, CAST(frage_status AS INT64) AS frage_status, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_frage`;

-- Table: DBP_DATA.MCX_L_INVERS_BEREICH
insert into `dbp_data.mcx_l_invers_bereich` (invers_ber_id, invers_kat_id, td_insert, td_update)
SELECT CAST(invers_ber_id AS INT64) AS invers_ber_id, CAST(invers_kat_id AS INT64) AS invers_kat_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_invers_bereich`;

-- Table: DBP_DATA.MCX_L_INVERS_KATEGORIE
insert into `dbp_data.mcx_l_invers_kategorie` (invers_kat_id, umfrage_id, invers_kat_sort, td_insert, td_update)
SELECT CAST(invers_kat_id AS INT64) AS invers_kat_id, CAST(umfrage_id AS INT64) AS umfrage_id, CAST(invers_kat_sort AS INT64) AS invers_kat_sort, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_invers_kategorie`;

-- Table: DBP_DATA.MCX_L_KATEGORIE
insert into `dbp_data.mcx_l_kategorie` (kat_id, teilbereich_id, td_update, td_insert)
SELECT CAST(kat_id AS INT64) AS kat_id, CAST(teilbereich_id AS INT64) AS teilbereich_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_kategorie`;

-- Table: DBP_DATA.MCX_L_TEILBEREICH
insert into `dbp_data.mcx_l_teilbereich` (teilbereich_id, ber_id, td_update, td_insert)
SELECT CAST(teilbereich_id AS INT64) AS teilbereich_id, CAST(ber_id AS INT64) AS ber_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_teilbereich`;

-- Table: DBP_DATA.MCX_L_UMFRAGE
insert into `dbp_data.mcx_l_umfrage` (umfrage_id, umfrage_bez, td_update, td_insert)
SELECT CAST(umfrage_id AS INT64) AS umfrage_id, umfrage_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_umfrage`;

-- Table: DBP_DATA.MCX_L_ZEITSPANNE
insert into `dbp_data.mcx_l_zeitspanne` (zeitspanne_id, zeitspanne_sort_key, td_update, td_insert)
SELECT CAST(zeitspanne_id AS INT64) AS zeitspanne_id, CAST(zeitspanne_sort_key AS INT64) AS zeitspanne_sort_key, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_l_zeitspanne`;

-- Table: DBP_DATA.MCX_ZEITSPANNE_SPR_ZU
insert into `dbp_data.mcx_zeitspanne_spr_zu` (zeitspanne_id, spr_id, zeitspanne_bez, td_update, td_insert)
SELECT CAST(zeitspanne_id AS INT64) AS zeitspanne_id, CAST(spr_id AS INT64) AS spr_id, zeitspanne_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mcx_zeitspanne_spr_zu`;

-- Table: DBP_DATA.MDL_ANTWORT_SPR_ZU
insert into `dbp_data.mdl_antwort_spr_zu` (frage_id, antwort_id, spr_id, antwort_bez, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(antwort_id AS INT64) AS antwort_id, CAST(spr_id AS INT64) AS spr_id, antwort_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_antwort_spr_zu`;

-- Table: DBP_DATA.MDL_BEFRAGUNG_SPR_ZU
insert into `dbp_data.mdl_befragung_spr_zu` (befragung_id, spr_id, befragung_bez, td_insert, td_update)
SELECT CAST(befragung_id AS INT64) AS befragung_id, CAST(spr_id AS INT64) AS spr_id, befragung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_befragung_spr_zu`;

-- Table: DBP_DATA.MDL_BEREICH_SPR_ZU
insert into `dbp_data.mdl_bereich_spr_zu` (bereich_id, spr_id, bereich_bez, td_insert, td_update)
SELECT CAST(bereich_id AS INT64) AS bereich_id, CAST(spr_id AS INT64) AS spr_id, bereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_bereich_spr_zu`;

-- Table: DBP_DATA.MDL_FRAGE_ANTWORT_ZU
insert into `dbp_data.mdl_frage_antwort_zu` (frage_id, antwort_id, nok_fg, td_update, td_insert)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(antwort_id AS INT64) AS antwort_id, CAST(nok_fg AS INT64) AS nok_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mdl_frage_antwort_zu`;

-- Table: DBP_DATA.MDL_FRAGE_BEFRAGUNG_BEREICH_KATEGORIE_ZU
insert into `dbp_data.mdl_frage_befragung_bereich_kategorie_zu` (frage_id, befragung_id, bereich_id, kategorie_id, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(befragung_id AS INT64) AS befragung_id, CAST(bereich_id AS INT64) AS bereich_id, CAST(kategorie_id AS INT64) AS kategorie_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_frage_befragung_bereich_kategorie_zu`;

-- Table: DBP_DATA.MDL_FRAGE_NAME_SPR_ZU
insert into `dbp_data.mdl_frage_name_spr_zu` (frage_id, spr_id, frage_name_bez, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(spr_id AS INT64) AS spr_id, frage_name_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_frage_name_spr_zu`;

-- Table: DBP_DATA.MDL_FRAGE_SPR_ZU
insert into `dbp_data.mdl_frage_spr_zu` (frage_id, spr_id, frage_bez, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, CAST(spr_id AS INT64) AS spr_id, frage_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_frage_spr_zu`;

-- Table: DBP_DATA.MDL_KATEGORIE_GRUPPE_SPR_ZU
insert into `dbp_data.mdl_kategorie_gruppe_spr_zu` (kategorie_gruppe_id, spr_id, kategorie_gruppe_bez, td_update, td_insert)
SELECT CAST(kategorie_gruppe_id AS INT64) AS kategorie_gruppe_id, CAST(spr_id AS INT64) AS spr_id, kategorie_gruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mdl_kategorie_gruppe_spr_zu`;

-- Table: DBP_DATA.MDL_KATEGORIE_GRUPPE_ZU
insert into `dbp_data.mdl_kategorie_gruppe_zu` (kategorie_id, kategorie_gruppe_id, td_insert, td_update)
SELECT CAST(kategorie_id AS INT64) AS kategorie_id, CAST(kategorie_gruppe_id AS INT64) AS kategorie_gruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_kategorie_gruppe_zu`;

-- Table: DBP_DATA.MDL_KATEGORIE_SPR_ZU
insert into `dbp_data.mdl_kategorie_spr_zu` (kategorie_id, spr_id, kategorie_bez, td_insert, td_update)
SELECT CAST(kategorie_id AS INT64) AS kategorie_id, CAST(spr_id AS INT64) AS spr_id, kategorie_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_kategorie_spr_zu`;

-- Table: DBP_DATA.MDL_L_BEFRAGUNG
insert into `dbp_data.mdl_l_befragung` (befragung_id, td_insert, td_update)
SELECT CAST(befragung_id AS INT64) AS befragung_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_l_befragung`;

-- Table: DBP_DATA.MDL_L_BEREICH
insert into `dbp_data.mdl_l_bereich` (bereich_id, hauptbereich_fg, td_insert, td_update)
SELECT CAST(bereich_id AS INT64) AS bereich_id, CAST(hauptbereich_fg AS INT64) AS hauptbereich_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_l_bereich`;

-- Table: DBP_DATA.MDL_L_FRAGE
insert into `dbp_data.mdl_l_frage` (frage_id, mdl_frage_id, hauptfrage_fg, td_insert, td_update)
SELECT CAST(frage_id AS INT64) AS frage_id, mdl_frage_id, CAST(hauptfrage_fg AS INT64) AS hauptfrage_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_l_frage`;

-- Table: DBP_DATA.MDL_L_KATEGORIE
insert into `dbp_data.mdl_l_kategorie` (kategorie_id, td_insert, td_update)
SELECT CAST(kategorie_id AS INT64) AS kategorie_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_l_kategorie`;

-- Table: DBP_DATA.MDL_L_ZEITSPANNE_EINKAUF
insert into `dbp_data.mdl_l_zeitspanne_einkauf` (zeitspanne_einkauf_id, zeitspanne_einkauf_sort_id, td_insert, td_update)
SELECT CAST(zeitspanne_einkauf_id AS INT64) AS zeitspanne_einkauf_id, CAST(zeitspanne_einkauf_sort_id AS INT64) AS zeitspanne_einkauf_sort_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_l_zeitspanne_einkauf`;

-- Table: DBP_DATA.MDL_VIS_BEREICH_SPR_ZU
insert into `dbp_data.mdl_vis_bereich_spr_zu` (bereich_id, spr_id, bereich_bez, td_update, td_insert)
SELECT CAST(bereich_id AS INT64) AS bereich_id, CAST(spr_id AS INT64) AS spr_id, bereich_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mdl_vis_bereich_spr_zu`;

-- Table: DBP_DATA.MDL_ZEITSPANNE_EINKAUF_SPR_ZU
insert into `dbp_data.mdl_zeitspanne_einkauf_spr_zu` (zeitspanne_einkauf_id, spr_id, zeitspanne_einkauf_bez, td_insert, td_update)
SELECT CAST(zeitspanne_einkauf_id AS INT64) AS zeitspanne_einkauf_id, CAST(spr_id AS INT64) AS spr_id, zeitspanne_einkauf_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mdl_zeitspanne_einkauf_spr_zu`;

-- Table: DBP_DATA.MELDUNGSTYP_SPR_ZU
insert into `dbp_data.meldungstyp_spr_zu` (mandant_id, spr_id, meldungstyp_id, meldungstyp_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, meldungstyp_id, meldungstyp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_meldungstyp_spr_zu`;

-- Table: DBP_DATA.MGG_ABTEILUNG_SPR_ZU
insert into `dbp_data.mgg_abteilung_spr_zu` (mandant_id, mgg_abteilung_id, spr_id, mgg_abteilung_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mgg_abteilung_id AS INT64) AS mgg_abteilung_id, CAST(spr_id AS INT64) AS spr_id, mgg_abteilung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mgg_abteilung_spr_zu`;

-- Table: DBP_DATA.MGG_GRUPPE_SPR_ZU
insert into `dbp_data.mgg_gruppe_spr_zu` (mandant_id, mgg_gruppe_id, spr_id, mgg_gruppe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mgg_gruppe_id AS INT64) AS mgg_gruppe_id, CAST(spr_id AS INT64) AS spr_id, mgg_gruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mgg_gruppe_spr_zu`;

-- Table: DBP_DATA.MHD_WAELZPLAN_PRUEF_ID_SPR_ZU
insert into `dbp_data.mhd_waelzplan_pruef_id_spr_zu` (mandant_id, waelzplan_pruef_id, spr_id, waelzplan_pruef_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(waelzplan_pruef_id AS INT64) AS waelzplan_pruef_id, CAST(spr_id AS INT64) AS spr_id, waelzplan_pruef_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_mhd_waelzplan_pruef_id_spr_zu`;

-- Table: DBP_DATA.MITARBEITER_ABWESENH_SPR_ZU
insert into `dbp_data.mitarbeiter_abwesenh_spr_zu` (mandant_id, abwesenheit_id, spr_id, abwesenheit_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, abwesenheit_id, CAST(spr_id AS INT64) AS spr_id, abwesenheit_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitarbeiter_abwesenh_spr_zu`;

-- Table: DBP_DATA.MITARBEITER_GRUPPE_SPR_ZU
insert into `dbp_data.mitarbeiter_gruppe_spr_zu` (mandant_id, mitarbeiter_gruppe_id, spr_id, mitarbeiter_gruppe_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_gruppe_id, CAST(spr_id AS INT64) AS spr_id, mitarbeiter_gruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitarbeiter_gruppe_spr_zu`;

-- Table: DBP_DATA.MITARBEITER_KREIS_SPR_ZU
insert into `dbp_data.mitarbeiter_kreis_spr_zu` (mandant_id, mitarbeiter_kreis_id, spr_id, mitarbeiterkreis_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, mitarbeiter_kreis_id, CAST(spr_id AS INT64) AS spr_id, mitarbeiterkreis_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitarbeiter_kreis_spr_zu`;

-- Table: DBP_DATA.MITARBEITER_STATUS_SPR_ZU
insert into `dbp_data.mitarbeiter_status_spr_zu` (mandant_id, ma_status_id, spr_id, ma_status_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ma_status_id, CAST(spr_id AS INT64) AS spr_id, ma_status_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitarbeiter_status_spr_zu`;

-- Table: DBP_DATA.MITBEWERBER_SPR_ZU
insert into `dbp_data.mitbewerber_spr_zu` (mandant_id, mitbewerber_id, spr_id, mitbewerber_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mitbewerber_id AS INT64) AS mitbewerber_id, CAST(spr_id AS INT64) AS spr_id, mitbewerber_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitbewerber_spr_zu`;

-- Table: DBP_DATA.MITBEW_WUP
insert into `dbp_data.mitbew_wup` (mitbew_wup_id, mitbew_grp_id, mandant_id, wup_id, nb_id, mitbew_name, td_insert, td_update)
SELECT CAST(mitbew_wup_id AS INT64) AS mitbew_wup_id, mitbew_grp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, mitbew_name, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mitbew_wup`;

-- Table: DBP_DATA.MONDPHASE_SPR_ZU
insert into `dbp_data.mondphase_spr_zu` (mondphase_id, spr_id, mondphase_bez, td_insert, td_update)
SELECT CAST(mondphase_id AS INT64) AS mondphase_id, CAST(spr_id AS INT64) AS spr_id, mondphase_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mondphase_spr_zu`;

-- Table: DBP_DATA.MP_ODS_VAR_ZU
insert into `dbp_data.mp_ods_var_zu` (mandant_id, mp_ods_id, mp_ods_var_id, mp_ods_sub_var_id, mp_ods_var_val, mp_ods_var_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mp_ods_id AS INT64) AS mp_ods_id, CAST(mp_ods_var_id AS INT64) AS mp_ods_var_id, CAST(mp_ods_sub_var_id AS INT64) AS mp_ods_sub_var_id, CAST(mp_ods_var_val AS NUMERIC) AS mp_ods_var_val, mp_ods_var_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_mp_ods_var_zu`;

-- Table: DBP_DATA.NACHRICHTENKLASSE_SPR_ZU
insert into `dbp_data.nachrichtenklasse_spr_zu` (mandant_id, spr_id, nachrichtenklasse_id, nachrichtenklasse_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, nachrichtenklasse_id, nachrichtenklasse_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nachrichtenklasse_spr_zu`;

-- Table: DBP_DATA.NACHRICHTENSTATUS_SPR_ZU
insert into `dbp_data.nachrichtenstatus_spr_zu` (mandant_id, spr_id, nachrichtenstatus_id, nachrichtenstatus_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, nachrichtenstatus_id, nachrichtenstatus_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nachrichtenstatus_spr_zu`;

-- Table: DBP_DATA.NACHSCHUB_OPTION_SPR_ZU
insert into `dbp_data.nachschub_option_spr_zu` (mandant_id, spr_id, nachschub_option_id, nachschub_option_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(nachschub_option_id AS INT64) AS nachschub_option_id, nachschub_option_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nachschub_option_spr_zu`;

-- Table: DBP_DATA.NB
insert into `dbp_data.nb` (nb_id, nb_bez, td_insert, td_update)
SELECT CAST(nb_id AS INT64) AS nb_id, nb_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_nb`;

-- Table: DBP_DATA.NETTOSTUNDEN_GFOS
insert into `dbp_data.nettostunden_gfos` (mandant_id, wup_id, nb_id, dat, stunden_netto_markt, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(stunden_netto_markt AS NUMERIC) AS stunden_netto_markt, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_nettostunden_gfos`;

-- Table: DBP_DATA.NFMD_DISCOUNT_RULE_MATRIX
insert into `dbp_data.nfmd_discount_rule_matrix` (mandant_id, price_class_cd, hwg_id, curve_type_cd, experiment_group_cd, rule_created_dt, sell_wk34_from_wk3_rate_min, sell_wk34_from_wk3_rate_max, wrg_id, suggested_discount_rate, rule_decision_record, rule_status, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, price_class_cd, CAST(hwg_id AS INT64) AS hwg_id, CAST(curve_type_cd AS INT64) AS curve_type_cd, experiment_group_cd, rule_created_dt, CAST(sell_wk34_from_wk3_rate_min AS NUMERIC) AS sell_wk34_from_wk3_rate_min, CAST(sell_wk34_from_wk3_rate_max AS NUMERIC) AS sell_wk34_from_wk3_rate_max, wrg_id, CAST(suggested_discount_rate AS NUMERIC) AS suggested_discount_rate, rule_decision_record, rule_status, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_discount_rule_matrix`;

-- Table: DBP_DATA.NFMD_PARAMETER
insert into `dbp_data.nfmd_parameter` (mandant_id, dwh_created_tmsp, discount_steps, min_discount_pct, max_discount_pct, wrg_id, min_price_gross_local_val, no_touch_days_cnt, min_days_btw_discounts_cnt, max_days_btw_discounts_cnt, discount_day_of_week, validity_days_cnt, price_ending_threshold, max_discount_for_max_price_pct, max_price_for_max_discount, discount_type_fg, promo_lifecycle_weeks_cnt, experiment_cohorts_cnt, experiments_for_manual_evaluation_cnt, success_write_off_threshold, success_cohorts_threshold, export_day_of_week, apply_price_rounding_fg, frontend_data_retention_period_weeks_cnt, second_discount_pct, second_discount_validity_wks_cnt, second_discount_lifecycle_weeks_cnt, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dwh_created_tmsp, CAST(discount_steps AS INT64) AS discount_steps, CAST(min_discount_pct AS INT64) AS min_discount_pct, CAST(max_discount_pct AS INT64) AS max_discount_pct, wrg_id, CAST(min_price_gross_local_val AS NUMERIC) AS min_price_gross_local_val, CAST(no_touch_days_cnt AS INT64) AS no_touch_days_cnt, CAST(min_days_btw_discounts_cnt AS INT64) AS min_days_btw_discounts_cnt, CAST(max_days_btw_discounts_cnt AS INT64) AS max_days_btw_discounts_cnt, discount_day_of_week, CAST(validity_days_cnt AS INT64) AS validity_days_cnt, CAST(price_ending_threshold AS INT64) AS price_ending_threshold, CAST(max_discount_for_max_price_pct AS INT64) AS max_discount_for_max_price_pct, CAST(max_price_for_max_discount AS INT64) AS max_price_for_max_discount, CAST(discount_type_fg AS INT64) AS discount_type_fg, CAST(promo_lifecycle_weeks_cnt AS INT64) AS promo_lifecycle_weeks_cnt, CAST(experiment_cohorts_cnt AS INT64) AS experiment_cohorts_cnt, CAST(experiments_for_manual_evaluation_cnt AS INT64) AS experiments_for_manual_evaluation_cnt, CAST(success_write_off_threshold AS NUMERIC) AS success_write_off_threshold, CAST(success_cohorts_threshold AS INT64) AS success_cohorts_threshold, export_day_of_week, CAST(apply_price_rounding_fg AS INT64) AS apply_price_rounding_fg, CAST(frontend_data_retention_period_weeks_cnt AS INT64) AS frontend_data_retention_period_weeks_cnt, CAST(second_discount_pct AS INT64) AS second_discount_pct, CAST(second_discount_validity_wks_cnt AS INT64) AS second_discount_validity_wks_cnt, CAST(second_discount_lifecycle_weeks_cnt AS INT64) AS second_discount_lifecycle_weeks_cnt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_parameter`;

-- Table: DBP_DATA.NFMD_PIPELINE_EXPORT_LOG
insert into `dbp_data.nfmd_pipeline_export_log` (mandant_id, execution_tmsp, execution_year, execution_week, sent_rows_cnt, environment_name, erp_guid, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, execution_tmsp, CAST(execution_year AS INT64) AS execution_year, CAST(execution_week AS INT64) AS execution_week, CAST(sent_rows_cnt AS INT64) AS sent_rows_cnt, environment_name, erp_guid, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_nfmd_pipeline_export_log`;

-- Table: DBP_DATA.NIELSEN_MARKET_CLUSTER
insert into `dbp_data.nielsen_market_cluster` (mandant_id, nielsen_market_cluster_id, nielsen_market_cluster_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nielsen_market_cluster_id AS INT64) AS nielsen_market_cluster_id, nielsen_market_cluster_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_nielsen_market_cluster`;

-- Table: DBP_DATA.OCR_EINGANGSKANAL_SPR_ZU
insert into `dbp_data.ocr_eingangskanal_spr_zu` (mandant_id, ocr_eingangskanal_id, spr_id, ocr_eingangskanal_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ocr_eingangskanal_id, CAST(spr_id AS INT64) AS spr_id, ocr_eingangskanal_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ocr_eingangskanal_spr_zu`;

-- Table: DBP_DATA.OFENTYP_SPR_ZU
insert into `dbp_data.ofentyp_spr_zu` (mandant_id, ofen_typ_id, spr_id, ofen_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ofen_typ_id, CAST(spr_id AS INT64) AS spr_id, ofen_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ofentyp_spr_zu`;

-- Table: DBP_DATA.ORG_EINHEIT_BEREICH_SPR_ZU
insert into `dbp_data.org_einheit_bereich_spr_zu` (mandant_id, hr_objekt_bereich_id, spr_id, hr_objekt_bereich_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_bereich_id AS INT64) AS hr_objekt_bereich_id, CAST(spr_id AS INT64) AS spr_id, hr_objekt_bereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_org_einheit_bereich_spr_zu`;

-- Table: DBP_DATA.OUG_ID_SPR_ZU
insert into `dbp_data.oug_id_spr_zu` (mandant_id, oug_id, spr_id, oug_id_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(oug_id AS INT64) AS oug_id, CAST(spr_id AS INT64) AS spr_id, oug_id_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_oug_id_spr_zu`;

-- Table: DBP_DATA.PACKSTCK_GEBINDE_EINH_SPR_ZU
insert into `dbp_data.packstck_gebinde_einh_spr_zu` (mandant_id, packstueck_gebinde_einh_id, spr_id, packstueck_gebinde_einh_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, packstueck_gebinde_einh_id, CAST(spr_id AS INT64) AS spr_id, packstueck_gebinde_einh_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_packstck_gebinde_einh_spr_zu`;

-- Table: DBP_DATA.PACKSTUECK_GEBINDEART_SPR_ZU
insert into `dbp_data.packstueck_gebindeart_spr_zu` (mandant_id, packstueck_gebindeart_id, spr_id, packstueck_gebindeart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(packstueck_gebindeart_id AS INT64) AS packstueck_gebindeart_id, CAST(spr_id AS INT64) AS spr_id, packstueck_gebindeart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_packstueck_gebindeart_spr_zu`;

-- Table: DBP_DATA.PCON_ABWESENH_LOGIK_FG_ZU
insert into `dbp_data.pcon_abwesenh_logik_fg_zu` (mandant_id, abwesenheit_id, kjmo_bis, kjmo_von, logik_kz, langzeit_abwesend_fg, pflege_fg, beschaeftigungs_verbot_fg, krankheit_unfall_fg, sonstige_abwesenheit_fg, freigestellt_fg, mutterschutz_fg, elternzeit_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, abwesenheit_id, CAST(kjmo_bis AS INT64) AS kjmo_bis, CAST(kjmo_von AS INT64) AS kjmo_von, logik_kz, CAST(langzeit_abwesend_fg AS INT64) AS langzeit_abwesend_fg, CAST(pflege_fg AS INT64) AS pflege_fg, CAST(beschaeftigungs_verbot_fg AS INT64) AS beschaeftigungs_verbot_fg, CAST(krankheit_unfall_fg AS INT64) AS krankheit_unfall_fg, CAST(sonstige_abwesenheit_fg AS INT64) AS sonstige_abwesenheit_fg, CAST(freigestellt_fg AS INT64) AS freigestellt_fg, CAST(mutterschutz_fg AS INT64) AS mutterschutz_fg, CAST(elternzeit_fg AS INT64) AS elternzeit_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_pcon_abwesenh_logik_fg_zu`;

-- Table: DBP_DATA.PERS_TEILBEREICH_SPR_ZU
insert into `dbp_data.pers_teilbereich_spr_zu` (mandant_id, pers_teilbereich_id, spr_id, buchungskreis_id, pers_bereich_id, persteilbereich_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, pers_teilbereich_id, CAST(spr_id AS INT64) AS spr_id, CAST(buchungskreis_id AS INT64) AS buchungskreis_id, pers_bereich_id, persteilbereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_pers_teilbereich_spr_zu`;

-- Table: DBP_DATA.PHASENART_SPR_ZU
insert into `dbp_data.phasenart_spr_zu` (phasenart_id, spr_id, cpr_phase_bez, td_update, td_insert)
SELECT phasenart_id, CAST(spr_id AS INT64) AS spr_id, cpr_phase_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_phasenart_spr_zu`;

-- Table: DBP_DATA.PLANUNGSART_SPR_ZU
insert into `dbp_data.planungsart_spr_zu` (mandant_id, planungsart_id, spr_id, planungsart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, planungsart_id, CAST(spr_id AS INT64) AS spr_id, planungsart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_planungsart_spr_zu`;

-- Table: DBP_DATA.PLATZIERUNGSSTUFE_SPR_ZU
insert into `dbp_data.platzierungsstufe_spr_zu` (mandant_id, platzierungsstufe_id, spr_id, platzierungsstufe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, platzierungsstufe_id, CAST(spr_id AS INT64) AS spr_id, platzierungsstufe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_platzierungsstufe_spr_zu`;

-- Table: DBP_DATA.PLATZIERUNGSWG_SPR_ZU
insert into `dbp_data.platzierungswg_spr_zu` (mandant_id, platzierungswg_id, spr_id, platzierungswg_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(platzierungswg_id AS INT64) AS platzierungswg_id, CAST(spr_id AS INT64) AS spr_id, platzierungswg_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_platzierungswg_spr_zu`;

-- Table: DBP_DATA.PLATZIERUNGSWG_VS_SM_VERKAUFSMOEBEL_ZU
insert into `dbp_data.platzierungswg_vs_sm_verkaufsmoebel_zu` (mandant_id, platzierungswg_id, vs_id, sm_id, verkaufsmoebel_id, menge_soll_flaeche, flaeche_einh_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(platzierungswg_id AS INT64) AS platzierungswg_id, CAST(vs_id AS INT64) AS vs_id, CAST(sm_id AS INT64) AS sm_id, CAST(verkaufsmoebel_id AS INT64) AS verkaufsmoebel_id, CAST(menge_soll_flaeche AS NUMERIC) AS menge_soll_flaeche, flaeche_einh_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_platzierungswg_vs_sm_verkaufsmoebel_zu`;

-- Table: DBP_DATA.PM
insert into `dbp_data.pm` (pm_id, mandant_id, spr_id, pm_bez, td_update, td_insert)
SELECT CAST(pm_id AS INT64) AS pm_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, pm_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_pm`;

-- Table: DBP_DATA.PMR_WERBETHEMA
insert into `dbp_data.pmr_werbethema` (pmr_werbethema_id, pmr_werbethema_bez, td_update, td_insert)
SELECT pmr_werbethema_id, pmr_werbethema_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_pmr_werbethema`;

-- Table: DBP_DATA.POSITIONSTYP_GRP_SPR_ZU
insert into `dbp_data.positionstyp_grp_spr_zu` (mandant_id, positionstyp_grp_id, spr_id, positionstyp_grp_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, positionstyp_grp_id, CAST(spr_id AS INT64) AS spr_id, positionstyp_grp_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_positionstyp_grp_spr_zu`;

-- Table: DBP_DATA.POSTEN_KZ_SAP_SPR_ZU
insert into `dbp_data.posten_kz_sap_spr_zu` (mandant_id, spr_id, posten_kz_sap, posten_bez_sap, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, posten_kz_sap, posten_bez_sap, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_posten_kz_sap_spr_zu`;

-- Table: DBP_DATA.PREIS_STEUERUNG_SPR_ZU
insert into `dbp_data.preis_steuerung_spr_zu` (preis_steuer_kz, mandant_id, spr_id, preis_steuerung_bez, td_insert, td_update)
SELECT preis_steuer_kz, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, preis_steuerung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_preis_steuerung_spr_zu`;

-- Table: DBP_DATA.PROBLEMCODE_GRUPPE_ZU
insert into `dbp_data.problemcode_gruppe_zu` (system_id, mandant_id, problemgruppe_id, problemcode_id, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(problemgruppe_id AS INT64) AS problemgruppe_id, problemcode_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_problemcode_gruppe_zu`;

-- Table: DBP_DATA.PROBLEMCODE_SPR_ZU
insert into `dbp_data.problemcode_spr_zu` (system_id, mandant_id, problemcode_id, spr_id, problemcode_bez, problemcode_bez_kurz, problemcode_bez_lang, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, problemcode_id, CAST(spr_id AS INT64) AS spr_id, problemcode_bez, problemcode_bez_kurz, problemcode_bez_lang, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_problemcode_spr_zu`;

-- Table: DBP_DATA.PROBLEMGRUPPE_SPR_ZU
insert into `dbp_data.problemgruppe_spr_zu` (system_id, mandant_id, problemgruppe_id, spr_id, problemgruppe_bez, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(problemgruppe_id AS INT64) AS problemgruppe_id, CAST(spr_id AS INT64) AS spr_id, problemgruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_problemgruppe_spr_zu`;

-- Table: DBP_DATA.PROBLEMKLASSE_SPR_ZU
insert into `dbp_data.problemklasse_spr_zu` (system_id, mandant_id, problemklasse_id, spr_id, problemklasse_bez, problemklasse_bez_kurz, problemklasse_bez_lang, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, problemklasse_id, CAST(spr_id AS INT64) AS spr_id, problemklasse_bez, problemklasse_bez_kurz, problemklasse_bez_lang, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_problemklasse_spr_zu`;

-- Table: DBP_DATA.PROBLEMMELDUNG_OBJ_SPR_ZU
insert into `dbp_data.problemmeldung_obj_spr_zu` (system_id, mandant_id, spr_id, zus_obj_id, zus_obj_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, zus_obj_id, zus_obj_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_problemmeldung_obj_spr_zu`;

-- Table: DBP_DATA.PRODUKTGRUPPE_SPR_ZU
insert into `dbp_data.produktgruppe_spr_zu` (mandant_id, produktgruppe_id, spr_id, produktgruppe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(produktgruppe_id AS INT64) AS produktgruppe_id, CAST(spr_id AS INT64) AS spr_id, produktgruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_produktgruppe_spr_zu`;

-- Table: DBP_DATA.PRODUKT_SCHAUFENSTER_SPR_ZU
insert into `dbp_data.produkt_schaufenster_spr_zu` (mandant_id, psf_id, spr_id, psf_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(psf_id AS INT64) AS psf_id, CAST(spr_id AS INT64) AS spr_id, psf_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_produkt_schaufenster_spr_zu`;

-- Table: DBP_DATA.PROFIL_SPR_ZU
insert into `dbp_data.profil_spr_zu` (mandant_id, profil_id, spr_id, profil_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(profil_id AS INT64) AS profil_id, CAST(spr_id AS INT64) AS spr_id, profil_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_profil_spr_zu`;

-- Table: DBP_DATA.PROFIT_CENTER
insert into `dbp_data.profit_center` (pc_id, mandant_id, krk_id, system_id, wup_id, nb_id, werk_id, td_insert, td_update)
SELECT pc_id, CAST(mandant_id AS INT64) AS mandant_id, krk_id, CAST(system_id AS INT64) AS system_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(werk_id AS INT64) AS werk_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_profit_center`;

-- Table: DBP_DATA.PROFIT_CENTER_GRP
insert into `dbp_data.profit_center_grp` (pc_grp_id, mandant_id, system_id, pc_hiertyp_id, pc_grp_mutter_id, pc_grp_id_kons, kl_pc_grp_id, ebene_id, ebene_pos_id, td_insert, td_update)
SELECT pc_grp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(pc_hiertyp_id AS INT64) AS pc_hiertyp_id, pc_grp_mutter_id, pc_grp_id_kons, kl_pc_grp_id, CAST(ebene_id AS INT64) AS ebene_id, CAST(ebene_pos_id AS INT64) AS ebene_pos_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_profit_center_grp`;

-- Table: DBP_DATA.PROFIT_CENTER_GRP_SPR_ZU
insert into `dbp_data.profit_center_grp_spr_zu` (pc_grp_id, spr_id, system_id, mandant_id, pc_hiertyp_id, pc_grp_bez, td_insert, td_update)
SELECT pc_grp_id, CAST(spr_id AS INT64) AS spr_id, CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(pc_hiertyp_id AS INT64) AS pc_hiertyp_id, pc_grp_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_profit_center_grp_spr_zu`;

-- Table: DBP_DATA.PROGNOSE_FEINGLIEDERUNG_SPR_ZU
insert into `dbp_data.prognose_feingliederung_spr_zu` (prognose_feingliederung_id, spr_id, prognose_feingliederung_bez, td_update, td_insert)
SELECT CAST(prognose_feingliederung_id AS INT64) AS prognose_feingliederung_id, CAST(spr_id AS INT64) AS spr_id, prognose_feingliederung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_prognose_feingliederung_spr_zu`;

-- Table: DBP_DATA.PROZESSBEREICH_SPR_ZU
insert into `dbp_data.prozessbereich_spr_zu` (system_id, mandant_id, prozessbereich_id, spr_id, prozessbereich_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, prozessbereich_id, CAST(spr_id AS INT64) AS spr_id, prozessbereich_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_prozessbereich_spr_zu`;

-- Table: DBP_DATA.PSP_KONDITIONSWERT
insert into `dbp_data.psp_konditionswert` (mandant_id, psp_id, wrg_id, betrag_konditionswert_gebucht, betrag_konditionswert_ungebucht, konditionsart_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(psp_id AS INT64) AS psp_id, wrg_id, CAST(betrag_konditionswert_gebucht AS NUMERIC) AS betrag_konditionswert_gebucht, CAST(betrag_konditionswert_ungebucht AS NUMERIC) AS betrag_konditionswert_ungebucht, CAST(konditionsart_id AS INT64) AS konditionsart_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_psp_konditionswert`;

-- Table: DBP_DATA.QA_DEKLARATIONSFEHLER_SPR_ZU
insert into `dbp_data.qa_deklarationsfehler_spr_zu` (mandant_id, qa_deklarationsfehler_id, spr_id, qa_deklarationsfehler_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, qa_deklarationsfehler_id, CAST(spr_id AS INT64) AS spr_id, qa_deklarationsfehler_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_qa_deklarationsfehler_spr_zu`;

-- Table: DBP_DATA.QA_MANGEL_SPR_ZU
insert into `dbp_data.qa_mangel_spr_zu` (mandant_id, qa_mangel_id, spr_id, qa_mangel_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, qa_mangel_id, CAST(spr_id AS INT64) AS spr_id, qa_mangel_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_qa_mangel_spr_zu`;

-- Table: DBP_DATA.RABATT_TYP_SPR_ZU
insert into `dbp_data.rabatt_typ_spr_zu` (mandant_id, spr_id, rabatt_typ_id, rabatt_typ_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(rabatt_typ_id AS INT64) AS rabatt_typ_id, rabatt_typ_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rabatt_typ_spr_zu`;

-- Table: DBP_DATA.RECH_BELEG_STATUS_SPR_ZU
insert into `dbp_data.rech_beleg_status_spr_zu` (system_id, mandant_id, spr_id, rech_beleg_status_id, rech_beleg_status_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, rech_beleg_status_id, rech_beleg_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rech_beleg_status_spr_zu`;

-- Table: DBP_DATA.RECH_ERFASSUNG_SPR_ZU
insert into `dbp_data.rech_erfassung_spr_zu` (system_id, mandant_id, spr_id, erfassung_id, erfassung_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, erfassung_id, erfassung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rech_erfassung_spr_zu`;

-- Table: DBP_DATA.RECH_KONTOART_SPR_ZU
insert into `dbp_data.rech_kontoart_spr_zu` (mandant_id, spr_id, rech_kontoart_id, rech_kontoart_bez, system_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, rech_kontoart_id, rech_kontoart_bez, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_rech_kontoart_spr_zu`;

-- Table: DBP_DATA.REGIO_POLYGON_ADRESSE_ZU
insert into `dbp_data.regio_polygon_adresse_zu` (mandant_id, regio_stufe_id, regio_polygon_id, adresse_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regio_stufe_id AS INT64) AS regio_stufe_id, CAST(regio_polygon_id AS INT64) AS regio_polygon_id, CAST(adresse_id AS INT64) AS adresse_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regio_polygon_adresse_zu`;

-- Table: DBP_DATA.REGIO_POLYGON_SPR_ZU
insert into `dbp_data.regio_polygon_spr_zu` (mandant_id, regio_stufe_id, regio_polygon_id, spr_id, regio_polygon_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regio_stufe_id AS INT64) AS regio_stufe_id, CAST(regio_polygon_id AS INT64) AS regio_polygon_id, CAST(spr_id AS INT64) AS spr_id, regio_polygon_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regio_polygon_spr_zu`;

-- Table: DBP_DATA.REGIO_STUFE_SPR_ZU
insert into `dbp_data.regio_stufe_spr_zu` (mandant_id, regio_stufe_id, spr_id, regio_stufe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(regio_stufe_id AS INT64) AS regio_stufe_id, CAST(spr_id AS INT64) AS spr_id, regio_stufe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_regio_stufe_spr_zu`;

-- Table: DBP_DATA.REKLAMATIONSGRUND_SPR_ZU
insert into `dbp_data.reklamationsgrund_spr_zu` (mandant_id, reklamationsgrund_id, spr_id, reklamationsgrund_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(reklamationsgrund_id AS INT64) AS reklamationsgrund_id, CAST(spr_id AS INT64) AS spr_id, reklamationsgrund_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_reklamationsgrund_spr_zu`;

-- Table: DBP_DATA.RETAIL_COMPANY
insert into `dbp_data.retail_company` (ext_system_name, ext_retail_company_id, mandant_id, retail_company_code, retail_company_name, competitor_fg, td_update, td_insert)
SELECT ext_system_name, CAST(ext_retail_company_id AS INT64) AS ext_retail_company_id, CAST(mandant_id AS INT64) AS mandant_id, retail_company_code, retail_company_name, CAST(competitor_fg AS INT64) AS competitor_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_retail_company`;

-- Table: DBP_DATA.RETAIL_STORE_DISTANCE
insert into `dbp_data.retail_store_distance` (ext_system_name, ext_store_id, wup_id, mandant_id, drivetime_distance_km, nb_id, td_update, td_insert)
SELECT ext_system_name, CAST(ext_store_id AS INT64) AS ext_store_id, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(drivetime_distance_km AS BIGNUMERIC) AS drivetime_distance_km, CAST(nb_id AS INT64) AS nb_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_retail_store_distance`;

-- Table: DBP_DATA.ROHSTOFF_GRUPPE
insert into `dbp_data.rohstoff_gruppe` (rohstoff_gruppe_typ_id, rohstoff_gruppe_name, rohstoff_gruppe_kurz_name, td_update, td_insert)
SELECT CAST(rohstoff_gruppe_typ_id AS INT64) AS rohstoff_gruppe_typ_id, rohstoff_gruppe_name, rohstoff_gruppe_kurz_name, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rohstoff_gruppe`;

-- Table: DBP_DATA.ROHSTOFF_GRUPPE_ZUORDNUNG
insert into `dbp_data.rohstoff_gruppe_zuordnung` (rohstoff_gruppe_typ_id, rohstoff_gruppe_name, zugeordnete_rohstoff_gruppe_typ_id, zugeordnete_rohstoff_gruppe_name, rohstoff_gruppe_zuordnungstyp_id, dat_gueltig_von, dat_gueltig_bis, td_update, td_insert)
SELECT CAST(rohstoff_gruppe_typ_id AS INT64) AS rohstoff_gruppe_typ_id, rohstoff_gruppe_name, CAST(zugeordnete_rohstoff_gruppe_typ_id AS INT64) AS zugeordnete_rohstoff_gruppe_typ_id, zugeordnete_rohstoff_gruppe_name, CAST(rohstoff_gruppe_zuordnungstyp_id AS INT64) AS rohstoff_gruppe_zuordnungstyp_id, dat_gueltig_von, dat_gueltig_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rohstoff_gruppe_zuordnung`;

-- Table: DBP_DATA.ROHSTOFF_ROHSTOFF_GRUPPE_ZU
insert into `dbp_data.rohstoff_rohstoff_gruppe_zu` (rohstoff_nr, rohstoff_gruppe_typ_id, rohstoff_gruppe_name, rohstoff_blend_kfl_cd, rohstoff_cluster_id, td_update, td_insert)
SELECT rohstoff_nr, CAST(rohstoff_gruppe_typ_id AS INT64) AS rohstoff_gruppe_typ_id, rohstoff_gruppe_name, rohstoff_blend_kfl_cd, CAST(rohstoff_cluster_id AS INT64) AS rohstoff_cluster_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rohstoff_rohstoff_gruppe_zu`;

-- Table: DBP_DATA.ROW_GRUND_SPR_ZU
insert into `dbp_data.row_grund_spr_zu` (system_id, mandant_id, spr_id, row_grund_id, row_grund_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, row_grund_id, row_grund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_row_grund_spr_zu`;

-- Table: DBP_DATA.RPM_FELD_AUSPR_SPR_ZU
insert into `dbp_data.rpm_feld_auspr_spr_zu` (rpm_feld_id, rpm_feld_auspr_id, spr_id, rpm_tab_id, rpm_feld_auspr_bez, td_update, td_insert)
SELECT CAST(rpm_feld_id AS INT64) AS rpm_feld_id, CAST(rpm_feld_auspr_id AS INT64) AS rpm_feld_auspr_id, CAST(spr_id AS INT64) AS spr_id, CAST(rpm_tab_id AS INT64) AS rpm_tab_id, rpm_feld_auspr_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_feld_auspr_spr_zu`;

-- Table: DBP_DATA.RPM_FELD_AUSPR_ZU
insert into `dbp_data.rpm_feld_auspr_zu` (rpm_feld_id, rpm_feld_auspr_id, rpm_tab_id, auspr_format_bez, td_update, td_insert)
SELECT CAST(rpm_feld_id AS INT64) AS rpm_feld_id, CAST(rpm_feld_auspr_id AS INT64) AS rpm_feld_auspr_id, CAST(rpm_tab_id AS INT64) AS rpm_tab_id, auspr_format_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_feld_auspr_zu`;

-- Table: DBP_DATA.RPM_FIN_GRUPPE_SPR_ZU
insert into `dbp_data.rpm_fin_gruppe_spr_zu` (fin_gruppe_id, spr_id, fin_kategorie_id, fin_gruppe_bez, td_update, td_insert)
SELECT fin_gruppe_id, CAST(spr_id AS INT64) AS spr_id, fin_kategorie_id, fin_gruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_fin_gruppe_spr_zu`;

-- Table: DBP_DATA.RPM_FIN_KATEGORIE_SPR_ZU
insert into `dbp_data.rpm_fin_kategorie_spr_zu` (fin_kategorie_id, spr_id, fin_kategorie_bez, td_update, td_insert)
SELECT fin_kategorie_id, CAST(spr_id AS INT64) AS spr_id, fin_kategorie_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_fin_kategorie_spr_zu`;

-- Table: DBP_DATA.RPM_IMMOBILIE_PER
insert into `dbp_data.rpm_immobilie_per` (rpm_hierarchie_id, dat_von, techn_platz_id, vs_id, mandant_id, wrg_id, gesamtbew_note, bewertungszahl_a, bewertungszahl_b, bewertungszahl_c, dat_bis, gj_umbvorschl, wup_id, nb_id, wup_standort, strasse, plz, zielumsatz_3gj, dat_eroeffn_fb_imm, uebernahme_von, td_update, td_insert)
SELECT rpm_hierarchie_id, dat_von, techn_platz_id, CAST(vs_id AS INT64) AS vs_id, CAST(mandant_id AS INT64) AS mandant_id, wrg_id, CAST(gesamtbew_note AS NUMERIC) AS gesamtbew_note, CAST(bewertungszahl_a AS NUMERIC) AS bewertungszahl_a, CAST(bewertungszahl_b AS NUMERIC) AS bewertungszahl_b, CAST(bewertungszahl_c AS NUMERIC) AS bewertungszahl_c, dat_bis, CAST(gj_umbvorschl AS INT64) AS gj_umbvorschl, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, wup_standort, strasse, plz, CAST(zielumsatz_3gj AS NUMERIC) AS zielumsatz_3gj, dat_eroeffn_fb_imm, uebernahme_von, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_immobilie_per`;

-- Table: DBP_DATA.RPM_IMMOBILIE_SPR_ZU
insert into `dbp_data.rpm_immobilie_spr_zu` (rpm_immobilie_id, spr_id, dat_von, rpm_immobilie_bez, td_update, td_insert)
SELECT rpm_immobilie_id, CAST(spr_id AS INT64) AS spr_id, dat_von, rpm_immobilie_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_immobilie_spr_zu`;

-- Table: DBP_DATA.RPM_PHASE_SPR_ZU
insert into `dbp_data.rpm_phase_spr_zu` (rpm_phase_id, rpm_projekt_typ_id, spr_id, rpm_phase_bez, td_update, td_insert)
SELECT rpm_phase_id, rpm_projekt_typ_id, CAST(spr_id AS INT64) AS spr_id, rpm_phase_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_phase_spr_zu`;

-- Table: DBP_DATA.RPM_PLANTYP_SPR_ZU
insert into `dbp_data.rpm_plantyp_spr_zu` (spr_id, rpm_plantyp_id, rpm_plantyp_bez, td_update, td_insert)
SELECT CAST(spr_id AS INT64) AS spr_id, CAST(rpm_plantyp_id AS INT64) AS rpm_plantyp_id, rpm_plantyp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_plantyp_spr_zu`;

-- Table: DBP_DATA.RPM_STATUS_SPR_ZU
insert into `dbp_data.rpm_status_spr_zu` (rpm_status_id, spr_id, rpm_status_bez, td_update, td_insert)
SELECT CAST(rpm_status_id AS INT64) AS rpm_status_id, CAST(spr_id AS INT64) AS spr_id, rpm_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpm_status_spr_zu`;

-- Table: DBP_DATA.RPW_FAKTURAARTEN
insert into `dbp_data.rpw_fakturaarten` (mandant_id, fakturaart_id, vertriebbelegtyp_id, soll_haben_kz, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, fakturaart_id, vertriebbelegtyp_id, soll_haben_kz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_rpw_fakturaarten`;

-- Table: DBP_DATA.RPW_L_BELASTUNGSART
insert into `dbp_data.rpw_l_belastungsart` (belastungsart_vd_id, belastungsart_id, td_update, td_insert)
SELECT CAST(belastungsart_vd_id AS INT64) AS belastungsart_vd_id, belastungsart_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpw_l_belastungsart`;

-- Table: DBP_DATA.RPW_L_BELASTUNGSART_VD
insert into `dbp_data.rpw_l_belastungsart_vd` (belastungsart_vd_id, belastungsart_vd_bez, td_update, td_insert)
SELECT CAST(belastungsart_vd_id AS INT64) AS belastungsart_vd_id, belastungsart_vd_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rpw_l_belastungsart_vd`;

-- Table: DBP_DATA.RUECKGABE_VERWENDUNG_SPR_ZU
insert into `dbp_data.rueckgabe_verwendung_spr_zu` (mandant_id, spr_id, rueckgabe_verwendung_kz, rueckgabe_verwendung_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, rueckgabe_verwendung_kz, rueckgabe_verwendung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rueckgabe_verwendung_spr_zu`;

-- Table: DBP_DATA.RUECKSENDUNG_STATUS_SPR_ZU
insert into `dbp_data.ruecksendung_status_spr_zu` (mandant_id, ruecksendung_status_id, spr_id, ruecksendung_status_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ruecksendung_status_id AS INT64) AS ruecksendung_status_id, CAST(spr_id AS INT64) AS spr_id, ruecksendung_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ruecksendung_status_spr_zu`;

-- Table: DBP_DATA.RUECKSENDUNG_TYP_SPR_ZU
insert into `dbp_data.ruecksendung_typ_spr_zu` (mandant_id, ruecksendung_typ_kz, spr_id, ruecksendung_typ_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ruecksendung_typ_kz, CAST(spr_id AS INT64) AS spr_id, ruecksendung_typ_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ruecksendung_typ_spr_zu`;

-- Table: DBP_DATA.RUECK_GRUND_SPR_ZU
insert into `dbp_data.rueck_grund_spr_zu` (rueck_grund_id, mandant_id, spr_id, rueck_grund_bez, td_update, td_insert)
SELECT CAST(rueck_grund_id AS INT64) AS rueck_grund_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, rueck_grund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_rueck_grund_spr_zu`;

-- Table: DBP_DATA.SAMMEL_LADUNG_SPR_ZU
insert into `dbp_data.sammel_ladung_spr_zu` (sammel_ladung_fg, spr_id, sammel_ladung_bez, td_insert, td_update)
SELECT CAST(sammel_ladung_fg AS INT64) AS sammel_ladung_fg, CAST(spr_id AS INT64) AS spr_id, sammel_ladung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sammel_ladung_spr_zu`;

-- Table: DBP_DATA.SAP_PERIODE_KALENDER_ZU
insert into `dbp_data.sap_periode_kalender_zu` (mandant_id, krk_id, buchungsperiode_id, sap_buchungs_jahr, kjmo, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, krk_id, CAST(buchungsperiode_id AS INT64) AS buchungsperiode_id, CAST(sap_buchungs_jahr AS INT64) AS sap_buchungs_jahr, CAST(kjmo AS INT64) AS kjmo, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sap_periode_kalender_zu`;

-- Table: DBP_DATA.SB_BEURTEILER
insert into `dbp_data.sb_beurteiler` (beurteiler_id, mandant_id, ma_id, anz_sb_soll, anz_sb_rot_bis, anz_sb_gelb_bis, operativ_fg, td_insert, td_update)
SELECT CAST(beurteiler_id AS INT64) AS beurteiler_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(ma_id AS INT64) AS ma_id, CAST(anz_sb_soll AS INT64) AS anz_sb_soll, CAST(anz_sb_rot_bis AS NUMERIC) AS anz_sb_rot_bis, CAST(anz_sb_gelb_bis AS NUMERIC) AS anz_sb_gelb_bis, CAST(operativ_fg AS INT64) AS operativ_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteiler`;

-- Table: DBP_DATA.SB_BEURTEIL_BEREICH_SPR_ZU
insert into `dbp_data.sb_beurteil_bereich_spr_zu` (beurteilung_bereich_id, mandant_id, spr_id, beurteilung_bereich_bez, td_insert, td_update)
SELECT CAST(beurteilung_bereich_id AS INT64) AS beurteilung_bereich_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, beurteilung_bereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_bereich_spr_zu`;

-- Table: DBP_DATA.SB_BEURTEIL_DETAIL_SPR_ZU
insert into `dbp_data.sb_beurteil_detail_spr_zu` (beurteilung_detail_id, mandant_id, spr_id, beurteilung_detail_bez, td_insert, td_update)
SELECT CAST(beurteilung_detail_id AS INT64) AS beurteilung_detail_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, beurteilung_detail_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_beurteil_detail_spr_zu`;

-- Table: DBP_DATA.SB_GRUND_SPR_ZU
insert into `dbp_data.sb_grund_spr_zu` (sb_grund_id, mandant_id, spr_id, sb_grund_bez, td_insert, td_update)
SELECT CAST(sb_grund_id AS INT64) AS sb_grund_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, sb_grund_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_grund_spr_zu`;

-- Table: DBP_DATA.SB_MANDANT_EBENE
insert into `dbp_data.sb_mandant_ebene` (mandant_id, sb_ebene, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sb_ebene AS INT64) AS sb_ebene, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_mandant_ebene`;

-- Table: DBP_DATA.SB_SCHWELLWERT_WTAG
insert into `dbp_data.sb_schwellwert_wtag` (mandant_id, wtag_id, vertrieb_fg, sw_rot_bis, sw_gelb_bis, sw_gelb_ab, sw_rot_ab, sw_soll, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wtag_id AS INT64) AS wtag_id, CAST(vertrieb_fg AS INT64) AS vertrieb_fg, CAST(sw_rot_bis AS NUMERIC) AS sw_rot_bis, CAST(sw_gelb_bis AS NUMERIC) AS sw_gelb_bis, CAST(sw_gelb_ab AS NUMERIC) AS sw_gelb_ab, CAST(sw_rot_ab AS NUMERIC) AS sw_rot_ab, CAST(sw_soll AS NUMERIC) AS sw_soll, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_schwellwert_wtag`;

-- Table: DBP_DATA.SB_SCHWELLWERT_ZEIT
insert into `dbp_data.sb_schwellwert_zeit` (mandant_id, zeit_stunde_von, vertrieb_fg, zeit_stunde_bis, sw_rot_bis, sw_gelb_bis, sw_gelb_ab, sw_rot_ab, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(zeit_stunde_von AS INT64) AS zeit_stunde_von, CAST(vertrieb_fg AS INT64) AS vertrieb_fg, CAST(zeit_stunde_bis AS INT64) AS zeit_stunde_bis, CAST(sw_rot_bis AS NUMERIC) AS sw_rot_bis, CAST(sw_gelb_bis AS NUMERIC) AS sw_gelb_bis, CAST(sw_gelb_ab AS NUMERIC) AS sw_gelb_ab, CAST(sw_rot_ab AS NUMERIC) AS sw_rot_ab, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sb_schwellwert_zeit`;

-- Table: DBP_DATA.SCHWELLWERT_SPR_ZU
insert into `dbp_data.schwellwert_spr_zu` (mandant_id, sw_id, spr_id, sw_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sw_id AS INT64) AS sw_id, CAST(spr_id AS INT64) AS spr_id, sw_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_schwellwert_spr_zu`;

-- Table: DBP_DATA.SHOPPER_SCORE_SCHWELLWERTE
insert into `dbp_data.shopper_score_schwellwerte` (mandant_id, abt_id, arthiertyp_id, dat_von, dat_bis, ertrag_uplift_schwellwert, wrg_id, kaeufer_uplift_schwellwert, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(abt_id AS INT64) AS abt_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, dat_von, dat_bis, CAST(ertrag_uplift_schwellwert AS BIGNUMERIC) AS ertrag_uplift_schwellwert, wrg_id, CAST(kaeufer_uplift_schwellwert AS BIGNUMERIC) AS kaeufer_uplift_schwellwert, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_shopper_score_schwellwerte`;

-- Table: DBP_DATA.SHR_ARBEITSZEIT_ANTEIL_MAPPING
insert into `dbp_data.shr_arbeitszeit_anteil_mapping` (mandant_id, kjmo_bis, anz_stunden_bis, kjmo_von, anz_stunden_von, arbeitszeit_anteil, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo_bis AS INT64) AS kjmo_bis, CAST(anz_stunden_bis AS NUMERIC) AS anz_stunden_bis, CAST(kjmo_von AS INT64) AS kjmo_von, CAST(anz_stunden_von AS NUMERIC) AS anz_stunden_von, CAST(arbeitszeit_anteil AS NUMERIC) AS arbeitszeit_anteil, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_shr_arbeitszeit_anteil_mapping`;

-- Table: DBP_DATA.SHR_MA_FUNKTION_GRUPPE_SPR_ZU
insert into `dbp_data.shr_ma_funktion_gruppe_spr_zu` (shr_ma_funktion_gruppe_id, spr_id, shr_ma_funktion_gruppe_bez, td_insert, td_update)
SELECT CAST(shr_ma_funktion_gruppe_id AS INT64) AS shr_ma_funktion_gruppe_id, CAST(spr_id AS INT64) AS spr_id, shr_ma_funktion_gruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_shr_ma_funktion_gruppe_spr_zu`;

-- Table: DBP_DATA.SOK_ABTEILUNG_SPR_ZU
insert into `dbp_data.sok_abteilung_spr_zu` (mandant_id, sok_abteilung_id, spr_id, sok_abteilung_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sok_abteilung_id AS INT64) AS sok_abteilung_id, CAST(spr_id AS INT64) AS spr_id, sok_abteilung_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_sok_abteilung_spr_zu`;

-- Table: DBP_DATA.SOK_FIMA_BAUSTEIN_SPR_ZU
insert into `dbp_data.sok_fima_baustein_spr_zu` (mandant_id, sok_fima_baustein_id, spr_id, sok_fima_baustein_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sok_fima_baustein_id AS INT64) AS sok_fima_baustein_id, CAST(spr_id AS INT64) AS spr_id, sok_fima_baustein_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_sok_fima_baustein_spr_zu`;

-- Table: DBP_DATA.SOK_KATEGORIE_SPR_ZU
insert into `dbp_data.sok_kategorie_spr_zu` (mandant_id, sok_kategorie_id, spr_id, sok_kategorie_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sok_kategorie_id AS INT64) AS sok_kategorie_id, CAST(spr_id AS INT64) AS spr_id, sok_kategorie_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_sok_kategorie_spr_zu`;

-- Table: DBP_DATA.SONDERABWICKLUNG_SPR_ZU
insert into `dbp_data.sonderabwicklung_spr_zu` (mandant_id, sonderabwicklung_id, spr_id, sonderabwicklung_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, sonderabwicklung_id, CAST(spr_id AS INT64) AS spr_id, sonderabwicklung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sonderabwicklung_spr_zu`;

-- Table: DBP_DATA.SORT_KLASS_SPR_ZU
insert into `dbp_data.sort_klass_spr_zu` (mandant_id, klassifizierung_id, spr_id, klassifizierung_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(klassifizierung_id AS INT64) AS klassifizierung_id, CAST(spr_id AS INT64) AS spr_id, klassifizierung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sort_klass_spr_zu`;

-- Table: DBP_DATA.SPARTE_SPR_ZU
insert into `dbp_data.sparte_spr_zu` (sparte_id, spr_id, sparte_bez, td_insert, td_update)
SELECT CAST(sparte_id AS INT64) AS sparte_id, CAST(spr_id AS INT64) AS spr_id, sparte_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sparte_spr_zu`;

-- Table: DBP_DATA.SPERR_SPR_ZU
insert into `dbp_data.sperr_spr_zu` (mandant_id, sperr_id, spr_id, sperr_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, sperr_id, CAST(spr_id AS INT64) AS spr_id, sperr_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_sperr_spr_zu`;

-- Table: DBP_DATA.SPLITSOURCE_SPR_ZU
insert into `dbp_data.splitsource_spr_zu` (mandant_id, spr_id, splitsource_id, splitsource_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, splitsource_id, splitsource_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_splitsource_spr_zu`;

-- Table: DBP_DATA.SSM_ABTEILUNG_SPR_ZU
insert into `dbp_data.ssm_abteilung_spr_zu` (wup_abt_id, spr_id, wup_abt_bez, td_insert, td_update)
SELECT CAST(wup_abt_id AS INT64) AS wup_abt_id, CAST(spr_id AS INT64) AS spr_id, wup_abt_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_abteilung_spr_zu`;

-- Table: DBP_DATA.SSM_BEREICH_SPR_ZU
insert into `dbp_data.ssm_bereich_spr_zu` (wup_bereich_id, spr_id, wup_bereich_bez, td_insert, td_update)
SELECT CAST(wup_bereich_id AS INT64) AS wup_bereich_id, CAST(spr_id AS INT64) AS spr_id, wup_bereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_bereich_spr_zu`;

-- Table: DBP_DATA.SSM_CLUSTER_PROZESS_ZU
insert into `dbp_data.ssm_cluster_prozess_zu` (mandant_id, ssm_cluster_id, ssm_prozess_id, dat_von, etagen_anz, wup_bereich_id, wup_abt_id, dat_bis, fixwert_mo, fixwert_di, fixwert_mi, fixwert_do, fixwert_fr, fixwert_sa, fixwert_so, zeit_benchmark, prognose_multiplikator, anpassung_nettoleistung_up_fg, anpassung_nettoleistung_down_fg, start_variabel_typ, start_variabel_wert, ende_variabel_typ, ende_variabel_wert, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ssm_cluster_id AS INT64) AS ssm_cluster_id, CAST(ssm_prozess_id AS INT64) AS ssm_prozess_id, dat_von, CAST(etagen_anz AS INT64) AS etagen_anz, CAST(wup_bereich_id AS INT64) AS wup_bereich_id, CAST(wup_abt_id AS INT64) AS wup_abt_id, dat_bis, CAST(fixwert_mo AS NUMERIC) AS fixwert_mo, CAST(fixwert_di AS NUMERIC) AS fixwert_di, CAST(fixwert_mi AS NUMERIC) AS fixwert_mi, CAST(fixwert_do AS NUMERIC) AS fixwert_do, CAST(fixwert_fr AS NUMERIC) AS fixwert_fr, CAST(fixwert_sa AS NUMERIC) AS fixwert_sa, CAST(fixwert_so AS NUMERIC) AS fixwert_so, CAST(zeit_benchmark AS BIGNUMERIC) AS zeit_benchmark, CAST(prognose_multiplikator AS NUMERIC) AS prognose_multiplikator, CAST(anpassung_nettoleistung_up_fg AS INT64) AS anpassung_nettoleistung_up_fg, CAST(anpassung_nettoleistung_down_fg AS INT64) AS anpassung_nettoleistung_down_fg, start_variabel_typ, CAST(start_variabel_wert AS NUMERIC) AS start_variabel_wert, ende_variabel_typ, CAST(ende_variabel_wert AS NUMERIC) AS ende_variabel_wert, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ssm_cluster_prozess_zu`;

-- Table: DBP_DATA.SSM_CLUSTER_SPR_ZU
insert into `dbp_data.ssm_cluster_spr_zu` (mandant_id, wup_bereich_id, wup_abt_id, ssm_cluster_id, spr_id, ssm_cluster_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_bereich_id AS INT64) AS wup_bereich_id, CAST(wup_abt_id AS INT64) AS wup_abt_id, CAST(ssm_cluster_id AS INT64) AS ssm_cluster_id, CAST(spr_id AS INT64) AS spr_id, ssm_cluster_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_cluster_spr_zu`;

-- Table: DBP_DATA.SSM_WUP_PROZESS_WERBEVERTEILUNG
insert into `dbp_data.ssm_wup_prozess_werbeverteilung` (mandant_id, wup_id, nb_id, ssm_prozess_id, dat, wert, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(ssm_prozess_id AS INT64) AS ssm_prozess_id, dat, CAST(wert AS INT64) AS wert, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ssm_wup_prozess_werbeverteilung`;

-- Table: DBP_DATA.STATUSCODE_GRUPPE_ZU
insert into `dbp_data.statuscode_gruppe_zu` (system_id, mandant_id, statuscode_id, statusgruppe_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(statuscode_id AS INT64) AS statuscode_id, CAST(statusgruppe_id AS INT64) AS statusgruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_statuscode_gruppe_zu`;

-- Table: DBP_DATA.STATUSCODE_SPR_ZU
insert into `dbp_data.statuscode_spr_zu` (system_id, mandant_id, statuscode_id, spr_id, statuscode_bez, statuscode_bez_kurz, statuscode_bez_lang, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(statuscode_id AS INT64) AS statuscode_id, CAST(spr_id AS INT64) AS spr_id, statuscode_bez, statuscode_bez_kurz, statuscode_bez_lang, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_statuscode_spr_zu`;

-- Table: DBP_DATA.STATUSGRUPPE_SPR_ZU
insert into `dbp_data.statusgruppe_spr_zu` (system_id, mandant_id, statusgruppe_id, spr_id, statusgruppe_bez, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(statusgruppe_id AS INT64) AS statusgruppe_id, CAST(spr_id AS INT64) AS spr_id, statusgruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_statusgruppe_spr_zu`;

-- Table: DBP_DATA.STATUS_LADTRAEGER_SPR_ZU
insert into `dbp_data.status_ladtraeger_spr_zu` (status_ladtraeger, spr_id, mandant_id, status_ladtraeger_bez, td_insert, td_update)
SELECT status_ladtraeger, CAST(spr_id AS INT64) AS spr_id, CAST(mandant_id AS INT64) AS mandant_id, status_ladtraeger_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_status_ladtraeger_spr_zu`;

-- Table: DBP_DATA.STUECKLISTE_TYP_SPR_ZU
insert into `dbp_data.stueckliste_typ_spr_zu` (mandant_id, stueckliste_typ_id, spr_id, stueckliste_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, stueckliste_typ_id, CAST(spr_id AS INT64) AS spr_id, stueckliste_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_stueckliste_typ_spr_zu`;

-- Table: DBP_DATA.STUECKLIST_VERWENDUNG_SPR_ZU
insert into `dbp_data.stuecklist_verwendung_spr_zu` (mandant_id, stueckliste_verwendung_id, spr_id, stueckliste_verwendung_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(stueckliste_verwendung_id AS INT64) AS stueckliste_verwendung_id, CAST(spr_id AS INT64) AS spr_id, stueckliste_verwendung_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_stuecklist_verwendung_spr_zu`;

-- Table: DBP_DATA.SUBKATEGORIE_1_SPR_ZU
insert into `dbp_data.subkategorie_1_spr_zu` (mandant_id, subkategorie_1_id, spr_id, subkategorie_1_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(subkategorie_1_id AS INT64) AS subkategorie_1_id, CAST(spr_id AS INT64) AS spr_id, subkategorie_1_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_subkategorie_1_spr_zu`;

-- Table: DBP_DATA.SUBKATEGORIE_2_SPR_ZU
insert into `dbp_data.subkategorie_2_spr_zu` (mandant_id, subkategorie_2_id, spr_id, subkategorie_2_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(subkategorie_2_id AS INT64) AS subkategorie_2_id, CAST(spr_id AS INT64) AS spr_id, subkategorie_2_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_subkategorie_2_spr_zu`;

-- Table: DBP_DATA.SYSTEMSTATUS_SPR_ZU
insert into `dbp_data.systemstatus_spr_zu` (mandant_id, systemstatus_id, spr_id, system_id, systemstatus_bez_kurz, systemstatus_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, systemstatus_id, CAST(spr_id AS INT64) AS spr_id, CAST(system_id AS INT64) AS system_id, systemstatus_bez_kurz, systemstatus_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_systemstatus_spr_zu`;

-- Table: DBP_DATA.TARIFGEBIET_SPR_ZU
insert into `dbp_data.tarifgebiet_spr_zu` (mandant_id, tarifgebiet_id, spr_id, tarifgebiet_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, tarifgebiet_id, CAST(spr_id AS INT64) AS spr_id, tarifgebiet_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tarifgebiet_spr_zu`;

-- Table: DBP_DATA.TECHN_PLATZ_E_2_TERMIN
insert into `dbp_data.techn_platz_e_2_termin` (techn_platz_id, dat, mandant_id, bed_konzept_fleisch, bed_konzept_fleisch_dat, bed_konzept_wurst, bed_konzept_wurst_dat, bed_konzept_kaese, bed_konzept_kaese_dat, bed_konzept_fisch, bed_konzept_fisch_dat, frische_baecker, frische_baecker_dat, discount_backshop, discount_backshop_dat, bed_konzept_leergut, bed_konzept_leergut_dat, bed_konzept_bulk_food, bed_konzept_bulk_food_dat, bedien_insel, bedien_insel_dat, imbiss, imbiss_dat, bed_konzept_feinkost, bed_konzept_feinkost_dat, td_insert, td_update)
SELECT techn_platz_id, dat, CAST(mandant_id AS INT64) AS mandant_id, bed_konzept_fleisch, bed_konzept_fleisch_dat, bed_konzept_wurst, bed_konzept_wurst_dat, bed_konzept_kaese, bed_konzept_kaese_dat, bed_konzept_fisch, bed_konzept_fisch_dat, frische_baecker, frische_baecker_dat, discount_backshop, discount_backshop_dat, bed_konzept_leergut, bed_konzept_leergut_dat, bed_konzept_bulk_food, bed_konzept_bulk_food_dat, bedien_insel, bedien_insel_dat, imbiss, imbiss_dat, bed_konzept_feinkost, bed_konzept_feinkost_dat, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_techn_platz_e_2_termin`;

-- Table: DBP_DATA.TECHN_PLATZ_OBL_HIST
insert into `dbp_data.techn_platz_obl_hist` (techn_platz_id, mandant_id, tech_platz_bez, tp_vl_name, tp_vkl_name, tp_ol_vermietung, tp_bl_kbl_name, tp_betreuer_kbl_name, tp_bl_projekt_name, tp_pl_kbl, dat_extrakt, td_insert, td_update)
SELECT techn_platz_id, CAST(mandant_id AS INT64) AS mandant_id, tech_platz_bez, tp_vl_name, tp_vkl_name, tp_ol_vermietung, tp_bl_kbl_name, tp_betreuer_kbl_name, tp_bl_projekt_name, tp_pl_kbl, dat_extrakt, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_techn_platz_obl_hist`;

-- Table: DBP_DATA.TEKU_BERICHT_KAT_ZU_PER
insert into `dbp_data.teku_bericht_kat_zu_per` (teku_bericht_id, teku_kategorie_id, dat_von, dat_bis, teku_kategorie_note, td_insert, td_update)
SELECT CAST(teku_bericht_id AS INT64) AS teku_bericht_id, CAST(teku_kategorie_id AS INT64) AS teku_kategorie_id, dat_von, dat_bis, CAST(teku_kategorie_note AS INT64) AS teku_kategorie_note, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_bericht_kat_zu_per`;

-- Table: DBP_DATA.TEKU_EINSATZ
insert into `dbp_data.teku_einsatz` (teku_einsatz_id, teku_tour_id, testkunde_id, dat_soll, dat_korr, dat_ist, storno_fg, td_insert, td_update)
SELECT CAST(teku_einsatz_id AS INT64) AS teku_einsatz_id, CAST(teku_tour_id AS INT64) AS teku_tour_id, CAST(testkunde_id AS INT64) AS testkunde_id, dat_soll, dat_korr, dat_ist, CAST(storno_fg AS INT64) AS storno_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_einsatz`;

-- Table: DBP_DATA.TEKU_FRAGE_CHECKLISTE_ZU
insert into `dbp_data.teku_frage_checkliste_zu` (teku_fragestellung_id, teku_fragestellung_pos_id, teku_frage_id, teku_checkliste_id, td_insert, td_update)
SELECT CAST(teku_fragestellung_id AS INT64) AS teku_fragestellung_id, CAST(teku_fragestellung_pos_id AS INT64) AS teku_fragestellung_pos_id, CAST(teku_frage_id AS INT64) AS teku_frage_id, CAST(teku_checkliste_id AS INT64) AS teku_checkliste_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_frage_checkliste_zu`;

-- Table: DBP_DATA.TEKU_FRAGE_KATEGORIE_ZU_PER
insert into `dbp_data.teku_frage_kategorie_zu_per` (teku_frage_kat_zu_id, dat_von, teku_kategorie_id, teku_frage_id, teku_frage_pos_id, teku_frage_gewicht, dat_bis, td_insert, td_update)
SELECT CAST(teku_frage_kat_zu_id AS INT64) AS teku_frage_kat_zu_id, dat_von, CAST(teku_kategorie_id AS INT64) AS teku_kategorie_id, CAST(teku_frage_id AS INT64) AS teku_frage_id, CAST(teku_frage_pos_id AS INT64) AS teku_frage_pos_id, CAST(teku_frage_gewicht AS INT64) AS teku_frage_gewicht, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_frage_kategorie_zu_per`;

-- Table: DBP_DATA.TEKU_FRAGE_MENUE_ZU
insert into `dbp_data.teku_frage_menue_zu` (teku_fragestellung_id, teku_fragestellung_pos_id, teku_frage_id, teku_menue_id, td_insert, td_update)
SELECT CAST(teku_fragestellung_id AS INT64) AS teku_fragestellung_id, CAST(teku_fragestellung_pos_id AS INT64) AS teku_fragestellung_pos_id, CAST(teku_frage_id AS INT64) AS teku_frage_id, CAST(teku_menue_id AS INT64) AS teku_menue_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_frage_menue_zu`;

-- Table: DBP_DATA.TEKU_FRAGE_SPR_ZU
insert into `dbp_data.teku_frage_spr_zu` (teku_frage_id, spr_id, teku_frage_bez, teku_frage_bez_lang, td_insert, td_update)
SELECT CAST(teku_frage_id AS INT64) AS teku_frage_id, CAST(spr_id AS INT64) AS spr_id, teku_frage_bez, teku_frage_bez_lang, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_frage_spr_zu`;

-- Table: DBP_DATA.TEKU_KATEGORIE_SPR_ZU
insert into `dbp_data.teku_kategorie_spr_zu` (teku_kategorie_id, spr_id, teku_kategorie_bez, td_insert, td_update)
SELECT CAST(teku_kategorie_id AS INT64) AS teku_kategorie_id, CAST(spr_id AS INT64) AS spr_id, teku_kategorie_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_kategorie_spr_zu`;

-- Table: DBP_DATA.TEKU_SCHWELLWERT_PER
insert into `dbp_data.teku_schwellwert_per` (mandant_id, teku_berichts_objekt_id, teku_hierarchie_objekt_id, teku_spalte_bez, dat_von, dat_bis, sw_gruen_bis, sw_rot_ab, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, teku_berichts_objekt_id, teku_hierarchie_objekt_id, teku_spalte_bez, dat_von, dat_bis, CAST(sw_gruen_bis AS NUMERIC) AS sw_gruen_bis, CAST(sw_rot_ab AS NUMERIC) AS sw_rot_ab, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_schwellwert_per`;

-- Table: DBP_DATA.TEKU_TESTKUNDE
insert into `dbp_data.teku_testkunde` (testkunde_id, mandant_id, testkunde_name, testkunde_vorname, testkunde_anrede, testkunde_funktion, testkunde_dat_bis, td_insert, td_update)
SELECT CAST(testkunde_id AS INT64) AS testkunde_id, CAST(mandant_id AS INT64) AS mandant_id, testkunde_name, testkunde_vorname, testkunde_anrede, testkunde_funktion, testkunde_dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_testkunde`;

-- Table: DBP_DATA.TEKU_TOUR
insert into `dbp_data.teku_tour` (teku_tour_id, mandant_id, teku_tour_bez, td_insert, td_update)
SELECT CAST(teku_tour_id AS INT64) AS teku_tour_id, CAST(mandant_id AS INT64) AS mandant_id, teku_tour_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_tour`;

-- Table: DBP_DATA.TEKU_TOUR_MARKT_ZU
insert into `dbp_data.teku_tour_markt_zu` (teku_tour_wup_zu_id, teku_tour_pos_id, teku_tour_id, mandant_id, wup_id, teku_checkliste_id, aktiv_fg, td_insert, td_update)
SELECT CAST(teku_tour_wup_zu_id AS INT64) AS teku_tour_wup_zu_id, CAST(teku_tour_pos_id AS INT64) AS teku_tour_pos_id, CAST(teku_tour_id AS INT64) AS teku_tour_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(teku_checkliste_id AS INT64) AS teku_checkliste_id, CAST(aktiv_fg AS INT64) AS aktiv_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_teku_tour_markt_zu`;

-- Table: DBP_DATA.TMS_DISPOSTELLE
insert into `dbp_data.tms_dispostelle` (mandant_id, system_id, tms_dispostelle_id, tms_dispostelle_name, lagernummer_id, bestand_tms_gp_id, bestand_tms_gp_typ_cd, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_dispostelle_id AS INT64) AS tms_dispostelle_id, tms_dispostelle_name, lagernummer_id, bestand_tms_gp_id, bestand_tms_gp_typ_cd, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_dispostelle`;

-- Table: DBP_DATA.TMS_FAHRZEUG
insert into `dbp_data.tms_fahrzeug` (mandant_id, system_id, tms_fahrzeug_id, tms_fahrzeug_lfd_nr, tms_fahrzeugtyp_id, tms_fahrzeug_trailer_id, spediteur_tms_gp_id, spediteur_tms_gp_typ_cd, verbrauch_pro_100km, tms_treibstoff_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_fahrzeug_id, CAST(tms_fahrzeug_lfd_nr AS INT64) AS tms_fahrzeug_lfd_nr, CAST(tms_fahrzeugtyp_id AS INT64) AS tms_fahrzeugtyp_id, tms_fahrzeug_trailer_id, spediteur_tms_gp_id, spediteur_tms_gp_typ_cd, CAST(verbrauch_pro_100km AS NUMERIC) AS verbrauch_pro_100km, CAST(tms_treibstoff_id AS INT64) AS tms_treibstoff_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_fahrzeug`;

-- Table: DBP_DATA.TMS_GP_BESCHRAENKUNG_ZU
insert into `dbp_data.tms_gp_beschraenkung_zu` (mandant_id, system_id, tms_gp_id, tms_gp_typ_cd, tms_beschraenkung_id, tms_beschraenkung_pos_nr, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_gp_id, tms_gp_typ_cd, CAST(tms_beschraenkung_id AS INT64) AS tms_beschraenkung_id, CAST(tms_beschraenkung_pos_nr AS INT64) AS tms_beschraenkung_pos_nr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_gp_beschraenkung_zu`;

-- Table: DBP_DATA.TMS_KONTO
insert into `dbp_data.tms_konto` (mandant_id, system_id, tms_konto_id, tms_konto_lfd_nr, tms_konto_bez, tms_konto_txt, tms_fibu_konto_cd, tms_kostenstelle_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, CAST(tms_konto_id AS INT64) AS tms_konto_id, CAST(tms_konto_lfd_nr AS INT64) AS tms_konto_lfd_nr, tms_konto_bez, tms_konto_txt, tms_fibu_konto_cd, CAST(tms_kostenstelle_id AS INT64) AS tms_kostenstelle_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tms_konto`;

-- Table: DBP_DATA.TOURART_SUBTYP_SPR_ZU
insert into `dbp_data.tourart_subtyp_spr_zu` (tourart_subtyp_id, spr_id, mandant_id, tourart_subtyp_bez, td_insert, td_update)
SELECT CAST(tourart_subtyp_id AS INT64) AS tourart_subtyp_id, CAST(spr_id AS INT64) AS spr_id, CAST(mandant_id AS INT64) AS mandant_id, tourart_subtyp_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tourart_subtyp_spr_zu`;

-- Table: DBP_DATA.TP_MERKMAL_SPR_ZU
insert into `dbp_data.tp_merkmal_spr_zu` (tp_merkmal_id, spr_id, mandant_id, tp_merkmal_bez, td_insert, td_update)
SELECT CAST(tp_merkmal_id AS INT64) AS tp_merkmal_id, CAST(spr_id AS INT64) AS spr_id, CAST(mandant_id AS INT64) AS mandant_id, tp_merkmal_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_tp_merkmal_spr_zu`;

-- Table: DBP_DATA.TRANSAKTION_SPR_ZU
insert into `dbp_data.transaktion_spr_zu` (mandant_id, transaktion_id, spr_id, transaktion_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transaktion_id AS INT64) AS transaktion_id, CAST(spr_id AS INT64) AS spr_id, transaktion_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_transaktion_spr_zu`;

-- Table: DBP_DATA.TRANSFER_STATUS_SPR_ZU
insert into `dbp_data.transfer_status_spr_zu` (mandant_id, spr_id, transfer_status_id, transfer_status_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(transfer_status_id AS INT64) AS transfer_status_id, transfer_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transfer_status_spr_zu`;

-- Table: DBP_DATA.TRANSPORTART_SPR_ZU
insert into `dbp_data.transportart_spr_zu` (mandant_id, transportart_id, spr_id, transportart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, transportart_id, CAST(spr_id AS INT64) AS spr_id, transportart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_transportart_spr_zu`;

-- Table: DBP_DATA.TRANSPORTSTATUS_SPR_ZU
insert into `dbp_data.transportstatus_spr_zu` (mandant_id, transportstatus_id, spr_id, transportstatus_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transportstatus_id AS INT64) AS transportstatus_id, CAST(spr_id AS INT64) AS spr_id, transportstatus_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_transportstatus_spr_zu`;

-- Table: DBP_DATA.TRANSPORT_GV_SPR_ZU
insert into `dbp_data.transport_gv_spr_zu` (mandant_id, transport_gv_id, spr_id, transport_gv_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(transport_gv_id AS INT64) AS transport_gv_id, CAST(spr_id AS INT64) AS spr_id, transport_gv_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_transport_gv_spr_zu`;

-- Table: DBP_DATA.TS_BELOS_ADRESSE_WUP_ZU
insert into `dbp_data.ts_belos_adresse_wup_zu` (mandant_id, belos_adresse_id, wup_id, nb_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, belos_adresse_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_belos_adresse_wup_zu`;

-- Table: DBP_DATA.TS_BEST_VORSCHLAG_WBS
insert into `dbp_data.ts_best_vorschlag_wbs` (mandant_id, wup_id, nb_id, art_id, dat_ausfuehrung, menge_wbs_final, check_vz_fg, check_wup_fg, status_verarbeitung, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(art_id AS INT64) AS art_id, dat_ausfuehrung, CAST(menge_wbs_final AS NUMERIC) AS menge_wbs_final, CAST(check_vz_fg AS INT64) AS check_vz_fg, CAST(check_wup_fg AS INT64) AS check_wup_fg, CAST(status_verarbeitung AS INT64) AS status_verarbeitung, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ts_best_vorschlag_wbs`;

-- Table: DBP_DATA.TS_KMR_FREIGABE_KJMO
insert into `dbp_data.ts_kmr_freigabe_kjmo` (mandant_id, kjmo, freigabe_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(freigabe_fg AS INT64) AS freigabe_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ts_kmr_freigabe_kjmo`;

-- Table: DBP_DATA.TS_MERCAREON_MAPPING
insert into `dbp_data.ts_mercareon_mapping` (mercareon_standort, mercareon_entladestelle, mandant_id, wup_id, nb_id, lagernummer_ewm_id, lagernummer_les_id, entladestelle_id, artikelsortiment_id, td_update, td_insert)
SELECT mercareon_standort, mercareon_entladestelle, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagernummer_ewm_id, lagernummer_les_id, CAST(entladestelle_id AS INT64) AS entladestelle_id, artikelsortiment_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_mercareon_mapping`;

-- Table: DBP_DATA.TS_SCM_ART_CLUSTER_ZU
insert into `dbp_data.ts_scm_art_cluster_zu` (mandant_id, art_cluster_id, art_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_cluster_id AS INT64) AS art_cluster_id, CAST(art_id AS INT64) AS art_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_art_cluster_zu`;

-- Table: DBP_DATA.TS_SCM_GESCHAEFTSVORFALL_GRP_MAP
insert into `dbp_data.ts_scm_geschaeftsvorfall_grp_map` (geschaeftsvorfall_id, ewm_fg, scm_gv_grp_id, scm_gv_prozess_id, td_update, td_insert)
SELECT geschaeftsvorfall_id, CAST(ewm_fg AS INT64) AS ewm_fg, scm_gv_grp_id, scm_gv_prozess_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_geschaeftsvorfall_grp_map`;

-- Table: DBP_DATA.TS_SCM_GESCHAEFTSVORFALL_GRP_SPR_ZU
insert into `dbp_data.ts_scm_geschaeftsvorfall_grp_spr_zu` (scm_gv_grp_id, spr_id, scm_gv_grp_bez, td_update, td_insert)
SELECT scm_gv_grp_id, CAST(spr_id AS INT64) AS spr_id, scm_gv_grp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_geschaeftsvorfall_grp_spr_zu`;

-- Table: DBP_DATA.TS_SCM_GESCHAEFTSVORFALL_PROZESS_SPR_ZU
insert into `dbp_data.ts_scm_geschaeftsvorfall_prozess_spr_zu` (scm_gv_prozess_id, spr_id, scm_gv_grp_bez, td_update, td_insert)
SELECT scm_gv_prozess_id, CAST(spr_id AS INT64) AS spr_id, scm_gv_grp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_geschaeftsvorfall_prozess_spr_zu`;

-- Table: DBP_DATA.TS_SCM_L_ART_CLUSTER
insert into `dbp_data.ts_scm_l_art_cluster` (mandant_id, art_cluster_id, art_cluster_bez, art_cluster_descr, art_cluster_del_fg, update_timestamp, update_user, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(art_cluster_id AS INT64) AS art_cluster_id, art_cluster_bez, art_cluster_descr, CAST(art_cluster_del_fg AS INT64) AS art_cluster_del_fg, CAST(update_timestamp AS DATETIME) AS update_timestamp, update_user, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_l_art_cluster`;

-- Table: DBP_DATA.TS_SCM_L_WUP_CLUSTER
insert into `dbp_data.ts_scm_l_wup_cluster` (mandant_id, wup_cluster_id, wup_cluster_bez, wup_cluster_descr, wup_cluster_del_fg, update_timestamp, update_user, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_cluster_id AS INT64) AS wup_cluster_id, wup_cluster_bez, wup_cluster_descr, CAST(wup_cluster_del_fg AS INT64) AS wup_cluster_del_fg, CAST(update_timestamp AS DATETIME) AS update_timestamp, update_user, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_l_wup_cluster`;

-- Table: DBP_DATA.TS_SCM_TOR_GRUPPE_MAP
insert into `dbp_data.ts_scm_tor_gruppe_map` (mandant_id, lagernummer_id, wup_id, nb_id, tor_id_zugeordnet, tor_gruppe, hallenseite_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, tor_id_zugeordnet, tor_gruppe, hallenseite_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_tor_gruppe_map`;

-- Table: DBP_DATA.TS_SCM_WUP_CLUSTER_ZU
insert into `dbp_data.ts_scm_wup_cluster_zu` (mandant_id, wup_id, wup_cluster_id, nb_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(wup_cluster_id AS INT64) AS wup_cluster_id, CAST(nb_id AS INT64) AS nb_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_scm_wup_cluster_zu`;

-- Table: DBP_DATA.TS_SORTIMENT_PREISKLASSE_UWG
insert into `dbp_data.ts_sortiment_preisklasse_uwg` (mandant_id, kl_uwg_id, wrg_id, preislage_1, preislage_2, preislage_3, preislage_4, preislage_5, preislage_6, preislage_7, preislage_8, preislage_9, preislage_10, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kl_uwg_id AS INT64) AS kl_uwg_id, wrg_id, CAST(preislage_1 AS NUMERIC) AS preislage_1, CAST(preislage_2 AS NUMERIC) AS preislage_2, CAST(preislage_3 AS NUMERIC) AS preislage_3, CAST(preislage_4 AS NUMERIC) AS preislage_4, CAST(preislage_5 AS NUMERIC) AS preislage_5, CAST(preislage_6 AS NUMERIC) AS preislage_6, CAST(preislage_7 AS NUMERIC) AS preislage_7, CAST(preislage_8 AS NUMERIC) AS preislage_8, CAST(preislage_9 AS NUMERIC) AS preislage_9, CAST(preislage_10 AS NUMERIC) AS preislage_10, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_ts_sortiment_preisklasse_uwg`;

-- Table: DBP_DATA.TS_SORTIMENT_PREISKLASSE_WUG
insert into `dbp_data.ts_sortiment_preisklasse_wug` (mandant_id, arthiertyp_id, wg_id, wug_id, wrg_id, preislage_1, preislage_2, preislage_3, preislage_4, preislage_5, preislage_6, preislage_7, preislage_8, preislage_9, preislage_10, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, CAST(wug_id AS INT64) AS wug_id, wrg_id, CAST(preislage_1 AS NUMERIC) AS preislage_1, CAST(preislage_2 AS NUMERIC) AS preislage_2, CAST(preislage_3 AS NUMERIC) AS preislage_3, CAST(preislage_4 AS NUMERIC) AS preislage_4, CAST(preislage_5 AS NUMERIC) AS preislage_5, CAST(preislage_6 AS NUMERIC) AS preislage_6, CAST(preislage_7 AS NUMERIC) AS preislage_7, CAST(preislage_8 AS NUMERIC) AS preislage_8, CAST(preislage_9 AS NUMERIC) AS preislage_9, CAST(preislage_10 AS NUMERIC) AS preislage_10, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_sortiment_preisklasse_wug`;

-- Table: DBP_DATA.TS_WBS_ARTIKEL_VZ
insert into `dbp_data.ts_wbs_artikel_vz` (mandant_id, kjwo, angebot_id, aktion_id, ausliefergruppe_id, art_id, wup_id_vz, nb_id_vz, mandant_id_vz, bezugsweg_id, gp_id, clear_stock_id, lieferung_tag_offset, estimation_fg, adjustment_id, max_kapa_fg, dat_letzte_nachversorgung, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo AS INT64) AS kjwo, CAST(angebot_id AS INT64) AS angebot_id, aktion_id, ausliefergruppe_id, CAST(art_id AS INT64) AS art_id, CAST(wup_id_vz AS INT64) AS wup_id_vz, CAST(nb_id_vz AS INT64) AS nb_id_vz, CAST(mandant_id_vz AS INT64) AS mandant_id_vz, CAST(bezugsweg_id AS INT64) AS bezugsweg_id, CAST(gp_id AS INT64) AS gp_id, CAST(clear_stock_id AS INT64) AS clear_stock_id, CAST(lieferung_tag_offset AS INT64) AS lieferung_tag_offset, CAST(estimation_fg AS INT64) AS estimation_fg, CAST(adjustment_id AS INT64) AS adjustment_id, CAST(max_kapa_fg AS INT64) AS max_kapa_fg, dat_letzte_nachversorgung, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_wbs_artikel_vz`;

-- Table: DBP_DATA.TS_WBS_AUSLIEFERGRUPPE
insert into `dbp_data.ts_wbs_ausliefergruppe` (mandant_id, ausliefergruppe_id, berechnung_schwellwert_pal_abrundung_proz, berechnung_schwellwert_pal_aufrundung_proz, berechnung_kolli_rundung_proz, nachversorgung_schwellwert_pal_abrundung_proz, nachversorgung_schwellwert_pal_aufrundung_proz, nachversorgung_kolli_rundung_proz, max_kapa_endbestand_proz, bestand_betrachtung_proz, rest_von_normalbestand_proz, erweiterung_bedarfshorizont_tage, menge_zielendbestand_schwellwert_ame, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausliefergruppe_id, CAST(berechnung_schwellwert_pal_abrundung_proz AS NUMERIC) AS berechnung_schwellwert_pal_abrundung_proz, CAST(berechnung_schwellwert_pal_aufrundung_proz AS NUMERIC) AS berechnung_schwellwert_pal_aufrundung_proz, CAST(berechnung_kolli_rundung_proz AS NUMERIC) AS berechnung_kolli_rundung_proz, CAST(nachversorgung_schwellwert_pal_abrundung_proz AS NUMERIC) AS nachversorgung_schwellwert_pal_abrundung_proz, CAST(nachversorgung_schwellwert_pal_aufrundung_proz AS NUMERIC) AS nachversorgung_schwellwert_pal_aufrundung_proz, CAST(nachversorgung_kolli_rundung_proz AS NUMERIC) AS nachversorgung_kolli_rundung_proz, CAST(max_kapa_endbestand_proz AS NUMERIC) AS max_kapa_endbestand_proz, CAST(bestand_betrachtung_proz AS NUMERIC) AS bestand_betrachtung_proz, CAST(rest_von_normalbestand_proz AS NUMERIC) AS rest_von_normalbestand_proz, CAST(erweiterung_bedarfshorizont_tage AS INT64) AS erweiterung_bedarfshorizont_tage, CAST(menge_zielendbestand_schwellwert_ame AS INT64) AS menge_zielendbestand_schwellwert_ame, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_wbs_ausliefergruppe`;

-- Table: DBP_DATA.TS_WBS_VZ_TAG
insert into `dbp_data.ts_wbs_vz_tag` (mandant_id, wup_id, nb_id, dat, non_adjustable_day_fg, kommentar, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(non_adjustable_day_fg AS INT64) AS non_adjustable_day_fg, kommentar, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_ts_wbs_vz_tag`;

-- Table: DBP_DATA.TU_NUTZUNGSGRUND_SPR_ZU
insert into `dbp_data.tu_nutzungsgrund_spr_zu` (mandant_id, lager, tu_nutzungsgrund_id, spr_id, tu_nutzungsgrund_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lager, tu_nutzungsgrund_id, CAST(spr_id AS INT64) AS spr_id, tu_nutzungsgrund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_tu_nutzungsgrund_spr_zu`;

-- Table: DBP_DATA.UNTERNMNS_BEREICH_SPR_ZU
insert into `dbp_data.unternmns_bereich_spr_zu` (mandant_id, unternehmens_bereich_id, spr_id, unternehmens_bereich_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, unternehmens_bereich_id, CAST(spr_id AS INT64) AS spr_id, unternehmens_bereich_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_unternmns_bereich_spr_zu`;

-- Table: DBP_DATA.VERFUEGBARKEITSGRUPPE_SPR_ZU
insert into `dbp_data.verfuegbarkeitsgruppe_spr_zu` (mandant_id, spr_id, lagernummer_id, verfuegbarkeitsgruppe_id, verfuegbarkeitsgruppe_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, lagernummer_id, verfuegbarkeitsgruppe_id, verfuegbarkeitsgruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_verfuegbarkeitsgruppe_spr_zu`;

-- Table: DBP_DATA.VERKAUFSMOEBEL_SPR_ZU
insert into `dbp_data.verkaufsmoebel_spr_zu` (mandant_id, verkaufsmoebel_id, spr_id, verkaufsmoebel_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verkaufsmoebel_id AS INT64) AS verkaufsmoebel_id, CAST(spr_id AS INT64) AS spr_id, verkaufsmoebel_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_verkaufsmoebel_spr_zu`;

-- Table: DBP_DATA.VERRECHFALLART_SPR_ZU
insert into `dbp_data.verrechfallart_spr_zu` (mandant_id, verrechfallart_id, spr_id, verrechfallart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechfallart_id, CAST(spr_id AS INT64) AS spr_id, verrechfallart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_verrechfallart_spr_zu`;

-- Table: DBP_DATA.VERRECHFALL_KOSTENART_SPR_ZU
insert into `dbp_data.verrechfall_kostenart_spr_zu` (mandant_id, verrechfall_kostenart_id, spr_id, verrechfall_kostenart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechfall_kostenart_id, CAST(spr_id AS INT64) AS spr_id, verrechfall_kostenart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_verrechfall_kostenart_spr_zu`;

-- Table: DBP_DATA.VERRECHFALL_KOSTENTYP_SPR_ZU
insert into `dbp_data.verrechfall_kostentyp_spr_zu` (mandant_id, verrechfall_kostentyp_id, spr_id, verrechfall_kostentyp_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechfall_kostentyp_id, CAST(spr_id AS INT64) AS spr_id, verrechfall_kostentyp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_verrechfall_kostentyp_spr_zu`;

-- Table: DBP_DATA.VERRECHFALL_STATUS_SPR_ZU
insert into `dbp_data.verrechfall_status_spr_zu` (mandant_id, verrechfall_status_id, spr_id, verrechfall_status_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechfall_status_id, CAST(spr_id AS INT64) AS spr_id, verrechfall_status_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_verrechfall_status_spr_zu`;

-- Table: DBP_DATA.VERRECHNUNGSART_SPR_ZU
insert into `dbp_data.verrechnungsart_spr_zu` (mandant_id, verrechnungsart_id, spr_id, verrechnungsart_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, verrechnungsart_id, CAST(spr_id AS INT64) AS spr_id, verrechnungsart_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_verrechnungsart_spr_zu`;

-- Table: DBP_DATA.VERURSACHER_SPR_ZU
insert into `dbp_data.verursacher_spr_zu` (mandant_id, verursacher_id, spr_id, verursacher_bez, system_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(verursacher_id AS INT64) AS verursacher_id, CAST(spr_id AS INT64) AS spr_id, verursacher_bez, CAST(system_id AS INT64) AS system_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_verursacher_spr_zu`;

-- Table: DBP_DATA.VF
insert into `dbp_data.vf` (vf_id, vf_name, mandant_id, td_insert, td_update)
SELECT CAST(vf_id AS INT64) AS vf_id, vf_name, CAST(mandant_id AS INT64) AS mandant_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vf`;

-- Table: DBP_DATA.VIS_L_PROBLEMCODE
insert into `dbp_data.vis_l_problemcode` (mandant_id, problemcode_id, problemcode_bez, kopf_fehler_fg, pos_fehler_fg, mkcheck, faktor, aus_problemcode_id, active, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, problemcode_id, problemcode_bez, CAST(kopf_fehler_fg AS INT64) AS kopf_fehler_fg, CAST(pos_fehler_fg AS INT64) AS pos_fehler_fg, mkcheck, CAST(faktor AS NUMERIC) AS faktor, aus_problemcode_id, CAST(active AS INT64) AS active, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_l_problemcode`;

-- Table: DBP_DATA.VIS_L_PUK_KENNZAHL
insert into `dbp_data.vis_l_puk_kennzahl` (kennzahl_id, thema_id, td_insert, td_update)
SELECT CAST(kennzahl_id AS INT64) AS kennzahl_id, CAST(thema_id AS INT64) AS thema_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_l_puk_kennzahl`;

-- Table: DBP_DATA.VIS_L_PUK_THEMA
insert into `dbp_data.vis_l_puk_thema` (thema_id, td_insert, td_update)
SELECT CAST(thema_id AS INT64) AS thema_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_l_puk_thema`;

-- Table: DBP_DATA.VIS_L_PUK_TYP
insert into `dbp_data.vis_l_puk_typ` (puk_typ_id, td_insert, td_update)
SELECT CAST(puk_typ_id AS INT64) AS puk_typ_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_l_puk_typ`;

-- Table: DBP_DATA.VIS_PUK_KENNZAHL_SPR_ZU
insert into `dbp_data.vis_puk_kennzahl_spr_zu` (kennzahl_id, spr_id, kennzahl_bez, td_insert, td_update)
SELECT CAST(kennzahl_id AS INT64) AS kennzahl_id, CAST(spr_id AS INT64) AS spr_id, kennzahl_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_puk_kennzahl_spr_zu`;

-- Table: DBP_DATA.VIS_PUK_THEMA_SPR_ZU
insert into `dbp_data.vis_puk_thema_spr_zu` (thema_id, spr_id, thema_bez, td_insert, td_update)
SELECT CAST(thema_id AS INT64) AS thema_id, CAST(spr_id AS INT64) AS spr_id, thema_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_puk_thema_spr_zu`;

-- Table: DBP_DATA.VIS_PUK_TYP_SPR_ZU
insert into `dbp_data.vis_puk_typ_spr_zu` (puk_typ_id, spr_id, puk_typ_bez, td_insert, td_update)
SELECT CAST(puk_typ_id AS INT64) AS puk_typ_id, CAST(spr_id AS INT64) AS spr_id, puk_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_puk_typ_spr_zu`;

-- Table: DBP_DATA.VIS_SCHWELLWERT
insert into `dbp_data.vis_schwellwert` (mandant_id, wup_id, kjmo, sw_thema_id, sw_attribut_id, sw_attribut_wert, vis_schwellwert, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(kjmo AS INT64) AS kjmo, CAST(sw_thema_id AS INT64) AS sw_thema_id, CAST(sw_attribut_id AS INT64) AS sw_attribut_id, CAST(sw_attribut_wert AS INT64) AS sw_attribut_wert, CAST(vis_schwellwert AS NUMERIC) AS vis_schwellwert, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_schwellwert`;

-- Table: DBP_DATA.VIS_WETTBEWERBER
insert into `dbp_data.vis_wettbewerber` (mandant_id, wup_id, nb_id, wb_rang, wb_name, wb_dat_von, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wb_rang AS INT64) AS wb_rang, wb_name, wb_dat_von, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vis_wettbewerber`;

-- Table: DBP_DATA.VK
insert into `dbp_data.vk` (vk_id, vk_bez, mandant_id, td_insert, td_update)
SELECT CAST(vk_id AS INT64) AS vk_id, vk_bez, CAST(mandant_id AS INT64) AS mandant_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vk`;

-- Table: DBP_DATA.VORGANGSART_AG08_SPR_ZU
insert into `dbp_data.vorgangsart_ag08_spr_zu` (system_id, mandant_id, spr_id, vorgangsart_ag08_id, vorgangsart_ag08_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, vorgangsart_ag08_id, vorgangsart_ag08_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_vorgangsart_ag08_spr_zu`;

-- Table: DBP_DATA.VORGANGSART_WEWA_GRUPPE_ZU
insert into `dbp_data.vorgangsart_wewa_gruppe_zu` (system_id, mandant_id, vorgangsart_id, wewa_gruppe_id, open_fg, gemeldet_fg, teilgebucht_fg, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, vorgangsart_id, CAST(wewa_gruppe_id AS INT64) AS wewa_gruppe_id, CAST(open_fg AS INT64) AS open_fg, CAST(gemeldet_fg AS INT64) AS gemeldet_fg, CAST(teilgebucht_fg AS INT64) AS teilgebucht_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vorgangsart_wewa_gruppe_zu`;

-- Table: DBP_DATA.VORGANGSKLASSE_SPR_ZU
insert into `dbp_data.vorgangsklasse_spr_zu` (system_id, mandant_id, vorgangsklasse_id, spr_id, vorgangsklasse_bez, vorgangsklasse_bez_kurz, vorgangsklasse_bez_lang, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, vorgangsklasse_id, CAST(spr_id AS INT64) AS spr_id, vorgangsklasse_bez, vorgangsklasse_bez_kurz, vorgangsklasse_bez_lang, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vorgangsklasse_spr_zu`;

-- Table: DBP_DATA.VORGART_BEST_ENTW_SPR_ZU
insert into `dbp_data.vorgart_best_entw_spr_zu` (mandant_id, vorgart_best_entw_id, spr_id, vorgart_best_entw_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, vorgart_best_entw_id, CAST(spr_id AS INT64) AS spr_id, vorgart_best_entw_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_vorgart_best_entw_spr_zu`;

-- Table: DBP_DATA.VS
insert into `dbp_data.vs` (vs_id, vs_bez, vk_id, mandant_id, vsvt_bez, td_insert, td_update, vs_ref_wup_id)
SELECT CAST(vs_id AS INT64) AS vs_id, vs_bez, CAST(vk_id AS INT64) AS vk_id, CAST(mandant_id AS INT64) AS mandant_id, vsvt_bez, td_insert, td_update, CAST(vs_ref_wup_id AS INT64) AS vs_ref_wup_id
FROM `snowflake_snapshots.kfl_dbp_data_vs`;

-- Table: DBP_DATA.VZ_DISPO_ARTIKELSTATUS_SPR_ZU
insert into `dbp_data.vz_dispo_artikelstatus_spr_zu` (mandant_id, spr_id, vz_dispo_artikelstatus_id, vz_dispo_artikelstatus_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(vz_dispo_artikelstatus_id AS INT64) AS vz_dispo_artikelstatus_id, vz_dispo_artikelstatus_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_vz_dispo_artikelstatus_spr_zu`;

-- Table: DBP_DATA.VZ_DISPO_STATUS_SPR_ZU
insert into `dbp_data.vz_dispo_status_spr_zu` (mandant_id, spr_id, vz_dispo_status_id, vz_dispo_status_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(vz_dispo_status_id AS INT64) AS vz_dispo_status_id, vz_dispo_status_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_vz_dispo_status_spr_zu`;

-- Table: DBP_DATA.WAQFK_QUOTE
insert into `dbp_data.waqfk_quote` (mandant_id, lagernummer_id, wup_id, nb_id, waqfk_quote, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(waqfk_quote AS NUMERIC) AS waqfk_quote, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_waqfk_quote`;

-- Table: DBP_DATA.WARENBEWEGUNGSTYP_SPR_ZU
insert into `dbp_data.warenbewegungstyp_spr_zu` (mandant_id, warenbewegungstyp_id, spr_id, warenbewegungstyp_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, warenbewegungstyp_id, CAST(spr_id AS INT64) AS spr_id, warenbewegungstyp_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_warenbewegungstyp_spr_zu`;

-- Table: DBP_DATA.WBNK_GRUPPE_SPR_ZU
insert into `dbp_data.wbnk_gruppe_spr_zu` (system_id, mandant_id, wbnk_gruppe_id, spr_id, wbnk_gruppe_bez, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wbnk_gruppe_id AS INT64) AS wbnk_gruppe_id, CAST(spr_id AS INT64) AS spr_id, wbnk_gruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbnk_gruppe_spr_zu`;

-- Table: DBP_DATA.WBNK_GRUPPE_ZU
insert into `dbp_data.wbnk_gruppe_zu` (system_id, mandant_id, wbnk_id, wbnk_gruppe_id, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, wbnk_id, CAST(wbnk_gruppe_id AS INT64) AS wbnk_gruppe_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbnk_gruppe_zu`;

-- Table: DBP_DATA.WBNK_SPR_ZU
insert into `dbp_data.wbnk_spr_zu` (system_id, mandant_id, wbnk_id, spr_id, wbnk_bez, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, wbnk_id, CAST(spr_id AS INT64) AS spr_id, wbnk_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbnk_spr_zu`;

-- Table: DBP_DATA.WBS_L_ADJUSTMENT
insert into `dbp_data.wbs_l_adjustment` (mandant_id, adjustment_id, adjustment_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(adjustment_id AS INT64) AS adjustment_id, adjustment_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_l_adjustment`;

-- Table: DBP_DATA.WBS_L_ESTIMATION
insert into `dbp_data.wbs_l_estimation` (mandant_id, estimation_id, estimation_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(estimation_id AS INT64) AS estimation_id, estimation_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_l_estimation`;

-- Table: DBP_DATA.WBS_L_MANDANT_ZEITSLOTS
insert into `dbp_data.wbs_l_mandant_zeitslots` (mandant_id, zeitslot_id, zeitslot_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(zeitslot_id AS INT64) AS zeitslot_id, zeitslot_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_l_mandant_zeitslots`;

-- Table: DBP_DATA.WBS_L_MARKT_CLUSTER_INITIALE_BELIEFERUNG
insert into `dbp_data.wbs_l_markt_cluster_initiale_belieferung` (mandant_id, init_lief_markt_cluster_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(init_lief_markt_cluster_id AS INT64) AS init_lief_markt_cluster_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_l_markt_cluster_initiale_belieferung`;

-- Table: DBP_DATA.WBS_L_MARKT_CLUSTER_MIN_PLATZIERUNG
insert into `dbp_data.wbs_l_markt_cluster_min_platzierung` (mandant_id, min_platzierung_markt_cluster_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(min_platzierung_markt_cluster_id AS INT64) AS min_platzierung_markt_cluster_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_l_markt_cluster_min_platzierung`;

-- Table: DBP_DATA.WBS_MANDANT_AUSLIEFERUNGSGRUPPE_TAG_ZEITSLOTS_ZU
insert into `dbp_data.wbs_mandant_auslieferungsgruppe_tag_zeitslots_zu` (mandant_id, auslieferungsgruppe_id, wtag_id, zeitslot_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, auslieferungsgruppe_id, CAST(wtag_id AS INT64) AS wtag_id, CAST(zeitslot_id AS INT64) AS zeitslot_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wbs_mandant_auslieferungsgruppe_tag_zeitslots_zu`;

-- Table: DBP_DATA.WBS_PHASE_SPR_ZU
insert into `dbp_data.wbs_phase_spr_zu` (mandant_id, spr_id, wbs_phase_id, wbs_phase_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, CAST(wbs_phase_id AS INT64) AS wbs_phase_id, wbs_phase_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbs_phase_spr_zu`;

-- Table: DBP_DATA.WBS_PHASE_ZU
insert into `dbp_data.wbs_phase_zu` (mandant_id, ausliefergruppe_id, anz_tage_vor_aktion, wbs_phase_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausliefergruppe_id, CAST(anz_tage_vor_aktion AS INT64) AS anz_tage_vor_aktion, CAST(wbs_phase_id AS INT64) AS wbs_phase_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wbs_phase_zu`;

-- Table: DBP_DATA.WERBEFLAECHENABSCHNITT_SPR_ZU
insert into `dbp_data.werbeflaechenabschnitt_spr_zu` (werbeflaechenabschnitt_id, spr_id, werbeflaechenabschnitt_name, werbeflaechenabschnitt_wfl_bez, td_update, td_insert)
SELECT CAST(werbeflaechenabschnitt_id AS INT64) AS werbeflaechenabschnitt_id, CAST(spr_id AS INT64) AS spr_id, werbeflaechenabschnitt_name, werbeflaechenabschnitt_wfl_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_werbeflaechenabschnitt_spr_zu`;

-- Table: DBP_DATA.WERBEKAT_SPR_ZU
insert into `dbp_data.werbekat_spr_zu` (werbe_kat_id, mandant_id, spr_id, werbe_kat_bez, td_insert, td_update)
SELECT CAST(werbe_kat_id AS INT64) AS werbe_kat_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, werbe_kat_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_werbekat_spr_zu`;

-- Table: DBP_DATA.WERBEMITTEL_ART_SPR_ZU
insert into `dbp_data.werbemittel_art_spr_zu` (spr_id, werbemittel_art_id, werbemittel_art_bez, td_update, td_insert)
SELECT CAST(spr_id AS INT64) AS spr_id, werbemittel_art_id, werbemittel_art_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_werbemittel_art_spr_zu`;

-- Table: DBP_DATA.WERBEMITTEL_SPR_ZU
insert into `dbp_data.werbemittel_spr_zu` (werbemittelkanal_id, werbemittel_id, spr_id, werbemittel_bez, werbemittel_wfl_bez, td_update, td_insert)
SELECT werbemittelkanal_id, werbemittel_id, CAST(spr_id AS INT64) AS spr_id, werbemittel_bez, werbemittel_wfl_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_werbemittel_spr_zu`;

-- Table: DBP_DATA.WERBE_MEDIUM_SPR_ZU
insert into `dbp_data.werbe_medium_spr_zu` (mandant_id, medien_kz, spr_id, werbe_medium_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, medien_kz, CAST(spr_id AS INT64) AS spr_id, werbe_medium_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_werbe_medium_spr_zu`;

-- Table: DBP_DATA.WERBE_TYP_SPR_ZU
insert into `dbp_data.werbe_typ_spr_zu` (mandant_id, werbe_typ_id, werbe_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbe_typ_id AS INT64) AS werbe_typ_id, werbe_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_werbe_typ_spr_zu`;

-- Table: DBP_DATA.WERBE_TYP_WOCHE_ZU
insert into `dbp_data.werbe_typ_woche_zu` (mandant_id, werbe_typ_id, kjwo, werbewoche, kjmo, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbe_typ_id AS INT64) AS werbe_typ_id, CAST(kjwo AS INT64) AS kjwo, CAST(werbewoche AS INT64) AS werbewoche, CAST(kjmo AS INT64) AS kjmo, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_werbe_typ_woche_zu`;

-- Table: DBP_DATA.WETTERZUSTAND_SPR_ZU
insert into `dbp_data.wetterzustand_spr_zu` (wetterzustand_id, spr_id, wetterzustand_bez, td_insert, td_update)
SELECT CAST(wetterzustand_id AS INT64) AS wetterzustand_id, CAST(spr_id AS INT64) AS spr_id, wetterzustand_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wetterzustand_spr_zu`;

-- Table: DBP_DATA.WEWA_GRUPPE_SPR_ZU
insert into `dbp_data.wewa_gruppe_spr_zu` (system_id, mandant_id, wewa_gruppe_id, spr_id, wewa_gruppe_bez, td_insert, td_update)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wewa_gruppe_id AS INT64) AS wewa_gruppe_id, CAST(spr_id AS INT64) AS spr_id, wewa_gruppe_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wewa_gruppe_spr_zu`;

-- Table: DBP_DATA.WE_MESSAGE_STATUS_SPR_ZU
insert into `dbp_data.we_message_status_spr_zu` (mandant_id, we_message_status_id, spr_id, we_message_status_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(we_message_status_id AS INT64) AS we_message_status_id, CAST(spr_id AS INT64) AS spr_id, we_message_status_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_we_message_status_spr_zu`;

-- Table: DBP_DATA.WGVGRUPPE_SPR_ZU
insert into `dbp_data.wgvgruppe_spr_zu` (wgvgrp_id, mandant_id, wup_id, nb_id, spr_id, wgvgrp_bez, td_insert, td_update)
SELECT CAST(wgvgrp_id AS INT64) AS wgvgrp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(spr_id AS INT64) AS spr_id, wgvgrp_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wgvgruppe_spr_zu`;

-- Table: DBP_DATA.WG_AUSLIEFERUNGSGRUPPE_PER
insert into `dbp_data.wg_auslieferungsgruppe_per` (mandant_id, auslieferungsgruppe_id, wg_id, sortimentslistenart_id, dat_von, dat_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, auslieferungsgruppe_id, CAST(wg_id AS INT64) AS wg_id, sortimentslistenart_id, dat_von, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wg_auslieferungsgruppe_per`;

-- Table: DBP_DATA.WG_HIERARCHIE_EBENE_SPR_ZU
insert into `dbp_data.wg_hierarchie_ebene_spr_zu` (mandant_id, arthiertyp_id, wg_hierarchie_ebene_id, spr_id, wg_hierarchie_ebene_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_hierarchie_ebene_id AS INT64) AS wg_hierarchie_ebene_id, CAST(spr_id AS INT64) AS spr_id, wg_hierarchie_ebene_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wg_hierarchie_ebene_spr_zu`;

-- Table: DBP_DATA.WG_VERKETTUNG_HIERARCHIE_ZU_PER
insert into `dbp_data.wg_verkettung_hierarchie_zu_per` (mandant_id, wup_id, nb_id, wg_verkett_id, wg_verkett_hier_id, dat_von, dat_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_verkett_id AS INT64) AS wg_verkett_id, CAST(wg_verkett_hier_id AS INT64) AS wg_verkett_hier_id, dat_von, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wg_verkettung_hierarchie_zu_per`;

-- Table: DBP_DATA.WG_VERKETTUNG_PER
insert into `dbp_data.wg_verkettung_per` (mandant_id, wup_id, nb_id, wg_verkett_id, palettenlaenge, palettenbreite, palettenhoehe, palettengroesse_einh_id, palettenvolumen, palettenvolumen_einh_id, volumenabw_max, volumen_max, volumenabw_min, pal_min_volumen, kollilaenge, kollibreite, kollihoehe, kolligroesse_einh_id, kollivolumen, kollivolumen_einh_id, akl_komm_fg, aka_komm_fg, max_volumen_aufpackpal, max_anz_pal, max_volumen_palytp_a, max_volumen_paltyp_b, klapp_pal_fg, volumengrenze_kkp, dat_von, dat_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_verkett_id AS INT64) AS wg_verkett_id, CAST(palettenlaenge AS NUMERIC) AS palettenlaenge, CAST(palettenbreite AS NUMERIC) AS palettenbreite, CAST(palettenhoehe AS NUMERIC) AS palettenhoehe, palettengroesse_einh_id, CAST(palettenvolumen AS NUMERIC) AS palettenvolumen, palettenvolumen_einh_id, CAST(volumenabw_max AS NUMERIC) AS volumenabw_max, CAST(volumen_max AS NUMERIC) AS volumen_max, CAST(volumenabw_min AS NUMERIC) AS volumenabw_min, CAST(pal_min_volumen AS NUMERIC) AS pal_min_volumen, CAST(kollilaenge AS NUMERIC) AS kollilaenge, CAST(kollibreite AS NUMERIC) AS kollibreite, CAST(kollihoehe AS NUMERIC) AS kollihoehe, kolligroesse_einh_id, CAST(kollivolumen AS NUMERIC) AS kollivolumen, kollivolumen_einh_id, CAST(akl_komm_fg AS INT64) AS akl_komm_fg, CAST(aka_komm_fg AS INT64) AS aka_komm_fg, CAST(max_volumen_aufpackpal AS NUMERIC) AS max_volumen_aufpackpal, CAST(max_anz_pal AS INT64) AS max_anz_pal, CAST(max_volumen_palytp_a AS NUMERIC) AS max_volumen_palytp_a, CAST(max_volumen_paltyp_b AS NUMERIC) AS max_volumen_paltyp_b, CAST(klapp_pal_fg AS INT64) AS klapp_pal_fg, CAST(volumengrenze_kkp AS NUMERIC) AS volumengrenze_kkp, dat_von, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wg_verkettung_per`;

-- Table: DBP_DATA.WINDRICHTUNG_MAP
insert into `dbp_data.windrichtung_map` (windrichtung_schema_id_source, windrichtung_id_source, windrichtung_schema_id_dest, windrichtung_id_dest, td_insert, td_update)
SELECT CAST(windrichtung_schema_id_source AS INT64) AS windrichtung_schema_id_source, CAST(windrichtung_id_source AS INT64) AS windrichtung_id_source, CAST(windrichtung_schema_id_dest AS INT64) AS windrichtung_schema_id_dest, CAST(windrichtung_id_dest AS INT64) AS windrichtung_id_dest, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_windrichtung_map`;

-- Table: DBP_DATA.WINDRICHTUNG_SPR_ZU
insert into `dbp_data.windrichtung_spr_zu` (windrichtung_schema_id, windrichtung_id, spr_id, windrichtung_bez_kurz, windrichtung_bez_lang, td_insert, td_update)
SELECT CAST(windrichtung_schema_id AS INT64) AS windrichtung_schema_id, CAST(windrichtung_id AS INT64) AS windrichtung_id, CAST(spr_id AS INT64) AS spr_id, windrichtung_bez_kurz, windrichtung_bez_lang, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_windrichtung_spr_zu`;

-- Table: DBP_DATA.WM
insert into `dbp_data.wm` (wm_id, mandant_id, wm_name, td_insert, td_update)
SELECT CAST(wm_id AS INT64) AS wm_id, CAST(mandant_id AS INT64) AS mandant_id, wm_name, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wm`;

-- Table: DBP_DATA.WPL_REF_ART
insert into `dbp_data.wpl_ref_art` (art_id, mandant_id, unter_art_id, td_insert, td_update)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(unter_art_id AS INT64) AS unter_art_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wpl_ref_art`;

-- Table: DBP_DATA.WTAG_SPR_ZU
insert into `dbp_data.wtag_spr_zu` (wtag_id, spr_id, wtag_bez, td_update, td_insert)
SELECT CAST(wtag_id AS INT64) AS wtag_id, CAST(spr_id AS INT64) AS spr_id, wtag_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wtag_spr_zu`;

-- Table: DBP_DATA.WUG_RESTLAUFZEIT_KUNDE_ZU
insert into `dbp_data.wug_restlaufzeit_kunde_zu` (mandant_id, einstellung_objekt, einstellung_schema, arthiertyp_id, wg_id, wug_id, mhd_zeitraum_ab, restlaufzeit_ist, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, einstellung_objekt, einstellung_schema, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, CAST(wug_id AS INT64) AS wug_id, CAST(mhd_zeitraum_ab AS INT64) AS mhd_zeitraum_ab, CAST(restlaufzeit_ist AS INT64) AS restlaufzeit_ist, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wug_restlaufzeit_kunde_zu`;

-- Table: DBP_DATA.WUP_AENDERUNG_GRUND_SPR_ZU
insert into `dbp_data.wup_aenderung_grund_spr_zu` (wup_aenderung_grund_id, spr_id, wup_aenderung_grund_bez, td_update, td_insert)
SELECT CAST(wup_aenderung_grund_id AS INT64) AS wup_aenderung_grund_id, CAST(spr_id AS INT64) AS spr_id, wup_aenderung_grund_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_aenderung_grund_spr_zu`;

-- Table: DBP_DATA.WUP_EXPANSION_PER
insert into `dbp_data.wup_expansion_per` (wup_id, nb_id, mandant_id, dat_von, expansionstyp_id, filialart_id, dat_bis, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat_von, CAST(expansionstyp_id AS INT64) AS expansionstyp_id, CAST(filialart_id AS INT64) AS filialart_id, dat_bis, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_expansion_per`;

-- Table: DBP_DATA.WUP_GRP
insert into `dbp_data.wup_grp` (wupgrp_id, wupgrp_bez, wupgrptyp_id, td_insert, td_update)
SELECT CAST(wupgrp_id AS INT64) AS wupgrp_id, wupgrp_bez, CAST(wupgrptyp_id AS INT64) AS wupgrptyp_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_grp`;

-- Table: DBP_DATA.WUP_GRP_ZU
insert into `dbp_data.wup_grp_zu` (wup_id, mandant_id, nb_id, wupgrp_id, referenziert, referenzierend, td_insert, td_update)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wupgrp_id AS INT64) AS wupgrp_id, CAST(referenziert AS INT64) AS referenziert, CAST(referenzierend AS INT64) AS referenzierend, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_grp_zu`;

-- Table: DBP_DATA.WUP_INSTANZ_AUTODISPO
insert into `dbp_data.wup_instanz_autodispo` (mandant_id, wup_id, nb_id, instanz, dat_von, modus, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, instanz, dat_von, modus, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_instanz_autodispo`;

-- Table: DBP_DATA.WUP_OEFFNUNG_TYP_SPR_ZU
insert into `dbp_data.wup_oeffnung_typ_spr_zu` (mandant_id, wup_oeffnungs_typ_id, spr_id, wup_oeffnungs_typ_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_oeffnungs_typ_id AS INT64) AS wup_oeffnungs_typ_id, CAST(spr_id AS INT64) AS spr_id, wup_oeffnungs_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_oeffnung_typ_spr_zu`;

-- Table: DBP_DATA.WUP_STUNDEN_TAG_MD
insert into `dbp_data.wup_stunden_tag_md` (wup_id, nb_id, mandant_id, dat, stunden_markt, stunden_sonstige, stunden_plan, stunden_co5_sonstige, ums_netto_plan, ums_netto_plan_man, wrg_id, stunden_sonstige_plan, stunden_co1_iks, stunden_co2_ea, stunden_co3_anue, stunden_co4_reinigung, stunden_plan_pep, stunden_plan_meldeschluss_plus1, ums_netto_plan_man_meldeschluss_plus2, stunden_co_ist, stunden_co_plan, stunden_plan_meldeschluss_plus2, ums_netto_plan_man_meldeschluss_plus1, stunden_co_plan_plus1, stunden_co_plan_plus2, stunden_sonstige_plan_plus1, stunden_sonstige_plan_plus2, td_insert, td_update, stunden_versetzung)
SELECT CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(mandant_id AS INT64) AS mandant_id, dat, CAST(stunden_markt AS NUMERIC) AS stunden_markt, CAST(stunden_sonstige AS NUMERIC) AS stunden_sonstige, CAST(stunden_plan AS NUMERIC) AS stunden_plan, CAST(stunden_co5_sonstige AS NUMERIC) AS stunden_co5_sonstige, CAST(ums_netto_plan AS NUMERIC) AS ums_netto_plan, CAST(ums_netto_plan_man AS NUMERIC) AS ums_netto_plan_man, wrg_id, CAST(stunden_sonstige_plan AS NUMERIC) AS stunden_sonstige_plan, CAST(stunden_co1_iks AS NUMERIC) AS stunden_co1_iks, CAST(stunden_co2_ea AS NUMERIC) AS stunden_co2_ea, CAST(stunden_co3_anue AS NUMERIC) AS stunden_co3_anue, CAST(stunden_co4_reinigung AS NUMERIC) AS stunden_co4_reinigung, CAST(stunden_plan_pep AS NUMERIC) AS stunden_plan_pep, CAST(stunden_plan_meldeschluss_plus1 AS NUMERIC) AS stunden_plan_meldeschluss_plus1, CAST(ums_netto_plan_man_meldeschluss_plus2 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus2, CAST(stunden_co_ist AS NUMERIC) AS stunden_co_ist, CAST(stunden_co_plan AS NUMERIC) AS stunden_co_plan, CAST(stunden_plan_meldeschluss_plus2 AS NUMERIC) AS stunden_plan_meldeschluss_plus2, CAST(ums_netto_plan_man_meldeschluss_plus1 AS NUMERIC) AS ums_netto_plan_man_meldeschluss_plus1, CAST(stunden_co_plan_plus1 AS NUMERIC) AS stunden_co_plan_plus1, CAST(stunden_co_plan_plus2 AS NUMERIC) AS stunden_co_plan_plus2, CAST(stunden_sonstige_plan_plus1 AS NUMERIC) AS stunden_sonstige_plan_plus1, CAST(stunden_sonstige_plan_plus2 AS NUMERIC) AS stunden_sonstige_plan_plus2, td_insert, td_update, CAST(stunden_versetzung AS NUMERIC) AS stunden_versetzung
FROM `snowflake_snapshots.kfl_dbp_data_wup_stunden_tag_md`;

-- Table: DBP_DATA.WUP_TYP
insert into `dbp_data.wup_typ` (wup_typ_id, wup_typ_bez, td_insert, td_update)
SELECT CAST(wup_typ_id AS INT64) AS wup_typ_id, wup_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_wup_typ`;

-- Table: DBP_DATA.WUP_WG_VERKETTUNG_HIERARCHIE_PER
insert into `dbp_data.wup_wg_verkettung_hierarchie_per` (mandant_id, wup_id, nb_id, wg_verkett_hier_id, palettenlaenge, palettenbreite, palettenhoehe, palettengroesse_einh_id, palettenvolumen, palettenvolumen_einh_id, volumenabw_max, volumen_max, akl_komm_fg, klapp_pal_fg, volumengrenze_kkp, dat_von, dat_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wg_verkett_hier_id AS INT64) AS wg_verkett_hier_id, CAST(palettenlaenge AS NUMERIC) AS palettenlaenge, CAST(palettenbreite AS NUMERIC) AS palettenbreite, CAST(palettenhoehe AS NUMERIC) AS palettenhoehe, palettengroesse_einh_id, CAST(palettenvolumen AS NUMERIC) AS palettenvolumen, palettenvolumen_einh_id, CAST(volumenabw_max AS NUMERIC) AS volumenabw_max, CAST(volumen_max AS NUMERIC) AS volumen_max, CAST(akl_komm_fg AS INT64) AS akl_komm_fg, CAST(klapp_pal_fg AS INT64) AS klapp_pal_fg, CAST(volumengrenze_kkp AS NUMERIC) AS volumengrenze_kkp, dat_von, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_wup_wg_verkettung_hierarchie_per`;

-- Table: DBP_DATA.ZAEHL_GRUND_SPR_ZU
insert into `dbp_data.zaehl_grund_spr_zu` (mandant_id, zaehl_grund_id, spr_id, zaehl_grund_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zaehl_grund_id, CAST(spr_id AS INT64) AS spr_id, zaehl_grund_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_zaehl_grund_spr_zu`;

-- Table: DBP_DATA.ZAHLART_SPR_ZU
insert into `dbp_data.zahlart_spr_zu` (system_id, mandant_id, zahlart_id, spr_id, zahlart_bez, td_update, td_insert)
SELECT CAST(system_id AS INT64) AS system_id, CAST(mandant_id AS INT64) AS mandant_id, zahlart_id, CAST(spr_id AS INT64) AS spr_id, zahlart_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_data_zahlart_spr_zu`;

-- Table: DBP_DATA.ZEITFENSTER_SPR_ZU
insert into `dbp_data.zeitfenster_spr_zu` (mandant_id, zeitfenster_id, spr_id, zeitfenster_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(zeitfenster_id AS INT64) AS zeitfenster_id, CAST(spr_id AS INT64) AS spr_id, zeitfenster_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_zeitfenster_spr_zu`;

-- Table: DBP_DATA.ZUSTELLART_SPR_ZU
insert into `dbp_data.zustellart_spr_zu` (mandant_id, zustellart_id, spr_id, zustellart_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zustellart_id, CAST(spr_id AS INT64) AS spr_id, zustellart_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_data_zustellart_spr_zu`;

-- Table: DBP_DIALOG.D_L_GEKU_BEREICH
insert into `dbp_dialog.d_l_geku_bereich` (geku_bereich_uid, wmd_fg, kdc_fg, mzk_fg)
SELECT CAST(geku_bereich_uid AS INT64) AS geku_bereich_uid, CAST(wmd_fg AS INT64) AS wmd_fg, CAST(kdc_fg AS INT64) AS kdc_fg, CAST(mzk_fg AS INT64) AS mzk_fg
FROM `snowflake_snapshots.kfl_dbp_dialog_d_l_geku_bereich`;

-- Table: DBP_DIALOG.D_L_MP
insert into `dbp_dialog.d_l_mp` (mp_id, mandant_id, mp_schranke)
SELECT CAST(mp_id AS INT64) AS mp_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(mp_schranke AS INT64) AS mp_schranke
FROM `snowflake_snapshots.kfl_dbp_dialog_d_l_mp`;

-- Table: DBP_DIALOG.D_MP_MP_VAR_ZU
insert into `dbp_dialog.d_mp_mp_var_zu` (mandant_id, mp_id, mp_var_id, mp_sub_var_id, mp_var_val, mp_var_bez)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(mp_id AS INT64) AS mp_id, CAST(mp_var_id AS INT64) AS mp_var_id, CAST(mp_sub_var_id AS INT64) AS mp_sub_var_id, CAST(mp_var_val AS NUMERIC) AS mp_var_val, mp_var_bez
FROM `snowflake_snapshots.kfl_dbp_dialog_d_mp_mp_var_zu`;

-- Table: DBP_ETL_PROCESS.MARKANT_TAGE_DISPO_MAP
insert into `dbp_etl_process.markant_tage_dispo_map` (anz_arbeitstage, anz_kalendertage_mo, anz_kalendertage_di, anz_kalendertage_mi, anz_kalendertage_do, anz_kalendertage_fr, td_update, td_insert)
SELECT CAST(anz_arbeitstage AS INT64) AS anz_arbeitstage, CAST(anz_kalendertage_mo AS INT64) AS anz_kalendertage_mo, CAST(anz_kalendertage_di AS INT64) AS anz_kalendertage_di, CAST(anz_kalendertage_mi AS INT64) AS anz_kalendertage_mi, CAST(anz_kalendertage_do AS INT64) AS anz_kalendertage_do, CAST(anz_kalendertage_fr AS INT64) AS anz_kalendertage_fr, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_markant_tage_dispo_map`;

-- Table: DBP_ETL_PROCESS.PEP_INT_KPI_WG_ABT_ZU
insert into `dbp_etl_process.pep_int_kpi_wg_abt_zu` (mandant_id, wg_id, arthiertyp_id, pep_kpi_kz, dayforce_abt_bez, pep_kpi_bez, aktiv_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, pep_kpi_kz, dayforce_abt_bez, pep_kpi_bez, CAST(aktiv_fg AS INT64) AS aktiv_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_pep_int_kpi_wg_abt_zu`;

-- Table: DBP_ETL_PROCESS.PEP_KPI_WG_ABT_ZU
insert into `dbp_etl_process.pep_kpi_wg_abt_zu` (mandant_id, arthiertyp_id, wg_id, pep_kpi_id, dayforce_abt_bez, pep_kpi_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(wg_id AS INT64) AS wg_id, CAST(pep_kpi_id AS INT64) AS pep_kpi_id, dayforce_abt_bez, pep_kpi_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_pep_kpi_wg_abt_zu`;

-- Table: DBP_ETL_PROCESS.REPLIKATION_HADOOP_DAT
insert into `dbp_etl_process.replikation_hadoop_dat` (mandant_id, dat, zieltabelle_bez, replikation_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat, zieltabelle_bez, replikation_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_replikation_hadoop_dat`;

-- Table: DBP_ETL_PROCESS.ROHERTRAG_MAN
insert into `dbp_etl_process.rohertrag_man` (mandant_id, wup_id, nb_id, kjmo, rohertrag_ist, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(rohertrag_ist AS NUMERIC) AS rohertrag_ist, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_rohertrag_man`;

-- Table: DBP_ETL_PROCESS.TEKU_MARKT_KEIN_BERICHT
insert into `dbp_etl_process.teku_markt_kein_bericht` (mandant_id, wup_id, kein_bericht_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, kein_bericht_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_teku_markt_kein_bericht`;

-- Table: DBP_ETL_PROCESS.TRG_ARTBEW
insert into `dbp_etl_process.trg_artbew` (mandant_id, datzeit_aenderung, dat, trg_action, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(datzeit_aenderung AS DATETIME) AS datzeit_aenderung, dat, CAST(trg_action AS INT64) AS trg_action, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_trg_artbew`;

-- Table: DBP_ETL_PROCESS.VIS_MONAT_SHR_WUP_KENNZAHL_MAP
insert into `dbp_etl_process.vis_monat_shr_wup_kennzahl_map` (mandant_id, shr_kennzahl, lohnart_id, kjmo_bis, kjmo_von, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, shr_kennzahl, lohnart_id, CAST(kjmo_bis AS INT64) AS kjmo_bis, CAST(kjmo_von AS INT64) AS kjmo_von, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_vis_monat_shr_wup_kennzahl_map`;

-- Table: DBP_ETL_PROCESS.WUP_TAG_WBS_SETTING
insert into `dbp_etl_process.wup_tag_wbs_setting` (mandant_id, wup_id, nb_id, dat, non_adjustable_day_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, CAST(non_adjustable_day_fg AS INT64) AS non_adjustable_day_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_wup_tag_wbs_setting`;

-- Table: DBP_ETL_PROCESS.ZSKMDCLCUWERKS
insert into `dbp_etl_process.zskmdclcuwerks` (mandt, mtart, werks, td_update, td_insert)
SELECT mandt, mtart, werks, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_etl_process_zskmdclcuwerks`;

-- Table: DBP_MSI_DATA.ALTERSSTRUKTUR_EIS
insert into `dbp_msi_data.altersstruktur_eis` (altersstruktur_tag_id, altersstruktur_woche_id, altersstruktur_monat_id, mandant_id, wup_id, nb_id, td_insert, td_update)
SELECT CAST(altersstruktur_tag_id AS INT64) AS altersstruktur_tag_id, CAST(altersstruktur_woche_id AS INT64) AS altersstruktur_woche_id, CAST(altersstruktur_monat_id AS INT64) AS altersstruktur_monat_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_altersstruktur_eis`;

-- Table: DBP_MSI_DATA.BERICHTS_POS_ANL_KLS_ZU_PER
insert into `dbp_msi_data.berichts_pos_anl_kls_zu_per` (mandant_id, anlage_klasse_id, dat_von, dat_bis, ma_ldap, berichts_position_invest_id, berichts_position_it_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, anlage_klasse_id, dat_von, dat_bis, ma_ldap, CAST(berichts_position_invest_id AS INT64) AS berichts_position_invest_id, CAST(berichts_position_it_id AS INT64) AS berichts_position_it_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_berichts_pos_anl_kls_zu_per`;

-- Table: DBP_MSI_DATA.BERICHTS_POS_KOSTART_ZU_PER
insert into `dbp_msi_data.berichts_pos_kostart_zu_per` (mandant_id, kostenart_id, krk_id, dat_von, dat_bis, ma_ldap, berichts_position_invest_id, berichts_position_it_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, kostenart_id, krk_id, dat_von, dat_bis, ma_ldap, CAST(berichts_position_invest_id AS INT64) AS berichts_position_invest_id, CAST(berichts_position_it_id AS INT64) AS berichts_position_it_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_berichts_pos_kostart_zu_per`;

-- Table: DBP_MSI_DATA.FIPO_WEBSERVICE_URL
insert into `dbp_msi_data.fipo_webservice_url` (fipo_anlage_url, td_insert, td_update)
SELECT fipo_anlage_url, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_fipo_webservice_url`;

-- Table: DBP_MSI_DATA.GINFO_GRP_AUSSEN_FLAECHEN
insert into `dbp_msi_data.ginfo_grp_aussen_flaechen` (grp_1_id, grp_2_id, grp_3_id, grp_4_id, kaufland_typ_id, flaeche_attribut_id, quelle_beauftragung, td_insert, td_update)
SELECT CAST(grp_1_id AS INT64) AS grp_1_id, CAST(grp_2_id AS INT64) AS grp_2_id, CAST(grp_3_id AS INT64) AS grp_3_id, CAST(grp_4_id AS INT64) AS grp_4_id, kaufland_typ_id, CAST(flaeche_attribut_id AS INT64) AS flaeche_attribut_id, CAST(quelle_beauftragung AS INT64) AS quelle_beauftragung, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ginfo_grp_aussen_flaechen`;

-- Table: DBP_MSI_DATA.HERSTELLERWISSEN
insert into `dbp_msi_data.herstellerwissen` (mandant_id, gp_id, dat_zeit_pflege, dat_pflege, h452_herstellerwissen, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(gp_id AS INT64) AS gp_id, dat_zeit_pflege, dat_pflege, h452_herstellerwissen, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_herstellerwissen`;

-- Table: DBP_MSI_DATA.IOS_DATENFREIGABE_IME
insert into `dbp_msi_data.ios_datenfreigabe_ime` (user_id, ime_fg, td_insert, td_update)
SELECT user_id, CAST(ime_fg AS INT64) AS ime_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ios_datenfreigabe_ime`;

-- Table: DBP_MSI_DATA.KFL_RETAIL_STORE_MO_SUM
insert into `dbp_msi_data.kfl_retail_store_mo_sum` (mandant_id, wup_id, nb_id, kjmo, anz_review_rating, sum_review_rating, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kjmo AS INT64) AS kjmo, CAST(anz_review_rating AS INT64) AS anz_review_rating, CAST(sum_review_rating AS NUMERIC) AS sum_review_rating, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_kfl_retail_store_mo_sum`;

-- Table: DBP_MSI_DATA.KL_GESAMT
insert into `dbp_msi_data.kl_gesamt` (kl_gesamt_bez, kl_id, td_insert, td_update)
SELECT kl_gesamt_bez, CAST(kl_id AS INT64) AS kl_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_kl_gesamt`;

-- Table: DBP_MSI_DATA.LIEFERANTENWISSEN
insert into `dbp_msi_data.lieferantenwissen` (mandant_id, lieferant, dat_zeit_pflege, dat_pflege, c410_lieferantenwissen, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lieferant, dat_zeit_pflege, dat_pflege, c410_lieferantenwissen, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_lieferantenwissen`;

-- Table: DBP_MSI_DATA.LIN_DATENFREIGABE
insert into `dbp_msi_data.lin_datenfreigabe` (mandant_id, kjmo, vertrieb_fg, user_id, zeitstempel, lin_freigabe_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(vertrieb_fg AS INT64) AS vertrieb_fg, user_id, zeitstempel, CAST(lin_freigabe_fg AS INT64) AS lin_freigabe_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_lin_datenfreigabe`;

-- Table: DBP_MSI_DATA.L_BON_WUP
insert into `dbp_msi_data.l_bon_wup` (mandant_id, wup_id, bda_anym_fg, gesperrt_fg, dat, user_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(bda_anym_fg AS INT64) AS bda_anym_fg, CAST(gesperrt_fg AS INT64) AS gesperrt_fg, dat, user_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_bon_wup`;

-- Table: DBP_MSI_DATA.L_GINFO_GRP
insert into `dbp_msi_data.l_ginfo_grp` (grp_id, ebene_id, grp_bez, td_insert, td_update)
SELECT CAST(grp_id AS INT64) AS grp_id, CAST(ebene_id AS INT64) AS ebene_id, grp_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_ginfo_grp`;

-- Table: DBP_MSI_DATA.L_KMR_SECURITY
insert into `dbp_msi_data.l_kmr_security` (sec_kz, sec_bez, td_insert, td_update)
SELECT CAST(sec_kz AS INT64) AS sec_kz, sec_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_kmr_security`;

-- Table: DBP_MSI_DATA.L_KOSTENRECHNUNG_TYP
insert into `dbp_msi_data.l_kostenrechnung_typ` (kostenrechnung_typ_id, spr_id, kostenrechnung_typ_bez, td_insert, td_update)
SELECT CAST(kostenrechnung_typ_id AS INT64) AS kostenrechnung_typ_id, CAST(spr_id AS INT64) AS spr_id, kostenrechnung_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_kostenrechnung_typ`;

-- Table: DBP_MSI_DATA.L_MK_WUP
insert into `dbp_msi_data.l_mk_wup` (mandant_id, wup_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_mk_wup`;

-- Table: DBP_MSI_DATA.L_TEKU_ATTRIBUT
insert into `dbp_msi_data.l_teku_attribut` (teku_attribut_id, spr_id, teku_attribut_bez, td_insert, td_update)
SELECT CAST(teku_attribut_id AS INT64) AS teku_attribut_id, CAST(spr_id AS INT64) AS spr_id, teku_attribut_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_l_teku_attribut`;

-- Table: DBP_MSI_DATA.MIS_LIEFERQUOTE
insert into `dbp_msi_data.mis_lieferquote` (mandant_id, lieferquote, datenquote, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lieferquote AS NUMERIC) AS lieferquote, CAST(datenquote AS NUMERIC) AS datenquote, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_mis_lieferquote`;

-- Table: DBP_MSI_DATA.PROBLEMMELDUNG_RFI
insert into `dbp_msi_data.problemmeldung_rfi` (country_code, prmsgid, wrbtr, wmwst, werks, waers, srcpos, srcdoc, srcdgj, shkzg, rmwwr, rfi_date, resuser, sub_destination, request_id, record_no, logsys, delete_date, time_stamp_create, procarea, prmsgtst, prcode, object5, object4, object3, object2, object1, matnr, logtst, lifnr, lfpos, kreditor, impnr, gjahr, freigabe, fnpm_seq_id, fieldval5, fieldval4, fieldval3, fieldval2, fieldval1, exrgnr, ekgrp, edinum, ecmproc, severity, record_disposition, issue_count, dq_issue_test_guid, dq_issue_replacement_value, dq_issue_issue_details, dq_issue_issue_code, dq_issue_field_value_code, dq_issue_field_value, dq_issue_field_name, dq_issue_disposition, docclass, delflag, cruser, causer, bldat, belpos, belnr, autoflag, td_insert, td_update)
SELECT country_code, prmsgid, CAST(wrbtr AS NUMERIC) AS wrbtr, CAST(wmwst AS NUMERIC) AS wmwst, werks, waers, CAST(srcpos AS INT64) AS srcpos, srcdoc, CAST(srcdgj AS INT64) AS srcdgj, shkzg, CAST(rmwwr AS NUMERIC) AS rmwwr, rfi_date, resuser, sub_destination, request_id, CAST(record_no AS INT64) AS record_no, logsys, delete_date, time_stamp_create, procarea, CAST(prmsgtst AS INT64) AS prmsgtst, prcode, object5, object4, object3, object2, object1, matnr, CAST(logtst AS INT64) AS logtst, lifnr, CAST(lfpos AS INT64) AS lfpos, kreditor, impnr, CAST(gjahr AS INT64) AS gjahr, freigabe, CAST(fnpm_seq_id AS INT64) AS fnpm_seq_id, fieldval5, fieldval4, fieldval3, fieldval2, fieldval1, exrgnr, ekgrp, CAST(edinum AS INT64) AS edinum, CAST(ecmproc AS INT64) AS ecmproc, CAST(severity AS INT64) AS severity, record_disposition, CAST(issue_count AS INT64) AS issue_count, dq_issue_test_guid, dq_issue_replacement_value, dq_issue_issue_details, dq_issue_issue_code, CAST(dq_issue_field_value_code AS INT64) AS dq_issue_field_value_code, dq_issue_field_value, dq_issue_field_name, dq_issue_disposition, docclass, delflag, cruser, causer, bldat, CAST(belpos AS INT64) AS belpos, belnr, autoflag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_problemmeldung_rfi`;

-- Table: DBP_MSI_DATA.PRODUKTWISSEN
insert into `dbp_msi_data.produktwissen` (mandant_id, matching_id, dat_zeit_pflege, dat_pflege, f49_produktwissen, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(matching_id AS INT64) AS matching_id, dat_zeit_pflege, dat_pflege, f49_produktwissen, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_produktwissen`;

-- Table: DBP_MSI_DATA.SHR_DATENFREIGABE
insert into `dbp_msi_data.shr_datenfreigabe` (mandant_id, kjmo, dat, nat_int_fg, user_id, freigabe_uhrzeit, shr_freigabe_fg, dat_freigabe_kennzahlen, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, dat, CAST(nat_int_fg AS INT64) AS nat_int_fg, user_id, CAST(freigabe_uhrzeit AS INT64) AS freigabe_uhrzeit, CAST(shr_freigabe_fg AS INT64) AS shr_freigabe_fg, dat_freigabe_kennzahlen, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_shr_datenfreigabe`;

-- Table: DBP_MSI_DATA.SORTIMENT_ART_ERWARTET
insert into `dbp_msi_data.sortiment_art_erwartet` (mandant_id, matching_id, kjmo, kjwo_update, listung_sst_pflege, art_id, gtin, stk_re_pflege, status, region_summary, var_ost_basis_pflege, var_ost_gross_pflege, var_sued_ost_pflege, var_sued_west_pflege, var_west_pflege, var_nord_pflege, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(matching_id AS INT64) AS matching_id, CAST(kjmo AS INT64) AS kjmo, CAST(kjwo_update AS INT64) AS kjwo_update, CAST(listung_sst_pflege AS INT64) AS listung_sst_pflege, CAST(art_id AS INT64) AS art_id, gtin, CAST(stk_re_pflege AS NUMERIC) AS stk_re_pflege, status, CAST(region_summary AS INT64) AS region_summary, var_ost_basis_pflege, var_ost_gross_pflege, var_sued_ost_pflege, var_sued_west_pflege, var_west_pflege, var_nord_pflege, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_sortiment_art_erwartet`;

-- Table: DBP_MSI_DATA.STATUSMELDUNG_RFI
insert into `dbp_msi_data.statusmeldung_rfi` (country_code, statusid, wmwst, waers, status, statmsgtst, srcpos, srcdoc, srcdgj, srcdest, shkzg, rmwwr, rfi_date, sub_destination, request_id, record_no, logsys, delete_date, time_stamp_create, logtst, lifnr, kreditor, impnr, gjahr, freigabe, fnpm_seq_id, edinum, ecmproc, severity, record_disposition, issue_count, dq_issue_test_guid, dq_issue_replacement_value, dq_issue_issue_details, dq_issue_issue_code, dq_issue_field_value_code, dq_issue_field_value, dq_issue_field_name, dq_issue_disposition, docclass, cruser, belnr, autoflag, td_insert, td_update)
SELECT country_code, statusid, CAST(wmwst AS NUMERIC) AS wmwst, waers, CAST(status AS INT64) AS status, CAST(statmsgtst AS INT64) AS statmsgtst, CAST(srcpos AS INT64) AS srcpos, srcdoc, CAST(srcdgj AS INT64) AS srcdgj, srcdest, shkzg, CAST(rmwwr AS NUMERIC) AS rmwwr, rfi_date, sub_destination, request_id, CAST(record_no AS INT64) AS record_no, logsys, delete_date, time_stamp_create, CAST(logtst AS INT64) AS logtst, lifnr, kreditor, impnr, CAST(gjahr AS INT64) AS gjahr, freigabe, CAST(fnpm_seq_id AS INT64) AS fnpm_seq_id, CAST(edinum AS INT64) AS edinum, CAST(ecmproc AS INT64) AS ecmproc, CAST(severity AS INT64) AS severity, record_disposition, CAST(issue_count AS INT64) AS issue_count, dq_issue_test_guid, dq_issue_replacement_value, dq_issue_issue_details, dq_issue_issue_code, CAST(dq_issue_field_value_code AS INT64) AS dq_issue_field_value_code, dq_issue_field_value, dq_issue_field_name, dq_issue_disposition, docclass, cruser, belnr, autoflag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_statusmeldung_rfi`;

-- Table: DBP_MSI_DATA.TEMP_INNOVATION_LIDL_DIGITAL
insert into `dbp_msi_data.temp_innovation_lidl_digital` (innovationsthema, sparte, bereich, innovationsbeschreibung, prozessoptimierung, kosteneinsparung, umsatzsteigerung, kundenbindung, differenzierung, neutralisierung, qualitaetsverbesserung, mitarbeitermotivation, kuenstlicheintelligenz, prozessautomatisierung, bigdata_ki, blockchain, digitale_oekosysteme, cloudcomputing, cybersicherheit, robotik, vr, iot, weiteretechnologien, akt_reifegrad, ukri_diff, ukri_ndiff, nukri_diff, nukri_ndiff, meilenstein1, meilenstein1_ende, meilenstein2, meilenstein2_ende, meilenstein3, meilenstein3_ende, meilenstein4, meilenstein4_ende, meilenstein5, meilenstein5_ende, interneraufwand, inv_abteilungen, externepartner, kosten_externe_partner, alibaba, apple, baidu, cisco, facebook, fujitsu, google, samsung, huawei, ibm_, microsoft, oracle, panasonic, salesforce, sap, siemens, tencent, toshiba, weiterepartner, kommentar, td_update, td_insert)
SELECT innovationsthema, sparte, bereich, innovationsbeschreibung, prozessoptimierung, kosteneinsparung, umsatzsteigerung, kundenbindung, differenzierung, neutralisierung, qualitaetsverbesserung, mitarbeitermotivation, kuenstlicheintelligenz, prozessautomatisierung, bigdata_ki, blockchain, digitale_oekosysteme, cloudcomputing, cybersicherheit, robotik, vr, iot, weiteretechnologien, akt_reifegrad, ukri_diff, ukri_ndiff, nukri_diff, nukri_ndiff, meilenstein1, meilenstein1_ende, meilenstein2, meilenstein2_ende, meilenstein3, meilenstein3_ende, meilenstein4, meilenstein4_ende, meilenstein5, meilenstein5_ende, interneraufwand, inv_abteilungen, externepartner, kosten_externe_partner, alibaba, apple, baidu, cisco, facebook, fujitsu, google, samsung, huawei, ibm_, microsoft, oracle, panasonic, salesforce, sap, siemens, tencent, toshiba, weiterepartner, kommentar, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_temp_innovation_lidl_digital`;

-- Table: DBP_MSI_DATA.TS_AAD_REQUEST_RECEIPT_ZU
insert into `dbp_msi_data.ts_aad_request_receipt_zu` (bon_id, bon_dat, wup_id, mandant_id, aad_request_id, td_update, td_insert)
SELECT bon_id, bon_dat, CAST(wup_id AS INT64) AS wup_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(aad_request_id AS INT64) AS aad_request_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_aad_request_receipt_zu`;

-- Table: DBP_MSI_DATA.TS_AAD_REQUEST_WORKFLOW
insert into `dbp_msi_data.ts_aad_request_workflow` (aad_request_id, mandant_id, dwh_created_tmsp, creation_reason_comment_txt, wup_id, creator_user_id, request_type_id, hashed_cashier_id, request_status_type_id, fraud_value_gross_local_val, wrg_id, expiration_tmsp, scenario_id, scenario_hit_receipts_cnt, request_reason_type_id, comment_txt, first_approver_user_id, second_approver_user_id, approve_by_council_fg, criminal_complain_fg, taken_measure_comment_txt, loss_amount_gross_local_val, td_update, td_insert)
SELECT CAST(aad_request_id AS INT64) AS aad_request_id, CAST(mandant_id AS INT64) AS mandant_id, dwh_created_tmsp, creation_reason_comment_txt, CAST(wup_id AS INT64) AS wup_id, creator_user_id, CAST(request_type_id AS INT64) AS request_type_id, hashed_cashier_id, CAST(request_status_type_id AS INT64) AS request_status_type_id, CAST(fraud_value_gross_local_val AS NUMERIC) AS fraud_value_gross_local_val, wrg_id, expiration_tmsp, CAST(scenario_id AS INT64) AS scenario_id, CAST(scenario_hit_receipts_cnt AS INT64) AS scenario_hit_receipts_cnt, CAST(request_reason_type_id AS INT64) AS request_reason_type_id, comment_txt, first_approver_user_id, second_approver_user_id, CAST(approve_by_council_fg AS INT64) AS approve_by_council_fg, CAST(criminal_complain_fg AS INT64) AS criminal_complain_fg, taken_measure_comment_txt, CAST(loss_amount_gross_local_val AS NUMERIC) AS loss_amount_gross_local_val, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_aad_request_workflow`;

-- Table: DBP_MSI_DATA.TS_AAD_THRESHOLD_WORKFLOW
insert into `dbp_msi_data.ts_aad_threshold_workflow` (threshold_request_id, dwh_created_tmsp, mandant_id, region_id, scenario_id, scenario_metric_id, creator_user_id, scenario_metric_threshold_init_val, scenario_metric_user_val, request_status_type_id, creation_reason_comment_txt, approver_comment_txt, expiration_tmsp, td_update, td_insert)
SELECT CAST(threshold_request_id AS INT64) AS threshold_request_id, dwh_created_tmsp, CAST(mandant_id AS INT64) AS mandant_id, CAST(region_id AS INT64) AS region_id, CAST(scenario_id AS INT64) AS scenario_id, CAST(scenario_metric_id AS INT64) AS scenario_metric_id, creator_user_id, CAST(scenario_metric_threshold_init_val AS NUMERIC) AS scenario_metric_threshold_init_val, CAST(scenario_metric_user_val AS NUMERIC) AS scenario_metric_user_val, CAST(request_status_type_id AS INT64) AS request_status_type_id, creation_reason_comment_txt, approver_comment_txt, expiration_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_aad_threshold_workflow`;

-- Table: DBP_MSI_DATA.TS_KMR_MANDANT_UNTER_KATEGORIE_AUSSCHLUSS
insert into `dbp_msi_data.ts_kmr_mandant_unter_kategorie_ausschluss` (mandant_id, kmr_unter_kategorie_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kmr_unter_kategorie_id AS INT64) AS kmr_unter_kategorie_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_kmr_mandant_unter_kategorie_ausschluss`;

-- Table: DBP_MSI_DATA.TS_KMR_USER_SEC_KZ_ZU
insert into `dbp_msi_data.ts_kmr_user_sec_kz_zu` (user_id, sec_kz)
SELECT user_id, CAST(sec_kz AS INT64) AS sec_kz
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_kmr_user_sec_kz_zu`;

-- Table: DBP_MSI_DATA.TS_LAGERNUMMER_SORTIERUNG_SCM
insert into `dbp_msi_data.ts_lagernummer_sortierung_scm` (mandant_id, lagernummer_id, wup_id, nb_id, lagersortiment_id, artikelsortiment_id, lagernummer_sortierung_scm_id, lagernummer_sortierung_scm_bez, dat_pflege_layout, dat_tms_wanko, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, lagersortiment_id, artikelsortiment_id, lagernummer_sortierung_scm_id, lagernummer_sortierung_scm_bez, dat_pflege_layout, dat_tms_wanko, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_lagernummer_sortierung_scm`;

-- Table: DBP_MSI_DATA.TS_LAGERORT_EWM_DAT
insert into `dbp_msi_data.ts_lagerort_ewm_dat` (mandant_id, lagerort_id, lagernummer_id, wup_id, nb_id, dat, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagerort_id, lagernummer_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_lagerort_ewm_dat`;

-- Table: DBP_MSI_DATA.TS_LIN_GF_ORG_EBENE_ZU
insert into `dbp_msi_data.ts_lin_gf_org_ebene_zu` (user_id, hr_objekt_ebene2_id, hr_objekt_ebene3_id, hr_objekt_ebene4_id, td_update, td_insert)
SELECT user_id, CAST(hr_objekt_ebene2_id AS INT64) AS hr_objekt_ebene2_id, CAST(hr_objekt_ebene3_id AS INT64) AS hr_objekt_ebene3_id, CAST(hr_objekt_ebene4_id AS INT64) AS hr_objekt_ebene4_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_lin_gf_org_ebene_zu`;

-- Table: DBP_MSI_DATA.TS_L_BESCHAFFUNGSREGION
insert into `dbp_msi_data.ts_l_beschaffungsregion` (besch_region_id, besch_region_bez, td_update, td_insert)
SELECT CAST(besch_region_id AS INT64) AS besch_region_id, besch_region_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_l_beschaffungsregion`;

-- Table: DBP_MSI_DATA.TS_L_STELLPLATZKATEGORIE
insert into `dbp_msi_data.ts_l_stellplatzkategorie` (sammel_ladung_fg, anz_stellplatz_von, anz_stellplatz_bis, stellplatzkategorie, td_update, td_insert)
SELECT CAST(sammel_ladung_fg AS INT64) AS sammel_ladung_fg, CAST(anz_stellplatz_von AS INT64) AS anz_stellplatz_von, CAST(anz_stellplatz_bis AS INT64) AS anz_stellplatz_bis, stellplatzkategorie, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_l_stellplatzkategorie`;

-- Table: DBP_MSI_DATA.TS_ROHSTOFF_MONITORING_ANZEIGE
insert into `dbp_msi_data.ts_rohstoff_monitoring_anzeige` (rohstoff_nr, rohstoff_kategorie_kfl_name, rohstoff_kfl_bez, rohstoff_subkategorie_kfl_name, rohstoff_blend_kfl_txt, rohstoff_qualitaet_txt, rohstoff_quell_bez, rohstoff_cluster_id, dat_anzeige_von, dat_anzeige_bis, td_update, td_insert)
SELECT rohstoff_nr, rohstoff_kategorie_kfl_name, rohstoff_kfl_bez, rohstoff_subkategorie_kfl_name, rohstoff_blend_kfl_txt, rohstoff_qualitaet_txt, rohstoff_quell_bez, CAST(rohstoff_cluster_id AS INT64) AS rohstoff_cluster_id, dat_anzeige_von, dat_anzeige_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_rohstoff_monitoring_anzeige`;

-- Table: DBP_MSI_DATA.TS_SCM_CLUSTER
insert into `dbp_msi_data.ts_scm_cluster` (zeit_von, zeit_bis, wert_von, wert_bis, td_update, td_insert)
SELECT zeit_von, zeit_bis, CAST(wert_von AS BIGNUMERIC) AS wert_von, CAST(wert_bis AS BIGNUMERIC) AS wert_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_scm_cluster`;

-- Table: DBP_MSI_DATA.TS_WARENBEWERTUNG_ABSCHLUSS_BELADUNG
insert into `dbp_msi_data.ts_warenbewertung_abschluss_beladung` (mandant_id, dat_aenderung, job_start_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dat_aenderung, CAST(job_start_fg AS INT64) AS job_start_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_warenbewertung_abschluss_beladung`;

-- Table: DBP_MSI_DATA.TS_WBS_AKTION_NON_STD_WEIGHTS
insert into `dbp_msi_data.ts_wbs_aktion_non_std_weights` (mandant_id, werbe_typ_id, kjwo, dat_quelle, dat_ziel, gewichtung_prz, dat_von_orig, dat_bis_orig, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werbe_typ_id AS INT64) AS werbe_typ_id, CAST(kjwo AS INT64) AS kjwo, dat_quelle, dat_ziel, CAST(gewichtung_prz AS NUMERIC) AS gewichtung_prz, dat_von_orig, dat_bis_orig, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_aktion_non_std_weights`;

-- Table: DBP_MSI_DATA.TS_WBS_AUSLIEFERGRUPPE_BERECHNUNGSLAUF
insert into `dbp_msi_data.ts_wbs_ausliefergruppe_berechnungslauf` (mandant_id, ausliefergruppe_id, berechnungsprozess_id, berechnungslauf_nr, zeitslot_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausliefergruppe_id, CAST(berechnungsprozess_id AS INT64) AS berechnungsprozess_id, CAST(berechnungslauf_nr AS INT64) AS berechnungslauf_nr, CAST(zeitslot_id AS INT64) AS zeitslot_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_ausliefergruppe_berechnungslauf`;

-- Table: DBP_MSI_DATA.TS_WBS_INITIALE_BELIEFERUNG_STANDARD
insert into `dbp_msi_data.ts_wbs_initiale_belieferung_standard` (mandant_id, ausliefergruppe_id, werbe_start_wtag_id, werbe_ende_wtag_id, anz_tage_werbe_dauer, init_lief_markt_cluster_id, estimation_id, anz_ame_split_grenze, auto_split_fg, auto_split_prozent, anz_pal_auto_split_grenze, anz_tage_vor_akt_lieferstart_auto_split_ame, anz_tage_vor_akt_lieferstart_auto_split_pal, anz_tage_auto_split_pal, anz_tage_fix_split_mhd_grenze, unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, anz_tage_phase_switch_i, anz_tage_phase_switch_ii, anz_tage_phase_switch_iii, anz_tage_phase_switch_iv, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausliefergruppe_id, CAST(werbe_start_wtag_id AS INT64) AS werbe_start_wtag_id, CAST(werbe_ende_wtag_id AS INT64) AS werbe_ende_wtag_id, CAST(anz_tage_werbe_dauer AS INT64) AS anz_tage_werbe_dauer, CAST(init_lief_markt_cluster_id AS INT64) AS init_lief_markt_cluster_id, CAST(estimation_id AS INT64) AS estimation_id, CAST(anz_ame_split_grenze AS INT64) AS anz_ame_split_grenze, CAST(auto_split_fg AS INT64) AS auto_split_fg, CAST(auto_split_prozent AS INT64) AS auto_split_prozent, CAST(anz_pal_auto_split_grenze AS INT64) AS anz_pal_auto_split_grenze, CAST(anz_tage_vor_akt_lieferstart_auto_split_ame AS INT64) AS anz_tage_vor_akt_lieferstart_auto_split_ame, CAST(anz_tage_vor_akt_lieferstart_auto_split_pal AS INT64) AS anz_tage_vor_akt_lieferstart_auto_split_pal, CAST(anz_tage_auto_split_pal AS INT64) AS anz_tage_auto_split_pal, CAST(anz_tage_fix_split_mhd_grenze AS INT64) AS anz_tage_fix_split_mhd_grenze, CAST(unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, CAST(anz_tage_phase_switch_i AS INT64) AS anz_tage_phase_switch_i, CAST(anz_tage_phase_switch_ii AS INT64) AS anz_tage_phase_switch_ii, CAST(anz_tage_phase_switch_iii AS INT64) AS anz_tage_phase_switch_iii, CAST(anz_tage_phase_switch_iv AS INT64) AS anz_tage_phase_switch_iv, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_initiale_belieferung_standard`;

-- Table: DBP_MSI_DATA.TS_WBS_INITIALE_BELIEFERUNG_WOCHE
insert into `dbp_msi_data.ts_wbs_initiale_belieferung_woche` (mandant_id, ausliefergruppe_id, kjwo, werbe_start_wtag_id, werbe_ende_wtag_id, anz_tage_werbe_dauer, init_lief_markt_cluster_id, estimation_id, anz_ame_split_grenze, auto_split_fg, auto_split_prozent, anz_pal_auto_split_grenze, anz_tage_vor_akt_lieferstart_auto_split_ame, anz_tage_vor_akt_lieferstart_auto_split_pal, anz_tage_auto_split_pal, anz_tage_fix_split_mhd_grenze, unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, anz_tage_phase_switch_i, anz_tage_phase_switch_ii, anz_tage_phase_switch_iii, anz_tage_phase_switch_iv, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ausliefergruppe_id, CAST(kjwo AS INT64) AS kjwo, CAST(werbe_start_wtag_id AS INT64) AS werbe_start_wtag_id, CAST(werbe_ende_wtag_id AS INT64) AS werbe_ende_wtag_id, CAST(anz_tage_werbe_dauer AS INT64) AS anz_tage_werbe_dauer, CAST(init_lief_markt_cluster_id AS INT64) AS init_lief_markt_cluster_id, CAST(estimation_id AS INT64) AS estimation_id, CAST(anz_ame_split_grenze AS INT64) AS anz_ame_split_grenze, CAST(auto_split_fg AS INT64) AS auto_split_fg, CAST(auto_split_prozent AS INT64) AS auto_split_prozent, CAST(anz_pal_auto_split_grenze AS INT64) AS anz_pal_auto_split_grenze, CAST(anz_tage_vor_akt_lieferstart_auto_split_ame AS INT64) AS anz_tage_vor_akt_lieferstart_auto_split_ame, CAST(anz_tage_vor_akt_lieferstart_auto_split_pal AS INT64) AS anz_tage_vor_akt_lieferstart_auto_split_pal, CAST(anz_tage_auto_split_pal AS INT64) AS anz_tage_auto_split_pal, CAST(anz_tage_fix_split_mhd_grenze AS INT64) AS anz_tage_fix_split_mhd_grenze, CAST(unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, CAST(unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent AS INT64) AS unter_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_7_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_6_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_5_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_4_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_3_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_2_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_1_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_0_tage_vor_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_1_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_2_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_3_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_4_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_5_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_6_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_7_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_8_tage_nach_werbestart_fix_split_prozent, CAST(ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent AS INT64) AS ueber_mhd_grenze_9_tage_nach_werbestart_fix_split_prozent, CAST(anz_tage_phase_switch_i AS INT64) AS anz_tage_phase_switch_i, CAST(anz_tage_phase_switch_ii AS INT64) AS anz_tage_phase_switch_ii, CAST(anz_tage_phase_switch_iii AS INT64) AS anz_tage_phase_switch_iii, CAST(anz_tage_phase_switch_iv AS INT64) AS anz_tage_phase_switch_iv, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_initiale_belieferung_woche`;

-- Table: DBP_MSI_DATA.TS_WBS_REFMARKT
insert into `dbp_msi_data.ts_wbs_refmarkt` (mandant_id, wup_id, nb_id, wup_id_ref, nb_id_ref, ref_faktor_fallback, mandant_id_vz_fallback, wup_id_vz_fallback, nb_id_vz_fallback, fixamount_share_alg_500, fixamount_share_alg_120, estimation_fg, adjustment_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id_ref AS INT64) AS wup_id_ref, CAST(nb_id_ref AS INT64) AS nb_id_ref, CAST(ref_faktor_fallback AS NUMERIC) AS ref_faktor_fallback, CAST(mandant_id_vz_fallback AS INT64) AS mandant_id_vz_fallback, CAST(wup_id_vz_fallback AS INT64) AS wup_id_vz_fallback, CAST(nb_id_vz_fallback AS INT64) AS nb_id_vz_fallback, CAST(fixamount_share_alg_500 AS NUMERIC) AS fixamount_share_alg_500, CAST(fixamount_share_alg_120 AS NUMERIC) AS fixamount_share_alg_120, CAST(estimation_fg AS INT64) AS estimation_fg, CAST(adjustment_id AS INT64) AS adjustment_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_refmarkt`;

-- Table: DBP_MSI_DATA.TS_WBS_RUNDUNGSPROFILE
insert into `dbp_msi_data.ts_wbs_rundungsprofile` (mandant_id, rundungsprofil_id, wbs_relevant_fg, aufrundung_ab_prozent, abrundung_bis_prozent, rundung_ziel_einh_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, rundungsprofil_id, CAST(wbs_relevant_fg AS INT64) AS wbs_relevant_fg, CAST(aufrundung_ab_prozent AS NUMERIC) AS aufrundung_ab_prozent, CAST(abrundung_bis_prozent AS NUMERIC) AS abrundung_bis_prozent, rundung_ziel_einh_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_rundungsprofile`;

-- Table: DBP_MSI_DATA.TS_WBS_WARENGRUPPE
insert into `dbp_msi_data.ts_wbs_warengruppe` (mandant_id, kjwo, wg_id, estimation_fg, adjustment_id, auto_bestellmenge_mit_bestand_phase_switch_i_fg, auto_bestellmenge_mit_bestand_phase_switch_iii_fg, bonuskauf_promotionstyp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjwo AS INT64) AS kjwo, CAST(wg_id AS INT64) AS wg_id, CAST(estimation_fg AS INT64) AS estimation_fg, CAST(adjustment_id AS INT64) AS adjustment_id, CAST(auto_bestellmenge_mit_bestand_phase_switch_i_fg AS INT64) AS auto_bestellmenge_mit_bestand_phase_switch_i_fg, CAST(auto_bestellmenge_mit_bestand_phase_switch_iii_fg AS INT64) AS auto_bestellmenge_mit_bestand_phase_switch_iii_fg, bonuskauf_promotionstyp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_warengruppe`;

-- Table: DBP_MSI_DATA.TS_WBS_WARENGRUPPE_STANDARD
insert into `dbp_msi_data.ts_wbs_warengruppe_standard` (mandant_id, wg_id, estimation_fg, adjustment_id, auto_bestellmenge_mit_bestand_phase_switch_i_fg, auto_bestellmenge_mit_bestand_phase_switch_iii_fg, bonuskauf_promotionstyp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wg_id AS INT64) AS wg_id, CAST(estimation_fg AS INT64) AS estimation_fg, CAST(adjustment_id AS INT64) AS adjustment_id, CAST(auto_bestellmenge_mit_bestand_phase_switch_i_fg AS INT64) AS auto_bestellmenge_mit_bestand_phase_switch_i_fg, CAST(auto_bestellmenge_mit_bestand_phase_switch_iii_fg AS INT64) AS auto_bestellmenge_mit_bestand_phase_switch_iii_fg, bonuskauf_promotionstyp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_warengruppe_standard`;

-- Table: DBP_MSI_DATA.TS_WBS_ZEITSLOTS_AENDERUNG
insert into `dbp_msi_data.ts_wbs_zeitslots_aenderung` (mandant_id, auslieferungsgruppe_id, dat, zeitslot_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, auslieferungsgruppe_id, dat, CAST(zeitslot_id AS INT64) AS zeitslot_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wbs_zeitslots_aenderung`;

-- Table: DBP_MSI_DATA.TS_WUP_DAT_LEERGUT
insert into `dbp_msi_data.ts_wup_dat_leergut` (mandant_id, wup_id, nb_id, dat, wrg_id, betrag_leergut_zaehlung, betrag_leergut_inventur, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, wrg_id, CAST(betrag_leergut_zaehlung AS NUMERIC) AS betrag_leergut_zaehlung, CAST(betrag_leergut_inventur AS NUMERIC) AS betrag_leergut_inventur, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wup_dat_leergut`;

-- Table: DBP_MSI_DATA.TS_WUP_TM_GP_KOSTEN_UPLOAD_PER
insert into `dbp_msi_data.ts_wup_tm_gp_kosten_upload_per` (mandant_id, system_id, tms_gp_id, tms_gp_typ_cd, wup_id, nb_id, kosten_upload_fg, dat_bis, dat_von, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(system_id AS INT64) AS system_id, tms_gp_id, tms_gp_typ_cd, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(kosten_upload_fg AS INT64) AS kosten_upload_fg, dat_bis, dat_von, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wup_tm_gp_kosten_upload_per`;

-- Table: DBP_MSI_DATA.TS_WUP_ZEIT_ANLIEFERUNG_PER
insert into `dbp_msi_data.ts_wup_zeit_anlieferung_per` (mandant_id, wup_id, nb_id, transportsortiment_id, dat_von, dat_bis, zeit_anlieferung, zeit_anlieferung_num, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, transportsortiment_id, dat_von, dat_bis, zeit_anlieferung, CAST(zeit_anlieferung_num AS INT64) AS zeit_anlieferung_num, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_ts_wup_zeit_anlieferung_per`;

-- Table: DBP_MSI_DATA.TUPEL_TAGS
insert into `dbp_msi_data.tupel_tags` (mandant_id, matching_id, tupel_tag, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(matching_id AS INT64) AS matching_id, tupel_tag, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_tupel_tags`;

-- Table: DBP_MSI_DATA.USER_KURSTYP_ZU
insert into `dbp_msi_data.user_kurstyp_zu` (user_id, kurstyp_id, td_insert, td_update)
SELECT user_id, CAST(kurstyp_id AS INT64) AS kurstyp_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_kurstyp_zu`;

-- Table: DBP_MSI_DATA.USER_MANDANT_ZU
insert into `dbp_msi_data.user_mandant_zu` (mandant_id, user_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, user_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_mandant_zu`;

-- Table: DBP_MSI_DATA.USER_VIS_BENCHMARK_ZU
insert into `dbp_msi_data.user_vis_benchmark_zu` (user_id, mandant_id, hierarchie_element_id, hierarchie_ebene_id, td_insert, td_update)
SELECT user_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(hierarchie_element_id AS INT64) AS hierarchie_element_id, hierarchie_ebene_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_vis_benchmark_zu`;

-- Table: DBP_MSI_DATA.USER_WRG_TYP_ZU
insert into `dbp_msi_data.user_wrg_typ_zu` (user_id, wrg_typ_id, berichtskurs_typ_id, td_update, td_insert)
SELECT user_id, CAST(wrg_typ_id AS INT64) AS wrg_typ_id, CAST(berichtskurs_typ_id AS INT64) AS berichtskurs_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_wrg_typ_zu`;

-- Table: DBP_MSI_DATA.USER_WRG_ZU
insert into `dbp_msi_data.user_wrg_zu` (user_id, wrg_id, td_insert, td_update)
SELECT user_id, wrg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_wrg_zu`;

-- Table: DBP_MSI_DATA.USER_WUP_AUSWAHL
insert into `dbp_msi_data.user_wup_auswahl` (user_id, auswahl_bez, td_insert, td_update)
SELECT user_id, auswahl_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_user_wup_auswahl`;

-- Table: DBP_MSI_DATA.VIS_COCKPIT_WUP
insert into `dbp_msi_data.vis_cockpit_wup` (mandant_id, wup_id, nb_id, wrg_id, cockpit_variante, exp_ber_fg, ums_dat_von, ums_dat_bis, ums_netto_wup_akt, ums_netto_wup_vor, ums_netto_wup_abw, ums_netto_rang, ums_netto_nat, ums_netto_min, ums_netto_max, abs_dat_von, abs_dat_bis, abs_brutto_wup_akt, abs_umsatz_wup_akt, abs_brutto_wup_vor, abs_umsatz_wup_vor, abs_quote_wup, abs_quote_rang, abs_quote_nat, abs_quote_nat_akt, abs_quote_nat_vor, kuga_dat_von, kuga_dat_bis, kuga_wup_akt, kuga_wup_vor, kuga_wup_abw, kuga_rang, kuga_nat, kuga_min, kuga_max, pk_dat_von, pk_dat_bis, pk_kosten_wup_akt, pk_umsatz_wup_akt, pk_kosten_wup_vor, pk_umsatz_wup_vor, pk_quote_wup, pk_quote_rang, pk_quote_nat, pk_quote_nat_akt, pk_quote_nat_vor, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, wrg_id, CAST(cockpit_variante AS INT64) AS cockpit_variante, CAST(exp_ber_fg AS INT64) AS exp_ber_fg, ums_dat_von, ums_dat_bis, CAST(ums_netto_wup_akt AS NUMERIC) AS ums_netto_wup_akt, CAST(ums_netto_wup_vor AS NUMERIC) AS ums_netto_wup_vor, CAST(ums_netto_wup_abw AS NUMERIC) AS ums_netto_wup_abw, CAST(ums_netto_rang AS INT64) AS ums_netto_rang, CAST(ums_netto_nat AS NUMERIC) AS ums_netto_nat, CAST(ums_netto_min AS NUMERIC) AS ums_netto_min, CAST(ums_netto_max AS NUMERIC) AS ums_netto_max, abs_dat_von, abs_dat_bis, CAST(abs_brutto_wup_akt AS NUMERIC) AS abs_brutto_wup_akt, CAST(abs_umsatz_wup_akt AS NUMERIC) AS abs_umsatz_wup_akt, CAST(abs_brutto_wup_vor AS NUMERIC) AS abs_brutto_wup_vor, CAST(abs_umsatz_wup_vor AS NUMERIC) AS abs_umsatz_wup_vor, CAST(abs_quote_wup AS NUMERIC) AS abs_quote_wup, CAST(abs_quote_rang AS INT64) AS abs_quote_rang, CAST(abs_quote_nat AS NUMERIC) AS abs_quote_nat, CAST(abs_quote_nat_akt AS NUMERIC) AS abs_quote_nat_akt, CAST(abs_quote_nat_vor AS NUMERIC) AS abs_quote_nat_vor, kuga_dat_von, kuga_dat_bis, CAST(kuga_wup_akt AS INT64) AS kuga_wup_akt, CAST(kuga_wup_vor AS INT64) AS kuga_wup_vor, CAST(kuga_wup_abw AS NUMERIC) AS kuga_wup_abw, CAST(kuga_rang AS INT64) AS kuga_rang, CAST(kuga_nat AS NUMERIC) AS kuga_nat, CAST(kuga_min AS NUMERIC) AS kuga_min, CAST(kuga_max AS NUMERIC) AS kuga_max, pk_dat_von, pk_dat_bis, CAST(pk_kosten_wup_akt AS NUMERIC) AS pk_kosten_wup_akt, CAST(pk_umsatz_wup_akt AS NUMERIC) AS pk_umsatz_wup_akt, CAST(pk_kosten_wup_vor AS NUMERIC) AS pk_kosten_wup_vor, CAST(pk_umsatz_wup_vor AS NUMERIC) AS pk_umsatz_wup_vor, CAST(pk_quote_wup AS NUMERIC) AS pk_quote_wup, CAST(pk_quote_rang AS INT64) AS pk_quote_rang, CAST(pk_quote_nat AS NUMERIC) AS pk_quote_nat, CAST(pk_quote_nat_akt AS NUMERIC) AS pk_quote_nat_akt, CAST(pk_quote_nat_vor AS NUMERIC) AS pk_quote_nat_vor, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_cockpit_wup`;

-- Table: DBP_MSI_DATA.VIS_MONAT_PROBLEME
insert into `dbp_msi_data.vis_monat_probleme` (mandant_id, kjmo, problemcode_id, anz_fehler, anz_fehler_kum, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, problemcode_id, CAST(anz_fehler AS INT64) AS anz_fehler, CAST(anz_fehler_kum AS INT64) AS anz_fehler_kum, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_monat_probleme`;

-- Table: DBP_MSI_DATA.VIS_STRUKTUR_KER
insert into `dbp_msi_data.vis_struktur_ker` (ker_lv, ker_id, spr_id, ker_bez, td_insert, td_update)
SELECT CAST(ker_lv AS INT64) AS ker_lv, ker_id, CAST(spr_id AS INT64) AS spr_id, ker_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vis_struktur_ker`;

-- Table: DBP_MSI_DATA.VK_KONZEPT_GINFO_FLAECHE_ZU
insert into `dbp_msi_data.vk_konzept_ginfo_flaeche_zu` (mandant_id, vk_konzept_id, ginfo_flaeche_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vk_konzept_id AS INT64) AS vk_konzept_id, ginfo_flaeche_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vk_konzept_ginfo_flaeche_zu`;

-- Table: DBP_MSI_DATA.VK_KONZEPT_SPR_ZU
insert into `dbp_msi_data.vk_konzept_spr_zu` (mandant_id, vk_konzept_id, spr_id, vk_konzept_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vk_konzept_id AS INT64) AS vk_konzept_id, CAST(spr_id AS INT64) AS spr_id, vk_konzept_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vk_konzept_spr_zu`;

-- Table: DBP_MSI_DATA.VK_KONZEPT_WG_ZU
insert into `dbp_msi_data.vk_konzept_wg_zu` (mandant_id, vk_konzept_id, wg_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(vk_konzept_id AS INT64) AS vk_konzept_id, CAST(wg_id AS INT64) AS wg_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_msi_data_vk_konzept_wg_zu`;

-- Table: DBP_MSI_DATA.WG_ZEK_ZU
insert into `dbp_msi_data.wg_zek_zu` (wg_id, arthiertyp_id, mandant_id, zek_id, td_update, td_insert)
SELECT CAST(wg_id AS INT64) AS wg_id, CAST(arthiertyp_id AS INT64) AS arthiertyp_id, CAST(mandant_id AS INT64) AS mandant_id, zek_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_data_wg_zek_zu`;

-- Table: DBP_MSI_VIEW2.TS_AIS_DE_L_EK_SAISON
insert into `dbp_msi_view2.ts_ais_de_l_ek_saison` (ek_saison_id, ek_saison_bez, td_update, td_insert)
SELECT CAST(ek_saison_id AS INT64) AS ek_saison_id, ek_saison_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view2_ts_ais_de_l_ek_saison`;

-- Table: DBP_MSI_VIEW2.TS_AIS_DE_PROGNOSE_AVQ_EK_SAISON_TAG
insert into `dbp_msi_view2.ts_ais_de_prognose_avq_ek_saison_tag` (mandant_id, ek_saison_id, dat_prognose, menge_absatz_prognose, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(ek_saison_id AS INT64) AS ek_saison_id, dat_prognose, CAST(menge_absatz_prognose AS NUMERIC) AS menge_absatz_prognose, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view2_ts_ais_de_prognose_avq_ek_saison_tag`;

-- Table: DBP_MSI_VIEW2.TS_EK_DASHBOARD_KOMMENTAR
insert into `dbp_msi_view2.ts_ek_dashboard_kommentar` (ek_dashboard_id, kommentar_txt, td_update, td_insert)
SELECT CAST(ek_dashboard_id AS INT64) AS ek_dashboard_id, kommentar_txt, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view2_ts_ek_dashboard_kommentar`;

-- Table: DBP_MSI_VIEW3.TS_LAGERORT_ALTN_SPR_ZU
insert into `dbp_msi_view3.ts_lagerort_altn_spr_zu` (mandant_id, lagerort_id, wup_id, nb_id, spr_id, lagerort_bez)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagerort_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(spr_id AS INT64) AS spr_id, lagerort_bez
FROM `snowflake_snapshots.kfl_dbp_msi_view3_ts_lagerort_altn_spr_zu`;

-- Table: DBP_MSI_VIEW3.TS_LIS_SCHWELLWERTE
insert into `dbp_msi_view3.ts_lis_schwellwerte` (mandant_id, wup_id, nb_id, schwellwert_typ_bez, schwellwert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, schwellwert_typ_bez, CAST(schwellwert AS NUMERIC) AS schwellwert
FROM `snowflake_snapshots.kfl_dbp_msi_view3_ts_lis_schwellwerte`;

-- Table: DBP_MSI_VIEW3.USER_PRJ_WRG_TYP_ZU
insert into `dbp_msi_view3.user_prj_wrg_typ_zu` (user_id, wrg_typ_id, td_update, td_insert)
SELECT user_id, CAST(wrg_typ_id AS INT64) AS wrg_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view3_user_prj_wrg_typ_zu`;

-- Table: DBP_MSI_VIEW_IOS.TS_PROJEKT_QS
insert into `dbp_msi_view_ios.ts_projekt_qs` (cpr_ext_id, qs_fg, user_id, dat_aenderung)
SELECT cpr_ext_id, CAST(qs_fg AS INT64) AS qs_fg, user_id, dat_aenderung
FROM `snowflake_snapshots.kfl_dbp_msi_view_ios_ts_projekt_qs`;

-- Table: DBP_MSI_VIEW_LIN.TS_LIN_KURS_USER_ZU
insert into `dbp_msi_view_lin.ts_lin_kurs_user_zu` (mandant_id, lin_kurs_id, user_id)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lin_kurs_id, user_id
FROM `snowflake_snapshots.kfl_dbp_msi_view_lin_ts_lin_kurs_user_zu`;

-- Table: DBP_MSI_VIEW_LOG.TS_ART_STELLPLATZ_FAKTOR
insert into `dbp_msi_view_log.ts_art_stellplatz_faktor` (art_id, mandant_id, stellplatz_faktor, td_update, td_insert)
SELECT CAST(art_id AS INT64) AS art_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(stellplatz_faktor AS NUMERIC) AS stellplatz_faktor, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_ts_art_stellplatz_faktor`;

-- Table: DBP_MSI_VIEW_LOG.TS_IN_LAGERORT_TECHNIKBEREICH_ZU
insert into `dbp_msi_view_log.ts_in_lagerort_technikbereich_zu` (mandant_id, werk_id, in_lagerort_id, technikbereich_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werk_id AS INT64) AS werk_id, in_lagerort_id, technikbereich_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_ts_in_lagerort_technikbereich_zu`;

-- Table: DBP_MSI_VIEW_LOG.TS_IN_WERK_FLAECHE_PER
insert into `dbp_msi_view_log.ts_in_werk_flaeche_per` (mandant_id, werk_id, gebaeude_bez, gebaeudeteil_bez, flaeche_qm, dat_von, dat_bis, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(werk_id AS INT64) AS werk_id, gebaeude_bez, gebaeudeteil_bez, CAST(flaeche_qm AS NUMERIC) AS flaeche_qm, dat_von, dat_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_ts_in_werk_flaeche_per`;

-- Table: DBP_MSI_VIEW_LOG.TS_LAGERORT_ALTN_SPR_ZU
insert into `dbp_msi_view_log.ts_lagerort_altn_spr_zu` (mandant_id, lagerort_id, wup_id, nb_id, spr_id, lagerort_bez, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, lagerort_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(spr_id AS INT64) AS spr_id, lagerort_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_ts_lagerort_altn_spr_zu`;

-- Table: DBP_MSI_VIEW_LOG.USER_PRJ_WRG_TYP_ZU
insert into `dbp_msi_view_log.user_prj_wrg_typ_zu` (user_id, wrg_typ_id, td_update, td_insert)
SELECT user_id, CAST(wrg_typ_id AS INT64) AS wrg_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_log_user_prj_wrg_typ_zu`;

-- Table: DBP_MSI_VIEW_NFMD.CONTROLL_VS_TREATMENT
insert into `dbp_msi_view_nfmd.controll_vs_treatment` (wup_id, ctrl_v_test_cd)
SELECT CAST(wup_id AS INT64) AS wup_id, ctrl_v_test_cd
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_controll_vs_treatment`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_ARTICLE_ARTICLE_CLUSTER_REL
insert into `dbp_msi_view_nfmd.ts_nfmd_article_article_cluster_rel` (mandant_id, aktion_id, art_id, article_cluster_id, kjwo_ww, dwh_created_tmsp, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(article_cluster_id AS INT64) AS article_cluster_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, dwh_created_tmsp, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_article_article_cluster_rel`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_ARTICLE_CLUSTER
insert into `dbp_msi_view_nfmd.ts_nfmd_article_cluster` (mandant_id, article_cluster_id, article_cluster_descr, article_cluster_descr_bg, article_cluster_descr_cz, article_cluster_descr_en, article_cluster_descr_hr, article_cluster_descr_pl, article_cluster_descr_ro, article_cluster_descr_sk, article_cluster_descr_native, active_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(article_cluster_id AS INT64) AS article_cluster_id, article_cluster_descr, article_cluster_descr_bg, article_cluster_descr_cz, article_cluster_descr_en, article_cluster_descr_hr, article_cluster_descr_pl, article_cluster_descr_ro, article_cluster_descr_sk, article_cluster_descr_native, CAST(active_fg AS INT64) AS active_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_article_cluster`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_ARTICLE_PRICE
insert into `dbp_msi_view_nfmd.ts_nfmd_article_price` (mandant_id, aktion_id, art_id, discount_type_name, kjwo_ww, wrg_id, manual_promo_price_gross_local_val, user_id, dwh_created_tmsp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, discount_type_name, CAST(kjwo_ww AS INT64) AS kjwo_ww, wrg_id, CAST(manual_promo_price_gross_local_val AS NUMERIC) AS manual_promo_price_gross_local_val, user_id, dwh_created_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_article_price`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_ARTICLE_PRICE_DATE
insert into `dbp_msi_view_nfmd.ts_nfmd_article_price_date` (mandant_id, aktion_id, art_id, discount_type_name, kjwo_ww, manual_promo_price_dt, user_id, dwh_created_tmsp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, discount_type_name, CAST(kjwo_ww AS INT64) AS kjwo_ww, manual_promo_price_dt, user_id, dwh_created_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_article_price_date`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_COMMENTS
insert into `dbp_msi_view_nfmd.ts_nfmd_comments` (mandant_id, aktion_id, art_id, kjwo_ww, user_id, comment_txt, dwh_created_tmsp, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, aktion_id, CAST(art_id AS INT64) AS art_id, CAST(kjwo_ww AS INT64) AS kjwo_ww, user_id, comment_txt, dwh_created_tmsp, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_comments`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_DECISION_APPROVAL_LOG
insert into `dbp_msi_view_nfmd.ts_nfmd_decision_approval_log` (mandant_id, dwh_created_tmsp, kjwo_ww, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dwh_created_tmsp, CAST(kjwo_ww AS INT64) AS kjwo_ww, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_decision_approval_log`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_MANUAL_PRICE_RELEASE_LOG
insert into `dbp_msi_view_nfmd.ts_nfmd_manual_price_release_log` (mandant_id, dwh_created_tmsp, kjwo_ww, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dwh_created_tmsp, CAST(kjwo_ww AS INT64) AS kjwo_ww, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_manual_price_release_log`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_MARKDOWN_DECISION
insert into `dbp_msi_view_nfmd.ts_nfmd_markdown_decision` (mandant_id, markdown_decision_id, markdown_decision_descr, markdown_decision_descr_bg, markdown_decision_descr_cz, markdown_decision_descr_en, markdown_decision_descr_hr, markdown_decision_descr_pl, markdown_decision_descr_ro, markdown_decision_descr_sk, markdown_decision_descr_native, active_fg, retoure_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(markdown_decision_id AS INT64) AS markdown_decision_id, markdown_decision_descr, markdown_decision_descr_bg, markdown_decision_descr_cz, markdown_decision_descr_en, markdown_decision_descr_hr, markdown_decision_descr_pl, markdown_decision_descr_ro, markdown_decision_descr_sk, markdown_decision_descr_native, CAST(active_fg AS INT64) AS active_fg, CAST(retoure_fg AS INT64) AS retoure_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_markdown_decision`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_SELECTED_ARTICLE_CLUSTER
insert into `dbp_msi_view_nfmd.ts_nfmd_selected_article_cluster` (mandant_id, dwh_created_tmsp, article_cluster_id, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, dwh_created_tmsp, CAST(article_cluster_id AS INT64) AS article_cluster_id, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_selected_article_cluster`;

-- Table: DBP_MSI_VIEW_NFMD.TS_NFMD_SELECTED_DECISION
insert into `dbp_msi_view_nfmd.ts_nfmd_selected_decision` (mandant_id, markdown_decision_id, user_id)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(markdown_decision_id AS INT64) AS markdown_decision_id, user_id
FROM `snowflake_snapshots.kfl_dbp_msi_view_nfmd_ts_nfmd_selected_decision`;

-- Table: DBP_MSI_VIEW_SCM.USER_PRJ_WRG_TYP_ZU
insert into `dbp_msi_view_scm.user_prj_wrg_typ_zu` (user_id, wrg_typ_id, td_update, td_insert)
SELECT user_id, CAST(wrg_typ_id AS INT64) AS wrg_typ_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_msi_view_scm_user_prj_wrg_typ_zu`;

-- Table: DBP_MSI_VIEW_VIS.TS_AVQ_SCHWELLWERT
insert into `dbp_msi_view_vis.ts_avq_schwellwert` (mandant_id, avq_schwellwert, we_bestand_schwellwert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(avq_schwellwert AS NUMERIC) AS avq_schwellwert, CAST(we_bestand_schwellwert AS NUMERIC) AS we_bestand_schwellwert
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_avq_schwellwert`;

-- Table: DBP_MSI_VIEW_VIS.TS_GEKU_VERTEILGEBIET_QUOTE
insert into `dbp_msi_view_vis.ts_geku_verteilgebiet_quote` (verteilgebiet_uid, kjwo, verteil_quote)
SELECT CAST(verteilgebiet_uid AS INT64) AS verteilgebiet_uid, CAST(kjwo AS INT64) AS kjwo, CAST(verteil_quote AS NUMERIC) AS verteil_quote
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_geku_verteilgebiet_quote`;

-- Table: DBP_MSI_VIEW_VIS.TS_HYG_THEMA_GRUPPEN_ZU
insert into `dbp_msi_view_vis.ts_hyg_thema_gruppen_zu` (hyg_thema_id, gj, hyg_thema_gruppe_id, hyg_thema_gruppe_mutter_id)
SELECT hyg_thema_id, CAST(gj AS INT64) AS gj, CAST(hyg_thema_gruppe_id AS INT64) AS hyg_thema_gruppe_id, CAST(hyg_thema_gruppe_mutter_id AS INT64) AS hyg_thema_gruppe_mutter_id
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_hyg_thema_gruppen_zu`;

-- Table: DBP_MSI_VIEW_VIS.TS_HYG_THEMA_GRUPPE_SPR_ZU
insert into `dbp_msi_view_vis.ts_hyg_thema_gruppe_spr_zu` (hyg_thema_gruppe_id, spr_id, hyg_thema_gruppe_bez)
SELECT CAST(hyg_thema_gruppe_id AS INT64) AS hyg_thema_gruppe_id, CAST(spr_id AS INT64) AS spr_id, hyg_thema_gruppe_bez
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_hyg_thema_gruppe_spr_zu`;

-- Table: DBP_MSI_VIEW_VIS.TS_L_HYG_THEMA_GRUPPE
insert into `dbp_msi_view_vis.ts_l_hyg_thema_gruppe` (hyg_thema_gruppe_id)
SELECT CAST(hyg_thema_gruppe_id AS INT64) AS hyg_thema_gruppe_id
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_l_hyg_thema_gruppe`;

-- Table: DBP_MSI_VIEW_VIS.TS_PROGNOSE_FEEDBACK
insert into `dbp_msi_view_vis.ts_prognose_feedback` (mandant_id, wup_id, nb_id, dat, zeitstempel, prognose_fg)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, dat, zeitstempel, CAST(prognose_fg AS INT64) AS prognose_fg
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_prognose_feedback`;

-- Table: DBP_MSI_VIEW_VIS.TS_VIS_JZG_ZIEL_EINGABE
insert into `dbp_msi_view_vis.ts_vis_jzg_ziel_eingabe` (mandant_id, nb_id, wup_id, wrg_id, gj, metrik_id, typ_id, level_id, wert_eingabe, kommentar_eingabe, zeitstempel)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(nb_id AS INT64) AS nb_id, CAST(wup_id AS INT64) AS wup_id, wrg_id, CAST(gj AS INT64) AS gj, CAST(metrik_id AS INT64) AS metrik_id, CAST(typ_id AS INT64) AS typ_id, CAST(level_id AS INT64) AS level_id, CAST(wert_eingabe AS BIGNUMERIC) AS wert_eingabe, kommentar_eingabe, zeitstempel
FROM `snowflake_snapshots.kfl_dbp_msi_view_vis_ts_vis_jzg_ziel_eingabe`;

-- Table: DBP_ODS.KASSE_TYP_SPR_ZU
insert into `dbp_ods.kasse_typ_spr_zu` (kasse_typ_id, spr_id, kasse_typ_bez, kasse_name_bez, td_update, td_insert)
SELECT CAST(kasse_typ_id AS INT64) AS kasse_typ_id, CAST(spr_id AS INT64) AS spr_id, kasse_typ_bez, kasse_name_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_ods_kasse_typ_spr_zu`;

-- Table: DBP_ODS.L_BON_LOAD_STATUS_BITFELD
insert into `dbp_ods.l_bon_load_status_bitfeld` (bitfeld_position_id, load_status_bez, td_insert, td_update)
SELECT CAST(bitfeld_position_id AS INT64) AS bitfeld_position_id, load_status_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_l_bon_load_status_bitfeld`;

-- Table: DBP_ODS.L_BUCHUNGSSCHLUESSEL
insert into `dbp_ods.l_buchungsschluessel` (buchungsschluessel_id, td_insert, td_update)
SELECT CAST(buchungsschluessel_id AS INT64) AS buchungsschluessel_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_l_buchungsschluessel`;

-- Table: DBP_ODS.L_KPOS_ZAHLUNG_TYP_SPR_ZU
insert into `dbp_ods.l_kpos_zahlung_typ_spr_zu` (kpos_zahlung_typ_id, mandant_id, spr_id, kpos_zahlung_typ_bez, td_insert, td_update)
SELECT kpos_zahlung_typ_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, kpos_zahlung_typ_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_l_kpos_zahlung_typ_spr_zu`;

-- Table: DBP_ODS.L_KUNDENKARTE_TYP
insert into `dbp_ods.l_kundenkarte_typ` (kundenkarte_typ_id, td_insert, td_update)
SELECT CAST(kundenkarte_typ_id AS INT64) AS kundenkarte_typ_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_l_kundenkarte_typ`;

-- Table: DBP_ODS.L_ZAHLUNGSMITTEL
insert into `dbp_ods.l_zahlungsmittel` (zahlungsmittel_id, mandant_id, td_insert, td_update)
SELECT zahlungsmittel_id, CAST(mandant_id AS INT64) AS mandant_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_l_zahlungsmittel`;

-- Table: DBP_ODS.ZAHLUNGSMITTEL_SPR_ZU
insert into `dbp_ods.zahlungsmittel_spr_zu` (zahlungsmittel_id, mandant_id, spr_id, zahlungsmittel_bez, td_insert, td_update)
SELECT zahlungsmittel_id, CAST(mandant_id AS INT64) AS mandant_id, CAST(spr_id AS INT64) AS spr_id, zahlungsmittel_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_ods_zahlungsmittel_spr_zu`;

-- Table: DBP_PROCESS.LOAD_CHK_FIGURES
insert into `dbp_process.load_chk_figures` (cycle_id, sql_name, sql_type, record_count, durationsec, err_count, job_name, scr_name, loop_id, proc_type, td_insert, td_update)
SELECT CAST(cycle_id AS INT64) AS cycle_id, sql_name, sql_type, CAST(record_count AS INT64) AS record_count, CAST(durationsec AS INT64) AS durationsec, CAST(err_count AS INT64) AS err_count, job_name, scr_name, CAST(loop_id AS INT64) AS loop_id, proc_type, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_process_load_chk_figures`;

-- Table: DBP_SECURITY.BIS_EINKAEUFER_LDAP_ZU
insert into `dbp_security.bis_einkaeufer_ldap_zu` (mandant_id, ma_ldap, einkaeufer_bis_id, eigene_gruppe_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, ma_ldap, einkaeufer_bis_id, CAST(eigene_gruppe_fg AS INT64) AS eigene_gruppe_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_bis_einkaeufer_ldap_zu`;

-- Table: DBP_SECURITY.GF_CODE
insert into `dbp_security.gf_code` (gf_id, mandant_id, gf_code, td_insert, td_update)
SELECT CAST(gf_id AS INT64) AS gf_id, CAST(mandant_id AS INT64) AS mandant_id, gf_code, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_gf_code`;

-- Table: DBP_SECURITY.IOS_MANDANT_USERSEQUENZ_ZU
insert into `dbp_security.ios_mandant_usersequenz_zu` (mandant_id, usersequenz, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, usersequenz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_ios_mandant_usersequenz_zu`;

-- Table: DBP_SECURITY.KASSIERER_DECODED
insert into `dbp_security.kassierer_decoded` (kassierer_id, timestamp_dec, user_decoding, encode_fg, td_insert, td_update)
SELECT CAST(kassierer_id AS INT64) AS kassierer_id, timestamp_dec, user_decoding, CAST(encode_fg AS INT64) AS encode_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_kassierer_decoded`;

-- Table: DBP_SECURITY.KMR_SECURITY_FILTER_MANDANT_ZU
insert into `dbp_security.kmr_security_filter_mandant_zu` (mandant_id, sf_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(sf_id AS INT64) AS sf_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_kmr_security_filter_mandant_zu`;

-- Table: DBP_SECURITY.KMR_SECURITY_FILTER_SEC_ZU
insert into `dbp_security.kmr_security_filter_sec_zu` (sf_id, sec_kz, td_insert, td_update)
SELECT CAST(sf_id AS INT64) AS sf_id, CAST(sec_kz AS INT64) AS sec_kz, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_kmr_security_filter_sec_zu`;

-- Table: DBP_SECURITY.LBS_GRUPPE
insert into `dbp_security.lbs_gruppe` (lbs_gruppe_id, lbs_gruppe_bez, td_update, td_insert)
SELECT CAST(lbs_gruppe_id AS INT64) AS lbs_gruppe_id, lbs_gruppe_bez, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_lbs_gruppe`;

-- Table: DBP_SECURITY.LBS_GRUPPE_USER_ZU
insert into `dbp_security.lbs_gruppe_user_zu` (lbs_gruppe_id, user_id, dat_gueltig_bis, td_update, td_insert)
SELECT CAST(lbs_gruppe_id AS INT64) AS lbs_gruppe_id, user_id, dat_gueltig_bis, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_lbs_gruppe_user_zu`;

-- Table: DBP_SECURITY.LBS_GRUPPE_ZEK_ZU
insert into `dbp_security.lbs_gruppe_zek_zu` (mandant_id, lbs_gruppe_id, zek_id, alle_zek_fg, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(lbs_gruppe_id AS INT64) AS lbs_gruppe_id, zek_id, CAST(alle_zek_fg AS INT64) AS alle_zek_fg, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_lbs_gruppe_zek_zu`;

-- Table: DBP_SECURITY.LBS_USER_ZEK_ZU
insert into `dbp_security.lbs_user_zek_zu` (mandant_id, zek_id, user_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zek_id, user_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_lbs_user_zek_zu`;

-- Table: DBP_SECURITY.LEIST_EINZELAUSWERTUNG_WUP
insert into `dbp_security.leist_einzelauswertung_wup` (mandant_id, wup_id, nb_id, leist_einzelauswertung_fg, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wup_id AS INT64) AS wup_id, CAST(nb_id AS INT64) AS nb_id, CAST(leist_einzelauswertung_fg AS INT64) AS leist_einzelauswertung_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_leist_einzelauswertung_wup`;

-- Table: DBP_SECURITY.L_BIS_LDAP
insert into `dbp_security.l_bis_ldap` (ma_ldap, td_insert, td_update)
SELECT ma_ldap, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_l_bis_ldap`;

-- Table: DBP_SECURITY.L_IMS_USER_IT_PROJEKT
insert into `dbp_security.l_ims_user_it_projekt` (user_id, it_projekt_id, td_update, td_insert)
SELECT user_id, it_projekt_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_l_ims_user_it_projekt`;

-- Table: DBP_SECURITY.L_KMR_SECURITY_FILTER
insert into `dbp_security.l_kmr_security_filter` (sf_id, sf_bez, td_insert, td_update)
SELECT CAST(sf_id AS INT64) AS sf_id, sf_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_l_kmr_security_filter`;

-- Table: DBP_SECURITY.L_MSI_USER
insert into `dbp_security.l_msi_user` (user_id, msi_produkt_bez, td_insert, td_update)
SELECT user_id, msi_produkt_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_l_msi_user`;

-- Table: DBP_SECURITY.SHR_NCS_EMPFAENGER
insert into `dbp_security.shr_ncs_empfaenger` (mandant_id, kjmo, hr_objekt_ebene1_id, email, vorname, nachname, geschlecht_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(kjmo AS INT64) AS kjmo, CAST(hr_objekt_ebene1_id AS INT64) AS hr_objekt_ebene1_id, email, vorname, nachname, CAST(geschlecht_id AS INT64) AS geschlecht_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_shr_ncs_empfaenger`;

-- Table: DBP_SECURITY.SORTIMENT_USER_WG_ZU
insert into `dbp_security.sortiment_user_wg_zu` (mandant_id, user_id, wg_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, user_id, CAST(wg_id AS INT64) AS wg_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_sortiment_user_wg_zu`;

-- Table: DBP_SECURITY.TS_KMR_USER_SECURITY_FILTER_ZU
insert into `dbp_security.ts_kmr_user_security_filter_zu` (user_id, sf_id, td_insert, td_update)
SELECT user_id, CAST(sf_id AS INT64) AS sf_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_ts_kmr_user_security_filter_zu`;

-- Table: DBP_SECURITY.USER_EK_ANZEIGE_ZU
insert into `dbp_security.user_ek_anzeige_zu` (user_id, ek_anzeige_fg, td_insert, td_update)
SELECT user_id, CAST(ek_anzeige_fg AS INT64) AS ek_anzeige_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_user_ek_anzeige_zu`;

-- Table: DBP_SECURITY.USER_EK_ANZEIGE_ZU_LOG
insert into `dbp_security.user_ek_anzeige_zu_log` (user_id, ek_anzeige_fg, td_insert, td_update)
SELECT user_id, CAST(ek_anzeige_fg AS INT64) AS ek_anzeige_fg, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_user_ek_anzeige_zu_log`;

-- Table: DBP_SECURITY.USER_HR_OBJEKT_ID_ZU
insert into `dbp_security.user_hr_objekt_id_zu` (mandant_id, hr_objekt_ebene1_id, user_id, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(hr_objekt_ebene1_id AS INT64) AS hr_objekt_ebene1_id, user_id, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_user_hr_objekt_id_zu`;

-- Table: DBP_SECURITY.USER_MANDANT_MSIPRODUKT_ZU
insert into `dbp_security.user_mandant_msiprodukt_zu` (mandant_id, user_id, msi_produkt_bez, td_insert, td_update)
SELECT CAST(mandant_id AS INT64) AS mandant_id, user_id, msi_produkt_bez, td_insert, td_update
FROM `snowflake_snapshots.kfl_dbp_security_user_mandant_msiprodukt_zu`;

-- Table: DBP_SECURITY.WBL_GF_ZU
insert into `dbp_security.wbl_gf_zu` (mandant_id, wbl_id, gf_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, CAST(wbl_id AS INT64) AS wbl_id, CAST(gf_id AS INT64) AS gf_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_wbl_gf_zu`;

-- Table: DBP_SECURITY.ZEK_WBL_ZU
insert into `dbp_security.zek_wbl_zu` (mandant_id, zek_id, wbl_id, td_update, td_insert)
SELECT CAST(mandant_id AS INT64) AS mandant_id, zek_id, CAST(wbl_id AS INT64) AS wbl_id, td_update, td_insert
FROM `snowflake_snapshots.kfl_dbp_security_zek_wbl_zu`;
