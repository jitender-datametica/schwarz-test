--==============================================================
-- Table: aad_scenario
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: aad_scenario
   generated from Powerdesigner on Mittwoch, 10. Mai 2023 08:29:20
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.aad_scenario (
scenario_id INT64 NOT NULL OPTIONS(description='Unique Identifier of the Scenario'),
scenario_grp_id INT64 NOT NULL OPTIONS(description='Unique Identifier of the Scenariogroup'),
dwh_created_tmsp DATETIME OPTIONS(description='Auto generate by Insert'),
dwh_updated_tmsp DATETIME OPTIONS(description='Auto generate by Update'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (scenario_id) NOT ENFORCED
) OPTIONS(description=' Contains the scenario and scenariogroup mapping');
