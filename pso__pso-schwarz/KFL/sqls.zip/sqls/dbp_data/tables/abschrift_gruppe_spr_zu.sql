--==============================================================
-- Table: abschrift_gruppe_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: abschrift_gruppe_spr_zu
   generated from Powerdesigner on Wednesday, January 31, 2024 2:33:01 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.abschrift_gruppe_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
abschriftgruppe_id INT64 NOT NULL OPTIONS(description='Merkmal zur Gruppierung der Abschriften'),
spr_id INT64 NOT NULL OPTIONS(description='Sprache ID'),
abschriftgrp_bez STRING(40) COLLATE 'und:ci'
OPTIONS(description='Sprachabhängige Bezeichnung der Abschriftengruppe            '),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, abschriftgruppe_id, spr_id) NOT ENFORCED
) OPTIONS(description='VIS - Sprachabhängige Bezeichnung der Abschriftenhierarchien (=gruppen)');
