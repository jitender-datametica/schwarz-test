--==============================================================
-- Table: abschriftart_int_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: abschriftart_int_zu
   generated from Powerdesigner on Wednesday, January 31, 2024 2:33:01 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.abschriftart_int_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
abschriftart_id INT64 NOT NULL OPTIONS(description='Abschriftenart  -  numerisch'),
abschriftart_int_id INT64 NOT NULL
OPTIONS(description='ID Einheitliche Abschriftart KL international (z.B. -1=Werbeabschriften)'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, abschriftart_id, abschriftart_int_id) NOT ENFORCED
)
OPTIONS(description='VIS - Mapping-Tabelle nationale Abschrftenarten zu der iEinheitlichen Abschriftenarten KL international');
