--==============================================================
-- Table: abschriftgruppe_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: abschriftgruppe_spr_zu
   generated from Powerdesigner on Donnerstag, 4. April 2024 14:47:28
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.abschriftgruppe_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache'),
abschriftgruppe_id INT64 NOT NULL
OPTIONS(description='ID der Abschriftgruppe. Unterschiedliche Lagerbewegungsarten, Abschriftarten und Preisänderungsgründe können zu Abschriftgruppen zusammengefasst werden. Zwischen den Gruppen gibt es eine Hierarchie mit mehreren Ebenen.'),
abschriftgruppe_bez STRING(100) OPTIONS(description='Sprachabhängige Bezeichnung der Abschriftgruppe.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, spr_id, abschriftgruppe_id) NOT ENFORCED
) OPTIONS(description='Sprachtabelle der Abschriftgruppen.');
