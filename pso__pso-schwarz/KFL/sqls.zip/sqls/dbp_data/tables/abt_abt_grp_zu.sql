--==============================================================
-- Table: abt_abt_grp_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: abt_abt_grp_zu
   generated from Powerdesigner on Wednesday, January 31, 2024 2:33:01 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.abt_abt_grp_zu (
abt_id INT64 NOT NULL
OPTIONS(description='Abteilungs ID negativer Zahlenraum: im DWH generierte IDs, positive Werte: aus Stammdatensystem übernommen'),
arthiertyp_id INT64 NOT NULL
OPTIONS(description='Artikel - Hierarchie - Typ - ID: kennzeichnet, ob es sich um eine Hierarchie mit zwei- oder dreistelligen Warengruppen  handelt            '),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
abt_grp_id INT64 NOT NULL
OPTIONS(description='Abteilungsgruppe (z.B. Markt Gesamt, Markt vergleichbar, Food Frische, etc.)'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (abt_id, arthiertyp_id, mandant_id, abt_grp_id) NOT ENFORCED
) OPTIONS(description='VIS - Abteilung - Abteilungsgruppe Zuordnung');
