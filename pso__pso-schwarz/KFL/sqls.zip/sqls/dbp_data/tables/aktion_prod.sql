create table if not exists `dbp_data.aktion_prod`
(
  aktion_id string collate 'und:ci',
  mandant_id int64,
  bewart_id int64,
  aktionsart_id string collate 'und:ci',
  werbe_kat_id int64,
  dat_von date,
  dat_bis date,
  preisaktiviert_fg int64,
  kjwo_von int64,
  aktion_typ_id string collate 'und:ci',
  td_update timestamp,
  td_insert timestamp
);
