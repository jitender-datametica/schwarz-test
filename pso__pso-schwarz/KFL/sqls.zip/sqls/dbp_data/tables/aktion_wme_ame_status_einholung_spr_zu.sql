--==============================================================
-- Table: aktion_wme_ame_status_einholung_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: aktion_wme_ame_status_einholung_spr_zu
   generated from Powerdesigner on Wednesday, February 14, 2024 10:50:35 AM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.aktion_wme_ame_status_einholung_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
status_einholung_id INT64 NOT NULL OPTIONS(description='ID Status der Einholung'),
spr_id INT64 NOT NULL OPTIONS(description='DWH Sprach ID '),
status_einholung_bez STRING(80) COLLATE 'und:ci' NOT NULL OPTIONS(description='Bezeichnung Status der Einholung'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, status_einholung_id, spr_id) NOT ENFORCED
)
OPTIONS(description='VIS - Sprachabhängige Bezeichnungen zum Status Einholung der Werbemengen / Allg. Mengeneinholung - manuelle Beladung');
