CREATE TABLE IF NOT EXISTS dbp_data.aktivitaetsbereich_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
lagernummer_id STRING(4) NOT NULL OPTIONS(description='Lagernummer'),
aktivitaetsbereich_id STRING(4) NOT NULL OPTIONS(description='Aktivitätsbereich'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache'),
aktivitaetsbereich_bez STRING(40) OPTIONS(description='Bezeichnung'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration')
) OPTIONS(description='Aktivitätsbereich - Bezeichnung');
