--==============================================================
-- Table: amx_de_b_process_pruefung_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: amx_de_b_process_pruefung_zu
   generated from Powerdesigner on Wednesday, February 14, 2024 10:50:35 AM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.amx_de_b_process_pruefung_zu (
business_process_id INT64 NOT NULL OPTIONS(description='Eindeutige ID des Geschäftsprozesses'),
pruefung_id INT64 NOT NULL OPTIONS(description='Eindeutige ID der Prüfung'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (business_process_id, pruefung_id) NOT ENFORCED
)
OPTIONS(description='KMR - Audimex. Bildet n:m Beziehungen für business_process_id und Pruefungen ab für Kurzcheck DE Daten');
