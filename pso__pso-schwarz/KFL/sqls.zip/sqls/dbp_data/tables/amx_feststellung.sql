CREATE TABLE IF NOT EXISTS dbp_data.amx_feststellung (
feststellung_id INT64 NOT NULL,
amx_system_id INT64 DEFAULT -1 NOT NULL,
pruefung_id INT64 DEFAULT -1 NOT NULL,
pruef_kapitel_id INT64 DEFAULT -1 NOT NULL,
amx_frage_id INT64 DEFAULT -1 NOT NULL,
feststellung_bez STRING(255) COLLATE 'und:ci' DEFAULT ' ' NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
