--==============================================================
-- Table: amx_l_pruefung_klasse
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: amx_l_pruefung_klasse
   generated from Powerdesigner on Wednesday, February 14, 2024 10:50:35 AM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.amx_l_pruefung_klasse (
pruefung_klasse_id INT64 NOT NULL
OPTIONS(description='Eindeutige ID der Prüfungsklasse aus dem Quellfeld ID'),
amx_system_id INT64 DEFAULT -1 NOT NULL
OPTIONS(description='Unterscheidung zw. Den unterschiedlichen AMX Systemen. 1 = OneAudimex / 2 = KL Audimex'),
pruefung_klasse_bez STRING(50) COLLATE 'und:ci' DEFAULT ' ' NOT NULL
OPTIONS(description='Bezeichnung der Prüfungsklasse aus dem Quellfeld name, z.Bsp. Revision Vertrieb'),
amx_grp_id INT64
OPTIONS(description='Gruppierung zusammengehöriger Elemente aus den unterschiedlichen AMX Systemen            '),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (pruefung_klasse_id, amx_system_id) NOT ENFORCED
) OPTIONS(description='VIS audimex - Lookup Tabelle der Prüfungs-Klassen aus der Quelltabelle audimex.auditing_class');
