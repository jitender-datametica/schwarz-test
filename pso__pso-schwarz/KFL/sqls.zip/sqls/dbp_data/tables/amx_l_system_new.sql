CREATE TABLE IF NOT EXISTS dbp_data.amx_l_system_new (
amx_system_id BIGNUMERIC(38,0) NOT NULL,
amx_system_bez STRING(20) COLLATE 'und:ci',
td_insert TIMESTAMP,
td_update TIMESTAMP
);