--==============================================================
-- Table: anlage_kostenstelle_zu_per
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: anlage_kostenstelle_zu_per
   generated from Powerdesigner on Wednesday, February 14, 2024 10:50:35 AM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.anlage_kostenstelle_zu_per (
anlage_id STRING(20) NOT NULL OPTIONS(description='ID der Anlagen Hauptnummer aus anln1'),
anlage_sub_id INT64 NOT NULL OPTIONS(description='ID der Anlagen Unternummer aus anln2'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
buchungskreis_id INT64 NOT NULL
OPTIONS(description='Zuordnung des Buchungskreises zu dem WUP über die SAP Quelle T001K und T001. Der Buchungskreis entspricht unter dem Mandanten einer Zusammenfassung von Werken (Hierarchie: Mandant, Buchungskreis, Werk/Betrieb). Bsp: Buchungskreis 282 entspricht Kaufland'),
dat_von DATE NOT NULL OPTIONS(description='Beginn der Gültigkeitsperiode '),
dat_bis DATE NOT NULL
OPTIONS(description='Datum, bis zu dem die Zuordnung gültig ist. Bei aktiven Zuordnungen ist der 31.12.9999 eingetragen'),
kostenstelle_id STRING(10) NOT NULL OPTIONS(description='ID der Kostenstelle, z.Bsp. 9676-400'),
geschaeftsbereich_id STRING(4) NOT NULL
OPTIONS(description='Der Geschaeftsbereich ist eine interne Organisationseinheit, fuer den eine interne Bilanz sowie Gewinn- und Verlustrechnung erstellt werden kann. Aus gsber'),
system_id INT64 OPTIONS(description='Spezifiziert das Quellsystem, aus dem die Daten kommen.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (anlage_id, anlage_sub_id, mandant_id, buchungskreis_id, dat_von) NOT ENFORCED
) OPTIONS(description='IMS - Historisierte Zuordnung der Kostenstelle zur Anlage aus der SAP-Quelle anlz');
