
CREATE TABLE IF NOT EXISTS dbp_data.anlieferung_management_det (
mandant_id INT64 NOT NULL,
anlieferung_id STRING(20) COLLATE 'und:ci' NOT NULL,
best_beleg_id INT64 NOT NULL,
lagernummer_id STRING(3) COLLATE 'und:ci' NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
retoure_fg INT64 DEFAULT 0,
palettiert_fg INT64 DEFAULT 0,
werbung_fg INT64 DEFAULT 0,
menge_palette_ist INT64,
menge_palette_soll INT64 DEFAULT 0 NOT NULL,
gp_id INT64 DEFAULT -1 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
