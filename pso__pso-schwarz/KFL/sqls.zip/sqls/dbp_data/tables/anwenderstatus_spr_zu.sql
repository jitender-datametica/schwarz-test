CREATE TABLE IF NOT EXISTS dbp_data.anwenderstatus_spr_zu (
mandant_id INT64 NOT NULL,
anwenderstatus_id STRING(5) COLLATE 'und:ci' NOT NULL,
spr_id INT64 NOT NULL,
system_id INT64 NOT NULL,
anwenderstatus_bez_kurz STRING(4) COLLATE 'und:ci',
anwenderstatus_bez STRING(30) COLLATE 'und:ci',
td_insert TIMESTAMP,
td_update TIMESTAMP
);
