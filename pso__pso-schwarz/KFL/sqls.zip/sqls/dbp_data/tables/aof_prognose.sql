CREATE TABLE IF NOT EXISTS dbp_data.aof_prognose (
mandant_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
art_id INT64 NOT NULL,
zeitreihenart STRING(10) COLLATE 'und:ci' NOT NULL,
dat_prognoselauf DATE NOT NULL,
dat DATE NOT NULL,
menge NUMERIC(29,3) DEFAULT 0 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
) PARTITION BY dat
CLUSTER BY art_id, wup_id, mandant_id;
