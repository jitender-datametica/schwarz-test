--==============================================================
-- Table: art_backen_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: art_backen_spr_zu
   generated from Powerdesigner on Tuesday, February 20, 2024 3:55:29 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.art_backen_spr_zu (
art_id INT64 NOT NULL
OPTIONS(description='Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter) Regel: Neuer Artikel -> Counter +1'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache            '),
art_backen_bez STRING(50) COLLATE 'und:ci' OPTIONS(description='Artikelbezeichnung speziell für den Backshop'),
feierabend_fg INT64 DEFAULT 0 NOT NULL,
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (art_id, mandant_id, spr_id) NOT ENFORCED
) OPTIONS(description='VIS Backshop - Im Backshop werden von den Stammdaten abweichende Artikelbezeichnungen verwendet');
