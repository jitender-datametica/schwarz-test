CREATE TABLE IF NOT EXISTS dbp_data.art_bestand_vw_sum (
mandant_id INT64 NOT NULL,
vw_id INT64 NOT NULL,
bezugsweg_id INT64 NOT NULL,
lagerbestand_fg INT64 NOT NULL,
nb_id INT64 NOT NULL,
art_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
dat DATE NOT NULL,
gp_id INT64 NOT NULL,
relevant_fg INT64 NOT NULL,
wrg_id STRING(3) COLLATE 'und:ci' DEFAULT 'EUR' NOT NULL,
menge_lgbest_erp_frei_bme NUMERIC(29,3) NOT NULL,
menge_lgbest_erp_qual_bme NUMERIC(29,3) NOT NULL,
menge_lgbest_erp_gesamt_bme NUMERIC(29,3) NOT NULL,
betrag_vk_netto_frei_bme NUMERIC(29,4),
betrag_vk_netto_qual_bme NUMERIC(29,4),
betrag_vk_netto_gesamt_bme NUMERIC(29,4),
menge_abgang_bme NUMERIC(29,3),
betrag_vk_netto_abgang NUMERIC(29,4) DEFAULT 0 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
) PARTITION BY dat
CLUSTER BY mandant_id, lagerbestand_fg, nb_id, art_id;
