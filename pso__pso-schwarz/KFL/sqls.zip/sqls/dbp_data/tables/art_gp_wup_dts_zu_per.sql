--==============================================================
-- Table: art_gp_wup_dts_zu_per
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: art_gp_wup_dts_zu_per
   generated from Powerdesigner on Montag, 16. Januar 2023 16:15:43
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.art_gp_wup_dts_zu_per (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH.'),
wup_id INT64 NOT NULL OPTIONS(description='Filialnummer und werksbezogene Kundennummer.'),
nb_id INT64 OPTIONS(description='Nebenbetriebskennziffer.'),
art_id INT64 NOT NULL
OPTIONS(description='Input: Artikel-ID einschließlich der Generationen-ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige Artikel-ID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter). Regel: Neuer Artikel -> Counter +1.'),
gp_id INT64 NOT NULL OPTIONS(description='Geschäftspartner-ID (GP) / Lieferanten-ID.'),
loesch_fg INT64 NOT NULL
OPTIONS(description='Flag: Löschkennzeichen. Gibt an, ob dieser Eintrag in SAP zum Löschen markiert wurde.'),
dat_von DATE NOT NULL OPTIONS(description='Gültig von.'),
dat_bis DATE OPTIONS(description='Gültig bis.'),
verkaufsorganisation_id STRING(4) NOT NULL
OPTIONS(description='Organisatorische Einheit, die für den Vertrieb bestimmter Produkte oder Dienstleistungen verantwortlich ist, z.B. KL = Kaufland.'),
vw_id INT64 NOT NULL
OPTIONS(description='ID des Vertriebswegs. Einkaufs-Sicht auf die wup Objekte. 1 = Ost, 2 = West, 3 = Nord.'),
auslieferungsgruppe_id STRING(4)
OPTIONS(description='ID der Auslieferungsgruppe. Eine Auslieferungsgruppe (manchmal auch Ausliefergruppe) ist eine Bündelung von Artikeln mit gleichen Eigenschaften Aufgrund welchen sie zusammen ausgeliefert werden können, VZ in Richtung Filiale. Z.B.: Food Trocken (Mehl, Konserven, Nudeln), Tiefkühlware (Fisch, Pizza, Eis, Tiefkühlgemuese), etc.'),
dispoteilsortiment_id STRING(9)
OPTIONS(description='Beschaffungsinformationen Dispoteilsortiment (DTS) - SAP Tabelle ZE1WBB06 Feld ZDTS. Der Inhalt ergibt sich aus der Verkettung der Auslieferungsgruppe (z. B. 300 = Food) und den Terminierungsgruppen (nicht sprechendes Gruppierungsmerkmal das Lieferzyklen innerhalb der Auslieferungsgruppe steuert).'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, wup_id, art_id, gp_id, loesch_fg, dat_von) NOT ENFORCED
)
OPTIONS(description='SCM - Filialversorgung Zuordnung Beschaffungszyklen aus ZE1WBB06. SAP lädt die Daten täglich neu ohne sie zu historisieren, was über diese Tabelle hier gelöst wird.');
