create table if not exists `dbp_data.art_gp_wup_zu_per_120825`
(
  mandant_id int64 not null options(description="mandant im dwh."),
  gp_id int64 not null options(description="geschäftspartner-id (lieferanten-id)."),
  wup_id int64 not null options(description="der wup beinhaltet märkte und läger. wup = warenumschlagsplatz, mutter wup-id wird verwendet für beziehung lager zu verteilzentrum."),
  nb_id int64 options(description="im bisherigen system die 4 stelle der marktnummer die nebenbetriebskennziffer."),
  dat_von date not null options(description="beginn der gültigkeitsperiode."),
  bezugsweg_id int64 not null options(description="kennzeichnet, ob der artikel vom zentrallager bezogen wird (bezugsweg = 4) oder direkt vom lieferanten (bezugsweg = 1)."),
  art_id int64 not null options(description="input: artikel - id einschliesslich der generationen - id (9-stellig); output: 7stellige l&s-id + counter = 8stellige artikelid. wwnnnnpc (warengruppe, nummer, prüfziffer, counter) regel: neuer artikel -> counter +1."),
  einkaufsorganisation_id int64 options(description="aus ekorg. die einkaufsorganisation_id ist erforderlich um einen lieferanten der tabelle gp zusammen mit dem attribut gp_id eindeutig zu identifizieren. 1000 = warenlieferant, 5000 = frischelieferant, 9000 = (?) könnte es auch geben."),
  dat_bis date options(description="datum, bis zu dem die zuordnung gilt. bei bestehenden zuordnungen: 9999-12-31."),
  ek_brutto numeric(18, 4) options(description="einkaufspreis brutto (bedeutung vgl. kalkulationsschema) aus abrut. tatsächlicher einkaufspreis. verwendet den aktionspreis, wenn vorhanden, ansonsten den normalpreis."),
  ek_netto numeric(18, 4) options(description="einkaufspreis netto (bedeutung vgl. kalkulationsschema), aus aknet."),
  ek_nettonetto numeric(18, 4) options(description="einkaufspreis nettonetto (bedeutung vgl. kalkulationsschema), aus aknne."),
  ek_kal_basis numeric(18, 4) options(description="kalkulationsbasis (bedeutung vgl. kalkulationsschema), aus ekkba."),
  ek_mep numeric(18, 4) options(description="markteinstandspreis ((bedeutung vgl. kalkulationsschema), aus mepre."),
  einstandspreis numeric(18, 4) options(description="kaufland einstandspreis (bedeutung vgl. kalkulationsschema), aus lsein.\n            ergibt sich aus dem einkaufspreis netto einer ware zuzüglich der beschaffungskosten oder bezugskosten und abzüglich der minderungen, etwa durch rabatt, skonto, bonus."),
  logistikkostenzuschlag numeric(18, 4) options(description="logistikkostenzuschlag (ein kalkulierter wert für die zentrallagerkosten, der bei zentraler lieferung bestandteil einiger einstandspreise ist), aus lokau."),
  wrg_id string(3) collate 'und:ci' options(description="kurzbezeichnung der währung, z.bsp. czk, eur."),
  komponentenmenge numeric(18, 4) options(description="menge des inhalts bei strukturierten artikeln (display) - aber nicht pfandartikeln. bei nicht strukturierten artikeln ist der wert = 1. die ek-preise werden mit diesem wert multipliziert, um zu einem gesamt-ek pro artikel zu kommen. aus kompmeng."),
  ek_brutto_nrfb_rab numeric(18, 4) options(description="einkaufspreis brutto abzgl. nicht-rabattfähiger betrag abzgl. artikelrabatte, aus abrna. verwendet den aktionspreis, wenn vorhanden, ansonsten den normalpreis."),
  bonusbasis numeric(18, 4) options(description="in sap auch ak-netto-nrfb genannt. aus abonba. verwendet den aktionspreis, wenn vorhanden, ansonsten den normalpreis."),
  bezugsnebenkosten numeric(18, 4) options(description="summe der bezugsnebenkosten, aus bnk."),
  zollwert numeric(9, 4) options(description="zollwert, betrifft vor allem importartikel. aus zollba."),
  ek_netto_bnk numeric(18, 4) options(description="einkaufspreis netto plus bezugsnebenkosten, aus akbn. verwendet den aktionspreis, wenn vorhanden, ansonsten den normalpreis."),
  ek_netto_bnk_sachk numeric(18, 4) options(description="einkaufspreis netto plus bezugsnebenkosten plus sachkosten, aus akbns. verwendet den aktionspreis, wenn vorhanden, ansonsten den normalpreis."),
  cycle_id int64 options(description="technisches hilfsfeld. zur feststellung der herkunft des satzes (loadfile, datum)."),
  td_insert timestamp options(description="technical fields for synchronisation framework. will be delted after last product migration"),
  td_update timestamp options(description="technical fields for synchronisation framework. will be delted after last product migration"),
  ek_mep_vor_fwu numeric(29, 4) options(description="markteinstandspreis vor festwertumlage: mit einführung der festwertumlage in kmo braucht es einenalten ek3netto ohne die festwertumlage als vergleichswert. dieser wert wird aus sap über zekp.mepol geliefert."),
  ek_brutto_normal numeric(29, 4) options(description="einkaufspreis brutto ohne aktionskonditionen (bedeutung vgl. kalkulationsschema). aus ebrut. der normalpreis / listenpreis."),
  primary key (mandant_id, gp_id, wup_id, dat_von, bezugsweg_id, art_id) not enforced
)
cluster by mandant_id
options(
  description="tp2 ais - artikel geschäftspartner markt zuordnung."
);
