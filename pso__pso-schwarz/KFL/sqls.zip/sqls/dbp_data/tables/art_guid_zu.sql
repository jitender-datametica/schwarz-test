CREATE TABLE IF NOT EXISTS `dbp_data.art_guid_zu` (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
art_guid_c22 STRING(22) NOT NULL OPTIONS(description='Materialnummer CHAR 22'),
art_guid STRING(32) OPTIONS(description='Materialnummer RAW 16'),
art_id INT64
OPTIONS(description='Artikelnummer im DWH. Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter) Regel: Neuer Artikel -> Counter +1'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration')
) OPTIONS(description='Zuordnung Artikel GUID zu Artikelnummer');
