create table if not exists `dbp_data.art_ipn_zu`
(
  ipn_id INT64 NOT NULL OPTIONS(description="Internationale Produktnummer"),
  gtin_id INT64 NOT NULL OPTIONS(description="Die Global Trade Item Number (GTIN) ist eine aus dem GS1-System (vormals EAN-System) stammende Identifikationsnummer, mit der Handelseinheiten ausgezeichnet werden können"),
  gtin_typ_kz STRING(2) COLLATE 'und:ci' OPTIONS(description="Nummerntyp der GTIN(Global Trade Item Number)"),
  loesch_fg INT64 OPTIONS(description="Löschvermerk"),
  td_insert TIMESTAMP OPTIONS(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  td_update TIMESTAMP OPTIONS(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  PRIMARY KEY (ipn_id, gtin_id) NOT ENFORCED
)
OPTIONS(
  description="TP2_AIS - Zuordnungstabelle IPN (Internationale Produkt Nummer) zu GTIN"
);
