CREATE TABLE IF NOT EXISTS dbp_data.art_lagernummer_zu_per (
mandant_id INT64 NOT NULL,
lagernummer_id STRING(3) COLLATE 'und:ci' NOT NULL,
art_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
dat_von DATE NOT NULL,
lager_bereich_kz STRING(3) COLLATE 'und:ci',
einlager_typ_kz STRING(3) COLLATE 'und:ci' DEFAULT '   ' NOT NULL,
lager_einheiten_typ STRING(3) COLLATE 'und:ci',
kapazitaet_verbrauch NUMERIC(29,3) DEFAULT 0 NOT NULL,
anz_ladtraeger_max INT64 DEFAULT 0 NOT NULL,
stellplatz_faktor NUMERIC(29,2) DEFAULT 1 NOT NULL,
zlv_ladhilf_fg INT64 DEFAULT 0 NOT NULL,
dat_bis DATE NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
