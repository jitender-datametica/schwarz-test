CREATE TABLE IF NOT EXISTS dbp_data.art_lagerplatz_tag (
art_id INT64 NOT NULL,
mandant_id INT64 NOT NULL,
dat DATE NOT NULL,
lagerplatz_id STRING(10) COLLATE 'und:ci' NOT NULL,
lagernummer_id STRING(3) COLLATE 'und:ci' NOT NULL,
lagertyp_id STRING(3) COLLATE 'und:ci' NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
mlgt_fg INT64 NOT NULL,
bestand_kz INT64,
lagerplatz_loesch_kz INT64 NOT NULL,
system_id INT64 DEFAULT 14 NOT NULL,
anzahl_quant INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
) PARTITION BY dat
CLUSTER BY mandant_id;
