CREATE TABLE IF NOT EXISTS dbp_data.art_spr_zu (
    mandant_id INT64 NOT NULL OPTIONS(description= 'Mandant im DWH'),
    art_id INT64 NOT NULL OPTIONS(description= 'Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter) Regel: Neuer Artikel -> Counter +1'),
    spr_id INT64 NOT NULL OPTIONS(description= 'ID der Sprache '),
    art_bez STRING(200) COLLATE 'und:ci' OPTIONS(description= 'Artikelbezeichnung aus SAP Retail.'),
    int_art_bez STRING(200) COLLATE 'und:ci' OPTIONS(description= 'Artikelbezeichnung aus ZSM, Diese können von SAP Retail Bezeichnungen abweichen.(ZSM:Zentrale Stammdaten Management, das verteilt die Bezeichnungen an SAP Retail, das diese überschreiben kann.)'),
    td_update TIMESTAMP OPTIONS(description= 'Technical fields for synchronisation framework. Will be delted after last product migration'),
    td_insert TIMESTAMP OPTIONS(description= 'Technical fields for synchronisation framework. Will be delted after last product migration'),
     primary key (mandant_id, art_id, spr_id) NOT ENFORCED
)OPTIONS(description='TP2_AIS - Sprachabhaengige Bezeichnungen der Artikel')
;
