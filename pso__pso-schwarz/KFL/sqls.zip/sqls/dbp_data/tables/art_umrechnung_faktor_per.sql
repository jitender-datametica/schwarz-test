--==============================================================
-- Table: art_umrechnung_faktor_per
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: art_umrechnung_faktor_per
   generated from Powerdesigner on Montag, 27. Januar 2025 17:12:48
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.art_umrechnung_faktor_per (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
altnv_menge_einh_id STRING(3) NOT NULL
OPTIONS(description='Id der alternativen Mengeneinheit. Anhand dieser ID wird pro Mandant und Artikel eine alternative Mengeneinheit eindeutig identifiziert.Aus meinh'),
art_id INT64 NOT NULL
OPTIONS(description='Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter) Regel: Neuer Artikel -> Counter +1'),
dat_von DATE NOT NULL
OPTIONS(description='Gültigkeitbeginn für diesen Datensatz. Es wird dazu das Datum aus dem Dateinamen der Schnittstelle herangezogen.'),
bruttogew NUMERIC(29,3) NOT NULL
OPTIONS(description='Das Feld  enthält das Bruttogewicht in der in dem Attribut gew_einh_id aufgeführten Einheit. Aus brgew'),
umrech_faktor BIGNUMERIC(38, 22) NOT NULL
OPTIONS(description='Umrechnungsfaktor für eine alternative Mengenheinheit zur Umrechnung einer Basismenge in diese Mengeneinheit.'),
gew_einh_id STRING(3) NOT NULL OPTIONS(description='Dieses Feld enthält die Einheit für das Bruttogewicht.Aus gewei'),
dat_bis DATE NOT NULL
OPTIONS(description='Gültigkeitsende des Datensatzes. Wenn dieser Datensatz die momentan gültige Version darstellt besitzt dieses Attribut den Wert 31.12.9999.'),
laenge NUMERIC(29,3) DEFAULT 0 NOT NULL OPTIONS(description='Länge (Tiefe) in cm aus laeng'),
breite NUMERIC(29,3) DEFAULT 0 NOT NULL OPTIONS(description='Breite in cm aus breit'),
hoehe NUMERIC(29,3) DEFAULT 0 NOT NULL OPTIONS(description='Höhe in cm aus hoehe'),
umrech_zaehler INT64 OPTIONS(description='Zähler für die Umrechnung in Basismengeneinheiten'),
umrech_nenner INT64 OPTIONS(description='Nenner für die Umrechnung in Basismengeneinheiten'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, altnv_menge_einh_id, art_id) NOT ENFORCED
)
OPTIONS(description='TP408_LVS - In dieser Tabelle sind die Umrechnungsfaktoren in die alternative Lagereinheit für die einzelnen Artikel hinterlegt - MULTISET');
