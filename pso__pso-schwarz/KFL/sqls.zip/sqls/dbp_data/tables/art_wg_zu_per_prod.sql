create table if not exists `dbp_data.art_wg_zu_per_prod`
(
  mandant_id int64,
  dat_von date,
  art_id int64,
  arthiertyp_id int64,
  wg_id int64,
  dat_bis date,
  wug_id int64,
  td_update timestamp,
  td_insert timestamp
);
