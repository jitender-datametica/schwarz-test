CREATE TABLE IF NOT EXISTS dbp_data.art_wup_frplauf_per (
mandant_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
art_id INT64 NOT NULL,
dat_von DATE DEFAULT CAST('1900-01-01' AS DATE) NOT NULL,
dat_bis DATE DEFAULT CAST('9999-12-31' AS DATE),
standardabweichung NUMERIC(29,5),
klassifikationsmittelwert NUMERIC(29,6),
servicelevel NUMERIC(29,2),
mindestbestand NUMERIC(29,6),
bestand NUMERIC(29,6),
frp_mindestbestand NUMERIC(29,6),
zielbestand NUMERIC(29,6),
maximalbestand NUMERIC(29,6),
td_insert TIMESTAMP,
td_update TIMESTAMP
)PARTITION BY dat_von
CLUSTER BY mandant_id, art_id, wup_id, nb_id;
