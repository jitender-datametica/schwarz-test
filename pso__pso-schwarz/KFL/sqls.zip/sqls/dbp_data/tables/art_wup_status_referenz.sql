CREATE TABLE IF NOT EXISTS dbp_data.art_wup_status_referenz (
mandant_id INT64 NOT NULL,
art_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
art_id_ref INT64 DEFAULT -1 NOT NULL,
wup_id_ref INT64 DEFAULT -1 NOT NULL,
nb_id_ref INT64 DEFAULT 0 NOT NULL,
dat_bis_ref DATE DEFAULT CAST('9999-12-31' AS DATE) NOT NULL,
faktor_ref NUMERIC(29,2) DEFAULT 1 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
