CREATE TABLE IF NOT EXISTS dbp_data.artbew_agg_wt (
mandant_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
dat DATE NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
