create table if not exists `dbp_data.artbew_agg_wt_prod`
(
  mandant_id int64,
  wup_id int64,
  nb_id int64,
  dat date,
  td_insert timestamp,
  td_update timestamp
);
