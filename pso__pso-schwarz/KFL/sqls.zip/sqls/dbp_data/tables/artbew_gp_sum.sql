--==============================================================
-- Table: artbew_gp_sum
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: artbew_gp_sum
   generated from Powerdesigner on Mittwoch, 18. Dezember 2024 18:05:06
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.artbew_gp_sum (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant'),
dat DATE NOT NULL OPTIONS(description='Datum im Format JJJJ-MM-TT'),
gp_id INT64 NOT NULL OPTIONS(description='Geschäftspartner - ID (Lieferanten - ID)            '),
vw_id INT64 NOT NULL
OPTIONS(description='ID des Vertriebswegs. Einkaufs-Sicht auf die wup Objekte            1 = Ost            2 = West            3 = Nord'),
wrg STRING(3) COLLATE 'und:ci' NOT NULL OPTIONS(description='Währung, z.Bsp. EUR'),
umrechnungskurs_hist NUMERIC(29,5) DEFAULT 0 NOT NULL
OPTIONS(description='Historischer Berichtskurs aus dbp_data.kurs '),
umsatz_netto NUMERIC(29,4) NOT NULL OPTIONS(description='Umsatz vermindert um den Mehrwertsteuerbetrag'),
diff_umsatz_netto_konz NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='von der Konzernwährung abweichender Umsatz netto'),
ek_mep NUMERIC(29,4) NOT NULL OPTIONS(description='Markteinstandspreis ((Bedeutung vgl. Kalkulationsschema)'),
diff_ek_mep_konz NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='von der Konzernwährung abweichender Einkaufspreis Markteinstandspreis'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, dat, gp_id, vw_id) NOT ENFORCED
)
OPTIONS(description='TP2_AIS - Aggregatstabelle enthält Umsatz und MEP pro Lieferant, Vertriebsweg und Tag - MULTISET');
