CREATE TABLE IF NOT EXISTS dbp_data.artbew_gtin (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
wup_id INT64 NOT NULL OPTIONS(description='Markt'),
dat DATE NOT NULL OPTIONS(description='Datum, Format YYYY-MM-DD'),
art_id INT64 NOT NULL
OPTIONS(description='Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Prüfziffer, Counter) Regel: Neuer Artikel -> Counter +1'),
gp_id INT64 NOT NULL OPTIONS(description='Geschäftspartner - ID (Lieferanten - ID)'),
nb_id INT64
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
bewart_id INT64 NOT NULL OPTIONS(description='1001 AF, 1002 SA'),
aktion_id STRING(10) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Aktionsnummer wie von den Kassen gemeldet (bei Kassensystem POSITION über Stammdaten angereichert)'),
promo_fg INT64 NOT NULL
OPTIONS(description='Das Promotion-Flag kennzeichnet einen Promotion-Artikel (z.Bsp. 3 für 2)'),
ean_kasse NUMERIC(29) NOT NULL OPTIONS(description='von den Kassensystemen gelieferte EAN'),
herst_id INT64 OPTIONS(description='Hersteller fall abweichend zum Lieferanten'),
mwst_id INT64 NOT NULL OPTIONS(description='Schlüssel des Mehrwertsteuersatzes'),
wrg STRING(3) COLLATE 'und:ci' OPTIONS(description='Währung, in der der Umsatz erzielt wurde'),
menge NUMERIC(29,3)
OPTIONS(description='Menge der Artikelbewegung (kann in Stück oder bei Gewichtsartikeln in KG sein)'),
umsatz_netto NUMERIC(29,4) OPTIONS(description='Umsatz vermindert um den Mehrwertsteuerbetrag'),
diff_umsatz_netto_konz NUMERIC(29,4) OPTIONS(description='von der Konzernwährung abweichender Umsatz netto'),
umsatz_mwst_betrag NUMERIC(29,4)
OPTIONS(description='Der Mehrwertsteuerbetrag wird hier redundant abgelegt. Er ist eigentlich pro Artikel als Mehrwertsteuersatz im Artikelstamm ersichtlich muss aber hier aus Performancegründen auch stehen.'),
diff_umsatz_mwst_betrag_konz NUMERIC(29,4)
OPTIONS(description='von der Konzernwährung abweichender Mehrwertsteuerbetrag'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, wup_id, dat, art_id, gp_id, bewart_id, promo_fg, ean_kasse) NOT ENFORCED
)
PARTITION BY dat
CLUSTER BY mandant_id, dat
OPTIONS(description='Aggregat aus Bons aller Länder (auch für POSITION statt WPUUMS). Benötigt für Marktforschungsinstitute, die Abverkäufe auf Ebene GTIN brauchen. Tabelle nicht mehr relevant wenn Umstellung auf KPOS ausgerollt.');
