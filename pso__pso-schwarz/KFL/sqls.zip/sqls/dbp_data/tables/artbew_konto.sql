create table if not exists `dbp_data.artbew_konto`(
    mandant_id INT64 not null,
    wup_id INT64 not null,
    konto_id INT64 not null,
    bewart_id INT64 not null,
    nb_id INT64 not null,
    arthiertyp_id INT64 not null,
    umsatz_brutto NUMERIC(29,2),
    umsatz_netto NUMERIC(29,2),
    umsatz_wrg string(3) collate 'und:ci',
    umsatz_brutto_konz NUMERIC(29,2),
    umsatz_netto_konz NUMERIC(29,2),
    kjmo INT64,
    td_insert timestamp,
    td_update timestamp
);
