--==============================================================
-- Table: artbew_wg_sum
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: artbew_wg_sum
   generated from Powerdesigner on Mittwoch, 18. Dezember 2024 18:05:06
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.artbew_wg_sum (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
arthiertyp_id INT64 NOT NULL
OPTIONS(description='Artikel - Hierarchie - Typ - ID: kennzeichnet, ob es sich um eine Hierarchie mit zwei- oder dreistelligen Warengruppen  handelt'),
wg_id INT64 NOT NULL OPTIONS(description='ID der Warengruppe'),
umrechnungskurs_hist NUMERIC(29,5) DEFAULT 0 NOT NULL
OPTIONS(description='Historischer Berichtskurs aus dbp_data.kurs '),
dat DATE NOT NULL OPTIONS(description='Datum, zu dem der Umsatz entstanden ist, im Format YYYY-MM-DD'),
wup_id INT64 NOT NULL OPTIONS(description='Nummer des Warenumschlagsplatzes'),
bewart_id INT64 NOT NULL
OPTIONS(description='Bewegungsart ID. Bewegungsarten > 1000 beziehen sich auf Warenausgang, < 1000 auf Wareneingang'),
kjmo INT64 NOT NULL OPTIONS(description='Kalenderjahremonat, Format JJJJMM'),
umsatz_brutto NUMERIC(29,4) NOT NULL OPTIONS(description='Umsatz incl. Mehrwertsteuerbetrag            '),
umsatz_netto NUMERIC(29,4) NOT NULL OPTIONS(description='Umsatz vermindert um den Mehrwertsteuerbetrag            '),
umsatz_wrg STRING(3) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Kurzbezeichnung der Währung, in der der Umsatz erzielt wurde, z.Bsp. CZK, EUR'),
umsatz_brutto_konz NUMERIC(29,4) NOT NULL OPTIONS(description='Umsatz brutto in der Konzernwährung'),
umsatz_netto_konz NUMERIC(29,4) NOT NULL OPTIONS(description='Umsatz netto in der Konzernwährung'),
quelle INT64 DEFAULT 0,
menge NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='ab KW46/12: Hier sind Mengen verschiedener Basismengeneinheiten (Stück und Gewichtsartikel) kumuliert enthalten. Sinnvoll ist das nicht, aber der FB (Vertrieb) will es so.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, nb_id, arthiertyp_id, wg_id, dat, wup_id, bewart_id) NOT ENFORCED
) 
CLUSTER BY mandant_id, bewart_id, wup_id, nb_id
OPTIONS(description='TP1 MIS - Aggregationstabelle artbew auf Ebene Warengruppe/Markt/Datum - MULTISET');
