--==============================================================
-- Table: artkz_display
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: artkz_display
   generated from Powerdesigner on Tuesday, February 20, 2024 3:55:28 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.artkz_display (
display_id INT64 NOT NULL
OPTIONS(description='Schlüssel des Artikelkennzeichens Display (0 = kein Displayartikel'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache            '),
display_bez STRING(80) COLLATE 'und:ci' OPTIONS(description='Bezeichnung des Artikelkennzeichens Display'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (display_id, mandant_id) NOT ENFORCED
) OPTIONS(description='TP2_AIS - Lookup Artikelkennzeichen Display');
