--==============================================================
-- Table: artkz_posten
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: artkz_posten
   generated from Powerdesigner on Sonntag, 4. Februar 2024 11:45:01
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.artkz_posten (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
posten_id STRING(2) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Eindeutige Kennzeichnung des Postenartikels, z.Bsp. PN'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache.'),
posten_bez STRING(40) COLLATE 'und:ci' OPTIONS(description='Sprachabhaengige Bezeichnung des Postenkennzeichens.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, spr_id) NOT ENFORCED
) OPTIONS(description='TP2_AIS - Lookuptabelle fuer das Artikelkennzeichen Postenartikel');
