CREATE TABLE IF NOT EXISTS dbp_data.as_food (
art_id INT64 NOT NULL OPTIONS(description='Artikelnummer im DWH'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
wup_id INT64 NOT NULL
OPTIONS(description='Mutter Wup ID wird verwendet für Beziehung Lager zu Verteilzentrum'),
dat_auslistung DATE NOT NULL OPTIONS(description='Das Datum der Auslistung aus dem Quellfeld aldat'),
gp_id INT64 DEFAULT -1 NOT NULL OPTIONS(description='Geschaeftspartner - ID (Lieferanten - ID)'),
wrg_id STRING(3) OPTIONS(description='Kurzbezeichnung der Waehrung, z.Bsp. CZK, EUR'),
phase_status INT64 DEFAULT -1 NOT NULL OPTIONS(description='Vermarktungsstatus aus dem Quellfeld vstatus'),
erl_fg INT64 DEFAULT 0 NOT NULL
OPTIONS(description='Erledigt Flag aus dem Quellfeld erlkz (0=(\'\',\'B\'); restlichen Auspraegungen = 1 (\'A\',\'C\',\'D\';\'E\',\'F\',\'G\',\'X\'))'),
dat_final DATE OPTIONS(description='Datum Laufzeitende aus dem Quellfeld final'),
menge_startbestand NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='Redundant. Aus Tabelle marktbestand_erp ermittelte Menge'),
vk_netto NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Redundant. Verkaufspreis netto aus der Tabelle marktbestand_erp_zu'),
menge_endbestand NUMERIC(29,4) DEFAULT 0 NOT NULL OPTIONS(description='Endbestand'),
erl_kz STRING(1) COLLATE 'und:ci' DEFAULT ' ' NOT NULL
OPTIONS(description='Redundant zu "erl_fg" die einzelnen Auspraegungen (Erledigt Flag aus dem Quellfeld erlkz (0=(\'\',\'B\'); restlichen Ausprägungen = 1 (\'A\',\'C\',\'D\';\'E\',\'F\',\'G\',\'X\')))'),
dat_aend DATE OPTIONS(description='Aenderungsdatum'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (art_id, mandant_id, nb_id, wup_id, dat_auslistung) NOT ENFORCED
) OPTIONS(description='AIS - Auslistungs-Schema Kopftabelle aus der Quelltabelle zrs_rvdata');
