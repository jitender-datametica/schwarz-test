--==============================================================
-- Table: as_food_det
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: as_food_det
   generated from Powerdesigner on Freitag, 25. Juli 2025 15:11:33
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.as_food_det (
art_id INT64 NOT NULL OPTIONS(description='Artikelnummer im DWH'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
wup_id INT64 NOT NULL
OPTIONS(description='Mutter Wup ID wird verwendet für Beziehung Lager zu Verteilzentrum'),
dat_auslistung DATE NOT NULL OPTIONS(description='Das Datum der Auslistung aus dem Quellfeld aldat'),
kjwo INT64 DEFAULT 0 NOT NULL OPTIONS(description='Kalenderjahreswoche. Format JJJJWW'),
phase_wo INT64 NOT NULL
OPTIONS(description='Kalenderjahreswoche. Format JJJJWW. Wird aus dem Quellfeld alweek befüllt. Referenz zur Tabelle woche'),
wrg_id STRING(3) COLLATE 'und:ci' OPTIONS(description='Kurzbezeichnung der Waehrung, z.Bsp. CZK, EUR'),
erl_kz STRING(1) NOT NULL OPTIONS(description='Erledigtkennzeichen aus SAP; Quelle: zrs_vrdata/erlkz'),
dat_final DATE OPTIONS(description='Datum Laufzeitende aus dem Quellfeld final'),
as_final_status_id INT64
OPTIONS(description='Klassifizierung der Datensätze nach Status des ausgelisteten Sortiments nachdem dat_final vorhanden ist. 0 = default / Kein Restbestand ; 1 = Absatz, trotz Finaldatum; 2 = Finaldatum, aber keine ERL-KZ = D (Abschrift)'),
phase_id INT64 NOT NULL OPTIONS(description='ID ergibt sich aus ALWEEK (ID = 0), WEEK01 (ID = 1), usw'),
phase_vk_brutto NUMERIC(29,2) DEFAULT 0 NOT NULL
OPTIONS(description='Verkaufspreis brutto aus dem Quellfeld vkpr01,vkpr02 usw. (VK der jeweiligen Phase) - Wert bezieht sich auf komplette Phase'),
phase_vk_netto NUMERIC(29,2) NOT NULL
OPTIONS(description='wird aus phase_vk_brutto errechnet (reduziert um MwSt-Betrag) - Wert bezieht sich auf komplette Phase'),
menge_totalabschrift NUMERIC(29,3) NOT NULL
OPTIONS(description='Menge der Totalabschriften (für DE AKZ = 122; KMO aus DWH-Tabelle marktabschriften)'),
betrag_totalabschrift_netto NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Betrag netto der Totalabschriften (für DE AKZ = 122; KMO aus DWH-Tabelle marktabschriften)'),
menge_preisabschrift NUMERIC(29,3) NOT NULL
OPTIONS(description='Menge der Preisabschriften (für DE AKZ = 22; KMO aus DWH-Tabelle marktabschriften)'),
betrag_preisabschrift_netto NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Betrag netto der Preisabschriften (für DE AKZ = 22; KMO aus DWH-Tabelle marktabschriften)'),
menge_endbestand_phase NUMERIC(29,3) NOT NULL
OPTIONS(description='Endbestand pro Phasenende - Wert bezieht sich nicht auf KJWO, sondern Ende der Phase'),
menge_endbestand NUMERIC(29,3)
OPTIONS(description='Endbestand pro Kalenderwoche - aus DWH-Tabelle marktbestand_erp. In der laufenden Woche beinhaltet die Spalte den Bestand des Vortages, in allen vergangenen Kalenderwochen, den Endbestand dieser KJWO.'),
menge_absatz NUMERIC(29,3) NOT NULL
OPTIONS(description='Menge des Absatz - aus DWH-Tabelle artbew (dient zum tagesgenauen Auslesen der Absaetze fuer die laenderspezifischen Phasenzeitraeume)'),
umsatz_netto NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Umsatz vermindert um den Mehrwertsteuerbetrag - aus DWH-Tabelle artbew (dient zum tagesgenauen Auslesen der Umsaetze fuer die laenderspezifischen Phasenzeiträume)'),
betrag_ek_nettonetto NUMERIC(29,4)
OPTIONS(description='Summe der Einkaufspreise nettonetto (Bedeutung vgl. Kalkulationsschema). - Wert aus DWH-Tabelle artbew_wo_sum.'),
betrag_ek_mep NUMERIC(29,4)
OPTIONS(description='Summe der Markteinstandspreise (Bedeutung vgl. Kalkulationsschema). - aus DWH-Tabelle artbew_wo_sum.'),
betrag_einstandspreis NUMERIC(29,4)
OPTIONS(description='Summe der Kaufland Einstandspreis (Bedeutung vgl. Kalkulationsschema). - aus DWH-Tabelle artbew_wo_sum.'),
betrag_logkostenzuschlag NUMERIC(29,4)
OPTIONS(description='Summe der Logistikkostenzuschläge (ein kalkulierter Wert für die Zentrallagerkosten, der bei zentraler Lieferung Bestandteil einiger Einstandspreise ist). -aus DWH-Tabelle artbew_wo_sum.'),
betrag_ek_mep_vor_fwu NUMERIC(29,4)
OPTIONS(description='Summe der Markteinstandspreise vor Festwertumlage: Mit Einführung der Festwertumlage in KMO braucht es einen "alten" EK3Netto ohne die Festwertumlage als Vergleichswert. Dieser Wert wird aus SAP über ZEKP.MEPOL geliefert.- aus DWH-Tabelle artbew_wo_sum.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (art_id, mandant_id, nb_id, wup_id, dat_auslistung, kjwo) NOT ENFORCED
) 
PARTITION BY dat_auslistung
CLUSTER BY mandant_id
OPTIONS(description='AIS - Auslistungs-Schema Detailtabelle aus der Quelltabelle zrs_rvdata');
