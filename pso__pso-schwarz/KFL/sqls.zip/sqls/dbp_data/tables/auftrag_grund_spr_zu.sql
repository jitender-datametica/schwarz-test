CREATE TABLE IF NOT EXISTS dbp_data.auftrag_grund_spr_zu (
mandant_id INT64 NOT NULL,
spr_id INT64 NOT NULL,
auftrag_grund_id STRING(3),
auftrag_grund_bez STRING(40),
td_update TIMESTAMP,
td_insert TIMESTAMP
);
