--==============================================================
-- Table: ausgeber_typ_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: ausgeber_typ_spr_zu
   generated from Powerdesigner on Tuesday, February 20, 2024 3:55:30 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.ausgeber_typ_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
ausgeber_typ_id STRING(3) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Typ des Ausgebers, es gibt z. Bsp. KDC, TIP und Filiale'),
spr_id INT64 NOT NULL OPTIONS(description='Nummer der Sprache'),
ausgeber_typ_bez STRING(40) COLLATE 'und:ci' OPTIONS(description='Bezeichnung des Ausgebertypen, z.Bsp. TIP'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, spr_id) NOT ENFORCED
) OPTIONS(description='VIS - sprachabhängige Bezeichnungen der Ausgebertypen');
