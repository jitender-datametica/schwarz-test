--==============================================================
-- Table: auslager_steuerung_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: auslager_steuerung_spr_zu
   generated from Powerdesigner on Mittwoch, 26. Januar 2022 08:20:33
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.auslager_steuerung_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
lagernummer_id STRING(4) COLLATE 'und:ci' NOT NULL OPTIONS(description='Lagernummer/Lagerkomplex'),
auslager_steuerung_id STRING(4) NOT NULL OPTIONS(description='Auslagerungssteuerung'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache            '),
auslager_steuerung_bez STRING(40) OPTIONS(description='Auslagerungssteuerung Bezeichnung'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration')
) OPTIONS(description='Description of Stock Removal Strategy (EWM)');
