CREATE TABLE IF NOT EXISTS dbp_data.autodispo_dif_tag (
	mandant_id INT64 NOT NULL,
	kunde_id INT64 NOT NULL,
	art_id INT64 NOT NULL,
	dat DATE NOT NULL,
	dat_ausfuehrung DATE NOT NULL,
	dif_typ_id INT64 NOT NULL,
	dif_status_id INT64,
	dif_wert NUMERIC(29,3),
	dif_kommentar STRING(100) COLLATE 'und:ci',
	sap_returncode STRING(255) COLLATE 'und:ci',
	td_insert TIMESTAMP,
	td_update TIMESTAMP
);
