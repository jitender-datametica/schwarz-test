--==============================================================
-- Table: avq_werbung_tag
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: avq_werbung_tag
   generated from Powerdesigner on Montag, 6. Oktober 2025 12:43:24
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.avq_werbung_tag (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
wup_id INT64 NOT NULL
OPTIONS(description='Mutter Wup ID wird verwendet für Beziehung Lager zu Verteilzentrum.'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer.'),
art_id INT64 NOT NULL
OPTIONS(description='Input: Artikel - Id einschliesslich der Generationen - ID (9-stellig); Output: 7stellige L&S-ID + Counter = 8stellige ArtikelID. WWNNNNPC (Warengruppe, Nummer, Pruefziffer, Counter) Regel: Neuer Artikel -> Counter +1.'),
dat_aktion_von DATE NOT NULL OPTIONS(description='Werbung/Aktion gültig ab'),
dat_aktion_bis DATE NOT NULL OPTIONS(description='Werbung/Aktion gültig bis'),
tag_index INT64 NOT NULL
OPTIONS(description='Index, der den wievielten Tag der Aktion anzeigt. Gegebenenfalls negativ für WE(Wareneingang) vor Aktion.'),
dat DATE OPTIONS(description='Einzelner Kalendertag des Gültigkeitszeitraums der Werbung/Aktion.'),
menge_bestand NUMERIC(29,3) OPTIONS(description='Bestand in Basis-ME'),
menge_abverkauf NUMERIC(29,3) OPTIONS(description='Abverkaufsmenge  in Basis-ME am betreffenden Datum der Werbung'),
menge_abverkauf_af NUMERIC(29,3) OPTIONS(description='Abverkauf Aktionsfrei (AF) in Basis-ME'),
menge_abverkauf_sa NUMERIC(29,3) OPTIONS(description='Abverkauf Sonderaktion (SA) in Basis-ME'),
menge_we NUMERIC(29,3) OPTIONS(description='Menge Wareneingang in Basis-ME'),
wrg_id STRING(3) OPTIONS(description='Kurzbezeichnung der Währung, z.Bsp. CZK, EUR'),
betrag_umsatz_netto NUMERIC(29,3) OPTIONS(description='Umsatz Netto'),
exc209_fg INT64
OPTIONS(description='Flag gibt an, ob ein Nullbestand gemäß der Exception 209 in F&R vorliegt. Exception 209 bedeutet einen Nullbestand. Quelle im DWH: dbp_data.ausnahme, aus SAP F&R.'),
nullbestand_fg NUMERIC(29,3)
OPTIONS(description='Flag gibt an, ob ein Nullbestand für den Artikel am Lagerort ausgewiesen wird. Quelle: SAP Retail (Tabelle MARD).'),
exc214_fg INT64
OPTIONS(description='Flag gibt an, ob ein Minusbestand gemäß der Exception 214 in F&R vorliegt. Exception 214 bedeutet Minusbestand. Quelle im DWH: dbp_data.ausnahme, aus SAP F&R.'),
minusbestand_fg NUMERIC(29,3)
OPTIONS(description='Flag gibt an, ob ein Minusbestand für den Artikel am Lagerort ausgewiesen wird. Quelle: SAP Retail (Tabelle MARD).'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, wup_id, nb_id, art_id, dat_aktion_von, dat_aktion_bis, tag_index) NOT ENFORCED
)
OPTIONS(description='AVQ(Abverkaufsquote) Kennzahlen aus Tages Ebene - Zusatzebene, enthält einen Datensatz pro Tag der Aktion (Datum+Index) sowie Datensätze für WE vor Aktion (negativer Index)');
