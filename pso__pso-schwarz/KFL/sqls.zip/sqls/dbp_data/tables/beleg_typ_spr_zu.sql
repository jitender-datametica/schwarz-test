CREATE TABLE IF NOT EXISTS dbp_data.beleg_typ_spr_zu (
system_id INT64 NOT NULL,
mandant_id INT64 NOT NULL,
beleg_typ_id STRING(6) COLLATE 'und:ci' NOT NULL,
spr_id INT64 NOT NULL,
beleg_typ_bez STRING(40) COLLATE 'und:ci',
td_insert TIMESTAMP,
td_update TIMESTAMP
);
