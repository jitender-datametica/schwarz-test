CREATE TABLE IF NOT EXISTS dbp_data.belegklasse_gruppe_zu (
system_id INT64 NOT NULL,
mandant_id INT64 NOT NULL,
belegklasse_id STRING(5) COLLATE 'und:ci' NOT NULL,
belegklasse_gruppe_id INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
