--==============================================================
-- Table: belos_standort_typ_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: belos_standort_typ_spr_zu
   generated from Powerdesigner on Tuesday, February 20, 2024 3:55:30 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.belos_standort_typ_spr_zu (
belos_standort_typ_id INT64 NOT NULL OPTIONS(description='ID des Belos_standorttyps. Wird im DWH vergeben'),
spr_id INT64 NOT NULL
OPTIONS(description='In diesem Feld werden die Sprachen der DWH Tabelle spr referenziert.'),
belos_standort_typ_bez STRING(30) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Bezeichnung des Belos-Standorttyps, z.Bsp. Palettenhändler'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (belos_standort_typ_id, spr_id) NOT ENFORCED
)
OPTIONS(description='LIS - Sprachabhängige Bezeichnung der Standorttypen. Manuell befüllte Tabelle, ohne SST zu Vorsystem');
