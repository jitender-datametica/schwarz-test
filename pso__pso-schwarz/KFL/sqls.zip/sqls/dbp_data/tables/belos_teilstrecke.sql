CREATE TABLE IF NOT EXISTS dbp_data.belos_teilstrecke (
mandant_id INT64 NOT NULL,
belos_vorgang_id INT64 NOT NULL,
teilstrecke_nr INT64 NOT NULL,
belos_adresse_absender_id STRING(40) COLLATE 'und:ci' NOT NULL,
belos_adresse_empfaenger_id STRING(40) COLLATE 'und:ci',
sendung_fg INT64 NOT NULL,
belos_ladung_id INT64 NOT NULL,
teilstrecke_id INT64 NOT NULL,
anz_stellplatz NUMERIC(29,3),
stellplatz_menge_einh_id STRING(3) COLLATE 'und:ci',
belosart_fg INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
