--==============================================================
-- Table: belos_vorgang
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: belos_vorgang
   generated from Powerdesigner on Friday, August 5, 2022 5:13:19 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.belos_vorgang (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
belos_vorgang_id INT64 NOT NULL
OPTIONS(description='Im DWH generierte eindeutige ID für die Belos Vorgänge. Ein Belos Vorgang setzt sich aus einem Transportauftrag (Logistikdaten) und einer Sendung (Abrechnungsdaten).'),
komplettlieferung_fg INT64 NOT NULL
OPTIONS(description='Das Flag kennzeichnet ob der Belos Vorgang komplett geliefert wurde'),
loesch_fg INT64 NOT NULL
OPTIONS(description='Das Flag kennzeichnet den Belos Vorgang als geloescht (1 = geloescht)'),
in_time_fg INT64 NOT NULL
OPTIONS(description='Kennzeichen ob alle zu diesem Belos Vorgang gehörigen Positionen fristgerecht geliefert wurden'),
av_fg INT64 NOT NULL
OPTIONS(description='Kennzeichen ob mindestens eine zu diesem Belos Vorgang gehörige Position annahmeverweitert wurde'),
sammel_ladung_fg INT64 NOT NULL
OPTIONS(description='Kennzeichen ob es sich bei der Ladung um einen Sammeltransport oder einen direkten Transport handelt (Sammelladung = 1)'),
nb_id INT64
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
sendung_gew_einh_id STRING(3) COLLATE 'und:ci' NOT NULL OPTIONS(description='Gewichtseinheit, z.Bsp. KG'),
sendung_vol_einh_id STRING(3) COLLATE 'und:ci' NOT NULL OPTIONS(description='Volumeneinheit, z.Bsp. CDM'),
dat_leistung DATE NOT NULL OPTIONS(description='Datum der Leistungserstellung - Erstelldatum des Transportauftrags'),
dat_zustellung DATE NOT NULL OPTIONS(description='avisiertes Lieferdatum'),
sendung_id INT64 NOT NULL
OPTIONS(description='Fachschlüssel der referenzierten Belos Sendung die diesem Vorgang zugeodnet ist'),
wup_id INT64 NOT NULL
OPTIONS(description='Mutter Wup ID wird verwendet für Beziehung Lager zu Verteilzentrum'),
lagerort_id STRING(4) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Schlüssel für die Lagerorte. Die Lagerorte sind pro Werk/Betrieb eindeutig. Aus lgort '),
gp_id INT64 NOT NULL
OPTIONS(description='Geschäftspartner - ID (Lieferanten - ID). Hier der Hauptlieferant (Kreditor)'),
gewicht_sendung NUMERIC(29,3) NOT NULL OPTIONS(description='Abrechnungsrelevantes Gewicht der Sendung;'),
zustellart_id STRING(10) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Kennzeichen fuer die Arten der Zustellung eines Belos Vorgangs (z. B. Kosten und Fracht, frei Haus verzollt)'),
belos_vorgangart_id STRING(10) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Kennzeichen für die Art des Belos Vorgangs (z. B. Beschaffung, Annahmeverweigerung)'),
transportauftrag_id STRING(30) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Fachschluessel des referenzierten BELOS Transportauftrags der diesem Vorgang zugeodnet ist.'),
sonderabwicklung_id STRING(20) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Kennzeichen für die Sonderabwicklung eines Belos Vorgangs (z. B. Gekühlt, Tiko) - Feld enthält Bezeichnung! Compress (\'GK\',\'UGK\')'),
belos_adresse_absender_num_id INT64 NOT NULL
OPTIONS(description='numerischer Wert für die belos_adresse. Bei Märkten/Lägern ist hier die wup_id hinterlegt, ansonsten ein negativer Wert. Wird für Join-Zwecke benötigt'),
belos_adresse_abholung_id STRING(40) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Eindeutiger Schlüssel zur Identifikation einer Belos Adresse'),
belos_adresse_empfaenger_id STRING(40) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Eindeutiger Schlüssel zur Identifikation einer Belos Adresse'),
belos_adresse_spedition_id STRING(40) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Eindeutiger Schlüssel zur Identifikation einer Belos Adresse'),
vol_stauraum NUMERIC(29,3) NOT NULL
OPTIONS(description='Abrechnungsrelevantes Volumen des erforderlichen Stauraums der Sendung'),
debitor_id INT64 NOT NULL OPTIONS(description='Debintorennummer des Absenders /Empfängers.'),
anz_unterverpackung NUMERIC(29,3) OPTIONS(description='Anzahl der Unterverpackungen'),
unterverpackung_menge_einh_id STRING(3) COLLATE 'und:ci' OPTIONS(description='Mengeneinheit der Unterverpackung'),
lagernummer_id STRING(4) COLLATE 'und:ci' OPTIONS(description='ID der Lagernummer - höchste Ebene der Lagerhierarchie'),
system_id INT64 NOT NULL
OPTIONS(description='Die System ID kennzeichnet das Quellsystem der Daten (z. B. SAP PR1).'),
tour_id INT64 OPTIONS(description='Nummer des Transportes (Tour)'),
belosart_fg INT64 NOT NULL
OPTIONS(description='Zeigt an, ob es sich bei dem Vorgang um einen Distributions- oder Beschaffungsvorgang handelt'),
leergut_abh_fg INT64 NOT NULL OPTIONS(description='Flag für Leergutabholung'),
retouren_fg INT64 NOT NULL OPTIONS(description='Retouren Flag'),
industrie_abh_fg INT64 NOT NULL OPTIONS(description='Industrie Abholung Flag'),
anz_stellplatz NUMERIC(29,2) OPTIONS(description='Anzahl der Stellplätze aus SAP'),
anz_kolli NUMERIC(29,2) OPTIONS(description='Anzahl der Kollis'),
belos_sendungsstatus_id INT64 DEFAULT 3 NOT NULL
OPTIONS(description='referenziert auf die Lookup-Tabelle l_belos_tourstatus! Es werden nur die Ausprägungen 2 und 3 benutzt'),
rundlauf_transport_fg INT64 NOT NULL
OPTIONS(description='gesetzt bei Touren, die mehr als ein Ziel anfahren. Redundant zu tour, muss hier gespeichert werden, da belos_vorgang-Daten zeitlich vor tour-Daten geliefert werden.'),
fleischwerk_fg INT64 NOT NULL
OPTIONS(description='zeigt an, ob innerhalb der Tour ein Fleischwerk beliefert wurde. Redundant zu tour, muss hier gespeichert werden, da belos_vorgang-Daten zeitlich vor tour-Daten geliefert werden.'),
distribution_abr_fg INT64 NOT NULL
OPTIONS(description='zeigt einen abrechnungsrelevanten Vorgang an. Redundant zu tour, muss hier gespeichert werden, da belos_vorgang-Daten zeitlich vor tour-Daten geliefert werden.'),
brtgew_sendung NUMERIC(29,3) OPTIONS(description='Abrechnungsrelevantes Brutto-Gewicht der Sendung;'),
brtvol_stauraum NUMERIC(29,3) NOT NULL
OPTIONS(description='Abrechnungsrelevantes Brutto-Volumen des erforderlichen Stauraums der Sendung'),
anz_stellplatz_belos NUMERIC(29,2) OPTIONS(description='Anzahl der Stellplätze aus dem Belos-System'),
k_na_fg INT64 DEFAULT 0 NOT NULL
OPTIONS(description='Flag steht für Kaufland-nur Abrechnung. Für Transportprozesse, die in Regie des Dienstleisters durchgeführt werden. Flag wird gesetzt, wenn das Referenzfeld der SST mit CU beginnt'),
belos_auftrag_id_extern STRING(40) COLLATE 'und:ci'
OPTIONS(description='Nur für k_na-Prozesse: Auftragsnummer Warenlieferant aus der Quelle Referenz1 (Beginnt in der Quelle mit CU%)'),
belos_lieferschein_id STRING(40) COLLATE 'und:ci'
OPTIONS(description='Nur für k_na-Prozesse Lieferscheinnummer aus deem Quellfeld Referenz2. '),
belos_sendung_id_extern STRING(40) COLLATE 'und:ci'
OPTIONS(description='Nur für k_na-Prozesse: Sendungsnummer Dienstleister aus dem Quellfeld Referenz4. Beginnt im Quellfeld mit SU%'),
belos_bestell_beleg_id_extern STRING(40) COLLATE 'und:ci'
OPTIONS(description='Nur für k_na-Prozesse: Bestellbelegnummerr aus dem Quellfeld Referenz3. Beginnt im Quellfeld mit PO%'),
referenz STRING(255) COLLATE 'und:ci'
OPTIONS(description='Sonstige Eingaben Feld Referenznummer (enthält Referenz aus SST nde_sendung ohne PO (ab Oktober 2018 befüllt, davor null) - beschränkt auf 200 Zeichen)'),
mandant_id_debitor INT64 DEFAULT 1 NOT NULL
OPTIONS(description='Mandant_ID zur Eindeutigkeit des Debitors (bisher nur DE =1 / 04.06.2016)'),
datzeit_sendung_offen DATETIME OPTIONS(description='Zeitpunkt "Sendung offen"'),
datzeit_ware_versandbereit DATETIME OPTIONS(description='Zeitpunkt "Ware versandbereit"'),
datzeit_sendung_beauftragt DATETIME OPTIONS(description='Zeitpunkt "Sendung beauftragt"'),
datzeit_system_zugestellt DATETIME OPTIONS(description='Zeitpunkt "Systemstatus zugestellt"'),
datzeit_abholung_bis DATETIME OPTIONS(description='Zeitpunkt "Abholtermin (bis)".'),
datzeit_zustellung_bis DATETIME OPTIONS(description='Zeitpunkt "Zustelltermin (bis)".'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, belos_vorgang_id) NOT ENFORCED
)
OPTIONS(description='LIS - Der Belos Vorgang setzt sich aus dem Transportauftrag (mit den Logistikdaten) und den Sendungsinformationen (mit den Abrechnungsdaten) zusammen.');
