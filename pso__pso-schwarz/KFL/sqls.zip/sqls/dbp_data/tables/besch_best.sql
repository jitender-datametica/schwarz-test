--==============================================================
-- Table: besch_best
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: besch_best
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:13 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.besch_best (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
best_beleg_id INT64 NOT NULL
OPTIONS(description='Das Feld enthält die Beleg ID der Bestellung und dient der eindeutigen Identifikation der Bestellbelege.'),
gp_id INT64 NOT NULL OPTIONS(description='Geschäftspartner - ID (Lieferanten - ID)'),
dat_best_beleg DATE NOT NULL OPTIONS(description='Dieses Feld enthält das Belegdatum der Bestellung.'),
bestellart_id STRING(4) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Durch die Einkaufsbelegart kann man z.B. zwischen einer Bestellung, einer Anfrage und einem Lieferplan unterscheiden.'),
loesch_fg INT64 NOT NULL
OPTIONS(description='Das loesch_fg enthält das Löschkennzeichen für diese Position, Wert 1 entspricht gelöscht.'),
nachbest_fg INT64 NOT NULL
OPTIONS(description='Dieses Kennzeichen steuert beim Anlegen einer Bestellung, ob sie als Nachbestel-lung behandelt wird. Ist das Kennzeichen gesetzt, können aus dieser Bestellung ausschließlich Lieferungen generiert werden, die mit geringerer Priorität kommissioniert werden.'),
einkaufsorganisation_id INT64 NOT NULL OPTIONS(description='Einkaufsorganisation aus ekorg'),
kunde_id STRING(10) COLLATE 'und:ci'
OPTIONS(description='Kannfeld: Eingabe des Marktes der eine Veraenderung im Preis erhalten soll. Vom Normalpreis auf Sonderpreis oder umgekehrt.'),
dat_aenderung DATE
OPTIONS(description='Dieses Datum stellt das Übernahmedatum bei einem neuen Beleg bzw. das Updatedatum bei einer neuen Version eines Datensatzes dar.'),
wup_id INT64 OPTIONS(description='Verteilzentrum für die Bestellung (auf Kopfebene)'),
nb_id INT64
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
best_beleg_status_id STRING(1) COLLATE 'und:ci'
OPTIONS(description='Status der Bestellung, z. B. C entspricht Bestellung aus Wareneingang'),
system_id INT64 DEFAULT 7 NOT NULL
OPTIONS(description='Die System ID kennzeichnet das Quellsystem der Daten (z. B. SAP PR1).'),
empfaenger_wup_id INT64
OPTIONS(description='Bei dezentraler Bestellung ist dieser Wert mit dem Empfänger der Ware befüllt. Denormalisiert aus der Detailtabelle.'),
anz_pos_aktiv INT64 DEFAULT 0 NOT NULL
OPTIONS(description='Anzahl der nicht gelöschten Positionen aus der Detailtabelle. Denormalisiert'),
anz_pos_offen INT64 DEFAULT 0 NOT NULL
OPTIONS(description='Anzahl der noch nicht gelieferten Positionen aus der Detailtabelle. Nur nicht gelöschte. Denormalisiert'),
submi_id STRING(10) COLLATE 'und:ci'
OPTIONS(description='Submissionsnummer aus submi. Nummer oder Bezeichnung, die der Verwaltung mehrerer Anfragen oder Bestellungen dient.'),
ref_beleg_id_intern STRING(20) COLLATE 'und:ci'
OPTIONS(description='Interne Referenznummer des Kunden oder Lieferanten aus ihrez'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, best_beleg_id) NOT ENFORCED
)
PARTITION BY dat_best_beleg
OPTIONS(description='TP408_LVS - In dieser Tabelle sind die Kopfdaten der Bestellungen aus der SAP Tabelle EKKO enthalten.  - MULTISET');
