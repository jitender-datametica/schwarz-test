CREATE TABLE IF NOT EXISTS dbp_data.besch_best_belos_vorgang_zu (
mandant_id INT64 NOT NULL,
best_beleg_id INT64 NOT NULL,
belos_vorgang_id INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
