CREATE TABLE IF NOT EXISTS dbp_data.besch_faktura_kmo_columnar (
mandant_id INT64 NOT NULL,
faktura_beleg_id INT64 NOT NULL,
fakturaart_id STRING(4) COLLATE 'und:ci' NOT NULL,
dat_faktura_sap DATE NOT NULL,
fktyp STRING(1) COLLATE 'und:ci' NOT NULL,
kurrf NUMERIC(29,5),
dat_erstellung DATE NOT NULL,
zeit_erstellung INT64 NOT NULL,
wrg_id STRING(3) COLLATE 'und:ci' NOT NULL,
beleg_kondition_id TIME NOT NULL,
mandant_id_empfaenger INT64,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
