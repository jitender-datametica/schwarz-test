CREATE TABLE IF NOT EXISTS dbp_data.besch_faktura_kondit_columnar (
mandant_id INT64 NOT NULL,
faktura_beleg_id INT64 NOT NULL,
faktura_beleg_pos_id INT64 NOT NULL,
beleg_kondition_id INT64 NOT NULL,
kondition_schl_id STRING(4) COLLATE 'und:ci' NOT NULL,
kondition_wert NUMERIC(29,2) NOT NULL,
kappl STRING(2) COLLATE 'und:ci' NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
) CLUSTER BY mandant_id;
