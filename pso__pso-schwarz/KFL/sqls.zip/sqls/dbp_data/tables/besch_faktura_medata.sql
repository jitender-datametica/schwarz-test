--==============================================================
-- Table: besch_faktura_medata
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: besch_faktura_medata
   generated from Powerdesigner on Montag, 21. Juli 2025 05:50:00
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.besch_faktura_medata (
art_id INT64 NOT NULL OPTIONS(description='Artikel ID'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
faktura_markt INT64 NOT NULL OPTIONS(description='bezieht sich auf den empfangenden wup'),
dat_faktura DATE NOT NULL
OPTIONS(description='Abhängig von der Fakturaart ist hier entweder das Fakturadatum oder das Datum der Leistungserstellung hinterlegt'),
wup_id INT64 NOT NULL OPTIONS(description='in diesem Fall der beliefernde wup - Medatalager'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer'),
zwsum_3_betrag NUMERIC(29,4)
OPTIONS(description='Einkaufspreis netto  bzw. EK-Aktion netto vermindert um die Reklapauschale.'),
menge_fakturiert NUMERIC(29,3)
OPTIONS(description='Fakturierte Menge in Verkaufseinheiten, Displays werden als 1 gerechnet'),
ek_netto_bnk NUMERIC(29,4)
OPTIONS(description='Einkaufspreis netto plus Bezugsnebenkosten (Bedeutung vgl. Kalkulationsschema).'),
ek_mep NUMERIC(29,4) OPTIONS(description='Markteinstandspreis ((Bedeutung vgl. Kalkulationsschema).'),
logistikkostenzuschlag NUMERIC(29,4)
OPTIONS(description='Logistikkostenzuschlag (ein kalkulierter Wert für die Zentrallagerkosten, der bei zentraler Lieferung Bestandteil einiger Einstandspreise ist).'),
betrag_ek_mep_vor_fwu NUMERIC(29,5)
OPTIONS(description='Menge * Markteinstandspreis ohne Logistikkosten inkl. Handlingkosten. Quellfeld: ZEKP.MEPOL.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (art_id, mandant_id, faktura_markt, dat_faktura) NOT ENFORCED
) CLUSTER BY dat_faktura
OPTIONS(description='TP2 AIS - Fakturadaten aus Medata - Lägern (nicht in SAP)');
