CREATE TABLE IF NOT EXISTS dbp_data.besch_lief_belos_vorgang_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
lief_beleg_id NUMERIC(29,3) NOT NULL OPTIONS(description='DNetto-Ladungsgvolumen der HU'),
kj_lief_beleg INT64 NOT NULL OPTIONS(description='Kalenderjahr Lieferbeleg'),
dat_lief_soll DATE
OPTIONS(description='Datum, bei dem die Lieferung beim Kunden eingehen soll. Das System kann für den Warenausgang das Lieferdatum aufgrund vordefinierter Zeitschätzungen errechnen. Das Feld wird aus der Kopftabelle "vererbt", um einen PPI darüber bilden zu können (Performance'),
belos_vorgang_id INT64 NOT NULL OPTIONS(description='BELOS Vorgang ID'),
transportation_unit_id INT64 OPTIONS(description='Transporteinheit (intern)'),
dat_leistung DATE OPTIONS(description='Leistungsdatum (BELOS)'),
versandstelle_id STRING(4)
OPTIONS(description='Ort, an dem Lieferungen bearbeitet werden. Es kann sich dabei um einen physischen Ort (z.B. ein Lager oder eine Gruppe von Laderampen) oder um eine logische Gruppierung (z.B. eine Gruppe von Personen, die für die Versandaktivitäten zuständig ist) handeln.'),
lief_prefix STRING(1) DEFAULT ' ' OPTIONS(description='Präfix [aktuell nur "C" oder leer] (new and need default value)'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration')
) OPTIONS(description='Warenausgangs-Positionen auf Ebene Warengruppe');
