--==============================================================
-- Table: besch_lief_kuerzung
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: besch_lief_kuerzung
   generated from Powerdesigner on Montag, 6. November 2023 15:57:00
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.besch_lief_kuerzung (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant'),
dat_lief_soll DATE NOT NULL OPTIONS(description='Datum aus dem Quellfeld eindt'),
best_beleg_id INT64 NOT NULL
OPTIONS(description='ID des Belegs bezogen auf den Bestellbeleg, das Quellfeld ist vbeln (also der Lieferbeleg)'),
best_beleg_pos_id INT64 NOT NULL
OPTIONS(description='Position des Bestellbelegs (müsste also aus ebelp sein) aus posid '),
menge_best_bme NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='bestellte Menge des Artikel dieser Position in Bestellmengeneinheit. Aus menge'),
menge_lief_bme NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='Tatsächlich gelieferte Menge in Bestellmengeneinheiten aus lfimg'),
ek_netto_bnk_soll NUMERIC(29,4)
OPTIONS(description='Einkaufspreis netto_bnk bezogen auf die bestellte Menge.  In der Versorgung angereichert zur Performanceverbesserung. Die Währung entspricht der Bestellung.'),
ek_netto_bnk_ist NUMERIC(29,4)
OPTIONS(description='Einkaufspreis netto_bnk bezogen auf die gekürzte Menge.  In der Versorgung angereichert zur Performanceverbesserung. Die Währung entspricht der Bestellung.'),
vk_netto_ist NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Verkaufspreis netto  bezogen auf die gekürzte Menge.  In der Versorgung angereichert zur Performanceverbesserung. Die Währung entspricht der Bestellung'),
vk_netto_soll NUMERIC(29,4) DEFAULT 0 NOT NULL
OPTIONS(description='Verkaufspreis netto  bezogen auf die bestellte Menge.  In der Versorgung angereichert zur Performanceverbesserung. Die Währung entspricht der Bestellung'),
menge_best_kolli NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='Dieses Feld enthält die Bestellmenge in der Kollimengeneinheit.  In der Versorgung angereichert zur Performanceverbesserung'),
menge_lief_kolli NUMERIC(29,3) DEFAULT 0 NOT NULL
OPTIONS(description='Anzahl der gekürzten Position in Kollimengeneinheit In der Versorgung angereichert zur Performanceverbesserung'),
wrg_id STRING(3) COLLATE 'und:ci' NOT NULL OPTIONS(description='Kurzbezeichnung der Währung, z.Bsp. CZK, EUR'),
quelle STRING(10) COLLATE 'und:ci' DEFAULT 'ZDELMON' NOT NULL OPTIONS(description='quelltabelle sap retail'),
versandstelle_id STRING(4) DEFAULT '' NOT NULL
OPTIONS(description='ort, an dem lieferungen bearbeitet werden. es kann sich dabei um einen physischen ort (z.b. ein lager oder eine gruppe von laderampen) oder um eine logische gruppierung (z.b. eine gruppe von personen, die für die versandaktivitäten zuständig ist) handeln.'),
art_id INT64
OPTIONS(description='input: artikel-id einschliesslich der generationen-id (9-stellig); output: 7-stellige l&s-id + counter = 8-stellige artikel-id. wwnnnnpc (warengruppe, nummer, prüfziffer, counter) regel: neuer artikel -> counter +1.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, dat_lief_soll, best_beleg_id, best_beleg_pos_id) NOT ENFORCED
)
OPTIONS(description='AIS KMO - Hier sind durch die Logistik gekürzte Lieferungen (nicht oder nur teilweise erfüllte Bestellungen) in KMO gespeichert. Quelle ist zldelmon_short');
