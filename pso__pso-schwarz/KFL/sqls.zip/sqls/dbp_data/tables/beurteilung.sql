CREATE TABLE IF NOT EXISTS dbp_data.beurteilung (
beurteilung_id INT64 NOT NULL,
wup_id INT64,
nb_id INT64,
mandant_id INT64,
eindruck_gesamt STRING(50),
note_gesamt NUMERIC(29,2),
dat DATE NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
