--==============================================================
-- Table: beurteilung_bereichsnote
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: beurteilung_bereichsnote
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:13 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.beurteilung_bereichsnote (
bereichsnote_id INT64 NOT NULL
OPTIONS(description='Eindeutiger Schlüssel für die Beurteilung eines Bereiches eines Marktes (z.B. Ordnung und Sauberkeit).'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
beurteilung_bereich_id INT64
OPTIONS(description='Eindeutiger Schlüssel für den Bereich eines Marktes (z.B. Ordnung und Sauberkeit).'),
beurteilung_id INT64 NOT NULL
OPTIONS(description='Eindeutiger Schlüssel für die gesamte Beurteilung eines Marktes. Es können mehrere Beurteilungen pro Markt und Tag erfolgen.'),
note_bereich NUMERIC(29,2) OPTIONS(description='Schulnote für einen Bereich'),
eindruck_bereich STRING(50) COLLATE 'und:ci' OPTIONS(description='Textfeld für den Bereichseindruck'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (bereichsnote_id) NOT ENFORCED
) OPTIONS(description='VIS - Schnellbeurteilung Bereichsnote');
