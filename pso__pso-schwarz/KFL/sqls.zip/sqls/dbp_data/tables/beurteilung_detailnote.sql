--==============================================================
-- Table: beurteilung_detailnote
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: beurteilung_detailnote
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:13 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.beurteilung_detailnote (
detailnote_id INT64 NOT NULL
OPTIONS(description='Eindeutiger Schlüssel für die Beurteilung eines Details eines Bereiches eines Marktes (z.B. Ordnung und Sauberkeit Parkplatz).'),
beurteilung_id INT64 NOT NULL
OPTIONS(description='Eindeutiger Schlüssel für die gesamte Beurteilung eines Marktes. Es können mehrere Beurteilungen pro Markt und Tag erfolgen.'),
beurteilung_detail_id INT64
OPTIONS(description='Eindeutiger Schlüssel für das Detail eines Bereiches eines Marktes (z.B. Ordnung und Sauberkeit Parkplatz).'),
note_detail NUMERIC(29,2) OPTIONS(description='Schulnote für das Detail eines Bereiches'),
eindruck_detail STRING(50) COLLATE 'und:ci' OPTIONS(description='Textfeld für den Detaileindruck'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (detailnote_id, beurteilung_id) NOT ENFORCED
) OPTIONS(description='VIS - Schnellbeurteilung Detailnote');
