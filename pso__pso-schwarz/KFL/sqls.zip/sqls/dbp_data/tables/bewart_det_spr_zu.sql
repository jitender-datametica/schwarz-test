CREATE TABLE IF NOT EXISTS dbp_data.bewart_det_spr_zu (
mandant_id INT64 NOT NULL,
bewart_det_id INT64 DEFAULT 9999 NOT NULL,
spr_id INT64 NOT NULL,
bewart_det_bez STRING(70),
td_update TIMESTAMP,
td_insert TIMESTAMP
);
