--==============================================================
-- Table: bewart_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: bewart_spr_zu
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:13 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.bewart_spr_zu (
bewart_id INT64 NOT NULL
OPTIONS(description='Bewegungsart ID. Bewegungsarten > 1000 beziehen sich auf Warenausgang, < 1000 auf Wareneingang'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache            '),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
bewart_bez STRING(40) COLLATE 'und:ci' OPTIONS(description='Bezeichnung der Bewegungsart'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (bewart_id, spr_id, mandant_id) NOT ENFORCED
) OPTIONS(description='Bewegungsart-Sprachen-Zuordnung');
