CREATE TABLE IF NOT EXISTS dbp_data.blockbestand_per (
mandant_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
art_id INT64 NOT NULL,
dat_von DATE NOT NULL,
prozess_id INT64 NOT NULL,
dat_bis DATE NOT NULL,
menge_blockbestand NUMERIC(29,3) DEFAULT 0 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
