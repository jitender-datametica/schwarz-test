--==============================================================
-- Table: bonuskauf_produktvariante_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: bonuskauf_produktvariante_spr_zu
   generated from Powerdesigner on Freitag, 18. Februar 2022 09:43:04
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.bonuskauf_produktvariante_spr_zu (
bonuskauf_produktvariante_id STRING(10) NOT NULL OPTIONS(description='Produktvariante'),
spr_id INT64 NOT NULL OPTIONS(description='Sprachschlüssel'),
bonuskauf_produktvariante_bez STRING(60) OPTIONS(description='Bezeichnung Produktvariante'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration')
)
OPTIONS(description='This table provides the name to the product variety ID (Produktvariante) - means how the customer has to combine the products to get a discount          Example: 0 = Any Products, 1 = Same Products, 2 = Different Products');
