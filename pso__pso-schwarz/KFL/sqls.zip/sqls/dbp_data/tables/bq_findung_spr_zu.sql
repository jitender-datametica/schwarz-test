-- Table: bq_findung_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: bq_findung_spr_zu
   generated from Powerdesigner on Sonntag, 4. Februar 2024 12:13:15
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.bq_findung_spr_zu (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
bq_findung_id INT64 NOT NULL
OPTIONS(description='ID zur Kennzeichnung eines Ausstiegspunkts aus dem Kreisprozess'),
spr_id INT64 NOT NULL OPTIONS(description='Sprache im DWH'),
bq_findung_bez STRING(40) COLLATE 'und:ci' OPTIONS(description='Sprachabhängige Bezeichnung des Ausstiegspunkts'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, bq_findung_id, spr_id) NOT ENFORCED
)
OPTIONS(description='AIS - Sprachabhängige Bezeichnung der Ausstiegspunkte bei der Bezugsquellenfindung - initial versorgt');
