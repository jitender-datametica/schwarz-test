CREATE TABLE IF NOT EXISTS dbp_data.bsch_bestvor_det
(
  mandant_id INT64 NOT NULL OPTIONS(description="Mandant im DWH"),
  best_vor_nr INT64 NOT NULL OPTIONS(description="Bestellvorschlagsnummer, bei Bestellungen ohne Vorschlag die Bestellnummer aus der Tabelle besch_best"),
  best_vor_pos INT64 NOT NULL OPTIONS(description="Bestellvorschlagsposition"),
  dat_plan DATE NOT NULL OPTIONS(description="Planungsdatum"),
  art_id INT64 NOT NULL OPTIONS(description="Eindeutige Artikelnummer"),
  gp_id INT64 NOT NULL OPTIONS(description="Geschäftspartner - ID (Lieferanten - ID)"),
  menge_best_vor NUMERIC(29,4) NOT NULL OPTIONS(description="Vorgeschlagene Menge"),
  menge_best NUMERIC(29,4) NOT NULL OPTIONS(description="Bestellte Menge"),
  status STRING(2) COLLATE 'und:ci' NOT NULL OPTIONS(description="Status der Position: \n            \"VB\"  unveränderte Übernahme Vorschlag in Bestellung\n            \"V0\"  Vorschlag ohne Bestellung\n            \"0B\" Bestellung ohne Vorschlag\n            \"V+\" Bestellvorschlag erhöht\n            \"V-\" Bestellvorschlag reduziert\n            "),
  best_vor_einh INT64 NOT NULL OPTIONS(description="Faktor zur vorgeschlagenen Menge, umgerechnet über art_umrechnung_fakor_per"),
  best_einh INT64 NOT NULL OPTIONS(description="Faktor zur bestellten Menge, umgerechnet über art_umrechnung_fakor_per"),
  wup_id INT64 NOT NULL OPTIONS(description="Mutter Wup ID wird verwendet für Beziehung Lager zu Verteilzentrum"),
  nb_id INT64 NOT NULL OPTIONS(description="Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer"),
  bestellart_id STRING(4) COLLATE 'und:ci' DEFAULT '    ' NOT NULL OPTIONS(description="Durch die Einkaufsbelegart kann man z.B. zwischen einer Bestellung, einer Anfrage und einem Lieferplan unterscheiden."),
  dat_lief_soll DATE OPTIONS(description="Soll-Lieferdatum aus ZFRE_BV (fur_best_vor)"),
  td_update TIMESTAMP OPTIONS(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  td_insert TIMESTAMP OPTIONS(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  PRIMARY KEY (best_vor_nr, best_vor_pos, mandant_id) NOT ENFORCED
)
PARTITION BY dat_plan
CLUSTER BY mandant_id, dat_plan
OPTIONS(
  description="AIS -  F&R - Aggregat der Bestellvorschläge - MULTISET  ab KW 19/12 entfällt die bisherige SST - wird jetzt aus der Tabelle fur_best_vor befüllt"
);
