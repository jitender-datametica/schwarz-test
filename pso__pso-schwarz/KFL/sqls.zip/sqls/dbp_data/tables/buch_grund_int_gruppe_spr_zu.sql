--==============================================================
-- Table: buch_grund_int_gruppe_spr_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: buch_grund_int_gruppe_spr_zu
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:13 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.buch_grund_int_gruppe_spr_zu (
system_id INT64 NOT NULL
OPTIONS(description='Die System ID kennzeichnet das Quellsystem der Daten (z. B. SAP PR1).'),
mandant_id INT64 NOT NULL
OPTIONS(description='ID des Mandanten im DWH; Deutschland entspricht Mandant_ID = 1;'),
buch_grund_int_gruppe_id INT64 NOT NULL
OPTIONS(description='Gruppierungsmerkmal über interne Buchungsgründe'),
spr_id INT64 NOT NULL
OPTIONS(description='In diesem Feld werden die Sprachen der DWH Tabelle spr referenziert.'),
buch_grund_int_gruppe_bez STRING(40) COLLATE 'und:ci'
OPTIONS(description='Bezeichnung der Gruppierung über interne Buchungsgründe'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (system_id, mandant_id, buch_grund_int_gruppe_id, spr_id) NOT ENFORCED
)
OPTIONS(description='RPW - DATA - Sprachtabhängige Bezeichnungen für die Gruppierung des internen Buchungsgrundes             ');
