create table if not exists `dbp_data.coi_ump_hwg_sum`
(
  mandant_id INT64 not null options(description="Mandant im DWH"),
  wup_id INT64 not null options(description="WUP_ID entspricht der Marktnummer / Fililalnummer in SAP (WERKS)"),
  nb_id INT64 not null options(description="Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer"),
  dat date not null options(description="Datumswert des Umsatzes"),
  hwg_id INT64 not null options(description="ID der Hauptwarengruppe"),
  wrg_id string(3) collate 'und:ci' not null options(description="Kurzbezeichnung der Währung, z.Bsp. CZK, EUR"),
  umsatz_netto NUMERIC(29,4) not null options(description="Umsatz vermindert um den Mehrwertsteuerbetrag"),
  td_insert timestamp options(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  td_update timestamp options(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  primary key (mandant_id, wup_id, nb_id, dat, hwg_id) not enforced
)
options(
  description="WWC - COI Umsatzplanung - Aggregat für BE"
);
