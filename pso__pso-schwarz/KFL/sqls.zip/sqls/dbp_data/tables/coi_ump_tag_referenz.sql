--==============================================================
-- Table: coi_ump_tag_referenz
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: coi_ump_tag_referenz
   generated from Powerdesigner on Dienstag, 20. September 2022 17:35:32
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.coi_ump_tag_referenz (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH'),
gj_plan INT64 NOT NULL OPTIONS(description='Geschaeftsjahr, Format JJJJ'),
version_id INT64 NOT NULL OPTIONS(description='Die Planversion eines Geschaeftsjahres (1-9)'),
land_level STRING(3) COLLATE 'und:ci' NOT NULL
OPTIONS(description='Landes-Kategorisierung (1-3 Stellen) z.B HRK fuer Kroatien Kueste und HRL für Kroatien Land'),
dat_plan DATE NOT NULL OPTIONS(description='Datum des Plantag für das GJ auf Land-Level (im Format JJJJ-MM-TT)'),
dat_referenz DATE
OPTIONS(description='Datum des Referenztages des Vorjahres zum Plantag (im Format JJJJ-MM-TT) auf Ebene Land-Level'),
wrg_id STRING(3) OPTIONS(description='kurzbezeichnung der waehrung, z.bsp. czk, eur'),
faktor_kalender BIGNUMERIC(38, 10)
OPTIONS(description='Faktor in % fuer den Referenztag der Umsatzplanung (Auf- / Abschlag zum dat_referenz).'),
wert_kalender NUMERIC(29,4)
OPTIONS(description='Absolutwert fuer den Referenztag der Umsatzplanung (entweder faktor_kalender in % oder wert_kalender wird gefuellt) (kommt direkt aus der Upload-Excel)'),
umsatz_netto_tag_ges NUMERIC(29,4)
OPTIONS(description='Ist der Gesamtwert des betroffenen Umsatzes des eingegebenen Effektes (Wert). Teilsumme des umsatz_netto_basis_2 für den angegebenen Tag ueber alle hgws'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, gj_plan, version_id, dat_plan) NOT ENFORCED
)
OPTIONS(description='WWC - COI Umsatzplanung - Pflege der Referenztage Vorjahr auf Level Mandant / Land-Level - Planversion abhaengig - manueller Upload');
