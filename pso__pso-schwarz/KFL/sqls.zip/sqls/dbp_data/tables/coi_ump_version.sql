CREATE TABLE IF NOT EXISTS dbp_data.coi_ump_version (
mandant_id INT64 NOT NULL,
gj_plan INT64 NOT NULL,
version_id INT64 NOT NULL,
datzeit_upload DATETIME NOT NULL,
dat_planwerte_ist_ab DATE,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
