--==============================================================
-- Table: cos_bonuskauf_kunde_zu
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: cos_bonuskauf_kunde_zu
   generated from Powerdesigner on Mittwoch, 15. Februar 2023 16:46:47
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.cos_bonuskauf_kunde_zu (
bonuskauf_id STRING(20) NOT NULL OPTIONS(description='Eindeutige ID einer Bonuskaufaktion z.Bsp. 700, aus bbynr.'),
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH.'),
crm_kunde_id STRING(144) NOT NULL OPTIONS(description='CRM Kundenkarte-ID.'),
kauf_id STRING(144) DEFAULT '-1' NOT NULL OPTIONS(description='ID des kaufbaren Coupons (kaufbare Coupons).'),
anz_einloesung INT64 NOT NULL OPTIONS(description='Anzahl wie oft eingelöst.'),
wrg_id STRING(3) NOT NULL OPTIONS(description='Kurzbezeichnung der Währung, z.Bsp. CZK, EUR.'),
dat_kauf_rueckgabe DATETIME
OPTIONS(description='Datum und Zeit wann Coupon zurückgegeben wurde (kaufbare Coupons).'),
dat_kauf DATETIME
OPTIONS(description='Datum und Zeit wann Coupon gekauft wurde (kaufbare Coupons).'),
kauf_status_nr INT64 OPTIONS(description='Status des kaufbaren Coupons (kaufbare Coupons).'),
anz_kaufbar INT64 OPTIONS(description='Anzahl kaufbare Coupons (kaufbare Coupons).'),
dat_kauf_einloesung DATETIME
OPTIONS(description='Datum und Zeit der Einlösung (kaufbare Coupons).'),
status_aktiv_nr INT64 OPTIONS(description='Aktivierungsstatus in der App: 1 = aktiv; 2 = nicht aktiviert.'),
datzeit_status_aktivierung DATETIME
OPTIONS(description='Enthält Aktivierungsdatum und -zeit des Coupons.'),
status_einloesung INT64
OPTIONS(description='Einlösestatus: 0 = noch nicht eingelöst; 1 = teilweise eingelöst; 2 = eingelöst.'),
dat_status_einloesung DATETIME OPTIONS(description='Datum und Zeit der Einlösung.'),
kontrollgruppe INT64 OPTIONS(description='Kontrollgruppe Reco.'),
kampagnen_id STRING(20) OPTIONS(description='Campaign ID.'),
checkout_fg INT64 OPTIONS(description='Flag: Handelt es sich um einen Checkout Coupon Coupon.'),
anz_kauf_ist INT64 OPTIONS(description='Häufigkeit bisheriger Einkäufe.'),
anz_kauf_soll INT64 OPTIONS(description='Häufigkeit noch offener Einkäufe.'),
sum_kauf_ist NUMERIC(29,4) OPTIONS(description='Bisherige Summe der Einkäufe.'),
sum_kauf_soll NUMERIC(29,4) OPTIONS(description='Noch offene Summe.'),
dat_update DATETIME OPTIONS(description='Update Datum und Zeit dieser Tabelle.'),
kampagnen_version INT64 OPTIONS(description='Kampagnenversion.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, bonuskauf_id, crm_kunde_id, kauf_id, anz_einloesung) NOT ENFORCED
) OPTIONS(description='Customer Coupon Assignments - Redemption Count-Size of Control Group Reco.');
