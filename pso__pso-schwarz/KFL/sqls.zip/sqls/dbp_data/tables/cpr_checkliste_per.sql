create table if not exists `dbp_data.cpr_checkliste_per`
(
  cpr_checkliste_id string(32) collate 'und:ci' not null,
  dat_von date not null,
  dat_bis date not null,
  projekt_phase_id string(32) collate 'und:ci' not null,
  cpr_ext_id string(30) collate 'und:ci' not null,
  aenderbar_kz string(1) collate 'und:ci' not null,
  checklistenart_id string(20) collate 'und:ci' not null,
  sap_user string(20) collate 'und:ci' not null,
  nicht_relevant_fg INT64 not null,
  dat_aufloesung date,
  teil_massn_kz INT64 not null,
  cpr_systemstatus1_id INT64 not null,
  cpr_systemstatus2_id INT64 not null,
  cpr_systemstatus3_id INT64 not null,
  cpr_suchfeld_id INT64,
  zeitstempel datetime not null,
  td_update timestamp,
  td_insert timestamp
);
