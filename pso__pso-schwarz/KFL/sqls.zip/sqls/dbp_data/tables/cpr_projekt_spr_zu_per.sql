create table if not exists `dbp_data.cpr_projekt_spr_zu_per`
(
  projekt_id string(32) collate 'und:ci' not null options(description="Eindeutige ID des Projekts"),
  spr_id INT64 not null options(description="Referenz zu der Tabelle spr fuer jede DWH Sprache = 1."),
  dat_von date not null options(description="Datum, ab dem der Datensatz gültig ist"),
  dat_bis date not null options(description="Datum, bis zu dem der Datensatz gültig ist. Ist dieses Datum nicht bekannt, wird der 31.12.9999 eingestellt."),
  cpr_projekt_bez string(40) collate 'und:ci' not null options(description="Sprachabhängige Projektbeschreibung"),
  cpr_projekt_langtext string(320) collate 'und:ci' options(description="Sprachabhängiger Langtext zum Projekt"),
  td_update timestamp options(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  td_insert timestamp options(description="Technical fields for synchronisation framework. Will be delted after last product migration"),
  primary key (spr_id, dat_von) not enforced
)
options(
  description="IOS - Sprachabhängige  Projektbezeichnung"
);
