--==============================================================
-- Table: crm_kartebew
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: crm_kartebew
   generated from Powerdesigner on Mittwoch, 26. Februar 2025 13:53:17
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.crm_kartebew (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH.'),
wup_id INT64 NOT NULL
OPTIONS(description='Mutter Wup ID wird verwendet fur Beziehung Lager zu Verteilzentrum.'),
nb_id INT64 NOT NULL
OPTIONS(description='Im bisherigen System die 4 Stelle der Marktnummer die Nebenbetriebskennziffer.'),
kundenkarte_id STRING(255) NOT NULL
OPTIONS(description='Nummer der Kundenkarte / Bonuskarte (gehasht), kann gemappt werden mit ods_bon_kopf.kundenkarte_id.'),
dat DATE NOT NULL OPTIONS(description='Datum im Format JJJJ-MM-TT.'),
loyalty_berechtigt_fg INT64 NOT NULL
OPTIONS(description='Gibt an, ob CRM Promotion gewährt wurde. 1 = ja; 0 = nein. Ab 01.03.2025 wird das Flag aus ods_bon_kopf berechnet. (Logik für alte Daten folgt)'),
wrg_id STRING(3) NOT NULL OPTIONS(description='Kurzbezeichnung der Währung, z.Bsp. CZK, EUR.'),
umsatz_netto_sa NUMERIC(29,4) OPTIONS(description='SA Umsatz vermindert um den Mehrwertsteuerbetrag.'),
umsatz_netto_af NUMERIC(29,4) OPTIONS(description='AF Umsatz vermindert um den Mehrwertsteuerbetrag.'),
umsatz_brutto_sa NUMERIC(29,4) OPTIONS(description='SA Umsatz.'),
umsatz_brutto_af NUMERIC(29,4) OPTIONS(description='AF Umsatz.'),
anz_bons INT64 OPTIONS(description='Bons, die eine Kundenkarte generiert.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, wup_id, nb_id, kundenkarte_id, dat, loyalty_berechtigt_fg) NOT ENFORCED
)
PARTITION BY dat
OPTIONS(description='EK-KUN - MSDynamicsCRM - Aggregat auf Bondaten für CRM. Granularität Tag - Markt und loyalty_berechtigt_fg. Inhalt: Kundenkarte mit der Anzahl ihrer generierten Bons und ihres Umsatzes (brutto u. netto).');
