create table if not exists `dbp_data.crm_kartebew_prod`
(
  mandant_id int64,
  wup_id int64,
  nb_id int64,
  kundenkarte_id string,
  dat date,
  loyalty_berechtigt_fg int64,
  wrg_id string,
  umsatz_netto_sa numeric,
  umsatz_netto_af numeric,
  umsatz_brutto_sa numeric,
  umsatz_brutto_af numeric,
  anz_bons int64,
  td_update timestamp,
  td_insert timestamp
);
