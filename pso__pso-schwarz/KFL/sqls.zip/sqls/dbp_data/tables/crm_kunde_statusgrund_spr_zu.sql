CREATE TABLE IF NOT EXISTS dbp_data.crm_kunde_statusgrund_spr_zu (
kunde_statusgrund_id INT64 DEFAULT -9999 NOT NULL
OPTIONS(description='Statusgrund-ID des Kunden (liefert Information darüber, wieso der Kunde die entsprechende Status-ID hat)'),
spr_id INT64 NOT NULL OPTIONS(description='ID der Sprache'),
kunde_statusgrund_bez STRING(120) OPTIONS(description='Bezeichnung des Kundenstatusgrunds'),
td_insert TIMESTAMP,
td_update TIMESTAMP
)
OPTIONS(description='CRM - Sprachtabelle für das Attribut\"Statuscode\" (Entität\"Contact\", Kundenstatus) aus MS Dynamics CRM');
