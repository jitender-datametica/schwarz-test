CREATE TABLE IF NOT EXISTS dbp_data.crm_l_konto_typ (
crm_konto_typ_id INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
) OPTIONS(description='EK-INTEGER  - MSDynamicsCRM - Typ des Loyaltyaccounts');
