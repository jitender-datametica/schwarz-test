--==============================================================
-- Table: crm_l_kundenkarte_art
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: crm_l_kundenkarte_art
   generated from Powerdesigner on Tuesday, February 27, 2024 8:30:14 PM
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.crm_l_kundenkarte_art (
crm_kundenkarte_art_id INT64 NOT NULL
OPTIONS(description='Art der Kundenkarte (Ausprägungen: 1 für digital, 2 für physisch, default 1), nicht zu verwechseln mit ods_bon_kopf.kundenkarte_typ_id das kennzeichnet, ob der Bon mit Payback- (1) oder Kundenkarte (2) erzeugt wurde.'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (crm_kundenkarte_art_id) NOT ENFORCED
) OPTIONS(description='EK-KUN - MSDynamicsCRM - Lookup Art der Kundenkarte (Entitaet "arvato_loyaltycard")');
