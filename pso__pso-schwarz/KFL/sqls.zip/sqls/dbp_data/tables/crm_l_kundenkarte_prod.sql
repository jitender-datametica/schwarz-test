create table if not exists `dbp_data.crm_l_kundenkarte_prod`
(
  kundenkarte_id string,
  mandant_id int64,
  crm_kundenkarte_art_id int64,
  crm_kundenkarte_nr string,
  crm_konto_id string,
  gesperrt_fg int64,
  zeit_von datetime,
  zeit_bis datetime,
  geloescht_fg int64,
  td_insert timestamp,
  td_update timestamp
);
