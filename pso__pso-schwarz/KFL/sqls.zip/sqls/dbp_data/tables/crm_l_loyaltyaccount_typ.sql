CREATE TABLE IF NOT EXISTS dbp_data.crm_l_loyaltyaccount_typ (
crm_loyaltyaccount_typ_id INT64 NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
