CREATE TABLE IF NOT EXISTS dbp_data.crm_l_loyaltyaccount_typ_spr_zu (
crm_loyaltyaccount_typ_id INT64 NOT NULL,
spr_id INT64 NOT NULL,
crm_loyaltyaccount_typ_bez STRING(20) COLLATE 'und:ci',
td_insert TIMESTAMP,
td_update TIMESTAMP
);
