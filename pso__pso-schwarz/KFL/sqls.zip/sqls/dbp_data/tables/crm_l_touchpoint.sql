--==============================================================
-- Table: crm_l_touchpoint
--==============================================================
/* --------------------------------------------------------------------------------
   DDL for table: crm_l_touchpoint
   generated from Powerdesigner on Dienstag, 18. Oktober 2022 09:46:08
*/ --------------------------------------------------------------------------------


CREATE TABLE IF NOT EXISTS dbp_data.crm_l_touchpoint (
mandant_id INT64 NOT NULL OPTIONS(description='Mandant im DWH.'),
touchpoint_id INT64 NOT NULL
OPTIONS(description='Several count-fields that describe the amount of times that the ticket has been in each touchpoint (department, customer, store etc.).'),
td_update TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
td_insert TIMESTAMP
OPTIONS(description='Technical fields for synchronisation framework. Will be delted after last product migration'),
PRIMARY KEY (mandant_id, touchpoint_id) NOT ENFORCED
)
OPTIONS(description='Lookup for touchpoints (touchpoints are departments the ticket gets sent to during the solution process).');
