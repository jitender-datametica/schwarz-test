CREATE TABLE IF NOT EXISTS dbp_data.crm_ods_bon_kopf_kunde_tag_sum (
crm_kunde_id STRING(36) COLLATE 'und:ci' NOT NULL,
crm_loyaltyaccount_id STRING(36) COLLATE 'und:ci' NOT NULL,
kundenkarte_id STRING(255) COLLATE 'und:ci' NOT NULL,
crm_kundenkarte_art_id INT64 NOT NULL,
wup_id INT64 NOT NULL,
nb_id INT64 NOT NULL,
mandant_id INT64 NOT NULL,
dat DATE NOT NULL,
anz_bons INT64 NOT NULL,
ums_brutto NUMERIC(29,4) NOT NULL,
ums_netto NUMERIC(29,4) NOT NULL,
td_insert TIMESTAMP,
td_update TIMESTAMP
);
