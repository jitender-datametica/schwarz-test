CREATE OR REPLACE TABLE kfl_production_dbp_msi_view_shr_materialized.mv_abrechnungsmonat (
mandant_id INTEGER,
kjmo_abr INTEGER
);