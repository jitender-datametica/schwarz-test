CREATE OR REPLACE TABLE kfl_production_dbp_msi_view_shr_materialized.mv_mandant (
mandant_id INTEGER,
mandant_bez STRING(160) COLLATE 'und:ci',
mandant_kbez STRING(12) COLLATE 'und:ci',
mandant_sort_id INTEGER,
default_wrg STRING(12) COLLATE 'und:ci'
);