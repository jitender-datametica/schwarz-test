CREATE OR REPLACE TABLE kfl_production_dbp_msi_view_shr_materialized.mv_buchungskreis_spr_zu (
mandant_id INTEGER,
buchungskreis_id INTEGER,
system_id INTEGER,
buchungskreis_bez STRING(30) COLLATE 'und:ci'
);