CREATE OR REPLACE TABLE kfl_production_dbp_msi_view_shr_materialized.mv_jahr_kj (
kj INTEGER,
akt_kj INTEGER,
akt_kj_komplett INTEGER
);