CREATE OR REPLACE TABLE kfl_production_dbp_msi_view_shr_materialized.mv_l_unternmns_bereich (
mandant_id INTEGER,
unternehmens_bereich_id STRING(2) COLLATE 'und:ci'
);